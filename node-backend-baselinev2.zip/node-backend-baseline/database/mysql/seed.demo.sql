-- =====================================================================
-- DEMO DATA - DEVELOPMENT ONLY. NEVER load this file in production:
-- the passwords below are public (they are written in the README).
--
--   demo.admin@example.com   /  Admin@12345    (role: admin)
--   demo.member@example.com  /  Member@12345   (role: member)
--
-- Both accounts are "created by" the super admin (user_id = 1).
-- Requires seed.sql to have been loaded first. Idempotent.
-- =====================================================================

INSERT INTO users (user_id, full_name, email, is_active, created_by) VALUES
  (2, 'Demo Admin',  'demo.admin@example.com',  TRUE, 1),
  (3, 'Demo Member', 'demo.member@example.com', TRUE, 1)
ON DUPLICATE KEY UPDATE user_id = user_id;

INSERT INTO user_passwords (user_id, hash_password, must_change_password, created_by) VALUES
  (2, '$2b$12$9eYNyLaVRgdBqPKljk2mruEhMDjI3ifFOWRXkLTqbyc.2R1OJ9Y3C', FALSE, 1),
  (3, '$2b$12$jyZTDzbG03ee9DzXcs6SQeEVJNCqgzRVXoG9K.wN/JSENtYS8/6qm', FALSE, 1)
ON DUPLICATE KEY UPDATE user_id = user_id;

INSERT INTO user_roles (user_id, role_id, created_by)
SELECT 2, role_id, 1 FROM roles WHERE role_name = 'admin'
ON DUPLICATE KEY UPDATE user_id = user_id;

INSERT INTO user_roles (user_id, role_id, created_by)
SELECT 3, role_id, 1 FROM roles WHERE role_name = 'member'
ON DUPLICATE KEY UPDATE user_id = user_id;
