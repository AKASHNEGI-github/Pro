-- =====================================================================
-- node_backend_baseline : MySQL schema
-- Requires MySQL 8.0.16+ (expression defaults, enforced CHECK constraints).
-- MySQL 8.4 LTS is recommended.
--
-- Conventions
--   * All timestamps are DATETIME(6) and are stored in UTC.
--   * Soft delete only (is_deleted); rows are never physically removed
--     by the application (except expired tokens, by the cleanup job).
--   * created_by / updated_by reference users(user_id).
--       - user_id = 1 is the reserved SUPER ADMIN row (see README).
--       - created_by = NULL on a user row means "self-registered".
--
-- The database itself is created by `npm run db:schema` (or by the MySQL
-- Docker image); this file only defines the tables and never names the
-- database, so it can be loaded into any database:
--     mysql -u root -p <database_name> < database/mysql/schema.sql
-- =====================================================================

-- ---------------------------------------------------------------------
-- users
-- email_active / sso_id_active are NULL for soft-deleted rows, so the
-- UNIQUE indexes on them only apply among non-deleted users: a deleted
-- account keeps its email/sso_id on its own row (history intact) but
-- the value is immediately free for a new account to use.
-- ---------------------------------------------------------------------
CREATE TABLE users (
  user_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  sso_id VARCHAR(100),
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  last_login DATETIME(6) NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  created_by BIGINT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  email_active VARCHAR(150)
    GENERATED ALWAYS AS (IF(is_deleted = FALSE, email, NULL)) STORED,
  sso_id_active VARCHAR(100)
    GENERATED ALWAYS AS (IF(is_deleted = FALSE, sso_id, NULL)) STORED,
  CONSTRAINT uq_users_email_active UNIQUE (email_active),
  CONSTRAINT uq_users_sso_id_active UNIQUE (sso_id_active),
  CONSTRAINT fk_users_created_by FOREIGN KEY (created_by) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci;

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_active ON users(is_active);
CREATE INDEX idx_users_deleted ON users(is_deleted);

-- ---------------------------------------------------------------------
-- user_passwords (one row per user, overwritten in place on change)
-- updated_at doubles as "password last changed at": access tokens issued
-- before it are rejected (see README, "Access token invalidation").
-- The super admin has NO row here: its credentials live in ENV only.
-- ---------------------------------------------------------------------
CREATE TABLE user_passwords (
  user_password_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL UNIQUE,
  hash_password VARCHAR(255) NOT NULL,
  must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
  created_by BIGINT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  updated_by BIGINT NULL,
  updated_at DATETIME(6) NULL DEFAULT (UTC_TIMESTAMP(6)),
  CONSTRAINT fk_user_password_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_user_password_creator FOREIGN KEY (created_by) REFERENCES users(user_id),
  CONSTRAINT fk_user_password_updater FOREIGN KEY (updated_by) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci;

-- ---------------------------------------------------------------------
-- roles
-- Only the assignable roles live here (member, admin). "super_admin" is
-- intentionally NOT a row: it can never be assigned to anyone.
--   is_active  = FALSE  the role is switched off: its users have NO role and
--                       can do nothing until they get another one.
--   is_deleted = TRUE   the role is retired (soft delete), same effect.
-- ---------------------------------------------------------------------
CREATE TABLE roles (
  role_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  role_name VARCHAR(100) NOT NULL UNIQUE,
  role_level INT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  created_by BIGINT NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  updated_by BIGINT NULL,
  updated_at DATETIME(6) NULL DEFAULT (UTC_TIMESTAMP(6)),
  CONSTRAINT fk_roles_created_by FOREIGN KEY (created_by) REFERENCES users(user_id),
  CONSTRAINT fk_roles_updated_by FOREIGN KEY (updated_by) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci;

-- ---------------------------------------------------------------------
-- user_roles (one role per user)
-- A role change is always an UPDATE of the single row (user_id is UNIQUE).
-- There are NO is_active / is_deleted flags here: a role is switched off
-- on `roles` itself, and a deleted user is handled by users.is_deleted.
-- The super admin has NO row here.
-- ---------------------------------------------------------------------
CREATE TABLE user_roles (
  user_roles_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL UNIQUE,
  role_id BIGINT NOT NULL,
  assigned_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  created_by BIGINT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  updated_by BIGINT NULL,
  updated_at DATETIME(6) NULL DEFAULT (UTC_TIMESTAMP(6)),
  CONSTRAINT fk_user_roles_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_user_roles_role FOREIGN KEY (role_id) REFERENCES roles(role_id),
  CONSTRAINT fk_user_roles_created_by FOREIGN KEY (created_by) REFERENCES users(user_id),
  CONSTRAINT fk_user_roles_updated_by FOREIGN KEY (updated_by) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci;

CREATE INDEX idx_user_roles_role ON user_roles(role_id);

-- ---------------------------------------------------------------------
-- user_login_logs
-- ---------------------------------------------------------------------
CREATE TABLE user_login_logs (
  user_login_logs_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  login_time DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  login_status ENUM('SUCCESS','FAILURE') NOT NULL DEFAULT 'SUCCESS',
  failure_reason TEXT,
  ip_address VARCHAR(45),
  created_by BIGINT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  CONSTRAINT fk_login_logs_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_login_logs_created_by FOREIGN KEY (created_by) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci;

CREATE INDEX idx_login_logs_user ON user_login_logs(user_id);
CREATE INDEX idx_login_logs_login_time ON user_login_logs(login_time);

-- ---------------------------------------------------------------------
-- refresh_tokens (opaque, stored only as a SHA-256 hex digest)
-- Rotation: the used token gets revoked_at + replaced_by_hash, a new row
-- is inserted. Presenting an already-rotated token again = reuse
-- (theft signal) -> every active token of that user is revoked.
-- ---------------------------------------------------------------------
CREATE TABLE refresh_tokens (
  refresh_tokens_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL UNIQUE,
  expires_at DATETIME(6) NOT NULL,
  revoked_at DATETIME(6) NULL,
  replaced_by_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
  user_agent TEXT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  updated_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  CONSTRAINT fk_refresh_tokens_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci;

CREATE INDEX idx_refresh_tokens_user_id ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_expires_at ON refresh_tokens(expires_at);

-- ---------------------------------------------------------------------
-- user_security_profiles - answers used to recover a forgotten password
-- (no email involved). One row per user.
--
-- Questions 1-3 are fixed for everyone (date of birth + two questions
-- defined in the application), so only their bcrypt-hashed answers are
-- stored. Questions 4-5 are optional and written by the user, so their
-- text is stored too. Answers are normalised (trimmed, case-folded, DOB as
-- an ISO date) BEFORE hashing, and never stored or logged in plain text.
-- (The application additionally applies an HMAC "pepper" from ENV before
-- bcrypt, so a leaked database alone cannot be brute-forced offline.)
--
-- failed_attempts / locked_until implement the per-account lockout: after
-- 5 wrong verification attempts the account is locked for 15 minutes.
-- ---------------------------------------------------------------------
CREATE TABLE user_security_profiles (
  user_id BIGINT PRIMARY KEY,
  dob_hash VARCHAR(255) NOT NULL,
  answer_q2_hash VARCHAR(255) NOT NULL,
  answer_q3_hash VARCHAR(255) NOT NULL,
  custom_question_1 VARCHAR(200) NULL,
  custom_answer_1_hash VARCHAR(255) NULL,
  custom_question_2 VARCHAR(200) NULL,
  custom_answer_2_hash VARCHAR(255) NULL,
  failed_attempts INT NOT NULL DEFAULT 0,
  locked_until DATETIME(6) NULL,
  created_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  updated_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  CONSTRAINT fk_security_profiles_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  -- a custom question and its answer exist together, or not at all
  CONSTRAINT chk_custom_1_pair CHECK ((custom_question_1 IS NULL) = (custom_answer_1_hash IS NULL)),
  CONSTRAINT chk_custom_2_pair CHECK ((custom_question_2 IS NULL) = (custom_answer_2_hash IS NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci;

-- ---------------------------------------------------------------------
-- password_reset_tokens - issued only after every security answer was
-- correct. Short-lived (10 min), single-use, stored only as a SHA-256 hex
-- digest, exactly like refresh tokens.
-- ---------------------------------------------------------------------
CREATE TABLE password_reset_tokens (
  password_reset_tokens_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL UNIQUE,
  expires_at DATETIME(6) NOT NULL,
  used_at DATETIME(6) NULL,
  requested_ip VARCHAR(45) NULL,
  created_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  CONSTRAINT fk_password_reset_tokens_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci;

CREATE INDEX idx_password_reset_tokens_user ON password_reset_tokens(user_id);
CREATE INDEX idx_password_reset_tokens_expires ON password_reset_tokens(expires_at);
