import dotenv from 'dotenv';
import { runTasks } from './lib/dbTasks.js';

dotenv.config({ path: process.env.ENV_FILE || '.env', quiet: true });

const COMMANDS = {
  schema: { tasks: ['schema'], help: 'create the database (if missing) and all tables' },
  seed: { tasks: ['seed'], help: 'insert required data: super admin row + roles (idempotent)' },
  'seed-demo': { tasks: ['seed-demo'], help: 'insert DEMO users (development only!)' },
  setup: { tasks: ['schema', 'seed'], help: 'schema + seed  (production-safe)' },
  'setup-demo': {
    tasks: ['schema', 'seed', 'seed-demo'],
    help: 'schema + seed + demo users (development)',
  },
  reset: {
    tasks: ['drop', 'schema', 'seed', 'seed-demo'],
    help: 'DROP the database, then setup-demo (development only, refuses in production)',
    destructive: true,
  },
};

const name = process.argv[2];
const command = COMMANDS[name];

if (!command) {
  console.error('Usage: node scripts/db.js <command>\n');
  for (const [key, value] of Object.entries(COMMANDS)) {
    console.error(`  ${key.padEnd(11)} ${value.help}`);
  }
  process.exit(1);
}

const demoOrDestructive = command.destructive || command.tasks.includes('seed-demo');
if (demoOrDestructive && process.env.NODE_ENV === 'production') {
  console.error(`Refusing to run "${name}" with NODE_ENV=production.`);
  process.exit(1);
}

try {
  await runTasks(command.tasks, process.env, (step) => console.log(`-> ${step}`));
  console.log(`Done: ${name}`);
} catch (err) {
  if (err.code === 'ER_TABLE_EXISTS_ERROR') {
    console.error(
      `\n${err.sqlMessage}\nThe schema is already installed. For a clean development database run: npm run db:reset`,
    );
  } else {
    console.error(
      `\nDatabase task "${name}" failed: ${err.code ?? ''} ${err.sqlMessage ?? err.message}`,
    );
  }
  process.exit(1);
}
