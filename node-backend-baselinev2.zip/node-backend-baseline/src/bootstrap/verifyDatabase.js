import { config } from '../config/index.js';
import { ROLES } from '../constants/roles.js';
import { fetchAll, pingDatabase, pool } from '../database/index.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('bootstrap');

const REQUIRED_ROLES = [ROLES.ADMIN, ROLES.MEMBER];

/**
 * Fail fast at startup with an actionable message instead of failing on the first request:
 * the database must be reachable, the schema must exist and the seeded roles must be present.
 */
export async function verifyDatabase() {
  const { host, port, database, source } = config.db;

  try {
    await pingDatabase();
  } catch (err) {
    throw new Error(
      `Cannot connect to MySQL at ${host}:${port} (database "${database}"): ${err.code ?? err.message}`,
      { cause: err },
    );
  }
  log.info(
    { host, port, database, via: source === 'url' ? 'DB_URL' : 'local credentials' },
    'Connected to MySQL',
  );

  let roles;
  try {
    roles = await fetchAll(
      pool,
      `SELECT role_name FROM roles
        WHERE role_name IN (:admin, :member) AND is_active = TRUE AND is_deleted = FALSE`,
      { admin: ROLES.ADMIN, member: ROLES.MEMBER },
    );
  } catch (err) {
    if (err.cause?.code === 'ER_NO_SUCH_TABLE') {
      throw new Error('The database schema is missing. Run: npm run db:schema', { cause: err });
    }
    throw err;
  }

  const found = new Set(roles.map((row) => row.role_name));
  const missing = REQUIRED_ROLES.filter((role) => !found.has(role));
  if (missing.length > 0) {
    throw new Error(`Required roles are missing (${missing.join(', ')}). Run: npm run db:seed`);
  }
}
