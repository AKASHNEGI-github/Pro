import { config } from '../config/index.js';
import { SUPER_ADMIN_USER_ID } from '../constants/roles.js';
import { execute, fetchOne, isDuplicateEntry, withTransaction } from '../database/index.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('bootstrap');

/**
 * Invariant: the super admin has no password, role or security-profile row. Its credentials live
 * ONLY in ENV and "super_admin" is not an assignable role. If such rows exist, something wrote to
 * the reserved id by hand: refuse to start rather than run with an ambiguous account.
 */
async function assertNoStrayRows(conn) {
  const counts = await fetchOne(
    conn,
    `SELECT (SELECT COUNT(*) FROM user_passwords WHERE user_id = :id) AS passwords,
            (SELECT COUNT(*) FROM user_roles WHERE user_id = :id) AS roles,
            (SELECT COUNT(*) FROM user_security_profiles WHERE user_id = :id) AS profiles`,
    { id: SUPER_ADMIN_USER_ID },
  );
  if (counts.passwords + counts.roles + counts.profiles > 0) {
    throw new Error(
      `users.user_id = ${SUPER_ADMIN_USER_ID} is reserved for the super admin but has password/role/security-profile rows. ` +
        'Remove them (or move that user to another id) and restart.',
    );
  }
}

async function syncOnce() {
  const { name, email } = config.superAdmin;
  const id = SUPER_ADMIN_USER_ID;

  return withTransaction(async (conn) => {
    const existing = await fetchOne(
      conn,
      `SELECT full_name, email, is_active, is_deleted
         FROM users WHERE user_id = :id FOR UPDATE`,
      { id },
    );
    await assertNoStrayRows(conn);

    if (!existing) {
      await execute(
        conn,
        `INSERT INTO users (user_id, full_name, email, is_active, is_deleted, created_by)
         VALUES (:id, :name, :email, TRUE, FALSE, NULL)`,
        { id, name, email },
      );
      return 'created';
    }

    const inSync =
      existing.full_name === name &&
      existing.email === email &&
      Boolean(existing.is_active) &&
      !existing.is_deleted;
    if (inSync) return 'unchanged';

    await execute(
      conn,
      `UPDATE users SET full_name = :name, email = :email, is_active = TRUE, is_deleted = FALSE
        WHERE user_id = :id`,
      { id, name, email },
    );
    return 'updated';
  });
}

/**
 * Runs at every startup: makes the reserved row users.user_id = 1 match SUPER_ADMIN_NAME /
 * SUPER_ADMIN_EMAIL from ENV (creating it if the seed was not loaded). The password is never
 * stored: login compares against SUPER_ADMIN_PASSWORD_HASH.
 *
 * @returns {Promise<'created'|'updated'|'unchanged'>}
 */
export async function ensureSuperAdmin() {
  for (let attempt = 0; ; attempt += 1) {
    try {
      const result = await syncOnce();
      log.info({ userId: SUPER_ADMIN_USER_ID, result }, 'Super admin account is ready');
      return result;
    } catch (err) {
      // Two instances starting at the same moment can both try to INSERT row 1: retry once.
      if (isDuplicateEntry(err, 'PRIMARY') && attempt === 0) continue;
      if (isDuplicateEntry(err, 'uq_users_email_active')) {
        throw new Error(
          `SUPER_ADMIN_EMAIL "${config.superAdmin.email}" is already used by another active account. ` +
            'Change SUPER_ADMIN_EMAIL or delete/rename that account.',
          { cause: err },
        );
      }
      throw err;
    }
  }
}
