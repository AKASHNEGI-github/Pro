import bcrypt from 'bcrypt';
import { config } from '../config/index.js';

export function hashPassword(plain) {
  return bcrypt.hash(plain, config.password.bcryptRounds);
}

let dummyHash;

/**
 * True when `plain` matches the bcrypt `hash`.
 *
 * Pass `null` as the hash for an account that has no password (unknown e-mail, no password
 * row): it still spends the time of one real comparison and returns false, so the response
 * time never reveals whether an e-mail address is registered.
 */
export async function verifyPassword(plain, hash) {
  if (hash) return bcrypt.compare(plain, hash);

  dummyHash ??= bcrypt.hash('timing-equalisation-dummy', config.password.bcryptRounds);
  await bcrypt.compare(plain, await dummyHash);
  return false; // never a match, not even for the dummy's own password
}
