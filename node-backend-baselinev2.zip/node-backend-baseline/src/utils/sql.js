/** Escapes %, _ and \\ so user input is matched literally inside a LIKE pattern. */
export function escapeLike(value) {
  return String(value).replace(/[\\%_]/g, (char) => `\\${char}`);
}

/** "%term%" with the term escaped. Always pair with: LIKE :param ESCAPE '\\\\' */
export function containsPattern(value) {
  return `%${escapeLike(value)}%`;
}
