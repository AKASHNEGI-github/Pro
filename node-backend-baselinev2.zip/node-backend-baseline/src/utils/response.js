import { requestContext } from '../context/requestContext.js';

/**
 * Standard API response - exactly two JSON shapes. The HTTP status code is the source of
 * truth, so the body does not repeat it.
 *
 *   Success:  { success: true,  message, data, meta?, requestId }
 *   Failure:  { success: false, message, error: { code, details? }, requestId }
 */

/** Pure body builders (no `res`), exported so they can be unit-tested. */
export function buildSuccessBody({ message = 'Success', data = null, meta } = {}) {
  const body = { success: true, message, data };
  if (meta !== undefined) body.meta = meta;
  body.requestId = requestContext.getRequestId();
  return body;
}

export function buildFailureBody({ message, code, details }) {
  const error = { code };
  if (details !== undefined && details !== null) error.details = details;
  return { success: false, message, error, requestId: requestContext.getRequestId() };
}

/**
 * Handlers answer with these helpers (the Node twin of `ApiResponse.ok(data=..., message=...)`):
 *
 *   ApiResponse.ok(res, { message: 'Profile fetched', data: user });
 *   ApiResponse.created(res, { message: 'Account created', data: user });
 *
 * Failures are never sent from handlers: throw an AppError and the error handler calls `fail`.
 */
export const ApiResponse = Object.freeze({
  /** 200 */
  ok(res, options = {}) {
    return res.status(200).json(buildSuccessBody(options));
  },

  /** 201 */
  created(res, options = {}) {
    return res.status(201).json(buildSuccessBody(options));
  },

  /** Used by the global error handler only. Applies the error's status, headers and body. */
  fail(res, error) {
    for (const [name, value] of Object.entries(error.headers ?? {})) {
      if (!res.getHeader(name)) res.setHeader(name, value); // e.g. keep the limiter's own Retry-After
    }
    return res
      .status(error.statusCode)
      .json(buildFailureBody({ message: error.message, code: error.code, details: error.details }));
  },
});
