import { Router } from 'express';
import { validate } from '../../middlewares/validate.middleware.js';
import { ApiResponse } from '../../utils/response.js';
import { probeSchema } from './health.schema.js';
import * as healthService from './health.service.js';

/** Infrastructure probes (mounted at /health, outside the versioned API prefix). */
const router = Router();

const live = (_req, res) => {
  ApiResponse.ok(res, { message: 'Service is alive', data: healthService.getLiveness() });
};

router.get('/', validate(probeSchema), live);
router.get('/live', validate(probeSchema), live);

router.get('/ready', validate(probeSchema), async (_req, res) => {
  const data = await healthService.getReadiness();
  ApiResponse.ok(res, { message: 'Service is ready', data });
});

export default router;
