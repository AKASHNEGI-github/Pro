import { Router } from 'express';
import { ROLES } from '../../constants/roles.js';
import { authenticate } from '../../middlewares/authenticate.middleware.js';
import { authorize } from '../../middlewares/authorize.middleware.js';
import { validate } from '../../middlewares/validate.middleware.js';
import { ApiResponse } from '../../utils/response.js';
import { toUserResponse } from '../users/users.mapper.js';
import {
  changeRoleSchema,
  createUserSchema,
  listUsersSchema,
  setStatusSchema,
  updateUserSchema,
  userIdSchema,
} from './admin.schema.js';
import { AdminService } from './admin.service.js';

/**
 * User management for admins (and the super admin).
 * Route-level RBAC is declared once here; "may this admin touch THAT user?" is enforced by
 * admin.policy.js inside the service.
 */
const router = Router();
const adminService = new AdminService();

router.use(authenticate(), authorize(ROLES.ADMIN));

router.get('/users', validate(listUsersSchema), async (req, res) => {
  const { users, meta } = await adminService.listUsers(req.user, req.validated.query);
  ApiResponse.ok(res, {
    message: 'Users fetched successfully',
    data: users.map(toUserResponse),
    meta,
  });
});

router.post('/users', validate(createUserSchema), async (req, res) => {
  const { user, temporaryPassword } = await adminService.createUser(req.user, req.validated.body);
  ApiResponse.created(res, {
    message:
      'User created. Share the temporary password through a secure channel; it is shown only once and must be changed at first login',
    data: { user: toUserResponse(user), temporaryPassword },
  });
});

router.get('/users/:userId', validate(userIdSchema), async (req, res) => {
  const user = await adminService.getUser(req.user, req.validated.params.userId);
  ApiResponse.ok(res, { message: 'User fetched successfully', data: toUserResponse(user) });
});

router.patch('/users/:userId', validate(updateUserSchema), async (req, res) => {
  const user = await adminService.updateUser(
    req.user,
    req.validated.params.userId,
    req.validated.body,
  );
  ApiResponse.ok(res, { message: 'User updated successfully', data: toUserResponse(user) });
});

router.patch('/users/:userId/role', validate(changeRoleSchema), async (req, res) => {
  const user = await adminService.changeUserRole(
    req.user,
    req.validated.params.userId,
    req.validated.body.role,
  );
  ApiResponse.ok(res, { message: 'User role updated successfully', data: toUserResponse(user) });
});

router.patch('/users/:userId/status', validate(setStatusSchema), async (req, res) => {
  const user = await adminService.setUserActive(
    req.user,
    req.validated.params.userId,
    req.validated.body.isActive,
  );
  ApiResponse.ok(res, {
    message: user.isActive ? 'User activated successfully' : 'User deactivated successfully',
    data: toUserResponse(user),
  });
});

router.post('/users/:userId/reset-password', validate(userIdSchema), async (req, res) => {
  const { temporaryPassword } = await adminService.resetUserPassword(
    req.user,
    req.validated.params.userId,
  );
  ApiResponse.ok(res, {
    message:
      'Password reset. Share the temporary password through a secure channel; it is shown only once and must be changed at next login',
    data: { temporaryPassword },
  });
});

router.delete('/users/:userId', validate(userIdSchema), async (req, res) => {
  await adminService.deleteUser(req.user, req.validated.params.userId);
  ApiResponse.ok(res, { message: 'User deleted successfully' });
});

export default router;
