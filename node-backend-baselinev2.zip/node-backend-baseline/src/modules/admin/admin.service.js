import { ERROR_CODES } from '../../constants/errorCodes.js';
import { SUPER_ADMIN_USER_ID } from '../../constants/roles.js';
import {
  execute,
  fetchOne,
  fetchPage,
  isDuplicateEntry,
  pool,
  withTransaction,
} from '../../database/index.js';
import { ConflictError, NotFoundError } from '../../errors/index.js';
import { generateTemporaryPassword } from '../../utils/crypto.js';
import { createLogger } from '../../utils/logger.js';
import { buildPageMeta, toPagination } from '../../utils/pagination.js';
import { hashPassword } from '../../utils/password.js';
import { containsPattern } from '../../utils/sql.js';
import { TokenService } from '../auth/token.service.js';
import { RolesService } from '../roles/roles.service.js';
import { mapUserRow } from '../users/users.mapper.js';
import { assertActiveAccount, userNotFound } from '../users/users.rules.js';
import { UsersService } from '../users/users.service.js';
import { ADMIN_ACTIONS, assertCanAssignRole, assertCanManageUser } from './admin.policy.js';

const log = createLogger('admin');

const emailTaken = () =>
  new ConflictError('An account with this email already exists', {
    code: ERROR_CODES.EMAIL_ALREADY_EXISTS,
  });

const roleNotFound = () =>
  new NotFoundError('Role not found', { code: ERROR_CODES.ROLE_NOT_FOUND });

/** Only these columns can ever reach ORDER BY. */
const SORT_COLUMNS = Object.freeze({
  createdAt: 'u.created_at',
  fullName: 'u.full_name',
  email: 'u.email',
  lastLogin: 'u.last_login',
});

/** The backslash is doubled because it sits inside a MySQL string literal. */
const LIKE_ESCAPE = "ESCAPE '\\\\'";

/**
 * Locks the target row (SELECT ... FOR UPDATE) so concurrent admin actions on the same user are
 * serialised, then loads it: the policy check that follows always sees current data.
 * `conn` must be the connection of a transaction. Deleted users count as "not found".
 */
async function loadTargetForUpdate(conn, userId) {
  const locked = await fetchOne(
    conn,
    'SELECT user_id FROM users WHERE user_id = :userId AND is_deleted = FALSE FOR UPDATE',
    { userId },
  );
  if (!locked) throw userNotFound();

  return new UsersService(conn).findById(userId);
}

/**
 * User management for admins and the super admin. Every change follows the same recipe, in ONE
 * transaction: lock the target row -> check the policy (admin.policy.js) -> write.
 * The caller (`actor`) must hold an active role and an active account.
 */
export class AdminService {
  /** @param {object} [conn=pool]  the pool, or a connection from `withTransaction` */
  constructor(conn = pool) {
    this.conn = conn;
    this.users = new UsersService(conn);
    this.roles = new RolesService(conn);
  }

  /** @throws {NotFoundError} ROLE_NOT_FOUND when the role is missing, inactive or deleted */
  async #getAssignableRole(roleName) {
    const role = await this.roles.findAssignableByName(roleName);
    if (!role) throw roleNotFound();
    return role;
  }

  // ---------------------------------------------------------------------
  // Read
  // ---------------------------------------------------------------------

  /** Paginated, filterable, sortable user list. The super admin is only visible to itself. */
  async listUsers(actor, query) {
    assertActiveAccount(actor);
    const { page, limit, search, role, isActive, sortBy, sortOrder } = query;

    const conditions = ['u.is_deleted = FALSE'];
    const params = {};
    if (!actor.isSuperAdmin) {
      conditions.push('u.user_id <> :superAdminId');
      params.superAdminId = SUPER_ADMIN_USER_ID;
    }
    if (isActive !== undefined) {
      conditions.push('u.is_active = :isActive');
      params.isActive = isActive;
    }
    if (role) {
      conditions.push('r.role_name = :role');
      params.role = role;
    }
    if (search) {
      conditions.push(
        `(u.full_name LIKE :search ${LIKE_ESCAPE} OR u.email LIKE :search ${LIKE_ESCAPE})`,
      );
      params.search = containsPattern(search);
    }

    const fromWhere = `FROM users u
      LEFT JOIN user_roles ur ON ur.user_id = u.user_id
      LEFT JOIN roles r ON r.role_id = ur.role_id AND r.is_active = TRUE AND r.is_deleted = FALSE
     WHERE ${conditions.join(' AND ')}`;
    const direction = sortOrder === 'asc' ? 'ASC' : 'DESC';

    const { rows, total } = await fetchPage(
      this.conn,
      `SELECT u.user_id, u.full_name, u.email, u.is_active, u.last_login, u.created_at,
              r.role_name, r.role_level
         ${fromWhere}
        ORDER BY ${SORT_COLUMNS[sortBy]} ${direction}, u.user_id ASC`,
      `SELECT COUNT(*) AS total ${fromWhere}`,
      params,
      { skip: toPagination({ page, limit }).offset, limit },
    );

    return { users: rows.map(mapUserRow), meta: buildPageMeta({ page, limit, total }) };
  }

  async getUser(actor, userId) {
    assertActiveAccount(actor);

    const target = await this.users.findById(userId);
    if (!target) throw userNotFound();
    assertCanManageUser(actor, target, ADMIN_ACTIONS.VIEW);
    return target;
  }

  // ---------------------------------------------------------------------
  // Write
  // ---------------------------------------------------------------------

  /**
   * Creates a user with the chosen role. There is no e-mail service, so the system generates a
   * temporary password and returns it ONCE; the user must change it at first login.
   *
   * @returns {Promise<{ user: object, temporaryPassword: string }>}
   */
  async createUser(actor, { fullName, email, role: roleName }) {
    assertActiveAccount(actor);
    const role = await this.#getAssignableRole(roleName);
    assertCanAssignRole(actor, role.roleLevel);

    if (await this.users.emailExists(email)) throw emailTaken();

    const temporaryPassword = generateTemporaryPassword();
    const passwordHash = await hashPassword(temporaryPassword);

    try {
      const userId = await withTransaction((conn) =>
        new UsersService(conn).createAccount({
          fullName,
          email,
          passwordHash,
          mustChangePassword: true,
          roleName: role.roleName,
          createdBy: actor.userId,
        }),
      );
      log.info({ targetUserId: userId, role: role.roleName }, 'User created by admin');
      return { user: await this.users.findById(userId), temporaryPassword };
    } catch (err) {
      if (isDuplicateEntry(err, 'uq_users_email_active')) throw emailTaken(); // lost a race
      throw err;
    }
  }

  /** Profile = full name only. The e-mail is immutable (it is the login identifier). */
  async updateUser(actor, userId, { fullName }) {
    assertActiveAccount(actor);

    return withTransaction(async (conn) => {
      const target = await loadTargetForUpdate(conn, userId);
      assertCanManageUser(actor, target, ADMIN_ACTIONS.UPDATE_PROFILE);

      await execute(conn, 'UPDATE users SET full_name = :fullName WHERE user_id = :userId', {
        fullName,
        userId,
      });
      return new UsersService(conn).findById(userId);
    });
  }

  /** Activate / deactivate. A deactivated user can still sign in but cannot do anything. */
  async setUserActive(actor, userId, isActive) {
    assertActiveAccount(actor);

    return withTransaction(async (conn) => {
      const target = await loadTargetForUpdate(conn, userId);
      assertCanManageUser(actor, target, ADMIN_ACTIONS.SET_STATUS);

      await execute(conn, 'UPDATE users SET is_active = :isActive WHERE user_id = :userId', {
        isActive,
        userId,
      });
      log.info({ targetUserId: userId, isActive }, 'User activation changed');
      return new UsersService(conn).findById(userId);
    });
  }

  /**
   * Change a user's role (an UPDATE of the user's single user_roles row). It takes effect on
   * the user's very next request, because roles are re-read from the database on every request.
   */
  async changeUserRole(actor, userId, roleName) {
    assertActiveAccount(actor);
    const role = await this.#getAssignableRole(roleName);

    return withTransaction(async (conn) => {
      const target = await loadTargetForUpdate(conn, userId);
      assertCanManageUser(actor, target, ADMIN_ACTIONS.CHANGE_ROLE);
      assertCanAssignRole(actor, role.roleLevel);

      if (target.role !== role.roleName) {
        const params = { roleId: role.roleId, userId, actorId: actor.userId, now: new Date() };
        const { affectedRows } = await execute(
          conn,
          `UPDATE user_roles
              SET role_id = :roleId, assigned_at = :now, updated_by = :actorId, updated_at = :now
            WHERE user_id = :userId`,
          params,
        );
        if (affectedRows === 0) {
          // The user had no role row at all (e.g. created before roles existed): give them one.
          await execute(
            conn,
            `INSERT INTO user_roles
               (user_id, role_id, assigned_at, created_by, created_at, updated_by, updated_at)
             VALUES (:userId, :roleId, :now, :actorId, :now, :actorId, :now)`,
            params,
          );
        }
        log.info(
          { targetUserId: userId, from: target.role, to: role.roleName },
          'User role changed',
        );
      }
      return new UsersService(conn).findById(userId);
    });
  }

  /**
   * Admin password RESET: an admin never chooses or sees a real password. Generates a temporary
   * one, forces a change at next login, ends every session and clears any recovery lock.
   *
   * @returns {Promise<{ temporaryPassword: string }>}
   */
  async resetUserPassword(actor, userId) {
    assertActiveAccount(actor);

    const temporaryPassword = generateTemporaryPassword();
    const passwordHash = await hashPassword(temporaryPassword);

    await withTransaction(async (conn) => {
      const target = await loadTargetForUpdate(conn, userId);
      assertCanManageUser(actor, target, ADMIN_ACTIONS.RESET_PASSWORD);

      const params = { passwordHash, userId, actorId: actor.userId, now: new Date() };
      const { affectedRows } = await execute(
        conn,
        `UPDATE user_passwords
            SET hash_password = :passwordHash, must_change_password = TRUE,
                updated_by = :actorId, updated_at = :now
          WHERE user_id = :userId`,
        params,
      );
      if (affectedRows === 0) {
        await execute(
          conn,
          `INSERT INTO user_passwords
             (user_id, hash_password, must_change_password, created_by, created_at, updated_by, updated_at)
           VALUES (:userId, :passwordHash, TRUE, :actorId, :now, :actorId, :now)`,
          params,
        );
      }

      await new TokenService(conn).revokeAllRefreshTokens(userId);
      await execute(
        conn,
        `UPDATE user_security_profiles
            SET failed_attempts = 0, locked_until = NULL, updated_at = :now
          WHERE user_id = :userId`,
        params,
      );
      await execute(
        conn,
        'UPDATE password_reset_tokens SET used_at = :now WHERE user_id = :userId AND used_at IS NULL',
        params,
      );
    });

    log.info({ targetUserId: userId }, 'Password reset by admin');
    return { temporaryPassword };
  }

  /** Soft delete + end every session of the user. */
  async deleteUser(actor, userId) {
    assertActiveAccount(actor);

    await withTransaction(async (conn) => {
      const target = await loadTargetForUpdate(conn, userId);
      assertCanManageUser(actor, target, ADMIN_ACTIONS.DELETE);
      await new UsersService(conn).softDelete(userId);
    });
    log.info({ targetUserId: userId }, 'User deleted by admin');
  }
}
