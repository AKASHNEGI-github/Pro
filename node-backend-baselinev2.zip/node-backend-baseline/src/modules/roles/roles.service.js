import { fetchAll, fetchOne, pool } from '../../database/index.js';
import { assertActiveAccount } from '../users/users.rules.js';

/** Roles stored in the `roles` table. Only an active, non-deleted role can be used or assigned. */
export class RolesService {
  /** @param {object} [conn=pool]  the pool, or a connection from `withTransaction` */
  constructor(conn = pool) {
    this.conn = conn;
  }

  /**
   * The role called `roleName`, or `null` when it does not exist, is inactive
   * (roles.is_active = FALSE) or deleted (roles.is_deleted = TRUE).
   * @returns {Promise<{ roleId: number, roleName: string, roleLevel: number|null }|null>}
   */
  async findAssignableByName(roleName) {
    const row = await fetchOne(
      this.conn,
      `SELECT role_id, role_name, role_level
         FROM roles
        WHERE role_name = :roleName AND is_active = TRUE AND is_deleted = FALSE`,
      { roleName },
    );
    if (!row) return null;
    return { roleId: row.role_id, roleName: row.role_name, roleLevel: row.role_level };
  }

  /**
   * Every assignable role, each flagged with whether THIS caller may assign it
   * (role_level <= the caller's own level; the super admin may assign every role).
   */
  async listRoles(actor, { assignable } = {}) {
    assertActiveAccount(actor);

    const rows = await fetchAll(
      this.conn,
      `SELECT role_id, role_name, role_level, description
         FROM roles
        WHERE is_active = TRUE AND is_deleted = FALSE
        ORDER BY role_level ASC, role_name ASC`,
    );
    const roles = rows.map((row) => ({
      roleId: row.role_id,
      roleName: row.role_name,
      roleLevel: row.role_level,
      description: row.description,
      assignable: actor.isSuperAdmin || (row.role_level ?? 0) <= actor.roleLevel,
    }));
    return assignable === undefined
      ? roles
      : roles.filter((role) => role.assignable === assignable);
  }
}
