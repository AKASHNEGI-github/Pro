import { Router } from 'express';
import { ROLES } from '../../constants/roles.js';
import { authenticate } from '../../middlewares/authenticate.middleware.js';
import { authorize } from '../../middlewares/authorize.middleware.js';
import { validate } from '../../middlewares/validate.middleware.js';
import { ApiResponse } from '../../utils/response.js';
import { listRolesSchema } from './roles.schema.js';
import { RolesService } from './roles.service.js';

const router = Router();
const rolesService = new RolesService();

/** Read-only list of assignable roles (for admin UIs: role dropdowns). */
router.get(
  '/',
  authenticate(),
  authorize(ROLES.ADMIN),
  validate(listRolesSchema),
  async (req, res) => {
    const roles = await rolesService.listRoles(req.user, req.validated.query);
    ApiResponse.ok(res, { message: 'Roles fetched successfully', data: roles });
  },
);

export default router;
