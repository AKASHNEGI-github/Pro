import { Router } from 'express';
import { authenticate } from '../../middlewares/authenticate.middleware.js';
import { denySuperAdmin } from '../../middlewares/authorize.middleware.js';
import { authLimiter } from '../../middlewares/rateLimiter.middleware.js';
import { validate } from '../../middlewares/validate.middleware.js';
import { ApiResponse } from '../../utils/response.js';
import { clearRefreshCookie } from '../auth/auth.cookies.js';
import { toSelfResponse } from './users.mapper.js';
import { deleteAccountSchema, updateProfileSchema } from './users.schema.js';
import { UsersService } from './users.service.js';

/** Self-service: every route acts on the CALLER's own account (/users/me). */
const router = Router();
const usersService = new UsersService();

// Allowed for inactive users and for users who still have to change their password.
router.get(
  '/me',
  authenticate({ allowInactive: true, allowPasswordChangePending: true }),
  (req, res) => {
    ApiResponse.ok(res, {
      message: 'Profile fetched successfully',
      data: toSelfResponse(req.user),
    });
  },
);

router.patch(
  '/me',
  authenticate(),
  denySuperAdmin,
  validate(updateProfileSchema),
  async (req, res) => {
    const user = await usersService.updateOwnProfile(req.user, req.validated.body);
    ApiResponse.ok(res, { message: 'Profile updated successfully', data: toSelfResponse(user) });
  },
);

// DELETE carries a JSON body ({ password }) on purpose: deleting needs re-authentication.
router.delete(
  '/me',
  authLimiter,
  authenticate(),
  denySuperAdmin,
  validate(deleteAccountSchema),
  async (req, res) => {
    await usersService.deleteOwnAccount(req.user, req.validated.body);
    clearRefreshCookie(res);
    ApiResponse.ok(res, { message: 'Account deleted successfully' });
  },
);

export default router;
