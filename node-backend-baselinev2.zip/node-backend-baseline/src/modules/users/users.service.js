import { ERROR_CODES } from '../../constants/errorCodes.js';
import { execute, fetchOne, pool, withTransaction } from '../../database/index.js';
import { BadRequestError, InternalServerError } from '../../errors/index.js';
import { createLogger } from '../../utils/logger.js';
import { verifyPassword } from '../../utils/password.js';
import { TokenService } from '../auth/token.service.js';
import { RolesService } from '../roles/roles.service.js';
import { mapUserRow } from './users.mapper.js';
import { assertActiveAccount, assertNotSuperAdmin, userNotFound } from './users.rules.js';

const log = createLogger('users');

/**
 * A NON-DELETED user with everything needed to authorize and display them: role, password state
 * and whether a recovery profile exists. Append `AND <condition>` to pick the user.
 *
 * The role is only joined while it is active and not deleted (roles.is_active / is_deleted), so
 * `role_name` is NULL for a user without a usable role. user_roles has one row per user and no
 * flags of its own.
 */
const SELECT_USER = `
  SELECT u.user_id, u.full_name, u.email, u.is_active, u.last_login, u.created_at,
         r.role_name, r.role_level,
         up.must_change_password, up.updated_at AS password_changed_at,
         usp.user_id AS security_profile_user_id
    FROM users u
    LEFT JOIN user_roles ur ON ur.user_id = u.user_id
    LEFT JOIN roles r ON r.role_id = ur.role_id AND r.is_active = TRUE AND r.is_deleted = FALSE
    LEFT JOIN user_passwords up ON up.user_id = u.user_id
    LEFT JOIN user_security_profiles usp ON usp.user_id = u.user_id
   WHERE u.is_deleted = FALSE`;

/**
 * Users: lookups, account creation / deletion and the self-service (/users/me) actions.
 * The account-state rules (deleted, inactive, no role) are in ./users.rules.js.
 *
 * Like every service it is bound to ONE connection (`this.conn`): the pool by default, or the
 * connection of a transaction: `withTransaction((conn) => new UsersService(conn)...)`.
 */
export class UsersService {
  /** @param {object} [conn=pool]  the pool, or a connection from `withTransaction` */
  constructor(conn = pool) {
    this.conn = conn;
  }

  // ---------------------------------------------------------------------
  // Lookups (deleted users are never found)
  // ---------------------------------------------------------------------

  /** @returns {Promise<object|null>} the internal user model, or null */
  async findById(userId) {
    const row = await fetchOne(this.conn, `${SELECT_USER} AND u.user_id = :userId`, { userId });
    return mapUserRow(row);
  }

  /** @returns {Promise<object|null>} the internal user model, or null */
  async findByEmail(email) {
    const row = await fetchOne(this.conn, `${SELECT_USER} AND u.email = :email`, { email });
    return mapUserRow(row);
  }

  /** True when a non-deleted account already uses this (normalised) e-mail address. */
  async emailExists(email) {
    const row = await fetchOne(
      this.conn,
      'SELECT user_id FROM users WHERE email = :email AND is_deleted = FALSE',
      { email },
    );
    return row !== null;
  }

  /** @throws {BadRequestError} INVALID_CURRENT_PASSWORD unless `plainPassword` is the user's password */
  async assertCurrentPassword(userId, plainPassword) {
    const row = await fetchOne(
      this.conn,
      'SELECT hash_password FROM user_passwords WHERE user_id = :userId',
      { userId },
    );
    if (!(await verifyPassword(plainPassword, row?.hash_password ?? null))) {
      throw new BadRequestError('The current password is incorrect', {
        code: ERROR_CODES.INVALID_CURRENT_PASSWORD,
      });
    }
  }

  // ---------------------------------------------------------------------
  // Create / delete
  // ---------------------------------------------------------------------

  /**
   * Creates the user, password and role rows. MUST run inside a transaction (build the service
   * on the connection of `withTransaction`) so a failure in any table leaves nothing behind.
   * Used by sign-up and by admin "create user".
   *
   * @param {object} input
   * @param {string} input.fullName
   * @param {string} input.email           normalised (trimmed, lower-case)
   * @param {string} input.passwordHash    bcrypt hash (hash BEFORE opening the transaction)
   * @param {boolean} [input.mustChangePassword=false]
   * @param {string} input.roleName        'member' | 'admin'
   * @param {number|null} [input.createdBy=null]  null = self-registered
   * @returns {Promise<number>} the new user_id
   */
  async createAccount({
    fullName,
    email,
    passwordHash,
    mustChangePassword = false,
    roleName,
    createdBy = null,
  }) {
    const role = await new RolesService(this.conn).findAssignableByName(roleName);
    if (!role) {
      throw new InternalServerError(`Role "${roleName}" is not configured`, {
        code: ERROR_CODES.ROLE_NOT_FOUND,
      });
    }

    const now = new Date();

    const { insertId: userId } = await execute(
      this.conn,
      `INSERT INTO users (full_name, email, is_active, created_by, created_at)
       VALUES (:fullName, :email, TRUE, :createdBy, :now)`,
      { fullName, email, createdBy, now },
    );
    await execute(
      this.conn,
      `INSERT INTO user_passwords
         (user_id, hash_password, must_change_password, created_by, created_at, updated_at)
       VALUES (:userId, :passwordHash, :mustChangePassword, :createdBy, :now, :now)`,
      { userId, passwordHash, mustChangePassword, createdBy, now },
    );
    await execute(
      this.conn,
      `INSERT INTO user_roles (user_id, role_id, assigned_at, created_by, created_at, updated_at)
       VALUES (:userId, :roleId, :now, :createdBy, :now, :now)`,
      { userId, roleId: role.roleId, createdBy, now },
    );
    return userId;
  }

  /**
   * Soft delete (users.is_deleted = TRUE) and end every session. Runs inside the caller's
   * transaction. The row stays for history, and because the unique e-mail index ignores deleted
   * rows, the address is immediately free for a new account.
   *
   * @throws {NotFoundError} USER_NOT_FOUND when the user does not exist or is already deleted
   */
  async softDelete(userId) {
    const { affectedRows } = await execute(
      this.conn,
      'UPDATE users SET is_deleted = TRUE WHERE user_id = :userId AND is_deleted = FALSE',
      { userId },
    );
    if (affectedRows === 0) throw userNotFound();

    await new TokenService(this.conn).revokeAllRefreshTokens(userId);
  }

  // ---------------------------------------------------------------------
  // Self-service (/users/me)
  // ---------------------------------------------------------------------

  /** Update own profile. Only the full name is editable: the e-mail is the login identifier. */
  async updateOwnProfile(actor, { fullName }) {
    assertNotSuperAdmin(actor);
    assertActiveAccount(actor);

    await execute(
      this.conn,
      'UPDATE users SET full_name = :fullName WHERE user_id = :userId AND is_deleted = FALSE',
      { fullName, userId: actor.userId },
    );
    return this.findById(actor.userId);
  }

  /** Delete own account (soft delete). Needs the current password. */
  async deleteOwnAccount(actor, { password }) {
    assertNotSuperAdmin(actor);
    assertActiveAccount(actor);
    await this.assertCurrentPassword(actor.userId, password);

    await withTransaction((conn) => new UsersService(conn).softDelete(actor.userId));
    log.info({ userId: actor.userId }, 'Account deleted by its owner');
  }
}
