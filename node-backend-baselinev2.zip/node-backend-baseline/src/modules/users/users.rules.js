import { ERROR_CODES } from '../../constants/errorCodes.js';
import { ForbiddenError, NotFoundError } from '../../errors/index.js';

/**
 * Account-state rules: what each state of a user means, written down ONCE.
 * Pure functions (no I/O). They are used by `authenticate()` on every request, by login and
 * token refresh, and at the top of every service method that acts on behalf of a user.
 *
 *   deleted   users.is_deleted = TRUE
 *             The account does not exist for the API. Every query filters it out with
 *             `is_deleted = FALSE`; the person has to sign up again.
 *
 *   inactive  users.is_active = FALSE
 *             May sign in, read /users/me and sign out. Nothing else        -> assertIsActive
 *
 *   no role   the user's role is missing, inactive (roles.is_active = FALSE) or deleted
 *             (roles.is_deleted = TRUE). The role is what grants permissions, so there is
 *             nothing the user may do and signing in is refused              -> assertHasRole
 *             (The super admin is exempt: its role is virtual and never stored.)
 */

export const userNotFound = () =>
  new NotFoundError('User not found', { code: ERROR_CODES.USER_NOT_FOUND });

/** @throws {ForbiddenError} ROLE_NOT_ASSIGNED */
export function assertHasRole(user) {
  if (!user.isSuperAdmin && !user.role) {
    throw new ForbiddenError('No active role is assigned to this account', {
      code: ERROR_CODES.ROLE_NOT_ASSIGNED,
    });
  }
}

/** @throws {ForbiddenError} ACCOUNT_INACTIVE */
export function assertIsActive(user) {
  if (!user.isActive) {
    throw new ForbiddenError('Your account is inactive. Please contact an administrator.', {
      code: ERROR_CODES.ACCOUNT_INACTIVE,
    });
  }
}

/** The user may use the API like a regular user: an active role AND an active account. */
export function assertActiveAccount(user) {
  assertHasRole(user);
  assertIsActive(user);
}

/** @throws {ForbiddenError} PASSWORD_CHANGE_REQUIRED */
export function assertPasswordChangeNotPending(user) {
  if (user.mustChangePassword) {
    throw new ForbiddenError('You must change your password before continuing', {
      code: ERROR_CODES.PASSWORD_CHANGE_REQUIRED,
    });
  }
}

/**
 * For self-service actions that do not apply to the super admin (change password, update
 * profile, delete account...): its identity and credentials are owned by ENV, never by the API.
 * @throws {ForbiddenError} SUPER_ADMIN_PROTECTED
 */
export function assertNotSuperAdmin(user) {
  if (user.isSuperAdmin) {
    throw new ForbiddenError(
      'The super admin account is managed through environment configuration, not the API',
      { code: ERROR_CODES.SUPER_ADMIN_PROTECTED },
    );
  }
}
