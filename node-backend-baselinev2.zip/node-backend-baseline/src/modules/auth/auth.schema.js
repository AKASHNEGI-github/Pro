import { MAX_CUSTOM_QUESTIONS } from '../../constants/securityQuestions.js';
import {
  emailSchema,
  existingPasswordSchema,
  fullNameSchema,
  passwordSchema,
  z,
} from '../../utils/validation.js';

/** Request schemas of the auth module. Shape: { body?, query?, params? } for `validate()`. */

// ---------------------------------------------------------------------
// Security profile (password recovery questions)
// ---------------------------------------------------------------------
function isValidPastDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) return false;
  return date.getUTCFullYear() >= 1900 && date.getTime() <= Date.now();
}

const dobSchema = z
  .string()
  .trim()
  .refine(isValidPastDate, 'Date of birth must be a valid past date in YYYY-MM-DD format');

const securityAnswerSchema = z
  .string()
  .trim()
  .min(2, 'Answer must be at least 2 characters')
  .max(100, 'Answer must be at most 100 characters');

const customQuestionSchema = z
  .string()
  .trim()
  .min(10, 'Question must be at least 10 characters')
  .max(200, 'Question must be at most 200 characters');

/** The recovery profile as submitted at sign-up and by PUT /auth/security-profile. */
const securityProfileInputSchema = z.strictObject({
  dob: dobSchema,
  q2: securityAnswerSchema,
  q3: securityAnswerSchema,
  customQuestions: z
    .array(z.strictObject({ question: customQuestionSchema, answer: securityAnswerSchema }))
    .max(MAX_CUSTOM_QUESTIONS, `At most ${MAX_CUSTOM_QUESTIONS} custom questions are allowed`)
    .default([]),
});

// ---------------------------------------------------------------------
// Requests
// ---------------------------------------------------------------------
export const registerSchema = {
  body: z.strictObject({
    fullName: fullNameSchema,
    email: emailSchema,
    password: passwordSchema,
    securityProfile: securityProfileInputSchema,
  }),
};

export const loginSchema = {
  body: z.strictObject({
    email: emailSchema,
    password: existingPasswordSchema,
  }),
};

export const changePasswordSchema = {
  body: z
    .strictObject({
      currentPassword: existingPasswordSchema,
      newPassword: passwordSchema,
    })
    .refine((data) => data.currentPassword !== data.newPassword, {
      message: 'New password must be different from the current password',
      path: ['newPassword'],
    }),
};

export const saveSecurityProfileSchema = {
  body: securityProfileInputSchema.extend({ currentPassword: existingPasswordSchema }),
};

export const recoveryQuestionsSchema = {
  body: z.strictObject({ email: emailSchema }),
};

export const recoveryVerifySchema = {
  body: z.strictObject({
    email: emailSchema,
    answers: z.strictObject({
      dob: dobSchema,
      q2: securityAnswerSchema,
      q3: securityAnswerSchema,
      custom1: securityAnswerSchema.optional(),
      custom2: securityAnswerSchema.optional(),
    }),
  }),
};

export const recoveryResetSchema = {
  body: z.strictObject({
    resetToken: z.string().min(20).max(256),
    newPassword: passwordSchema,
  }),
};
