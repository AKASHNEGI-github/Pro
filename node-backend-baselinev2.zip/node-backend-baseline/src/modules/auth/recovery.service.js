import { config } from '../../config/index.js';
import { ERROR_CODES } from '../../constants/errorCodes.js';
import {
  FIXED_SECURITY_QUESTIONS,
  SECURITY_QUESTION_KEYS,
} from '../../constants/securityQuestions.js';
import { requestContext } from '../../context/requestContext.js';
import { execute, fetchOne, pool, withTransaction } from '../../database/index.js';
import { BadRequestError, TooManyRequestsError, UnauthorizedError } from '../../errors/index.js';
import { generateOpaqueToken, sha256Hex } from '../../utils/crypto.js';
import { createLogger } from '../../utils/logger.js';
import { hashPassword, verifyPassword } from '../../utils/password.js';
import { UsersService } from '../users/users.service.js';
import { verifyAnswer } from './securityAnswers.js';
import { customQuestionsFromRow } from './securityProfile.service.js';
import { TokenService } from './token.service.js';

const log = createLogger('auth.recovery');

const invalidAnswers = () =>
  new UnauthorizedError('The security answers are incorrect', {
    code: ERROR_CODES.INVALID_SECURITY_ANSWERS,
  });

const lockedError = (retryAfterSeconds) =>
  new TooManyRequestsError(
    'Too many incorrect attempts. Password recovery is temporarily locked for this account',
    { code: ERROR_CODES.ACCOUNT_LOCKED, headers: { 'Retry-After': String(retryAfterSeconds) } },
  );

/** True only if EVERY question the user has was answered correctly. */
async function allAnswersCorrect(profile, answers) {
  const checks = [
    verifyAnswer(SECURITY_QUESTION_KEYS.DOB, answers.dob, profile.dob_hash),
    verifyAnswer(SECURITY_QUESTION_KEYS.Q2, answers.q2, profile.answer_q2_hash),
    verifyAnswer(SECURITY_QUESTION_KEYS.Q3, answers.q3, profile.answer_q3_hash),
  ];
  const custom = [
    [
      profile.custom_question_1,
      SECURITY_QUESTION_KEYS.CUSTOM_1,
      answers.custom1,
      profile.custom_answer_1_hash,
    ],
    [
      profile.custom_question_2,
      SECURITY_QUESTION_KEYS.CUSTOM_2,
      answers.custom2,
      profile.custom_answer_2_hash,
    ],
  ];
  for (const [question, key, answer, hash] of custom) {
    if (question) checks.push(answer ? verifyAnswer(key, answer, hash) : false);
  }
  return (await Promise.all(checks)).every(Boolean);
}

/**
 * Forgot password, without e-mail:
 *   1. getRecoveryQuestions -> the questions the user has to answer
 *   2. verifyAnswers        -> every answer correct => a 10-minute, single-use reset token
 *   3. resetPassword        -> token + new password
 * The questions and the stored answers are managed by SecurityProfileService.
 */
export class RecoveryService {
  /** @param {object} [conn=pool]  the pool, or a connection from `withTransaction` */
  constructor(conn = pool) {
    this.conn = conn;
    this.users = new UsersService(conn);
  }

  /**
   * The account a password can be recovered for. It must exist and not be deleted (deleted
   * users are never found), be ACTIVE (an inactive user can do nothing, recovery included) and
   * not be the ENV-owned super admin. For anything else the caller just sees "no such account".
   */
  async #findRecoverableUser(email) {
    const user = await this.users.findByEmail(email);
    return user && user.isActive && !user.isSuperAdmin ? user : null;
  }

  /**
   * Step 1. To avoid revealing which e-mails are registered, unknown accounts (and accounts
   * without a profile) receive the three fixed questions, exactly like a real account that
   * has no custom questions.
   */
  async getRecoveryQuestions(email) {
    const user = await this.#findRecoverableUser(email);
    const profile = user
      ? await fetchOne(
          this.conn,
          `SELECT custom_question_1, custom_question_2
             FROM user_security_profiles WHERE user_id = :userId`,
          { userId: user.userId },
        )
      : null;

    return {
      questions: [...FIXED_SECURITY_QUESTIONS, ...(profile ? customQuestionsFromRow(profile) : [])],
    };
  }

  /**
   * Step 2. The profile row is locked (FOR UPDATE) while the answers are checked, so parallel
   * guesses are serialised and cannot slip past the failed-attempt counter. After
   * SECURITY_MAX_FAILED_ATTEMPTS wrong tries the account is locked for SECURITY_LOCK_MINUTES.
   *
   * Failures are recorded (committed) first and only then turned into an exception.
   */
  async verifyAnswers({ email, answers }) {
    const { ip } = requestContext.getMeta();

    const user = await this.#findRecoverableUser(email);
    if (!user) {
      await verifyPassword('timing-equalisation', null); // costs as much as a real check
      throw invalidAnswers();
    }

    const outcome = await withTransaction((conn) =>
      new RecoveryService(conn).#checkAnswers(user.userId, answers, ip),
    );

    switch (outcome.status) {
      case 'verified':
        return {
          resetToken: outcome.resetToken,
          expiresAt: outcome.expiresAt,
          expiresInSeconds: Math.round(config.recovery.resetTokenTtlMs / 1000),
        };
      case 'locked':
        if (outcome.justLocked) {
          log.warn({ userId: user.userId }, 'Password recovery locked after too many failures');
        }
        throw lockedError(outcome.retryAfterSeconds);
      case 'no_profile':
        await verifyPassword('timing-equalisation', null);
        throw invalidAnswers();
      default:
        throw invalidAnswers();
    }
  }

  /** Transactional half of `verifyAnswers`. Returns a status; never throws for an outcome. */
  async #checkAnswers(userId, answers, ip) {
    const profile = await fetchOne(
      this.conn,
      `SELECT dob_hash, answer_q2_hash, answer_q3_hash,
              custom_question_1, custom_answer_1_hash, custom_question_2, custom_answer_2_hash,
              failed_attempts, locked_until
         FROM user_security_profiles
        WHERE user_id = :userId
          FOR UPDATE`,
      { userId },
    );
    if (!profile) return { status: 'no_profile' };

    const now = new Date();
    if (profile.locked_until && profile.locked_until.getTime() > now.getTime()) {
      return {
        status: 'locked',
        retryAfterSeconds: Math.ceil((profile.locked_until.getTime() - now.getTime()) / 1000),
      };
    }

    if (await allAnswersCorrect(profile, answers)) return this.#issueResetToken(userId, ip, now);
    return this.#registerFailedAttempt(userId, profile.failed_attempts, now);
  }

  async #issueResetToken(userId, ip, now) {
    await execute(
      this.conn,
      `UPDATE user_security_profiles
          SET failed_attempts = 0, locked_until = NULL, updated_at = :now WHERE user_id = :userId`,
      { now, userId },
    );
    // only ONE reset token may be alive at a time
    await execute(
      this.conn,
      'UPDATE password_reset_tokens SET used_at = :now WHERE user_id = :userId AND used_at IS NULL',
      { now, userId },
    );
    const resetToken = generateOpaqueToken();
    const expiresAt = new Date(now.getTime() + config.recovery.resetTokenTtlMs);
    await execute(
      this.conn,
      `INSERT INTO password_reset_tokens (user_id, token_hash, expires_at, requested_ip, created_at)
       VALUES (:userId, :tokenHash, :expiresAt, :ip, :now)`,
      { userId, tokenHash: sha256Hex(resetToken), expiresAt, ip, now },
    );
    return { status: 'verified', resetToken, expiresAt };
  }

  async #registerFailedAttempt(userId, failedAttempts, now) {
    const attempts = failedAttempts + 1;

    if (attempts >= config.recovery.maxFailedAttempts) {
      await execute(
        this.conn,
        `UPDATE user_security_profiles
            SET failed_attempts = 0, locked_until = :lockedUntil, updated_at = :now
          WHERE user_id = :userId`,
        { lockedUntil: new Date(now.getTime() + config.recovery.lockMs), now, userId },
      );
      return {
        status: 'locked',
        retryAfterSeconds: Math.ceil(config.recovery.lockMs / 1000),
        justLocked: true,
      };
    }

    await execute(
      this.conn,
      'UPDATE user_security_profiles SET failed_attempts = :attempts, updated_at = :now WHERE user_id = :userId',
      { attempts, now, userId },
    );
    return { status: 'wrong' };
  }

  /**
   * Step 3. Consumes the single-use token, sets the new password, revokes every session and
   * every access token issued before now (user_passwords.updated_at moves forward).
   */
  async resetPassword({ resetToken, newPassword }) {
    const newHash = await hashPassword(newPassword);
    const tokenHash = sha256Hex(resetToken);

    const outcome = await withTransaction(async (conn) => {
      const row = await fetchOne(
        conn,
        `SELECT prt.password_reset_tokens_id, prt.user_id, prt.expires_at, prt.used_at
           FROM password_reset_tokens prt
           JOIN users u ON u.user_id = prt.user_id AND u.is_deleted = FALSE AND u.is_active = TRUE
          WHERE prt.token_hash = :tokenHash
            FOR UPDATE`,
        { tokenHash },
      );
      const now = new Date();
      if (!row || row.used_at || row.expires_at.getTime() <= now.getTime()) {
        return { status: 'invalid' };
      }

      await execute(
        conn,
        'UPDATE password_reset_tokens SET used_at = :now WHERE password_reset_tokens_id = :id',
        { now, id: row.password_reset_tokens_id },
      );
      const { affectedRows } = await execute(
        conn,
        `UPDATE user_passwords
            SET hash_password = :newHash, must_change_password = FALSE,
                updated_by = :userId, updated_at = :now
          WHERE user_id = :userId`,
        { newHash, userId: row.user_id, now },
      );
      if (affectedRows === 0) return { status: 'invalid' };

      await new TokenService(conn).revokeAllRefreshTokens(row.user_id);
      return { status: 'ok', userId: row.user_id };
    });

    if (outcome.status !== 'ok') {
      throw new BadRequestError('The reset token is invalid or has expired', {
        code: ERROR_CODES.RESET_TOKEN_INVALID,
      });
    }
    log.info({ userId: outcome.userId }, 'Password reset through security questions');
  }
}
