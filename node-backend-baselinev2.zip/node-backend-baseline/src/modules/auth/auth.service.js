import { config } from '../../config/index.js';
import { ERROR_CODES } from '../../constants/errorCodes.js';
import { ROLES } from '../../constants/roles.js';
import { requestContext } from '../../context/requestContext.js';
import {
  execute,
  fetchOne,
  isDuplicateEntry,
  pool,
  withTransaction,
} from '../../database/index.js';
import { ConflictError, ForbiddenError, UnauthorizedError } from '../../errors/index.js';
import { createLogger } from '../../utils/logger.js';
import { maskEmail } from '../../utils/mask.js';
import { hashPassword, verifyPassword } from '../../utils/password.js';
import { assertActiveAccount, assertHasRole, assertNotSuperAdmin } from '../users/users.rules.js';
import { UsersService } from '../users/users.service.js';
import { buildSecurityProfileRecord, SecurityProfileService } from './securityProfile.service.js';
import { signAccessToken, TokenService } from './token.service.js';

const log = createLogger('auth');

const emailTaken = () =>
  new ConflictError('An account with this email already exists', {
    code: ERROR_CODES.EMAIL_ALREADY_EXISTS,
  });

const invalidCredentials = () =>
  new UnauthorizedError('Invalid email or password', { code: ERROR_CODES.INVALID_CREDENTIALS });

/** Adds one row to user_login_logs. `status` is 'SUCCESS' or 'FAILURE'. */
async function insertLoginLog(conn, userId, status, failureReason = null) {
  const { ip } = requestContext.getMeta();
  await execute(
    conn,
    `INSERT INTO user_login_logs
       (user_id, login_time, login_status, failure_reason, ip_address, created_at)
     VALUES (:userId, :now, :status, :failureReason, :ip, :now)`,
    { userId, status, failureReason, ip: ip?.slice(0, 45) ?? null, now: new Date() },
  );
}

/**
 * What a client receives after sign-in, token refresh or password change: a fresh access token
 * plus the refresh token (the router puts that one in the cookie, never in the body).
 */
function buildSession(userId, refresh, user) {
  const { accessToken, expiresIn } = signAccessToken(userId);
  return {
    user,
    accessToken,
    expiresIn,
    refreshToken: refresh.rawToken,
    refreshExpiresAt: refresh.expiresAt,
  };
}

/** Sign-up, login, token refresh, logout and password change. */
export class AuthService {
  /** @param {object} [conn=pool]  the pool, or a connection from `withTransaction` */
  constructor(conn = pool) {
    this.conn = conn;
    this.users = new UsersService(conn);
    this.tokens = new TokenService(conn);
  }

  // ---------------------------------------------------------------------
  // Sign-up
  // ---------------------------------------------------------------------

  /**
   * Public self-registration. Always creates a MEMBER. The user, password, role and security
   * profile rows are written in ONE transaction: if any table fails, nothing remains.
   *
   * @throws {ForbiddenError} REGISTRATION_DISABLED
   * @throws {ConflictError} EMAIL_ALREADY_EXISTS
   */
  async register({ fullName, email, password, securityProfile }) {
    if (!config.server.selfRegistrationEnabled) {
      throw new ForbiddenError('Self-registration is disabled', {
        code: ERROR_CODES.REGISTRATION_DISABLED,
      });
    }

    // Cheap early exit before spending CPU on hashing. The unique index stays the real authority.
    if (await this.users.emailExists(email)) throw emailTaken();

    // Hash BEFORE the transaction: no connection or lock is held while bcrypt works.
    const [passwordHash, profileRecord] = await Promise.all([
      hashPassword(password),
      buildSecurityProfileRecord(securityProfile),
    ]);

    try {
      const userId = await withTransaction(async (conn) => {
        const newUserId = await new UsersService(conn).createAccount({
          fullName,
          email,
          passwordHash,
          roleName: ROLES.MEMBER,
        });
        await new SecurityProfileService(conn).insert(newUserId, profileRecord);
        return newUserId;
      });
      log.info({ userId }, 'User registered');
      return await this.users.findById(userId);
    } catch (err) {
      if (isDuplicateEntry(err, 'uq_users_email_active')) throw emailTaken(); // lost a race
      throw err;
    }
  }

  // ---------------------------------------------------------------------
  // Login / refresh / logout
  // ---------------------------------------------------------------------

  /**
   * Authenticate with e-mail and password and open a session.
   *
   * Unknown e-mail and wrong password look exactly the same to the caller (same message, same
   * response time). Deleted users are never found. An inactive user CAN sign in; see below.
   *
   * @param {{ email: string, password: string }} credentials  e-mail already normalised
   * @returns {Promise<{ user, accessToken, expiresIn, refreshToken, refreshExpiresAt }>}
   * @throws {UnauthorizedError} INVALID_CREDENTIALS
   * @throws {ForbiddenError} ROLE_NOT_ASSIGNED
   */
  async login({ email, password }) {
    const user = await this.users.findByEmail(email);
    if (!user) {
      await verifyPassword(password, null); // costs as much as a real check: no timing leak
      log.warn({ email: maskEmail(email), reason: 'ACCOUNT_NOT_FOUND' }, 'Login failed');
      throw invalidCredentials();
    }

    const passwordHash = await this.#getPasswordHash(user);
    if (!(await verifyPassword(password, passwordHash))) {
      await this.#recordFailedLogin(
        user.userId,
        passwordHash ? 'INVALID_PASSWORD' : 'NO_PASSWORD_SET',
      );
      throw invalidCredentials();
    }

    // is_active is deliberately NOT checked here: an inactive user may sign in to read their
    // profile and to sign out, and authenticate() refuses everything else (ACCOUNT_INACTIVE).
    // A user without an active role could do nothing with a session, so that is refused here.
    assertHasRole(user);

    const refresh = await this.#openSession(user.userId);
    log.info({ userId: user.userId }, 'Login successful');

    // Reloaded because last_login has just changed.
    return buildSession(user.userId, refresh, await this.users.findById(user.userId));
  }

  /** The hash to compare with: ENV for the super admin, user_passwords for everyone else. */
  async #getPasswordHash(user) {
    if (user.isSuperAdmin) return config.superAdmin.passwordHash;

    const row = await fetchOne(
      this.conn,
      'SELECT hash_password FROM user_passwords WHERE user_id = :userId',
      { userId: user.userId },
    );
    return row?.hash_password ?? null;
  }

  /** ONE transaction: remember the login (last_login + log row) and create the refresh token. */
  async #openSession(userId) {
    return withTransaction(async (conn) => {
      await execute(conn, 'UPDATE users SET last_login = :now WHERE user_id = :userId', {
        now: new Date(),
        userId,
      });
      await insertLoginLog(conn, userId, 'SUCCESS');
      return new TokenService(conn).issueRefreshToken(userId);
    });
  }

  /**
   * Logs a failed attempt and stores it in user_login_logs. Best effort: a broken log table
   * must never change the outcome of a login attempt.
   */
  async #recordFailedLogin(userId, reason) {
    log.warn({ userId, reason }, 'Login failed');
    try {
      await insertLoginLog(this.conn, userId, 'FAILURE', reason);
    } catch (err) {
      log.warn({ userId, err }, 'Could not write the login log');
    }
  }

  /**
   * Exchange the refresh token for a new one (rotation) and a fresh access token.
   * @throws {UnauthorizedError} when the refresh token is invalid, expired or was already used
   */
  async refreshSession(rawRefreshToken) {
    const rotated = await this.tokens.rotateRefreshToken(rawRefreshToken);

    const user = await this.users.findById(rotated.userId);
    if (!user) {
      throw new UnauthorizedError('Invalid refresh token', { code: ERROR_CODES.TOKEN_INVALID });
    }
    assertHasRole(user);

    return buildSession(user.userId, rotated, user);
  }

  /** End the current session. Idempotent: a missing or unknown token is ignored. */
  async logout(rawRefreshToken) {
    if (rawRefreshToken) await this.tokens.revokeRefreshToken(rawRefreshToken);
  }

  /**
   * End every session of the user. Allowed for inactive users on purpose: signing out is
   * always possible.
   */
  async logoutAll(actor) {
    const revokedSessions = await this.tokens.revokeAllRefreshTokens(actor.userId);
    return { revokedSessions };
  }

  // ---------------------------------------------------------------------
  // Change password (signed in)
  // ---------------------------------------------------------------------

  /**
   * Needs the current password. Stores the new hash, ends EVERY session and, because
   * user_passwords.updated_at moves forward, kills every access token issued before now. The
   * calling device stays signed in: it gets a brand-new session from the same transaction.
   * This is also how a user clears `must_change_password` after an admin reset.
   *
   * @throws {BadRequestError} INVALID_CURRENT_PASSWORD
   */
  async changePassword(actor, { currentPassword, newPassword }) {
    assertNotSuperAdmin(actor);
    assertActiveAccount(actor);
    await this.users.assertCurrentPassword(actor.userId, currentPassword);

    const newHash = await hashPassword(newPassword);
    const refresh = await withTransaction(async (conn) => {
      await execute(
        conn,
        `UPDATE user_passwords
            SET hash_password = :newHash, must_change_password = FALSE,
                updated_by = :userId, updated_at = :now
          WHERE user_id = :userId`,
        { newHash, userId: actor.userId, now: new Date() },
      );
      const tokens = new TokenService(conn);
      await tokens.revokeAllRefreshTokens(actor.userId);
      return tokens.issueRefreshToken(actor.userId);
    });

    log.info({ userId: actor.userId }, 'Password changed');
    return buildSession(actor.userId, refresh);
  }
}
