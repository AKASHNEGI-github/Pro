import {
  FIXED_SECURITY_QUESTIONS,
  SECURITY_QUESTION_KEYS,
} from '../../constants/securityQuestions.js';
import { execute, fetchOne, pool, withTransaction } from '../../database/index.js';
import { createLogger } from '../../utils/logger.js';
import { assertActiveAccount, assertNotSuperAdmin } from '../users/users.rules.js';
import { UsersService } from '../users/users.service.js';
import { hashAnswer } from './securityAnswers.js';

const log = createLogger('auth.security-profile');

/** The custom questions of a profile row, as the public `{ key, question }` list. */
export function customQuestionsFromRow(row) {
  const questions = [];
  if (row.custom_question_1) {
    questions.push({ key: SECURITY_QUESTION_KEYS.CUSTOM_1, question: row.custom_question_1 });
  }
  if (row.custom_question_2) {
    questions.push({ key: SECURITY_QUESTION_KEYS.CUSTOM_2, question: row.custom_question_2 });
  }
  return questions;
}

/**
 * Hashes all answers (slow, CPU-bound -> do it BEFORE opening a transaction).
 * @param {{ dob: string, q2: string, q3: string, customQuestions: {question, answer}[] }} input
 */
export async function buildSecurityProfileRecord({ dob, q2, q3, customQuestions }) {
  const [dobHash, q2Hash, q3Hash, ...customHashes] = await Promise.all([
    hashAnswer(SECURITY_QUESTION_KEYS.DOB, dob),
    hashAnswer(SECURITY_QUESTION_KEYS.Q2, q2),
    hashAnswer(SECURITY_QUESTION_KEYS.Q3, q3),
    ...customQuestions.map((item, index) => hashAnswer(`custom${index + 1}`, item.answer)),
  ]);
  return {
    dobHash,
    q2Hash,
    q3Hash,
    custom: customQuestions.map((item, index) => ({
      question: item.question,
      hash: customHashes[index],
    })),
  };
}

/** The named SQL parameters shared by the INSERT and the UPDATE of a security profile. */
function profileParams(record) {
  const [first, second] = record.custom;
  return {
    dobHash: record.dobHash,
    q2Hash: record.q2Hash,
    q3Hash: record.q3Hash,
    custom1Question: first?.question ?? null,
    custom1Hash: first?.hash ?? null,
    custom2Question: second?.question ?? null,
    custom2Hash: second?.hash ?? null,
  };
}

/**
 * The security profile: the recovery questions a user answers at sign-up (and may change later).
 * The forgot-password flow that USES these answers is in recovery.service.js.
 */
export class SecurityProfileService {
  /** @param {object} [conn=pool]  the pool, or a connection from `withTransaction` */
  constructor(conn = pool) {
    this.conn = conn;
    this.users = new UsersService(conn);
  }

  /** Adds the profile of a user who has none yet (used by sign-up, inside its transaction). */
  async insert(userId, record) {
    await execute(
      this.conn,
      `INSERT INTO user_security_profiles
         (user_id, dob_hash, answer_q2_hash, answer_q3_hash,
          custom_question_1, custom_answer_1_hash, custom_question_2, custom_answer_2_hash,
          failed_attempts, locked_until, created_at, updated_at)
       VALUES (:userId, :dobHash, :q2Hash, :q3Hash,
               :custom1Question, :custom1Hash, :custom2Question, :custom2Hash,
               0, NULL, :now, :now)`,
      { userId, ...profileParams(record), now: new Date() },
    );
  }

  /** Overwrites an existing profile and clears the failed-attempt counter and any lock. */
  async #replace(userId, record) {
    await execute(
      this.conn,
      `UPDATE user_security_profiles
          SET dob_hash = :dobHash, answer_q2_hash = :q2Hash, answer_q3_hash = :q3Hash,
              custom_question_1 = :custom1Question, custom_answer_1_hash = :custom1Hash,
              custom_question_2 = :custom2Question, custom_answer_2_hash = :custom2Hash,
              failed_attempts = 0, locked_until = NULL, updated_at = :now
        WHERE user_id = :userId`,
      { userId, ...profileParams(record), now: new Date() },
    );
  }

  /** Whether the user has a profile, and which custom questions they wrote (never answers). */
  async getStatus(actor) {
    assertNotSuperAdmin(actor);
    assertActiveAccount(actor);

    const row = await fetchOne(
      this.conn,
      `SELECT custom_question_1, custom_question_2, updated_at
         FROM user_security_profiles WHERE user_id = :userId`,
      { userId: actor.userId },
    );
    return {
      isConfigured: Boolean(row),
      fixedQuestions: FIXED_SECURITY_QUESTIONS,
      customQuestions: row ? customQuestionsFromRow(row) : [],
      updatedAt: row?.updated_at ?? null,
    };
  }

  /**
   * Create or replace the caller's profile. Needs the CURRENT password: the answers are a second
   * way into the account, so a stolen access token alone must not be able to change them.
   *
   * @throws {BadRequestError} INVALID_CURRENT_PASSWORD
   */
  async save(actor, { currentPassword, ...profile }) {
    assertNotSuperAdmin(actor);
    assertActiveAccount(actor);
    await this.users.assertCurrentPassword(actor.userId, currentPassword);
    const record = await buildSecurityProfileRecord(profile);

    await withTransaction(async (conn) => {
      const existing = await fetchOne(
        conn,
        'SELECT user_id FROM user_security_profiles WHERE user_id = :userId FOR UPDATE',
        { userId: actor.userId },
      );
      const profiles = new SecurityProfileService(conn);
      if (existing) await profiles.#replace(actor.userId, record);
      else await profiles.insert(actor.userId, record);
    });

    log.info({ userId: actor.userId }, 'Security profile saved');
    return this.getStatus(actor);
  }
}
