import jwt from 'jsonwebtoken';
import { config } from '../../config/index.js';
import { ERROR_CODES } from '../../constants/errorCodes.js';
import { requestContext } from '../../context/requestContext.js';
import { execute, fetchOne, pool, withTransaction } from '../../database/index.js';
import { UnauthorizedError } from '../../errors/index.js';
import { generateOpaqueToken, sha256Hex } from '../../utils/crypto.js';
import { createLogger } from '../../utils/logger.js';

const log = createLogger('auth.tokens');

// ---------------------------------------------------------------------
// Access token: short-lived, stateless JWT (HS256). It only identifies the user (`sub`);
// role and account state are re-read from the database on every request.
// ---------------------------------------------------------------------
export function signAccessToken(userId) {
  const accessToken = jwt.sign({}, config.jwt.accessSecret, {
    algorithm: 'HS256',
    subject: String(userId),
    issuer: config.jwt.issuer,
    audience: config.jwt.audience,
    expiresIn: config.jwt.accessTtlSeconds,
  });
  return { accessToken, expiresIn: config.jwt.accessTtlSeconds };
}

/** @returns {{ userId: number, issuedAt: number }} @throws UnauthorizedError */
export function verifyAccessToken(token) {
  try {
    const payload = jwt.verify(token, config.jwt.accessSecret, {
      algorithms: ['HS256'],
      issuer: config.jwt.issuer,
      audience: config.jwt.audience,
    });
    const userId = Number(payload.sub);
    if (!Number.isSafeInteger(userId) || userId < 1) throw new Error('invalid subject');
    return { userId, issuedAt: payload.iat };
  } catch (err) {
    if (err instanceof jwt.TokenExpiredError) {
      throw new UnauthorizedError('Access token has expired', { code: ERROR_CODES.TOKEN_EXPIRED });
    }
    throw new UnauthorizedError('Invalid access token', { code: ERROR_CODES.TOKEN_INVALID });
  }
}

/**
 * 401 for a refresh token that was rotated moments ago (parallel tabs / requests).
 * The router must NOT clear the cookie for this one: the browser may already hold the newer one.
 */
export class RefreshTokenRaceError extends UnauthorizedError {
  constructor() {
    super('This refresh token was just used; retry with the latest one', {
      code: ERROR_CODES.TOKEN_INVALID,
    });
  }
}

const PURGE_BATCH = 1000;

/**
 * Refresh tokens: opaque random value, stored only as a SHA-256 digest, rotated on every use.
 * Build it on a transaction connection (`new TokenService(conn)`) when a write must be atomic
 * with other writes (login, password change).
 */
export class TokenService {
  /** @param {object} [conn=pool]  the pool, or a connection from `withTransaction` */
  constructor(conn = pool) {
    this.conn = conn;
  }

  /** Creates and stores a new refresh token. @returns {{ rawToken, tokenHash, expiresAt }} */
  async issueRefreshToken(userId) {
    const { userAgent } = requestContext.getMeta();
    const rawToken = generateOpaqueToken();
    const tokenHash = sha256Hex(rawToken);
    const now = new Date();
    const expiresAt = new Date(now.getTime() + config.refreshToken.ttlMs);

    await execute(
      this.conn,
      `INSERT INTO refresh_tokens (user_id, token_hash, expires_at, user_agent, created_at, updated_at)
       VALUES (:userId, :tokenHash, :expiresAt, :userAgent, :now, :now)`,
      { userId, tokenHash, expiresAt, userAgent, now },
    );
    return { rawToken, tokenHash, expiresAt };
  }

  /**
   * Exchanges a refresh token for a new one (rotation).
   *
   *   ok       -> old token revoked + replaced_by_hash set, new token issued
   *   leeway   -> the token was rotated moments ago (parallel tabs/requests): plain 401, the
   *               client simply retries with the newer cookie; nothing else is revoked
   *   reuse    -> an already-rotated token came back later = probable theft: EVERY active
   *               refresh token of that user is revoked
   *   expired / invalid -> 401
   *
   * The decision is made inside one transaction (row locked with FOR UPDATE, so two concurrent
   * requests with the same token cannot both succeed) and the exception is thrown only AFTER
   * the commit, otherwise the revocations of the "reuse" case would be rolled back.
   */
  async rotateRefreshToken(rawToken) {
    const tokenHash = sha256Hex(rawToken);
    const outcome = await withTransaction((conn) =>
      new TokenService(conn).#decideRotation(tokenHash),
    );

    switch (outcome.status) {
      case 'ok':
        return { userId: outcome.userId, rawToken: outcome.rawToken, expiresAt: outcome.expiresAt };
      case 'leeway':
        throw new RefreshTokenRaceError();
      case 'reuse':
        log.warn(
          { userId: outcome.userId },
          'Refresh token reuse detected - all refresh tokens of the user were revoked',
        );
        throw new UnauthorizedError(
          'Refresh token reuse detected. All sessions were revoked, please sign in again',
          { code: ERROR_CODES.TOKEN_INVALID },
        );
      case 'expired':
        throw new UnauthorizedError('Refresh token has expired', {
          code: ERROR_CODES.TOKEN_EXPIRED,
        });
      default:
        throw new UnauthorizedError('Invalid refresh token', { code: ERROR_CODES.TOKEN_INVALID });
    }
  }

  /** The transactional half of `rotateRefreshToken`: returns a status, never throws for outcomes. */
  async #decideRotation(tokenHash) {
    const row = await fetchOne(
      this.conn,
      `SELECT refresh_tokens_id, user_id, expires_at, revoked_at, replaced_by_hash
         FROM refresh_tokens
        WHERE token_hash = :tokenHash
          FOR UPDATE`,
      { tokenHash },
    );
    if (!row) return { status: 'invalid' };

    const now = new Date();

    if (row.revoked_at) {
      // Revoked by logout / password change / admin action: just invalid, nothing to escalate.
      if (row.replaced_by_hash === null) return { status: 'invalid' };

      if (now.getTime() - row.revoked_at.getTime() <= config.refreshToken.reuseLeewayMs) {
        return { status: 'leeway' };
      }
      await execute(
        this.conn,
        `UPDATE refresh_tokens SET revoked_at = :now, updated_at = :now
          WHERE user_id = :userId AND revoked_at IS NULL`,
        { now, userId: row.user_id },
      );
      return { status: 'reuse', userId: row.user_id };
    }

    if (row.expires_at.getTime() <= now.getTime()) return { status: 'expired' };

    const user = await fetchOne(
      this.conn,
      'SELECT user_id FROM users WHERE user_id = :userId AND is_deleted = FALSE',
      { userId: row.user_id },
    );
    if (!user) {
      await execute(
        this.conn,
        `UPDATE refresh_tokens SET revoked_at = :now, updated_at = :now
          WHERE refresh_tokens_id = :id`,
        { now, id: row.refresh_tokens_id },
      );
      return { status: 'invalid' };
    }

    const next = await this.issueRefreshToken(row.user_id);
    await execute(
      this.conn,
      `UPDATE refresh_tokens SET revoked_at = :now, replaced_by_hash = :replacedBy, updated_at = :now
        WHERE refresh_tokens_id = :id`,
      { now, replacedBy: next.tokenHash, id: row.refresh_tokens_id },
    );
    return {
      status: 'ok',
      userId: row.user_id,
      rawToken: next.rawToken,
      expiresAt: next.expiresAt,
    };
  }

  /** Logout of one session. Idempotent: unknown / already revoked tokens are ignored. */
  async revokeRefreshToken(rawToken) {
    await execute(
      this.conn,
      `UPDATE refresh_tokens SET revoked_at = :now, updated_at = :now
        WHERE token_hash = :tokenHash AND revoked_at IS NULL`,
      { now: new Date(), tokenHash: sha256Hex(rawToken) },
    );
  }

  /** Revokes every active session of a user. @returns {Promise<number>} sessions revoked */
  async revokeAllRefreshTokens(userId) {
    const { affectedRows } = await execute(
      this.conn,
      `UPDATE refresh_tokens SET revoked_at = :now, updated_at = :now
        WHERE user_id = :userId AND revoked_at IS NULL`,
      { now: new Date(), userId },
    );
    return affectedRows;
  }

  /**
   * Housekeeping (called by the cleanup job): physically removes tokens that expired more than
   * `retentionMs` ago. Rotated/revoked tokens are kept until they expire so that reuse
   * detection keeps working for their whole lifetime.
   */
  async purgeExpiredTokens({ retentionMs = 24 * 60 * 60 * 1000 } = {}) {
    const cutoff = new Date(Date.now() - retentionMs);
    // PURGE_BATCH is a constant, not user input.
    const refreshTokens = await this.#deleteInBatches(
      `DELETE FROM refresh_tokens WHERE expires_at < :cutoff LIMIT ${PURGE_BATCH}`,
      { cutoff },
    );
    const passwordResetTokens = await this.#deleteInBatches(
      `DELETE FROM password_reset_tokens WHERE expires_at < :cutoff LIMIT ${PURGE_BATCH}`,
      { cutoff },
    );
    return { refreshTokens, passwordResetTokens };
  }

  async #deleteInBatches(sql, params) {
    let total = 0;
    for (;;) {
      const { affectedRows } = await execute(this.conn, sql, params);
      total += affectedRows;
      if (affectedRows < PURGE_BATCH) return total;
    }
  }
}
