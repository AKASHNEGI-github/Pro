import { ERROR_CODES } from '../constants/errorCodes.js';

/**
 * Base class of every error the application throws on purpose (the Node twin of the FastAPI
 * `AppException`). The global error handler turns an AppError into the standard failure response:
 *
 *   HTTP status = statusCode   body.message = message   body.error = { code, details? }
 *   response headers = headers
 *
 * Throw one of the subclasses in `httpErrors.js` instead of using this class directly.
 */
export class AppError extends Error {
  /**
   * @param {string} message  Safe, human-readable message (it is sent to the client).
   * @param {object} [options]
   * @param {number} [options.statusCode=500]  HTTP status code.
   * @param {string} [options.code]            Stable machine-readable code (see ERROR_CODES).
   * @param {Array}  [options.details]         Public extra info, e.g. validation issues.
   * @param {Error}  [options.cause]           The original error. Logged, never sent to the client.
   * @param {Record<string, string>} [options.headers]  Extra response headers, e.g. Retry-After.
   */
  constructor(
    message,
    { statusCode = 500, code = ERROR_CODES.INTERNAL_ERROR, details, cause, headers } = {},
  ) {
    super(message, cause ? { cause } : undefined);
    this.name = new.target.name;
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.headers = headers ?? {};
    Error.captureStackTrace?.(this, new.target); // re-capture so the stack starts with the subclass name
  }
}
