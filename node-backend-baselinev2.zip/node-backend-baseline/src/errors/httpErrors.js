import { ERROR_CODES } from '../constants/errorCodes.js';
import { AppError } from './AppError.js';

/**
 * One class per HTTP status we use. Every constructor has the same shape:
 *
 *   new NotFoundError(message?, { code?, details?, cause?, headers? })
 *
 * The status code is fixed by the class; message and code have sensible defaults.
 */

export class BadRequestError extends AppError {
  constructor(message = 'Bad request', options = {}) {
    super(message, { code: ERROR_CODES.BAD_REQUEST, ...options, statusCode: 400 });
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = 'Authentication required', options = {}) {
    super(message, { code: ERROR_CODES.UNAUTHORIZED, ...options, statusCode: 401 });
  }
}

export class ForbiddenError extends AppError {
  constructor(message = 'You do not have permission to perform this action', options = {}) {
    super(message, { code: ERROR_CODES.FORBIDDEN, ...options, statusCode: 403 });
  }
}

export class NotFoundError extends AppError {
  constructor(message = 'Resource not found', options = {}) {
    super(message, { code: ERROR_CODES.NOT_FOUND, ...options, statusCode: 404 });
  }
}

export class ConflictError extends AppError {
  constructor(message = 'Resource already exists', options = {}) {
    super(message, { code: ERROR_CODES.CONFLICT, ...options, statusCode: 409 });
  }
}

export class PayloadTooLargeError extends AppError {
  constructor(message = 'Request payload is too large', options = {}) {
    super(message, { code: ERROR_CODES.PAYLOAD_TOO_LARGE, ...options, statusCode: 413 });
  }
}

export class ValidationError extends AppError {
  constructor(message = 'Validation failed', options = {}) {
    super(message, { code: ERROR_CODES.VALIDATION_ERROR, ...options, statusCode: 422 });
  }
}

export class TooManyRequestsError extends AppError {
  constructor(message = 'Too many requests, please try again later', options = {}) {
    super(message, { code: ERROR_CODES.RATE_LIMITED, ...options, statusCode: 429 });
  }
}

export class InternalServerError extends AppError {
  constructor(message = 'Something went wrong', options = {}) {
    super(message, { code: ERROR_CODES.INTERNAL_ERROR, ...options, statusCode: 500 });
  }
}

export class ServiceUnavailableError extends AppError {
  constructor(message = 'Service temporarily unavailable', options = {}) {
    super(message, { code: ERROR_CODES.SERVICE_UNAVAILABLE, ...options, statusCode: 503 });
  }
}

/**
 * A database operation failed unexpectedly. Raised by the data layer (BaseRepository), never by
 * services. The client only sees the generic 500 message; the SQL context goes to the logs.
 */
export class DatabaseError extends InternalServerError {}
