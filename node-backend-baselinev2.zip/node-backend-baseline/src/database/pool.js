import mysql from 'mysql2/promise';
import { buildSslOptions } from '../config/database.js';
import { config } from '../config/index.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('db');

/**
 * The single shared connection pool. Connects with DB_URL when it is set, otherwise with the
 * local DB_* credentials (the choice is made in src/config/database.js).
 *
 * - `namedPlaceholders`: SQL uses `:name` placeholders and a params object, e.g.
 *       WHERE email = :email     with    { email }
 * - All timestamps in the schema are UTC, so the driver reads/writes UTC (timezone: 'Z') and
 *   every new connection switches its session time zone to UTC as well.
 */
export const pool = mysql.createPool({
  host: config.db.host,
  port: config.db.port,
  user: config.db.user,
  password: config.db.password,
  database: config.db.database,
  namedPlaceholders: true,
  waitForConnections: true,
  connectionLimit: config.db.connectionLimit,
  queueLimit: config.db.queueLimit,
  connectTimeout: config.db.connectTimeoutMs,
  charset: 'utf8mb4',
  timezone: 'Z',
  supportBigNumbers: true, // BIGINT ids come back as numbers (strings only above 2^53)
  bigNumberStrings: false,
  dateStrings: false,
  enableKeepAlive: true,
  keepAliveInitialDelay: 10000,
  ssl: buildSslOptions(config.db.ssl),
});

/**
 * Runs once for every NEW physical connection, before the pool hands it out.
 *
 * The query timeout is a SERVER-SIDE session setting on purpose: MySQL kills a slow SELECT
 * cleanly and the connection stays usable. (A client-side timeout would have to abandon the
 * socket mid-read, which corrupts the connection.) It applies to SELECT statements only.
 */
pool.on('connection', (connection) => {
  connection.query("SET time_zone = '+00:00'", (err) => {
    if (err) log.error({ err }, 'Could not set the session time zone to UTC');
  });
  connection.query(
    `SET SESSION max_execution_time = ${Number(config.db.queryTimeoutMs)}`,
    (err) => {
      if (err) log.warn({ err }, 'Could not set max_execution_time; queries run without a timeout');
    },
  );
});

/** Cheap liveness probe used by startup checks and GET /health/ready. */
export async function pingDatabase() {
  await pool.query('SELECT 1');
}

export async function closePool() {
  await pool.end();
}
