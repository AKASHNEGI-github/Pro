import { setTimeout as sleep } from 'node:timers/promises';
import { createLogger } from '../utils/logger.js';
import { isDeadlock, toDatabaseError } from './baseRepository.js';
import { pool } from './pool.js';

const log = createLogger('db');

/** Awaits a driver call and turns its failure into an AppError (connection lost, pool closed...). */
async function guard(promise) {
  try {
    return await promise;
  } catch (err) {
    throw toDatabaseError(err);
  }
}

/** @returns {Promise<boolean>} false when the rollback itself failed (connection is unusable). */
async function rollback(conn) {
  try {
    await conn.rollback();
    return true;
  } catch (err) {
    log.error({ err }, 'Rollback failed; discarding the connection');
    return false;
  }
}

/**
 * Runs `work(conn)` inside ONE database transaction.
 *
 *     const userId = await withTransaction(async (conn) => {
 *       const { insertId } = await execute(conn, 'INSERT INTO users ...', { ... });
 *       await execute(conn, 'INSERT INTO user_passwords ...', { userId: insertId, ... });
 *       return insertId;
 *     });
 *
 *  - `conn` is used exactly like the pool: pass it to the helpers (`fetchOne(conn, ...)`) or build
 *    a service on it (`new TokenService(conn)`).
 *  - If `work` resolves, the transaction is committed and its value returned.
 *  - If `work` throws (or any statement fails), everything is rolled back and the error re-thrown.
 *  - Deadlocks are retried automatically, so `work` must be safe to run again: do password
 *    hashing / external calls BEFORE opening the transaction.
 *
 * Do NOT throw from inside `work` for an outcome that must stay committed (e.g. recording a failed
 * attempt): return a status from `work` and throw after the transaction has committed.
 * Nested transactions are not supported.
 */
export async function withTransaction(work, { maxDeadlockRetries = 2 } = {}) {
  for (let attempt = 0; ; attempt += 1) {
    const conn = await guard(pool.getConnection());
    let usable = true;

    try {
      await guard(conn.beginTransaction());
      const result = await work(conn);
      await guard(conn.commit());
      return result;
    } catch (err) {
      usable = await rollback(conn);
      if (isDeadlock(err) && attempt < maxDeadlockRetries) {
        log.warn({ attempt: attempt + 1 }, 'Deadlock detected; retrying the transaction');
        await sleep(25 * (attempt + 1));
        continue;
      }
      throw err;
    } finally {
      if (usable) conn.release();
      else conn.destroy(); // never hand a connection in an unknown state back to the pool
    }
  }
}
