/**
 * Everything a service needs to run raw MySQL queries, in ONE file:
 *
 *   1. error handling   how a MySQL failure becomes an AppError
 *   2. BaseRepository   runs one statement: named parameters, logging, error wrapping
 *   3. helpers          fetchOne / fetchAll / fetchPage / execute / executeMany  <- what services call
 *
 * SQL uses NAMED placeholders and a params object - never string concatenation:
 *
 *     const user = await fetchOne(this.conn, 'SELECT * FROM users WHERE email = :email', { email });
 *
 * `conn` is the pool (every call auto-commits) or the connection handed out by `withTransaction`.
 * A missing or `undefined` parameter throws: pass `null` when you mean SQL NULL.
 */
import {
  AppError,
  ConflictError,
  DatabaseError,
  ServiceUnavailableError,
} from '../errors/index.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('db');

// ---------------------------------------------------------------------------
// 1. Error handling
// ---------------------------------------------------------------------------

/** BaseRepository keeps the original MySQL error as the `cause` of the AppError it throws. */
const mysqlError = (err) => err?.cause ?? err;

/** True for a unique-key violation, optionally only for the index called `indexName`. */
export function isDuplicateEntry(err, indexName) {
  const { code, sqlMessage } = mysqlError(err) ?? {};
  if (code !== 'ER_DUP_ENTRY') return false;
  return !indexName || String(sqlMessage).includes(indexName);
}

export function isDeadlock(err) {
  return mysqlError(err)?.code === 'ER_LOCK_DEADLOCK';
}

const CONNECTION_ERRORS = new Set([
  'ECONNREFUSED',
  'ECONNRESET',
  'ETIMEDOUT',
  'ENOTFOUND',
  'EPIPE',
  'PROTOCOL_CONNECTION_LOST',
  'ER_CON_COUNT_ERROR',
  'ER_SERVER_SHUTDOWN',
]);

/**
 * Turns a raw MySQL / driver error into the AppError the client should see:
 *
 *   duplicate key                       -> 409 ConflictError
 *   deadlock / lock wait timeout        -> 503 ServiceUnavailableError (+ Retry-After)
 *   connection lost / pool closed       -> 503 ServiceUnavailableError (+ Retry-After)
 *   anything else                       -> 500 DatabaseError (details only in the logs)
 */
export function toDatabaseError(err) {
  if (err instanceof AppError) return err; // already translated

  if (err?.code === 'ER_DUP_ENTRY') {
    return new ConflictError('Resource already exists', { cause: err });
  }
  if (err?.code === 'ER_LOCK_DEADLOCK' || err?.code === 'ER_LOCK_WAIT_TIMEOUT') {
    return new ServiceUnavailableError('The system is busy, please retry', {
      cause: err,
      headers: { 'Retry-After': '1' },
    });
  }
  // mysql2 throws a plain Error ("Pool is closed.") for work that arrives during shutdown.
  if (CONNECTION_ERRORS.has(err?.code) || /pool is closed/i.test(err?.message)) {
    return new ServiceUnavailableError('The database is currently unavailable', {
      cause: err,
      headers: { 'Retry-After': '5' },
    });
  }
  return new DatabaseError(undefined, { cause: err });
}

// ---------------------------------------------------------------------------
// 2. BaseRepository
// ---------------------------------------------------------------------------

/** Shared async SQL execution helpers (MySQL only). */
export class BaseRepository {
  #conn;

  /** @param {{ execute: Function }} conn  the pool, or a connection from `withTransaction` */
  constructor(conn) {
    this.#conn = conn;
  }

  async #executeStatement(sql, params) {
    try {
      // The query timeout is a server-side session setting (see pool.js): MySQL kills a slow
      // SELECT cleanly and the connection stays usable.
      const [result] = await this.#conn.execute(sql, params);
      return result;
    } catch (err) {
      const error = toDatabaseError(err);
      if (error.statusCode >= 500) {
        log.error(
          {
            sqlPreview: sql.replace(/\s+/g, ' ').trim().slice(0, 200),
            paramKeys: Object.keys(params), // keys are safe to log, values may be PII
            errorCode: err?.code,
            err,
          },
          err?.code === 'ER_QUERY_TIMEOUT' ? 'Database query timed out' : 'Database query failed',
        );
      }
      throw error;
    }
  }

  /** First row as a plain object, or `null` when nothing matches. */
  async fetchOne(sql, params = {}) {
    const rows = await this.#executeStatement(sql, params);
    return rows[0] ?? null;
  }

  /** All rows as plain objects; `[]` when nothing matches. */
  async fetchAll(sql, params = {}) {
    return this.#executeStatement(sql, params);
  }

  /** One page of rows plus the total row count. `LIMIT :limit OFFSET :skip` is appended to `sql`. */
  async fetchPage(sql, countSql, params = {}, { skip = 0, limit = 20 } = {}) {
    // LIMIT/OFFSET are bound as integer STRINGS: some MySQL 8.0.22+ / driver combinations reject
    // JS numbers (sent as DOUBLE) for these placeholders in prepared statements.
    const paging = { limit: String(limit), skip: String(skip) };
    const rows = await this.fetchAll(`${sql.trimEnd()} LIMIT :limit OFFSET :skip`, {
      ...params,
      ...paging,
    });
    const countRow = await this.fetchOne(countSql, params);
    return { rows, total: countRow ? Number(countRow.total) : 0 };
  }

  /** INSERT / UPDATE / DELETE. `insertId` is the new AUTO_INCREMENT id of an INSERT. */
  async execute(sql, params = {}) {
    const { affectedRows, insertId } = await this.#executeStatement(sql, params);
    return { affectedRows, insertId };
  }

  /** Runs `sql` once per entry of `paramsList`, in order. */
  async executeMany(sql, paramsList) {
    for (const params of paramsList) await this.execute(sql, params);
  }
}

// ---------------------------------------------------------------------------
// 3. Helpers - what the services call
// ---------------------------------------------------------------------------

/**
 * Execute `sql` and return the first row as a plain object, or `null`.
 *
 * @param {object} conn      the pool, or a transaction connection
 * @param {string} sql       parameterised statement (`:name` placeholders)
 * @param {object} [params]  named bind parameters
 * @returns {Promise<object|null>}
 * @throws {DatabaseError} (or a more specific AppError, see `toDatabaseError`)
 */
export function fetchOne(conn, sql, params) {
  return new BaseRepository(conn).fetchOne(sql, params);
}

/**
 * Execute `sql` and return all rows as plain objects.
 *
 * @returns {Promise<object[]>} the rows; an empty array when none match
 */
export function fetchAll(conn, sql, params) {
  return new BaseRepository(conn).fetchAll(sql, params);
}

/**
 * Execute a paginated query and its companion count query.
 * `LIMIT :limit OFFSET :skip` is appended to `sql` automatically.
 *
 * @param {object} conn
 * @param {string} sql       data query (with its ORDER BY, without LIMIT/OFFSET)
 * @param {string} countSql  query returning a single `total` column, e.g.
 *                           `SELECT COUNT(*) AS total FROM ...`
 * @param {object} [params]  bind parameters shared by both queries
 * @param {{ skip?: number, limit?: number }} [paging]  rows to skip (OFFSET) / maximum rows (LIMIT)
 * @returns {Promise<{ rows: object[], total: number }>}
 */
export function fetchPage(conn, sql, countSql, params, paging) {
  return new BaseRepository(conn).fetchPage(sql, countSql, params, paging);
}

/**
 * Execute an INSERT / UPDATE / DELETE statement.
 * `affectedRows` counts rows MATCHED by the statement (an UPDATE that writes identical values
 * still counts them).
 *
 * @returns {Promise<{ affectedRows: number, insertId: number }>}
 */
export function execute(conn, sql, params) {
  return new BaseRepository(conn).execute(sql, params);
}

/** Execute `sql` once for each object in `paramsList` (bulk DML). */
export function executeMany(conn, sql, paramsList) {
  return new BaseRepository(conn).executeMany(sql, paramsList);
}
