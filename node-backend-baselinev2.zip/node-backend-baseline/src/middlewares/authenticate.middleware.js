import { ERROR_CODES } from '../constants/errorCodes.js';
import { requestContext } from '../context/requestContext.js';
import { UnauthorizedError } from '../errors/index.js';
import { verifyAccessToken } from '../modules/auth/token.service.js';
import {
  assertHasRole,
  assertIsActive,
  assertPasswordChangeNotPending,
} from '../modules/users/users.rules.js';
import { UsersService } from '../modules/users/users.service.js';

const BEARER = /^Bearer\s+(\S+)$/i;

const users = new UsersService();

const tokenNoLongerValid = (message) =>
  new UnauthorizedError(message, { code: ERROR_CODES.TOKEN_INVALID });

/**
 * Authentication (who are you?).
 *
 * 1. Verifies the Bearer access token (signature, expiry, issuer, audience).
 * 2. Re-reads the user from the database on EVERY request, so deactivation, deletion, role
 *    changes and password changes take effect immediately instead of at token expiry.
 *    Nothing about the user's role or state is ever trusted from the token itself.
 * 3. Applies the account-state rules (modules/users/users.rules.js). The strict behaviour is
 *    the default; a route must opt in to relax it:
 *      allowInactive              inactive users (is_active = false) may call this route
 *      allowPasswordChangePending users who must change their password may call this route
 *
 * Sets `req.user` (internal user model) and the acting user in the Request Context Store.
 */
export function authenticate({ allowInactive = false, allowPasswordChangePending = false } = {}) {
  return async (req, _res, next) => {
    const match = BEARER.exec(req.get('authorization') ?? '');
    if (!match) {
      throw new UnauthorizedError('Authentication required', { code: ERROR_CODES.UNAUTHORIZED });
    }

    const { userId, issuedAt } = verifyAccessToken(match[1]);

    const user = await users.findById(userId); // never returns a deleted user
    if (!user) throw tokenNoLongerValid('The access token is no longer valid');

    // Tokens issued before the last password change / reset are dead.
    if (user.passwordChangedAt && issuedAt < Math.floor(user.passwordChangedAt.getTime() / 1000)) {
      throw tokenNoLongerValid('The access token is no longer valid, please sign in again');
    }

    assertHasRole(user);
    if (!allowInactive) assertIsActive(user);
    if (!allowPasswordChangePending) assertPasswordChangeNotPending(user);

    req.user = user;
    requestContext.setUser(user);
    return next();
  };
}
