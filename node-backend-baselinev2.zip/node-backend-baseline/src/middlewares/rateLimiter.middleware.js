import { ipKeyGenerator, rateLimit } from 'express-rate-limit';
import { config } from '../config/index.js';
import { ERROR_CODES } from '../constants/errorCodes.js';
import { TooManyRequestsError } from '../errors/index.js';

const passThrough = (_req, _res, next) => next();

/** Lower-cased e-mail from the body (bounded), so a per-account limit can be layered on the IP. */
function emailFromBody(req) {
  const email = req.body?.email;
  return typeof email === 'string' ? email.trim().toLowerCase().slice(0, 150) : '';
}

/**
 * NOTE: the default store is in-memory, i.e. per process. Behind several instances use a shared
 * store (e.g. rate-limit-redis) - see README "Production checklist".
 */
function createLimiter({ limit, message, keyGenerator, skipSuccessfulRequests = false }) {
  if (!config.rateLimit.enabled) return passThrough;

  return rateLimit({
    windowMs: config.rateLimit.windowMs,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    skipSuccessfulRequests,
    ...(keyGenerator ? { keyGenerator } : {}),
    handler: (req, _res, next, options) => {
      const resetTime = req.rateLimit?.resetTime;
      const retryAfterSeconds = resetTime
        ? Math.max(1, Math.ceil((resetTime.getTime() - Date.now()) / 1000))
        : Math.ceil(options.windowMs / 1000);
      next(
        new TooManyRequestsError(message, {
          code: ERROR_CODES.RATE_LIMITED,
          headers: { 'Retry-After': String(retryAfterSeconds) },
        }),
      );
    },
  });
}

/** Every request, per IP. */
export const globalLimiter = createLimiter({
  limit: config.rateLimit.globalMax,
  message: 'Too many requests, please try again later',
});

/** All authentication-related routes, per IP. */
export const authLimiter = createLimiter({
  limit: config.rateLimit.authMax,
  message: 'Too many authentication requests, please try again later',
});

/** Login: per IP + e-mail; successful logins do not count. */
export const loginLimiter = createLimiter({
  limit: config.rateLimit.loginMax,
  skipSuccessfulRequests: true,
  message: 'Too many login attempts, please try again later',
  keyGenerator: (req) => `${ipKeyGenerator(req.ip)}|${emailFromBody(req)}`,
});

/** Forgot-password flow: per IP + e-mail (the per-account lockout in the DB is the second layer). */
export const recoveryLimiter = createLimiter({
  limit: config.rateLimit.recoveryMax,
  message: 'Too many password recovery attempts, please try again later',
  keyGenerator: (req) => `${ipKeyGenerator(req.ip)}|${emailFromBody(req)}`,
});
