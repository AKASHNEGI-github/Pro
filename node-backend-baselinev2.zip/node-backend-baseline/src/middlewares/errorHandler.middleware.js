import { ERROR_CODES } from '../constants/errorCodes.js';
import {
  AppError,
  BadRequestError,
  InternalServerError,
  PayloadTooLargeError,
} from '../errors/index.js';
import { createLogger } from '../utils/logger.js';
import { ApiResponse } from '../utils/response.js';

const log = createLogger('error');

/** Anything thrown anywhere -> an AppError (the only thing that is ever sent to the client). */
function normalizeError(err) {
  if (err instanceof AppError) return err;

  // body-parser / http-errors
  if (err?.type === 'entity.parse.failed') {
    return new BadRequestError('Malformed JSON in the request body', { cause: err });
  }
  if (err?.type === 'entity.too.large') {
    return new PayloadTooLargeError(undefined, { cause: err });
  }
  if (
    err?.expose === true &&
    Number.isInteger(err.status) &&
    err.status >= 400 &&
    err.status < 500
  ) {
    return new AppError(err.message, {
      statusCode: err.status,
      code: ERROR_CODES.BAD_REQUEST,
      cause: err,
    });
  }

  // Unknown = a bug. The client gets a generic message; the details stay in the logs.
  // (Database errors never arrive here raw: BaseRepository wraps them, see src/database/.)
  return new InternalServerError(undefined, { cause: err });
}

/**
 * Global error handler - the ONLY place that turns an exception into an HTTP response.
 * Must be registered last.
 */
export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);

  const appError = normalizeError(err);

  if (appError.statusCode >= 500) {
    log.error(
      { err: appError.cause ?? err, statusCode: appError.statusCode, code: appError.code },
      appError.message,
    );
  } else {
    log.debug({ statusCode: appError.statusCode, code: appError.code }, appError.message);
  }

  return ApiResponse.fail(res, appError);
}
