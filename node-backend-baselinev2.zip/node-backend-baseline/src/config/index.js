import { parseEnv } from './env.js';

const result = parseEnv(process.env);

if (!result.ok) {
  // The logger is not available yet (it depends on config), so write to stderr directly.
  // eslint-disable-next-line no-console
  console.error(
    [
      '',
      'Invalid environment configuration:',
      ...result.errors.map((message) => `  - ${message}`),
      '',
      'Copy .env.example to .env and fill in the values.',
      '',
    ].join('\n'),
  );
  process.exit(1);
}

const env = result.data;
const database = result.database; // resolved from DB_URL, or from the local DB_* credentials
const isProduction = env.NODE_ENV === 'production';
const isDevelopment = env.NODE_ENV === 'development';
const isTest = env.NODE_ENV === 'test';

function parseTrustProxy(value) {
  if (value === undefined || value === '' || value === 'false') return false;
  if (value === 'true') return true;
  if (/^\d+$/.test(value)) return Number(value);
  return value; // 'loopback', 'uniquelocal' or a comma-separated list of CIDRs
}

const corsOrigins = env.CORS_ORIGINS.split(',')
  .map((origin) => origin.trim().replace(/\/+$/, ''))
  .filter(Boolean);

export const API_PREFIX = '/api/v1';

/** Single, frozen source of truth. Nothing else in the codebase reads process.env. */
export const config = Object.freeze({
  app: Object.freeze({ name: env.APP_NAME }),
  env: env.NODE_ENV,
  isProduction,
  isDevelopment,
  isTest,

  server: Object.freeze({
    host: env.HOST,
    port: env.PORT,
    trustProxy: parseTrustProxy(env.TRUST_PROXY),
    apiPrefix: API_PREFIX,
    bodyLimit: '100kb',
    shutdownTimeoutMs: env.SHUTDOWN_TIMEOUT_MS,
    selfRegistrationEnabled: env.SELF_REGISTRATION_ENABLED ?? true,
  }),

  cors: Object.freeze({ origins: Object.freeze(corsOrigins) }),

  log: Object.freeze({
    level: env.LOG_LEVEL,
    pretty: env.LOG_PRETTY ?? isDevelopment,
  }),

  db: Object.freeze({
    source: database.source, // 'url' | 'local' (for the startup log; never contains the password)
    host: database.host,
    port: database.port,
    user: database.user,
    password: database.password,
    database: database.database,
    connectionLimit: env.DB_CONNECTION_LIMIT,
    queueLimit: env.DB_QUEUE_LIMIT,
    connectTimeoutMs: env.DB_CONNECT_TIMEOUT_MS,
    queryTimeoutMs: env.DB_QUERY_TIMEOUT_MS,
    ssl: Object.freeze({
      enabled: env.DB_SSL ?? false,
      caPath: env.DB_SSL_CA_PATH || null,
      rejectUnauthorized: env.DB_SSL_REJECT_UNAUTHORIZED ?? true,
    }),
  }),

  jwt: Object.freeze({
    accessSecret: env.JWT_ACCESS_SECRET,
    accessTtlSeconds: env.ACCESS_TOKEN_TTL_MINUTES * 60,
    issuer: env.JWT_ISSUER || env.APP_NAME,
    audience: env.JWT_AUDIENCE || `${env.APP_NAME}-clients`,
  }),

  refreshToken: Object.freeze({
    ttlMs: env.REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60 * 1000,
    reuseLeewayMs: env.REFRESH_TOKEN_REUSE_LEEWAY_SECONDS * 1000,
    cookie: Object.freeze({
      name: env.REFRESH_COOKIE_NAME,
      secure: env.REFRESH_COOKIE_SECURE ?? isProduction,
      sameSite: env.REFRESH_COOKIE_SAMESITE,
      domain: env.REFRESH_COOKIE_DOMAIN || undefined,
      path: `${API_PREFIX}/auth`,
    }),
  }),

  password: Object.freeze({ bcryptRounds: env.BCRYPT_ROUNDS }),

  recovery: Object.freeze({
    pepper: env.SECURITY_ANSWER_PEPPER,
    maxFailedAttempts: env.SECURITY_MAX_FAILED_ATTEMPTS,
    lockMs: env.SECURITY_LOCK_MINUTES * 60 * 1000,
    resetTokenTtlMs: env.PASSWORD_RESET_TOKEN_TTL_MINUTES * 60 * 1000,
  }),

  superAdmin: Object.freeze({
    name: env.SUPER_ADMIN_NAME,
    email: env.SUPER_ADMIN_EMAIL,
    passwordHash: env.SUPER_ADMIN_PASSWORD_HASH,
  }),

  rateLimit: Object.freeze({
    enabled: env.RATE_LIMIT_ENABLED ?? true,
    windowMs: env.RATE_LIMIT_WINDOW_MS,
    globalMax: env.RATE_LIMIT_MAX,
    authMax: env.AUTH_RATE_LIMIT_MAX,
    loginMax: env.LOGIN_RATE_LIMIT_MAX,
    recoveryMax: env.RECOVERY_RATE_LIMIT_MAX,
  }),

  cleanup: Object.freeze({ intervalMs: env.CLEANUP_INTERVAL_MINUTES * 60 * 1000 }),
});
