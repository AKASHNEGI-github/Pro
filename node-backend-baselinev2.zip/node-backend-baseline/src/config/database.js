/**
 * How we connect to MySQL. Shared by the app (src/config) and by the CLI scripts
 * (scripts/lib/dbTasks.js), so both always agree.
 *
 *   1. DB_URL is set   -> use it                    mysql://user:password@host:3306/database
 *   2. otherwise       -> use the local credentials DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME
 *
 * `resolveDatabaseConfig` is a pure function: no I/O, and an error message never contains a password.
 */
import fs from 'node:fs';

export const DEFAULT_DB_NAME = 'node_backend_baseline';

const DB_NAME_PATTERN = /^[A-Za-z0-9_]{1,64}$/;
const URL_HELP = 'expected mysql://user:password@host:3306/database';

const failure = (...errors) => ({ ok: false, errors });

function fromUrl(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    return failure(`DB_URL: is not a valid URL, ${URL_HELP}`);
  }

  if (url.protocol !== 'mysql:') return failure(`DB_URL: the scheme must be mysql://, ${URL_HELP}`);
  if (url.search || url.hash) {
    // Silently ignoring e.g. "?ssl-mode=REQUIRED" would connect WITHOUT encryption.
    return failure('DB_URL: query parameters are not supported; set DB_SSL=true instead');
  }

  let user;
  let password;
  let database;
  try {
    user = decodeURIComponent(url.username);
    password = decodeURIComponent(url.password);
    database = decodeURIComponent(url.pathname.replace(/^\//, ''));
  } catch {
    return failure('DB_URL: invalid percent-encoding (write "@" as %40, "/" as %2F, "%" as %25)');
  }

  const problems = [];
  if (!url.hostname) problems.push(`DB_URL: the host is missing, ${URL_HELP}`);
  if (!user) problems.push(`DB_URL: the user name is missing, ${URL_HELP}`);
  if (!DB_NAME_PATTERN.test(database)) {
    problems.push('DB_URL: the path must be the database name (letters, digits and underscores)');
  }
  if (problems.length > 0) return failure(...problems);

  return {
    ok: true,
    data: {
      source: 'url',
      host: url.hostname.replace(/^\[|\]$/g, ''), // IPv6 literals come wrapped in [ ]
      port: url.port ? Number(url.port) : 3306,
      user,
      password,
      database,
    },
  };
}

function fromLocalCredentials(env) {
  const problems = [];

  const port = env.DB_PORT ? Number(env.DB_PORT) : 3306;
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    problems.push('DB_PORT: must be an integer between 1 and 65535');
  }
  const user = env.DB_USER?.trim();
  if (!user) problems.push('DB_USER: is required when DB_URL is not set');
  const database = env.DB_NAME?.trim() || DEFAULT_DB_NAME;
  if (!DB_NAME_PATTERN.test(database)) {
    problems.push('DB_NAME: may contain only letters, digits and underscores (max 64)');
  }
  if (problems.length > 0) return failure(...problems);

  return {
    ok: true,
    data: {
      source: 'local',
      host: env.DB_HOST?.trim() || '127.0.0.1',
      port,
      user,
      password: env.DB_PASSWORD ?? '',
      database,
    },
  };
}

/**
 * @param {Record<string, string | undefined>} env  raw environment (e.g. process.env)
 * @returns {{ ok: true, data: { source: 'url'|'local', host, port, user, password, database } }
 *          | { ok: false, errors: string[] }}
 */
export function resolveDatabaseConfig(env) {
  const rawUrl = env.DB_URL?.trim();
  return rawUrl ? fromUrl(rawUrl) : fromLocalCredentials(env);
}

/**
 * TLS options for mysql2, or `undefined` when TLS is off (reads the CA file when one is given).
 * Shared by the app's pool and the db:* scripts. Needed by most managed MySQL services.
 *
 * @param {{ enabled?: boolean, caPath?: string|null, rejectUnauthorized?: boolean }} ssl
 */
export function buildSslOptions({ enabled, caPath, rejectUnauthorized = true }) {
  if (!enabled) return undefined;
  return {
    minVersion: 'TLSv1.2',
    rejectUnauthorized,
    ...(caPath ? { ca: fs.readFileSync(caPath) } : {}),
  };
}
