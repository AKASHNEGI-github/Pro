import dotenv from 'dotenv';
import { z } from 'zod';
import { resolveDatabaseConfig } from './database.js';

// Load .env (or the file named by ENV_FILE). Real process env vars always win.
dotenv.config({ path: process.env.ENV_FILE || '.env', quiet: true });

/** bcrypt hash of the documented DEV password in .env.example. Rejected in production. */
export const EXAMPLE_SUPER_ADMIN_HASH =
  '$2b$12$GVo/84BFVjH1Llj2dHuj7uicTXF7UkZoyxqCjemsvBEY.eQKNBczG';

const BCRYPT_HASH_REGEX = /^\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}$/;

const bool = z
  .enum(['true', 'false'], { error: 'must be "true" or "false"' })
  .transform((value) => value === 'true')
  .optional();

const int = (fallback, min, max) => z.coerce.number().int().min(min).max(max).default(fallback);

const envSchema = z.object({
  // ---- application ----
  APP_NAME: z.string().trim().min(1).default('node-backend-baseline'),
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: int(3000, 1, 65535),
  HOST: z.string().trim().min(1).default('0.0.0.0'),
  TRUST_PROXY: z.string().trim().optional(),
  CORS_ORIGINS: z.string().default(''),
  SHUTDOWN_TIMEOUT_MS: int(10000, 1000, 120000),
  SELF_REGISTRATION_ENABLED: bool,

  // ---- logging ----
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  LOG_PRETTY: bool,

  // ---- database ----
  // Either DB_URL, or the local DB_* credentials. The rules live in ./database.js (one place).
  DB_URL: z.string().trim().optional(),
  DB_HOST: z.string().trim().optional(),
  DB_PORT: z.string().trim().optional(),
  DB_USER: z.string().trim().optional(),
  DB_PASSWORD: z.string().optional(),
  DB_NAME: z.string().trim().optional(),
  DB_CONNECTION_LIMIT: int(10, 1, 200),
  DB_QUEUE_LIMIT: int(0, 0, 100000),
  DB_CONNECT_TIMEOUT_MS: int(10000, 1000, 120000),
  DB_QUERY_TIMEOUT_MS: int(30000, 100, 3600000),
  DB_SSL: bool,
  DB_SSL_CA_PATH: z.string().trim().optional(),
  DB_SSL_REJECT_UNAUTHORIZED: bool,

  // ---- access token (JWT) ----
  JWT_ACCESS_SECRET: z.string().min(32, 'must be at least 32 characters'),
  ACCESS_TOKEN_TTL_MINUTES: int(15, 1, 1440),
  JWT_ISSUER: z.string().trim().optional(),
  JWT_AUDIENCE: z.string().trim().optional(),

  // ---- refresh token ----
  REFRESH_TOKEN_TTL_DAYS: int(7, 1, 365),
  REFRESH_TOKEN_REUSE_LEEWAY_SECONDS: int(10, 0, 300),
  REFRESH_COOKIE_NAME: z
    .string()
    .trim()
    .regex(/^[A-Za-z0-9_-]+$/)
    .default('refresh_token'),
  REFRESH_COOKIE_SECURE: bool,
  REFRESH_COOKIE_SAMESITE: z.enum(['strict', 'lax', 'none']).default('strict'),
  REFRESH_COOKIE_DOMAIN: z.string().trim().optional(),

  // ---- passwords / recovery ----
  BCRYPT_ROUNDS: int(12, 4, 15),
  SECURITY_ANSWER_PEPPER: z.string().min(32, 'must be at least 32 characters'),
  SECURITY_MAX_FAILED_ATTEMPTS: int(5, 1, 100),
  SECURITY_LOCK_MINUTES: int(15, 1, 1440),
  PASSWORD_RESET_TOKEN_TTL_MINUTES: int(10, 1, 120),

  // ---- super admin (ENV only) ----
  SUPER_ADMIN_NAME: z.string().trim().min(2).max(100),
  SUPER_ADMIN_EMAIL: z.string().trim().toLowerCase().max(150).email(),
  SUPER_ADMIN_PASSWORD_HASH: z
    .string()
    .trim()
    .regex(BCRYPT_HASH_REGEX, 'must be a bcrypt hash (generate it with: npm run hash-password)'),

  // ---- rate limiting ----
  RATE_LIMIT_ENABLED: bool,
  RATE_LIMIT_WINDOW_MS: int(15 * 60 * 1000, 1000, 24 * 60 * 60 * 1000),
  RATE_LIMIT_MAX: int(600, 1, 1000000),
  AUTH_RATE_LIMIT_MAX: int(100, 1, 1000000),
  LOGIN_RATE_LIMIT_MAX: int(10, 1, 1000000),
  RECOVERY_RATE_LIMIT_MAX: int(10, 1, 1000000),

  // ---- maintenance ----
  CLEANUP_INTERVAL_MINUTES: int(60, 0, 10080),
});

/** Cross-field rules that only apply (or apply more strictly) in production. */
function productionGuards(env) {
  const problems = [];
  const placeholder = /change[_-]?me/i;

  if (placeholder.test(env.JWT_ACCESS_SECRET)) {
    problems.push('JWT_ACCESS_SECRET: still contains the CHANGE_ME placeholder');
  }
  if (placeholder.test(env.SECURITY_ANSWER_PEPPER)) {
    problems.push('SECURITY_ANSWER_PEPPER: still contains the CHANGE_ME placeholder');
  }
  if (env.SUPER_ADMIN_PASSWORD_HASH === EXAMPLE_SUPER_ADMIN_HASH) {
    problems.push('SUPER_ADMIN_PASSWORD_HASH: this is the public example hash from .env.example');
  }
  if (env.BCRYPT_ROUNDS < 10) {
    problems.push('BCRYPT_ROUNDS: must be at least 10 in production');
  }
  if (env.CORS_ORIGINS.split(',').some((origin) => origin.trim() === '*')) {
    problems.push('CORS_ORIGINS: wildcard "*" is not allowed (credentials are enabled)');
  }
  return problems;
}

/**
 * Validates a raw env object. Pure (no process exit) so it can be unit-tested.
 * @returns {{ ok: true, data: object, database: object } | { ok: false, errors: string[] }}
 *          `data` = the validated variables, `database` = the resolved MySQL connection settings.
 */
export function parseEnv(source) {
  const parsed = envSchema.safeParse(source);
  const errors = parsed.success
    ? []
    : parsed.error.issues.map((issue) => `${issue.path.join('.') || '(root)'}: ${issue.message}`);

  // Validated against the raw source so DB problems are listed together with every other problem.
  const database = resolveDatabaseConfig(source);
  if (!database.ok) errors.push(...database.errors);
  if (errors.length > 0) return { ok: false, errors };

  const env = parsed.data;
  if (env.REFRESH_COOKIE_SAMESITE === 'none' && env.REFRESH_COOKIE_SECURE === false) {
    errors.push('REFRESH_COOKIE_SAMESITE=none requires REFRESH_COOKIE_SECURE=true');
  }
  if (env.NODE_ENV === 'production') errors.push(...productionGuards(env));

  return errors.length > 0
    ? { ok: false, errors }
    : { ok: true, data: env, database: database.data };
}
