# Node Backend Baseline

An **Express 5 + MySQL** backend baseline: sign-up, login, rotating refresh tokens, role-based access control, password recovery and user management. It uses **raw SQL** and a small, readable data layer.

It is the Node.js twin of a FastAPI service and is built the same way on purpose: `router → service → fetchOne / fetchAll / execute helpers`, one exception hierarchy, one standard API response, a request-context store and structured logging. If you know the FastAPI code you already know where everything is (see the [cheat sheet](#fastapi-to-express-cheat-sheet)).

## Contents

1. [Overview](#1-overview)
2. [Quick start](#2-quick-start)
3. [Project structure](#3-project-structure)
4. [How a request flows](#4-how-a-request-flows)
5. [Roles and authorization (RBAC)](#5-roles-and-authorization-rbac)
6. [Database](#6-database)
7. [The data layer: writing SQL](#7-the-data-layer-writing-sql)
8. [Authentication and sessions](#8-authentication-and-sessions)
9. [Password recovery (security questions)](#9-password-recovery-security-questions)
10. [Standard API response and error handling](#10-standard-api-response-and-error-handling)
11. [API reference](#11-api-reference)
12. [Cross-cutting concepts](#12-cross-cutting-concepts)
13. [Configuration reference](#13-configuration-reference)
14. [Adding a new module](#14-adding-a-new-module)
15. [Rules we follow](#15-rules-we-follow)
16. [Decisions log](#16-decisions-log)
17. [Deployment and production checklist](#17-deployment-and-production-checklist)
18. [Frontend integration notes](#18-frontend-integration-notes)
19. [Troubleshooting](#19-troubleshooting)
20. [Known limitations and future extensions](#20-known-limitations-and-future-extensions)

---

## 1. Overview

### What you get

- **Authentication**: e-mail + password sign-in, a short-lived access token (JWT) and a rotating refresh token in an `httpOnly` cookie, with reuse detection.
- **Authorization**: `super_admin > admin > member`, enforced at route level and per target user, re-read from the database on every request.
- **Account lifecycle**: active / inactive / deleted users and active / inactive / deleted roles, with the rules written down in one place ([section 5](#account-states)).
- **Password recovery without e-mail**: peppered security answers, lockout, single-use reset tokens.
- **User management** for admins: create, list, search, update, activate, change role, reset password, delete.
- **Data layer**: `BaseRepository` and `fetchOne` / `fetchAll` / `fetchPage` / `execute` / `executeMany` in **one file**, named `:parameters`, transactions, MySQL errors translated once.
- **Foundations**: validated configuration (`DB_URL` or local credentials), standard API response, error hierarchy, request-context store, structured logging, rate limiting, graceful shutdown, health probes, Docker.

### Technology

| Concern | Choice |
| --- | --- |
| Runtime | Node.js 22+, ES modules |
| HTTP | Express 5 (async handlers need no `try/catch`: a rejected promise reaches the error handler) |
| Database | MySQL 8.0.16+ through `mysql2`, **no ORM**, prepared statements with named parameters |
| Validation | `zod` |
| Passwords / tokens | `bcrypt`, `jsonwebtoken` (HS256), SHA-256 digests for stored tokens |
| Logging | `pino` (JSON), `pino-pretty` in development |
| Hardening | `helmet`, `cors` allow-list, `express-rate-limit`, `compression` |

### FastAPI to Express cheat sheet

| FastAPI project | This project |
| --- | --- |
| `AppException` and subclasses (`app/core/exceptions.py`) | `AppError` and one class per status in `src/errors/` (`statusCode`, `message`, `details`, `cause`, `headers`) |
| `GlobalExceptionHandler` | `src/middlewares/errorHandler.middleware.js` |
| `ApiResponse.ok(data=..., message=...)` | `ApiResponse.ok(res, { data, message })` (`src/utils/response.js`) |
| `BaseRepository` + `fetch_one`, `fetch_all`, `fetch_page`, `execute`, `execute_many` | `src/database/baseRepository.js`: the class **and** `fetchOne`, `fetchAll`, `fetchPage`, `execute`, `executeMany` in one file |
| `:name` parameters and a dict | `:name` parameters and an object |
| `DatabaseError` wrapping every driver error | `DatabaseError`; connection loss and deadlocks become `503`, duplicates `409` |
| `DB_QUERY_TIMEOUT_MS` | same variable (a session `max_execution_time`, see [section 7](#query-timeout)) |
| `AuthService(conn)` + `Depends(_get_service)` | `new AuthService()` in the router; the connection defaults to the pool |
| `self._conn` | `this.conn` |
| `_get_user_by_email`, `_log_login_attempt` (private helpers) | `#getPasswordHash`, `#recordFailedLogin` (private `#` methods) |
| Pydantic schemas | `zod` schemas in `*.schema.js`, applied by `validate()` |
| `get_settings()` | `config` from `src/config`, validated at startup |
| `get_logger(__name__)` | `createLogger('module')` |
| `update_request_identity(user_id=...)` | `requestContext.setUser(user)` (called by `authenticate`) |
| `Depends(require_roles(...))` | `authenticate()` then `authorize(ROLES.ADMIN)` |

---

## 2. Quick start

### Prerequisites

- Node.js 22 or newer (`.nvmrc` is provided)
- A MySQL 8 server. The `db:*` scripts need an account that may `CREATE DATABASE`, unless the database already exists.

### Steps

```bash
# 1. Install
npm install

# 2. Configure
cp .env.example .env
#    Edit the database section (see "Connecting to MySQL" below) and generate real secrets
#    (see "Generating secrets").

# 3. Create the database (schema + required seed + demo users)
npm run db:setup:demo        # development
# npm run db:setup           # production-safe: schema + seed only, NO demo users

# 4. Run
npm run dev                  # watch mode + pretty logs
npm start                    # plain
```

The API is now on `http://localhost:3000/api/v1` (probes on `/health`).

### Connecting to MySQL

The app connects in **one of two ways**; the choice is made in `src/config/database.js`:

| | Set in `.env` | Used when |
| --- | --- | --- |
| **1. `DB_URL`** | `DB_URL=mysql://user:password@host:3306/database` | `DB_URL` is set. It wins, and the local values below are ignored |
| **2. Local database** | `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` | `DB_URL` is empty |

- Percent-encode special characters in the URL's user and password (`@` = `%40`, `/` = `%2F`, `:` = `%3A`, `#` = `%23`, `%` = `%25`).
- Query parameters in `DB_URL` are rejected, because silently ignoring `?ssl-mode=REQUIRED` would connect **without** encryption. Turn TLS on with `DB_SSL=true` instead.
- At startup the log line `Connected to MySQL` says which mode was used (`via: DB_URL` or `via: local credentials`). The password is never logged.
- The `db:*` scripts use the same rule, so `npm run db:setup` also works against a database given by `DB_URL`.

### Demo accounts (development only, `seed.demo.sql`)

| Role | E-mail | Password |
| --- | --- | --- |
| Super admin | value of `SUPER_ADMIN_EMAIL` (`superadmin@example.com` in `.env.example`) | `SuperAdmin@12345` (the hash in `.env.example`) |
| Admin | `demo.admin@example.com` | `Admin@12345` |
| Member | `demo.member@example.com` | `Member@12345` |

These passwords are public. `seed.demo.sql` must never be loaded in production (the `db:*` scripts refuse to, when `NODE_ENV=production`).

### Generating secrets

```bash
# JWT_ACCESS_SECRET and SECURITY_ANSWER_PEPPER (run twice, use two different values)
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"

# SUPER_ADMIN_PASSWORD_HASH (prompts for the password, input hidden)
npm run hash-password
```

Keep the single quotes around the hash in `.env` (`SUPER_ADMIN_PASSWORD_HASH='$2b$12$...'`): it contains `$` characters.

### Create the runtime database user (recommended)

The application itself never needs DDL rights:

```sql
CREATE USER 'app_user'@'%' IDENTIFIED BY 'a-strong-password';
GRANT SELECT, INSERT, UPDATE, DELETE ON node_backend_baseline.* TO 'app_user'@'%';
```

Put an account that may `CREATE DATABASE` in `DB_ADMIN_USER` / `DB_ADMIN_PASSWORD`; only the `db:*` scripts use it.

### Docker alternative

```bash
cp .env.example .env
docker compose up --build        # MySQL 8.4 (schema + seed + demo auto-loaded) + the API
```

`docker-compose.yml` is a **development** stack, and its API container always uses the compose MySQL (a `DB_URL` in `.env` is ignored there). See [section 17](#17-deployment-and-production-checklist) for production.

### Try it (curl)

```bash
B=http://localhost:3000/api/v1

# log in (the refresh token is stored in the cookie jar, never in the body)
curl -s -c jar.txt -H 'Content-Type: application/json' \
     -d '{"email":"demo.admin@example.com","password":"Admin@12345"}' $B/auth/login

# call a protected route with the access token from the response
curl -s -H "Authorization: Bearer <accessToken>" "$B/admin/users?limit=5"

# rotate the refresh token (cookie only, no body)
curl -s -b jar.txt -c jar.txt -X POST $B/auth/refresh
```

### npm scripts

| Script | What it does |
| --- | --- |
| `npm start` / `npm run dev` | Run the API / run with `node --watch` |
| `npm run db:schema` | Create the database (if missing) and all tables |
| `npm run db:seed` | Required data: super-admin row + roles (idempotent) |
| `npm run db:seed:demo` | Demo users (development only) |
| `npm run db:setup` | schema + seed |
| `npm run db:setup:demo` | schema + seed + demo users |
| `npm run db:reset` | **DROP** the database, then `setup:demo` (refuses in production) |
| `npm run hash-password` | Generate `SUPER_ADMIN_PASSWORD_HASH` |
| `npm run lint` / `lint:fix` | ESLint |
| `npm run format` / `format:check` | Prettier |

The `.sql` files never name the database, so no file needs editing when `DB_NAME` (or the database in `DB_URL`) is not `node_backend_baseline`.

---

## 3. Project structure

```
.
├── src/
│   ├── server.js                      # entry point: start-up checks, listen, graceful shutdown
│   ├── app.js                         # the Express app: middleware order, routes, error handling
│   ├── config/
│   │   ├── env.js                     # zod validation of every environment variable (fails fast)
│   │   ├── database.js                # DB_URL, or the local credentials -> one connection config
│   │   └── index.js                   # the frozen `config` object (the only reader of process.env)
│   ├── constants/                     # roles, error codes, security questions
│   ├── context/requestContext.js      # AsyncLocalStorage: requestId, ip, acting user
│   ├── database/
│   │   ├── baseRepository.js          # BaseRepository + fetchOne/fetchAll/fetchPage/execute/executeMany
│   │   ├── transaction.js             # withTransaction: commit, rollback, deadlock retry
│   │   ├── pool.js                    # the mysql2 pool (named parameters, UTC, query timeout)
│   │   └── index.js                   # what services import
│   ├── errors/                        # AppError, one class per HTTP status, DatabaseError
│   ├── middlewares/                   # authenticate, authorize, validate, rate limiters, error handler...
│   ├── modules/                       # one folder per feature (see "The module contract")
│   │   ├── index.js                   # the only place that mounts modules
│   │   ├── auth/                      # sign-up, login, tokens, password change, recovery
│   │   │   ├── auth.router.js / auth.schema.js / auth.service.js
│   │   │   ├── securityProfile.service.js   # the recovery questions of a user
│   │   │   ├── recovery.service.js    # forgot-password: questions -> verify -> reset
│   │   │   ├── token.service.js       # access tokens, refresh-token rotation
│   │   │   ├── securityAnswers.js     # normalise + pepper + hash answers
│   │   │   └── auth.cookies.js
│   │   ├── users/                     # /users/me, the user lookups, the account-state rules
│   │   │   ├── users.router.js / users.schema.js / users.service.js
│   │   │   ├── users.rules.js         # deleted / inactive / no-role rules (pure functions)
│   │   │   └── users.mapper.js        # database row -> internal user -> JSON
│   │   ├── admin/                     # user management; admin.policy.js = who may act on whom
│   │   ├── roles/                     # assignable roles
│   │   └── health/                    # /health/live and /health/ready
│   ├── bootstrap/                     # start-up checks: database/schema/roles, the super admin row
│   ├── jobs/cleanup.job.js            # purges expired tokens
│   └── utils/                         # response, logger, password, crypto, pagination, sql, validation...
├── database/mysql/
│   ├── schema.sql                     # tables only (never names the database)
│   ├── seed.sql                       # required rows: super-admin row + roles (idempotent)
│   └── seed.demo.sql                  # demo users (development only)
├── scripts/
│   ├── db.js                          # npm run db:*  (drop / schema / seed / reset)
│   ├── lib/dbTasks.js                 # what those commands do
│   └── hash-password.js               # npm run hash-password
├── .env.example                       # every setting, documented
├── Dockerfile  docker-compose.yml     # small non-root image / development stack
└── eslint.config.js  .prettierrc.json # code style
```

### The module contract

Every feature is a folder in `src/modules/` with three files. Each layer has one job:

| File | Job | Must not |
| --- | --- | --- |
| `<name>.router.js` | HTTP only: pick the middlewares, call the service, send `ApiResponse` | contain business rules or SQL |
| `<name>.schema.js` | `zod` schemas for `body`, `query` and `params` | |
| `<name>.service.js` | A class: business rules and the SQL, through the data-layer helpers | touch `req` / `res` |

Modules are mounted in `src/modules/index.js` and nowhere else. [Section 14](#14-adding-a-new-module) walks through adding one.

---

## 4. How a request flows

```
HTTP request
  │
  ▼  app.js (every request)
  requestContext → requestLogger → helmet → cors → compression → no-store → json/cookies → global rate limit
  │
  ▼  <module>.router.js (this route)
  [rate limiter] → authenticate() → authorize(...) → validate({ params, query, body }) → handler
  │
  ▼  handler (a few lines)
  const result = await someService.doThing(req.user, req.validated.body);
  ApiResponse.ok(res, { message, data: result });
  │
  ▼  <module>.service.js (business rules)
  assertActiveAccount(actor) → fetchOne(this.conn, sql, params) → decide → execute(...) → log → return
  │
  ▼  src/database (BaseRepository)
  prepared statement with named parameters → pool → MySQL
  │
  ▼  any error, anywhere above: `throw new SomeError(...)`
  errorHandler (the only place exceptions become responses) → { success: false, message, error: { code } }
```

### Layering rules

| Layer | Knows about | Never does |
| --- | --- | --- |
| Router | Express, services, schemas | SQL, business rules |
| Service | the data-layer helpers, rules/policies, errors | `req`, `res`, status codes |
| Rules / policies (`users.rules.js`, `admin.policy.js`) | plain objects | I/O of any kind (pure functions) |
| Data layer (`src/database`) | mysql2 | business rules |

Dependencies point one way: routers → services → data layer. A service may use another service (for example `AuthService` uses `UsersService`), and services never import routers.

### How a service gets its connection

Every service is a class bound to **one connection**, exactly like `AuthService(conn)` with `self._conn` in the FastAPI project:

```js
export class UsersService {
  constructor(conn = pool) {   // the pool by default: each query takes a connection and auto-commits
    this.conn = conn;
  }
}

const users = new UsersService();                                    // normal use (in a router)
await withTransaction((conn) => new UsersService(conn).softDelete(id)); // inside a transaction
```

---

## 5. Roles and authorization (RBAC)

### Roles

| Role | Level | Stored in | Purpose |
| --- | --- | --- | --- |
| `super_admin` | 1000 (in code) | `users` row **`user_id = 1`** only; **not** in `roles` | Top role, no restrictions, exactly one, credentials in ENV only |
| `admin` | 2 (`roles.role_level`) | `roles` + `user_roles` | User management |
| `member` | 1 (`roles.role_level`) | `roles` + `user_roles` | Default role of every sign-up |

### The super admin design

The super admin is a **reserved row, `users.user_id = 1`**, because `roles.created_by`, login logs and refresh tokens all have foreign keys to `users`. A purely virtual account would break them and lose the audit trail.

- The row holds only name and e-mail. At **every startup** they are synced from `SUPER_ADMIN_NAME` / `SUPER_ADMIN_EMAIL` (the row is also created, revived and re-activated if needed).
- It has **no** `user_passwords`, **no** `user_roles` and **no** security-profile row. The startup check refuses to run if someone wrote such rows for id 1.
- The password lives **only in ENV**, as a bcrypt hash (`SUPER_ADMIN_PASSWORD_HASH`), never as plain text. Login compares against it with bcrypt (constant time).
- "Only one super admin" is enforced structurally: there is no `super_admin` row in `roles`, so it can never be assigned through the API, and a second super admin cannot exist.
- Nobody can register with its e-mail (unique index).
- The super admin account is **managed by ENV, not by the API**. Change password, update profile, delete account and the recovery flow do not apply to it (`403 SUPER_ADMIN_PROTECTED`), and no admin endpoint can modify it, not even by the super admin itself.
- To rotate its password: generate a new hash (`npm run hash-password`), update the secret, restart. Existing sessions are not touched, see [limitations](#20-known-limitations-and-future-extensions).
- `created_by = 1` on a row means "created by the super admin"; `created_by = NULL` on a user means "self-registered".

### The hierarchy rule

> A user can manage only people ranked **strictly below** them: `super_admin > admin > member`.

Exceptions and additions that make it match the agreed behaviour:

- An **admin can create admins and promote a member to admin** (a role can be assigned if its level is ≤ the actor's own level). After that the new admin is a protected peer: other admins cannot edit, demote, deactivate, reset or delete them.
- **Nobody uses the admin endpoints on their own account** (`403 SELF_ACTION_NOT_ALLOWED`). That prevents self-lockout and self-escalation; use `/users/me` instead.
- **The super admin is invisible to admins**: it is left out of their user list and `GET /admin/users/1` answers `404`, so it cannot be targeted. Admins can still _view_ other admins (read-only).

### Permission matrix

| Action | Member | Admin | Super admin |
| --- | :---: | :---: | :---: |
| Sign up (always creates a Member) | public | | |
| Login, refresh, logout | ✓ | ✓ | ✓ |
| View own profile | ✓ | ✓ | ✓ (read-only) |
| Update own profile (name only; e-mail is immutable) | ✓ | ✓ | – |
| Change own password, manage own security profile | ✓ | ✓ | – (ENV) |
| Forgot password (security questions) | ✓ | ✓ | – (ENV) |
| Delete own account (soft delete, needs password) | ✓ | ✓ | – |
| List and view users | – | ✓ (super admin hidden) | ✓ all |
| Create a user (member or admin) | – | ✓ | ✓ |
| Update another user's profile | – | members only | anyone |
| Activate / deactivate | – | members only | anyone |
| Change a role | – | promote member → admin only | any direction |
| Reset another user's password | – | members only | anyone |
| Delete another user | – | members only | anyone |

"Anyone" never includes the super admin's own account.

### Two layers of authorization

1. **Route level**: `authenticate()` then `authorize(ROLES.ADMIN)` decide whether a _role_ may call an endpoint at all. The super admin always passes `authorize`.
2. **Instance level**: `admin.policy.js` decides whether _this actor_ may perform _this action_ on _that target_ (`assertCanManageUser`, `assertCanAssignRole`). They are pure functions: no database access.

The role is **never read from the token**. `authenticate` reloads the user from the database on every request, so a role change, deactivation or deletion takes effect on the user's very next request.

### Account states

The rules are written **once**, in `src/modules/users/users.rules.js` (pure functions). `authenticate()` applies them to every request, login and token refresh apply them before a session is opened, and every service method that acts for a user starts with them. Queries state the lifecycle filters explicitly too: `is_deleted = FALSE` on users, `is_active = TRUE AND is_deleted = FALSE` on roles.

| State | Flag | Can sign in | Can use the API |
| --- | --- | :---: | --- |
| Active | `users.is_active = 1` and an active role | ✓ | ✓ |
| Inactive | `users.is_active = 0` | ✓ | Only: view profile, refresh, logout, logout-all. Everything else → `403 ACCOUNT_INACTIVE` |
| No active role | the user's role is missing, inactive (`roles.is_active = 0`) or deleted (`roles.is_deleted = 1`) | ✗ `403 ROLE_NOT_ASSIGNED` | ✗ `403 ROLE_NOT_ASSIGNED` (the super admin is exempt) |
| Deleted | `users.is_deleted = 1` | ✗ (the user is "not found") | ✗ (access and refresh tokens stop working at once) |
| Must change password | `user_passwords.must_change_password = 1` | ✓ | Only: view profile, change password, refresh, logout, logout-all. Everything else → `403 PASSWORD_CHANGE_REQUIRED` |

- **Roles carry the flags, the user-role link does not.** `roles.is_active` switches a role off (its users have no role until they get another one) and `roles.is_deleted` retires it. `user_roles` has neither: it is only the one-row-per-user link, so a role change is always an `UPDATE`.
- **Inactive users can sign in on purpose**: they can see that they are inactive (`GET /users/me`) and sign out. They cannot recover a password either, because recovery counts as "doing something".
- **Deleted users must sign up again.** The unique e-mail index ignores deleted rows, so the address is free immediately.
- Strict is the default of `authenticate()`; a route opts out explicitly: `authenticate({ allowInactive: true, allowPasswordChangePending: true })`.

---

## 6. Database

### Entity relationships

```mermaid
erDiagram
  users ||--o| user_passwords : "credentials (none for super admin)"
  users ||--o| user_roles : "exactly one role (none for super admin)"
  roles ||--o{ user_roles : "assigned in"
  users ||--o| user_security_profiles : "recovery answers"
  users ||--o{ user_login_logs : "logins"
  users ||--o{ refresh_tokens : "sessions"
  users ||--o{ password_reset_tokens : "recovery tokens"
  users ||--o{ users : "created_by"
```

### Tables

| Table | Purpose |
| --- | --- |
| `users` | Identity. `is_active` = can sign in but cannot act. `is_deleted` = soft delete. `email_active` / `sso_id_active` are generated columns that are `NULL` for deleted rows, so the `UNIQUE` index only covers live users: a deleted account keeps its history **and** its e-mail is immediately free for a new account. Code looks users up by `email` with an explicit `is_deleted = FALSE`. |
| `user_passwords` | One row per user, overwritten on change. `must_change_password` forces a change at next login. `updated_at` doubles as "password last changed at" (invalidates older access tokens). |
| `roles` | Assignable roles (`member`, `admin`) with `role_level`, and the flags **`is_active`** (role switched off) and **`is_deleted`** (role retired). No `super_admin` row. |
| `user_roles` | One role per user (`user_id` is `UNIQUE`), so a role change is always an `UPDATE`. **No `is_active` / `is_deleted`**: those flags belong to `roles`. |
| `user_login_logs` | Every successful login and every failed attempt for a known account (`user_id` is `NOT NULL`, so unknown e-mails go to the application log only). |
| `refresh_tokens` | Only the SHA-256 digest of each token; rotation chain via `replaced_by_hash`. |
| `user_security_profiles` | Hashed answers to the recovery questions, plus `failed_attempts` / `locked_until`. |
| `password_reset_tokens` | Short-lived (10 min), single-use, digest only. |

### Conventions

- **UTC everywhere.** Every timestamp is `DATETIME(6)` in UTC; the pool uses `timezone: 'Z'` and every connection sets `time_zone = '+00:00'`. `updated_at` is not auto-updated by MySQL, so services set it explicitly.
- **Soft delete only.** Rows are never physically removed by the API (only expired tokens are purged, by the cleanup job). Every query on `users` filters `is_deleted = FALSE` explicitly.
- **Audit columns.** `created_by` / `updated_by` reference `users(user_id)`.
- **Booleans** are `TINYINT(1)`: the code converts them with `Boolean(...)`.
- **No `SELECT *` in application code**; columns are always listed explicitly.

### Differences from the original design

- `user_passwords.must_change_password BOOLEAN NOT NULL DEFAULT FALSE` was added (admin-created users and admin password resets need it).
- `user_roles` has **no** `is_active` / `is_deleted`; they stay on `roles` ([section 5](#account-states)).
- The SQL files **never name the database** (no `CREATE DATABASE`, no `USE`). `npm run db:schema` creates the database from code, and the MySQL Docker image runs the files inside `MYSQL_DATABASE`.

**Already have a database from the previous version?** The new code works with it as it is: the two old `user_roles` columns have defaults and are simply ignored. To match the new schema, drop them:

```sql
ALTER TABLE user_roles DROP COLUMN is_active, DROP COLUMN is_deleted;
```

`users` has no `updated_at` / `updated_by`, so profile edits are not audited at column level (see [future extensions](#20-known-limitations-and-future-extensions)). `sso_id` is unused in this baseline; it is an extension point.

### Seed files

| File | Contents | Environment |
| --- | --- | --- |
| `seed.sql` | Super-admin row (`user_id = 1`, placeholder name/e-mail, overwritten from ENV at startup) and the roles `member` (1) / `admin` (2). **Idempotent.** | every environment |
| `seed.demo.sql` | `demo.admin@example.com` and `demo.member@example.com` | development only |

### Running the SQL

```bash
npm run db:setup:demo        # or the individual db:schema / db:seed / db:seed:demo

# or manually, into a database that already exists:
mysql -u root -p node_backend_baseline < database/mysql/schema.sql
mysql -u root -p node_backend_baseline < database/mysql/seed.sql
```

Requirements: MySQL **8.0.16+** (expression defaults, enforced `CHECK` constraints); **8.4 LTS** recommended. There is no migration tool yet: for schema changes add numbered SQL files or adopt one (see future extensions).

---

## 7. The data layer: writing SQL

Everything that talks to MySQL lives in `src/database/`. A service never imports `mysql2` and never opens a connection: it imports the helpers.

```js
import { execute, fetchOne, fetchAll, fetchPage, withTransaction } from '../../database/index.js';
```

### The one file to read: `baseRepository.js`

Like the FastAPI `base_repository.py` and `query.py` merged into a single file, MySQL only. Read it top to bottom:

1. **Error handling**: how a MySQL failure becomes an `AppError`.
2. **`BaseRepository`**: runs one statement (named parameters, logging, error wrapping).
3. **The helpers** `fetchOne`, `fetchAll`, `fetchPage`, `execute`, `executeMany`: what services call. Each one is a one-line wrapper around `new BaseRepository(conn)`.

### The helpers

| Helper | Returns |
| --- | --- |
| `fetchOne(conn, sql, params)` | the first row as a plain object, or `null` |
| `fetchAll(conn, sql, params)` | an array of rows (`[]` when nothing matches) |
| `fetchPage(conn, sql, countSql, params, { skip, limit })` | `{ rows, total }`; `LIMIT :limit OFFSET :skip` is appended to `sql` |
| `execute(conn, sql, params)` | `{ affectedRows, insertId }` |
| `executeMany(conn, sql, paramsList)` | nothing; runs the statement once per entry |

`conn` is the pool (every call auto-commits) or the connection handed out by `withTransaction`. In the FastAPI project `execute` returns `rowcount`; here it returns an object because MySQL has no `RETURNING`: `insertId` is how you get the id of a new row.

```js
// one row, or null
const user = await fetchOne(
  this.conn,
  'SELECT user_id, full_name FROM users WHERE email = :email AND is_deleted = FALSE',
  { email },
);
if (!user) throw userNotFound();

// insert, and get the new id
const { insertId: userId } = await execute(
  this.conn,
  'INSERT INTO users (full_name, email, created_at) VALUES (:fullName, :email, :now)',
  { fullName, email, now: new Date() },
);

// update, and check that a row matched
const { affectedRows } = await execute(
  this.conn,
  'UPDATE users SET full_name = :fullName WHERE user_id = :userId AND is_deleted = FALSE',
  { fullName, userId },
);
if (affectedRows === 0) throw userNotFound();

// one page and the total
const { rows, total } = await fetchPage(
  this.conn,
  'SELECT user_id, full_name FROM users WHERE is_deleted = FALSE ORDER BY created_at DESC',
  'SELECT COUNT(*) AS total FROM users WHERE is_deleted = FALSE',
  {},
  { skip: 40, limit: 20 },
);
```

### Parameters

- SQL uses **named placeholders** (`:email`) and a params object. A name may appear several times (`... LIKE :search OR ... LIKE :search`).
- **Never** put a value into the SQL string. The only dynamic fragments allowed come from a whitelist, for example `ORDER BY ${SORT_COLUMNS[sortBy]}`.
- A missing or `undefined` parameter **throws** instead of silently becoming `NULL`. Pass `null` when you mean `NULL`.
- Pass `Date` objects for timestamps (stored as UTC). Pass `true` / `false` for booleans; MySQL returns `0` / `1`, so read them with `Boolean(row.flag)`.
- `LIKE` on user input: `containsPattern(term)` plus `ESCAPE` (see `AdminService.listUsers`).
- List the columns you need; no `SELECT *`.

### Transactions: `withTransaction`

```js
const userId = await withTransaction(async (conn) => {
  const id = await new UsersService(conn).createAccount({ ... });
  await new SecurityProfileService(conn).insert(id, profileRecord);
  return id; // returning commits
}); // throwing anywhere rolls back everything and re-throws
```

- `conn` works like the pool: pass it to the helpers, or build a service on it (`new TokenService(conn)`).
- Deadlocks are retried automatically (twice), so the callback must be safe to run again: do password hashing and other slow work **before** opening the transaction.
- If an outcome must stay committed (for example a failed-attempt counter), **return** a status from the callback and throw after the commit. `TokenService.rotateRefreshToken` does this.
- Transactions do not nest.

### Errors

A failed statement is logged **once**, with the SQL and the parameter **names** (never the values, they may be personal data), and thrown as an `AppError`. Services and the error handler therefore never see a raw driver error:

| MySQL situation | Thrown | Client gets |
| --- | --- | --- |
| duplicate key | `ConflictError` | `409` |
| deadlock, lock wait timeout | `ServiceUnavailableError` + `Retry-After: 1` | `503` |
| connection lost, pool closed | `ServiceUnavailableError` + `Retry-After: 5` | `503` |
| anything else (missing table, constraint, timeout...) | `DatabaseError` | `500` "Something went wrong" |

The driver's own error stays available as `error.cause` (for logs only). A service that expects a duplicate asks for it by index name:

```js
try {
  /* ...insert... */
} catch (err) {
  if (isDuplicateEntry(err, 'uq_users_email_active')) throw emailTaken(); // lost a race
  throw err;
}
```

### Query timeout

`DB_QUERY_TIMEOUT_MS` (default 30 seconds) is applied as the **session** variable `max_execution_time` whenever the pool opens a connection (`pool.js`). MySQL then cancels a `SELECT` that runs too long, cleanly, and the connection stays usable. A client-side timeout would have to abandon the socket in the middle of a read, which corrupts the connection.

The FastAPI code sets the variable before every statement. With a pool that `SET` could run on a *different* connection than the statement that follows, which is why it is set once per connection here. It applies to `SELECT` only; a cancelled query is logged as `Database query timed out`.

### Connection settings (`pool.js`)

- Connects with `DB_URL`, or with the local credentials ([section 2](#connecting-to-mysql)); TLS with `DB_SSL=true`.
- Every timestamp is UTC: the driver uses `timezone: 'Z'` and each connection runs `SET time_zone = '+00:00'`.
- `BIGINT` ids come back as numbers.
- `fetchPage` binds `LIMIT` / `OFFSET` as integer strings, because some MySQL 8.0.22+ and driver combinations reject JS numbers there. Callers still pass numbers; nobody else has to know.
- `affectedRows` counts rows **matched**, so an `UPDATE` that writes identical values still reports `1`.

---

## 8. Authentication and sessions

### Tokens

| | Access token | Refresh token |
| --- | --- | --- |
| Format | JWT, HS256 | 48 random bytes, opaque (64 chars, base64url) |
| Lifetime | 15 min (`ACCESS_TOKEN_TTL_MINUTES`) | 7 days (`REFRESH_TOKEN_TTL_DAYS`), sliding |
| Travels in | `Authorization: Bearer <token>` | `httpOnly` cookie `refresh_token` |
| Stored | nowhere (stateless) | **only its SHA-256 digest** (`refresh_tokens.token_hash`) |
| Claims | `sub`, `iat`, `exp`, `iss`, `aud` (**no role**) | n/a |

### Cookie attributes

`HttpOnly`, `SameSite=Strict` (configurable), `Secure` (default **on** in production), `Path=/api/v1/auth` (the browser only sends it to auth endpoints). The refresh token is **never** in a response body.

### Per-request check

For every authenticated request, `authenticate`:

1. verifies the JWT (algorithm pinned to HS256, issuer, audience, expiry);
2. **reloads the user, role and password state from the database**;
3. rejects tokens issued before the user's last password change (`iat < floor(user_passwords.updated_at)`; granularity is 1 second);
4. applies the account-state rules ([section 5](#account-states));
5. sets `req.user` and the acting user in the request context.

### Refresh-token rotation and reuse detection

`POST /auth/refresh` exchanges the cookie for a new access token **and a new refresh token**; the old one is revoked and linked to its replacement (`replaced_by_hash`).

| Situation | Result |
| --- | --- |
| Valid token | rotated, `200` |
| Unknown / revoked by logout or password change | `401 TOKEN_INVALID`, cookie cleared |
| Expired | `401 TOKEN_EXPIRED`, cookie cleared |
| Used again within `REFRESH_TOKEN_REUSE_LEEWAY_SECONDS` (10 s) of its rotation (parallel tabs) | benign `401 TOKEN_INVALID`; **nothing is revoked** and the cookie is left alone, the client retries with the newest cookie |
| An already-rotated token comes back **later** | treated as theft: **every active refresh token of that user is revoked**, `401 TOKEN_INVALID`, a warning is logged |
| User deleted | `401 TOKEN_INVALID` |
| The user no longer has an active role | `403 ROLE_NOT_ASSIGNED`, cookie cleared |

The row is locked (`FOR UPDATE`) while it is decided, so of N parallel refreshes with the same cookie exactly one wins. Long-expired rows are purged by the cleanup job; rotated tokens are kept until they expire so reuse detection keeps working.

### Login

`AuthService.login` reads like the FastAPI `login`: look up, verify, check the account state, open the session.

1. Look up the account by e-mail. Soft-deleted users are never found.
2. Verify the password: against `user_passwords` for everyone, against `SUPER_ADMIN_PASSWORD_HASH` for the super admin.
3. Unknown e-mail and wrong password produce the **same** `401 INVALID_CREDENTIALS` and the **same CPU cost** (`verifyPassword(password, null)` still runs one bcrypt comparison), so neither the message nor the timing reveals which e-mails exist.
4. Account state ([section 5](#account-states)): an **inactive** user may sign in (afterwards they can only view their profile and sign out); a user **without an active role** is refused with `403 ROLE_NOT_ASSIGNED`, because a session would be useless to them.
5. On success, in one transaction: update `last_login`, write a `SUCCESS` login log, issue the refresh token. A failed attempt for a known account writes a `FAILURE` log row (`INVALID_PASSWORD`, or `NO_PASSWORD_SET`); unknown e-mails go to the application log only.

Brute force on login is limited by rate limiting per IP **and** e-mail (10 failed attempts per 15 minutes by default). There is deliberately no per-account lockout on login (it would let anyone lock a victim out); the per-account lockout belongs to the recovery flow.

### Sign-up

`POST /auth/register` always creates a **member**, writes four tables in one transaction (`users`, `user_passwords`, `user_roles`, `user_security_profiles`) and does **not** sign the user in. The security profile is mandatory at sign-up. Set `SELF_REGISTRATION_ENABLED=false` to close public sign-up.

### Passwords

- Policy: 8 to **72 bytes** (bcrypt only uses the first 72 bytes), at least one lowercase, uppercase, digit and special character. Every broken rule is reported at once.
- bcrypt, cost 12 (`BCRYPT_ROUNDS`, at least 10 in production).
- **Change password** needs the current password. It revokes **all** refresh tokens, invalidates all older access tokens, and signs the _calling device_ back in with a brand-new session in the same transaction (other devices are signed out).
- **Admin-created users and admin resets** use a system-generated temporary password (16 characters, always policy-compliant, no look-alike characters), shown **once**, with `must_change_password = 1`. Until it is changed the user can only view their profile and change the password. Admins never choose or see a real password.

---

## 9. Password recovery (security questions)

There is no e-mail service, so recovery uses security questions chosen at sign-up.

### The questions

- **Three fixed questions** for everyone: date of birth, and two questions defined in `src/constants/securityQuestions.js` ("In which city were you born?", "What was the name of your first school?"). Only hashed answers are stored.
- **Up to two custom questions** written by the user. Their text is stored (the answer is hashed). A custom question and its answer exist together or not at all (a `CHECK` constraint).
- `GET /auth/security-questions` (public) returns the fixed questions so a sign-up form can render them.

### How answers are stored

Security answers are low-entropy (a date of birth has about 35,000 plausible values), so a plain bcrypt hash would be crackable offline after a database leak. Each answer goes through:

1. **Normalisation**: trim, collapse whitespace, Unicode NFKC, lower-case (`"  New   York "` equals `"new york"`).
2. **Pepper**: HMAC-SHA256 with `SECURITY_ANSWER_PEPPER` (lives in ENV, not in the database), bound to the question key.
3. **bcrypt** of that digest.

Plain answers are never stored or logged. Rotating the pepper invalidates every stored answer.

### The flow

| Step | Endpoint | Result |
| --- | --- | --- |
| 1 | `POST /auth/forgot-password/questions` `{ email }` | The three fixed questions plus the account's custom ones. Unknown and inactive accounts get the same shape (the three fixed questions). |
| 2 | `POST /auth/forgot-password/verify` `{ email, answers }` | If **every** answer is right: a reset token (10 min, single use). Otherwise `401 INVALID_SECURITY_ANSWERS` (it never says which answer was wrong). |
| 3 | `POST /auth/forgot-password/reset` `{ resetToken, newPassword }` | Sets the new password, revokes every session. |

Properties:

- **Lockout**: after **5** wrong attempts the account is locked for **15 minutes** (`429 ACCOUNT_LOCKED` + `Retry-After`), even correct answers are refused while locked. The profile row is locked (`FOR UPDATE`) while answers are checked, so parallel guessing cannot slip past the counter.
- Only **active** accounts can recover a password, and a reset token stops working if the account is deactivated before it is used.
- A malformed date of birth is a `422` and does not count as an attempt.
- A new verification invalidates the previous reset token; the token is stored only as a SHA-256 digest and is consumed atomically.
- Unknown e-mails, the super admin, inactive accounts and accounts without a profile all get the same generic `401` after the same CPU cost.
- Per-IP + e-mail rate limiting sits in front (10 per 15 minutes by default).

### Managing the profile

- Managed by `SecurityProfileService`; the flow above is `RecoveryService`.
- `GET /auth/security-profile`: is it configured, and the user's custom questions (never answers).
- `PUT /auth/security-profile`: create or replace it. Needs the **current password**, because the answers are a second way into the account and a stolen access token alone must not be able to change them. Admin-created users have no profile until they do this after their first login; forgot-password is unavailable to them until then (an admin reset is the fallback).

### Known trade-offs (inherent to security questions)

Security questions are weaker than e-mail or MFA recovery. Mitigations here: pepper + bcrypt, lockout, rate limits, single-use short-lived tokens, and all sessions revoked on reset. The lockout also means someone who knows a registered e-mail can lock that user's recovery for 15 minutes, and a lock reveals that the account exists. Consider MFA (TOTP) as a future extension.

---

## 10. Standard API response and error handling

There are exactly **two** response shapes. The HTTP status code is the source of truth, so the body does not repeat it.

**Success**

```json
{
  "success": true,
  "message": "Users fetched successfully",
  "data": [],
  "meta": { "page": 1, "limit": 20, "total": 134, "totalPages": 7 },
  "requestId": "b1c2d3e4-..."
}
```

- `data` is `null` when there is nothing to return.
- `meta` appears only on paginated lists.
- Convention for `data`: a single resource is the object itself; a list is an array (with `meta`); an endpoint returning several things uses a named object (`{ user, temporaryPassword }`, `{ accessToken, user }`).

**Failure**

```json
{
  "success": false,
  "message": "Validation failed",
  "error": {
    "code": "VALIDATION_ERROR",
    "details": [{ "field": "email", "message": "Invalid email address" }]
  },
  "requestId": "b1c2d3e4-..."
}
```

- `details` is optional (validation issues; the failing probe of a readiness check).
- `requestId` comes from the request context store and matches every log line of that request (also returned as the `X-Request-Id` header).
- **Unexpected errors return a generic message**; the stack trace and cause go to the logger only.

Helpers (`src/utils/response.js`): `ApiResponse.ok(res, { message, data, meta })` for `200` and `ApiResponse.created(res, { ... })` for `201`. Handlers never send failures: they throw an `AppError` and the error handler calls `ApiResponse.fail`.

### Custom exception classes

Throw these from services and routers (`src/errors/`). They all extend `AppError` (the twin of `AppException`). Constructor: `new XxxError(message?, { code?, details?, cause?, headers? })`. `headers` are added to the response (for example `Retry-After`); `cause` is the original error, which is logged and **never** sent to the client.

| Class | HTTP | Default code |
| --- | :---: | --- |
| `BadRequestError` | 400 | `BAD_REQUEST` |
| `UnauthorizedError` | 401 | `UNAUTHORIZED` |
| `ForbiddenError` | 403 | `FORBIDDEN` |
| `NotFoundError` | 404 | `NOT_FOUND` |
| `ConflictError` | 409 | `CONFLICT` |
| `PayloadTooLargeError` | 413 | `PAYLOAD_TOO_LARGE` |
| `ValidationError` | 422 | `VALIDATION_ERROR` |
| `TooManyRequestsError` | 429 | `RATE_LIMITED` |
| `InternalServerError` | 500 | `INTERNAL_ERROR` |
| `ServiceUnavailableError` | 503 | `SERVICE_UNAVAILABLE` |
| `DatabaseError` | 500 | `INTERNAL_ERROR` (thrown by the data layer; the client only sees the generic message) |

### Error codes

| Code | HTTP | Meaning |
| --- | :---: | --- |
| `VALIDATION_ERROR` | 422 | Body / query / params failed validation (also unknown fields) |
| `BAD_REQUEST` | 400 | Malformed JSON and other generic client errors |
| `INVALID_CURRENT_PASSWORD` | 400 | Wrong current password (deliberately not 401: clients must not treat it as an expired session) |
| `RESET_TOKEN_INVALID` | 400 | Password-reset token unknown, used, superseded or expired |
| `UNAUTHORIZED` | 401 | Missing / malformed `Authorization` header |
| `TOKEN_INVALID` | 401 | Bad, revoked or no-longer-valid token (also after a password change) |
| `TOKEN_EXPIRED` | 401 | Expired access or refresh token |
| `INVALID_CREDENTIALS` | 401 | Wrong e-mail or password |
| `INVALID_SECURITY_ANSWERS` | 401 | Recovery answers incorrect |
| `INSUFFICIENT_ROLE` | 403 | The role (or hierarchy) does not allow it |
| `ACCOUNT_INACTIVE` | 403 | `is_active = 0` |
| `PASSWORD_CHANGE_REQUIRED` | 403 | `must_change_password = 1` |
| `SUPER_ADMIN_PROTECTED` | 403 | Action not applicable to the ENV-managed super admin |
| `SELF_ACTION_NOT_ALLOWED` | 403 | Admin endpoint used on one's own account |
| `ROLE_NOT_ASSIGNED` | 403 | The account has no active role (login, token refresh and every request) |
| `REGISTRATION_DISABLED` | 403 | `SELF_REGISTRATION_ENABLED=false` |
| `CORS_ORIGIN_NOT_ALLOWED` | 403 | Origin not in `CORS_ORIGINS` |
| `USER_NOT_FOUND` / `ROLE_NOT_FOUND` / `ROUTE_NOT_FOUND` / `NOT_FOUND` | 404 | Resource not found |
| `EMAIL_ALREADY_EXISTS` / `CONFLICT` | 409 | Duplicate |
| `PAYLOAD_TOO_LARGE` | 413 | Body over 100 kb |
| `RATE_LIMITED` | 429 | Rate limit hit (`Retry-After` is sent) |
| `ACCOUNT_LOCKED` | 429 | Recovery locked after 5 wrong attempts (`Retry-After`) |
| `INTERNAL_ERROR` | 500 | Unexpected error (generic message) |
| `SERVICE_UNAVAILABLE` | 503 | Database unavailable / busy (`Retry-After`) |

---

## 11. API reference

Base URL: `/api/v1`. Probes live at `/health` (unversioned). Bodies are JSON (`Content-Type: application/json`, max 100 kb). Protected routes need `Authorization: Bearer <accessToken>`.

Legend for "Access": 🌐 public · 🍪 refresh cookie · 🔑 Bearer token (the role in brackets).

### Auth: `/auth`

| Method | Path | Access | Description |
| --- | --- | --- | --- |
| GET | `/auth/security-questions` | 🌐 | The fixed recovery questions |
| POST | `/auth/register` | 🌐 | Sign up (member). `201` |
| POST | `/auth/login` | 🌐 | Sign in → access token + cookie (`403 ROLE_NOT_ASSIGNED` if the account has no active role) |
| POST | `/auth/refresh` | 🍪 | Rotate the refresh token |
| POST | `/auth/logout` | 🍪 | End this session (idempotent) |
| POST | `/auth/logout-all` | 🔑 any (inactive / must-change allowed) | End every session |
| POST | `/auth/change-password` | 🔑 member, admin (must-change allowed) | Change password, keep this device signed in |
| GET | `/auth/security-profile` | 🔑 member, admin | Is the recovery profile configured? |
| PUT | `/auth/security-profile` | 🔑 member, admin | Create / replace the recovery profile |
| POST | `/auth/forgot-password/questions` | 🌐 | Questions for an e-mail |
| POST | `/auth/forgot-password/verify` | 🌐 | Verify answers → reset token |
| POST | `/auth/forgot-password/reset` | 🌐 | Set a new password with the token |

### Users (self-service): `/users`

| Method | Path | Access | Description |
| --- | --- | --- | --- |
| GET | `/users/me` | 🔑 any (inactive / must-change allowed) | Own profile |
| PATCH | `/users/me` | 🔑 member, admin | Update own **full name** (e-mail is immutable) |
| DELETE | `/users/me` | 🔑 member, admin | Delete own account. Body `{ "password": "..." }` (re-authentication) |

### Admin: `/admin` (admin and super admin)

| Method | Path | Description |
| --- | --- | --- |
| GET | `/admin/users` | List users. Query: `page`, `limit` (1-100, default 20), `search` (name or e-mail), `role` (`admin`/`member`), `isActive`, `sortBy` (`createdAt`, `fullName`, `email`, `lastLogin`), `sortOrder` (`asc`/`desc`) |
| POST | `/admin/users` | Create a user `{ fullName, email, role }` → temporary password (shown once). `201` |
| GET | `/admin/users/:userId` | Get one user |
| PATCH | `/admin/users/:userId` | Update the full name |
| PATCH | `/admin/users/:userId/role` | Change role `{ role: "admin" \| "member" }` |
| PATCH | `/admin/users/:userId/status` | Activate / deactivate `{ isActive: true \| false }` |
| POST | `/admin/users/:userId/reset-password` | Reset password → temporary password (shown once) |
| DELETE | `/admin/users/:userId` | Soft-delete the user |

Which targets an admin may act on is defined in [section 5](#5-roles-and-authorization-rbac).

### Other

| Method | Path | Access | Description |
| --- | --- | --- | --- |
| GET | `/roles` | 🔑 admin, super admin | Assignable roles with an `assignable` flag per caller; `?assignable=true` filters |
| GET | `/health`, `/health/live` | 🌐 | Liveness (no dependencies) |
| GET | `/health/ready` | 🌐 | Readiness: database ping, `503` when down |

### Examples (real responses)

**Sign up**: `POST /auth/register`

```json
{
  "fullName": "Aditi Singh",
  "email": "aditi@example.com",
  "password": "Str0ng!Pass",
  "securityProfile": {
    "dob": "1990-05-21",
    "q2": "Dehradun",
    "q3": "St Joseph Academy",
    "customQuestions": [{ "question": "What was the name of my first pet?", "answer": "Bruno" }]
  }
}
```

```json
{
  "success": true,
  "message": "Account created successfully",
  "data": {
    "userId": 4,
    "fullName": "Aditi Singh",
    "email": "aditi@example.com",
    "role": "member",
    "isActive": true,
    "lastLogin": null,
    "createdAt": "2026-10-28T18:22:46.976Z",
    "mustChangePassword": false,
    "hasSecurityProfile": true
  },
  "requestId": "b19bd40c-4c23-41bf-8cdc-5b3817686519"
}
```

**Login**: `POST /auth/login` `{ "email": "...", "password": "..." }` → `200` and `Set-Cookie: refresh_token=...; Path=/api/v1/auth; HttpOnly; SameSite=Strict`

```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5...",
    "tokenType": "Bearer",
    "expiresIn": 900,
    "user": {
      "userId": 4,
      "fullName": "Aditi Singh",
      "email": "aditi@example.com",
      "role": "member",
      "isActive": true,
      "lastLogin": "2026-10-28T18:22:47.317Z",
      "createdAt": "2026-10-28T18:22:46.976Z",
      "mustChangePassword": false,
      "hasSecurityProfile": true
    }
  },
  "requestId": "eeec4bb7-0190-473a-8618-f58401908034"
}
```

**Admin creates a user**: `POST /admin/users` `{ "fullName": "Rita Kumari", "email": "rita@example.com", "role": "member" }` → `201`

```json
{
  "success": true,
  "message": "User created. Share the temporary password through a secure channel; it is shown only once and must be changed at first login",
  "data": {
    "user": {
      "userId": 5,
      "fullName": "Rita Kumari",
      "email": "rita@example.com",
      "role": "member",
      "isActive": true,
      "lastLogin": null,
      "createdAt": "2026-10-28T18:22:48.003Z"
    },
    "temporaryPassword": "q?FwvsF9@6JX&ev7"
  },
  "requestId": "70aa6d54-309e-44cd-8c88-6a9b1980c2b3"
}
```

**Paginated list**: `GET /admin/users?limit=2&sortBy=createdAt&sortOrder=asc`

```json
{
  "success": true,
  "message": "Users fetched successfully",
  "data": [
    {
      "userId": 2,
      "fullName": "Demo Admin",
      "email": "demo.admin@example.com",
      "role": "admin",
      "isActive": true,
      "lastLogin": "2026-10-28T18:22:47.670Z",
      "createdAt": "2026-10-28T18:22:42.526Z"
    },
    {
      "userId": 3,
      "fullName": "Demo Member",
      "email": "demo.member@example.com",
      "role": "member",
      "isActive": true,
      "lastLogin": null,
      "createdAt": "2026-10-28T18:22:42.526Z"
    }
  ],
  "meta": { "page": 1, "limit": 2, "total": 4, "totalPages": 2 },
  "requestId": "4e3ca103-5efd-4d10-b041-da82d167e0ae"
}
```

**Validation failure** (every broken rule is reported at once; unknown fields are rejected):

```json
{
  "success": false,
  "message": "Validation failed",
  "error": {
    "code": "VALIDATION_ERROR",
    "details": [
      { "field": "fullName", "message": "Full name must be at least 2 characters" },
      { "field": "email", "message": "Invalid email address" },
      { "field": "password", "message": "Password must contain a digit" },
      { "field": "securityProfile", "message": "This field is required" },
      { "field": "role", "message": "Unrecognized field" }
    ]
  },
  "requestId": "10fc046c-4bbe-4f9f-9cf4-f882d092295e"
}
```

**Forgot password**

```text
POST /auth/forgot-password/questions   { "email": "aditi@example.com" }
  -> data.questions: [ {key:"dob"}, {key:"q2"}, {key:"q3"}, {key:"custom1", question:"What was the name of my first pet?"} ]

POST /auth/forgot-password/verify
  { "email": "aditi@example.com",
    "answers": { "dob": "1990-05-21", "q2": "dehradun", "q3": "St Joseph Academy", "custom1": "bruno" } }
  -> 200 { "data": { "resetToken": "qOT3lgljFSalKCNT...", "expiresAt": "...", "expiresInSeconds": 600 } }
  -> 401 INVALID_SECURITY_ANSWERS   (wrong answer; 5th wrong attempt -> 429 ACCOUNT_LOCKED)

POST /auth/forgot-password/reset       { "resetToken": "...", "newPassword": "N3w-Passw0rd!" }
  -> 200  (all sessions revoked; sign in with the new password)
```

**Change password** returns a fresh session for the calling device: `data: { accessToken, tokenType, expiresIn }` plus a new refresh cookie.

---

## 12. Cross-cutting concepts

### Request Context Store

`src/context/requestContext.js` wraps `AsyncLocalStorage`. The first middleware opens a store for each request and everything running inside the request can read it without it being passed through every function:

```
{ requestId, ip, userAgent, method, path, user: { userId, role } | null }
```

It is used for: the `requestId` in every log line and API response, the IP / user agent written to login logs and refresh tokens (`requestContext.getMeta()`), and the acting user in logs. **Authorization never reads from it**: services receive `actor` explicitly. Outside a request (scripts) it is simply empty.

The incoming `X-Request-Id` is adopted if it is short and harmless (`[A-Za-z0-9._-]`, 8-128 chars), otherwise a UUID is generated.

### Logger

`pino`, structured JSON on stdout (12-factor: let the platform collect and ship it). In development `pino-pretty` renders the same lines readably.

- Every line written during a request automatically carries `requestId` (and `userId` once authenticated) through the logger's mixin.
- `createLogger('module')` gives a child logger tagged with the module name.
- **Redaction**: `password`, `newPassword`, `currentPassword`, `temporaryPassword`, tokens, `authorization`, `cookie`, `answers` and `securityProfile` are replaced by `[REDACTED]` at the top level and one level deep. E-mails in auth logs are masked (`a***@example.com`). Query strings are never logged.
- One `Request completed` line per request: `error` for 5xx, `warn` for 4xx, `info` otherwise (`debug` for `/health`).
- A failed statement logs `Database query failed` once, with the SQL and the parameter **names** (never the values); see [section 7](#errors).

```json
{
  "level": "info",
  "time": "2026-10-28T18:22:47.320Z",
  "service": "node-backend-baseline",
  "env": "production",
  "module": "auth",
  "requestId": "eeec4bb7-...",
  "userId": 4,
  "msg": "Login successful"
}
```

### Middlewares

In order of execution (`src/app.js`):

| # | Middleware | Purpose |
| --- | --- | --- |
| 1 | `requestContextMiddleware` | Opens the context store, assigns / echoes `X-Request-Id` |
| 2 | `requestLogger` | One structured line per request |
| 3 | `helmet` | Security headers |
| 4 | `cors` | Explicit allow-list (`CORS_ORIGINS`), credentials on, no wildcard |
| 5 | `compression` | gzip |
| 6 | no-store | `Cache-Control: no-store` (responses carry tokens and personal data) |
| 7 | `express.json` + `cookieParser` | Body (100 kb) and cookies |
| 8 | `globalLimiter` | Per-IP rate limit |
| 9 | routes | Module routers |
| 10 | `notFoundHandler` | `404 ROUTE_NOT_FOUND` |
| 11 | `errorHandler` | The only place exceptions become responses |

Route-level building blocks: `authenticate(options)`, `authorize(...roles)`, `denySuperAdmin`, `validate({ params, query, body })`, `authLimiter`, `loginLimiter`, `recoveryLimiter`.

`validate` places parsed values on **`req.validated.{params,query,body}`**; handlers read only from there (Express 5 makes `req.query` read-only).

### Rate limiting

| Limiter | Key | Default | Applies to |
| --- | --- | --- | --- |
| global | IP | 600 / 15 min | every request |
| auth | IP | 100 / 15 min | every `/auth/*` route, and `DELETE /users/me` |
| login | IP + e-mail | 10 / 15 min, failed attempts only | `POST /auth/login` |
| recovery | IP + e-mail | 10 / 15 min | the three forgot-password routes |

Standard `RateLimit` / `RateLimit-Policy` / `Retry-After` headers are sent, and a blocked request gets the standard `429 RATE_LIMITED` body. The default store is **in memory (per process)**: behind several instances use a shared store (see the production checklist). Disable with `RATE_LIMIT_ENABLED=false` (development only).

### Security measures at a glance

- Prepared statements with named parameters everywhere; whitelisted `ORDER BY`; `LIKE` wildcards in search are escaped.
- Strict input validation, unknown body fields rejected (no mass assignment, no `__proto__` tricks).
- bcrypt for passwords and (peppered) security answers; tokens stored only as SHA-256 digests.
- Short-lived stateless access token, rotating refresh token with reuse detection, `httpOnly` + `SameSite=Strict` + path-scoped cookie.
- Role and state re-read from the database on every request; access tokens die on password change.
- Constant-cost, identical-message login and recovery failures (no user enumeration by message or timing).
- Account lockout on recovery, rate limiting on every auth route.
- `helmet`, strict CORS allow-list, `no-store`, `X-Powered-By` removed, body size limit.
- Generic 500 responses; secrets redacted from logs; configuration validated at startup with production guards (placeholder secrets, the public example hash, weak bcrypt cost and wildcard CORS are all refused when `NODE_ENV=production`).
- CSRF: the only cookie-authenticated routes are `refresh` and `logout`. `SameSite=Strict`, the path-scoped cookie and the CORS allow-list protect them; if you need `SameSite=None` (cross-site frontend) add an `Origin` check or a CSRF header.

---

## 13. Configuration reference

All configuration comes from environment variables (a `.env` file is loaded; real variables win). Everything is validated at startup by `src/config/env.js`: the app refuses to start and prints every problem. Nothing in `src` outside `src/config` reads `process.env`.

| Variable | Default | Description |
| --- | --- | --- |
| `NODE_ENV` | `development` | `development`, `test` or `production` (enables the production guards) |
| `PORT` / `HOST` | `3000` / `0.0.0.0` | Listen address |
| `TRUST_PROXY` | `false` | Reverse-proxy hops (`1`, `loopback`, CIDRs). Needed for the real client IP |
| `CORS_ORIGINS` | none | Comma-separated allowed browser origins (no `*`) |
| `SELF_REGISTRATION_ENABLED` | `true` | Allow public sign-up |
| `SHUTDOWN_TIMEOUT_MS` | `10000` | Graceful-shutdown deadline |
| `LOG_LEVEL` | `info` | `fatal` … `trace`, `silent` |
| `LOG_PRETTY` | `true` in development | Needs the `pino-pretty` dev dependency |
| `DB_URL` | none | `mysql://user:password@host:3306/database`. **When set it wins** and the local `DB_*` values below are ignored. Percent-encode special characters; no query parameters (use `DB_SSL`) |
| `DB_HOST` / `DB_PORT` | `127.0.0.1` / `3306` | Local database (used when `DB_URL` is empty) |
| `DB_NAME` | `node_backend_baseline` | Local database. Letters, digits, `_` |
| `DB_USER` / `DB_PASSWORD` | **required** unless `DB_URL` is set / empty | Runtime user (DML only is enough) |
| `DB_ADMIN_USER` / `DB_ADMIN_PASSWORD` | falls back to the runtime user | Used **only** by `npm run db:*` (replaces the user and password, also with `DB_URL`) |
| `DB_CONNECTION_LIMIT` / `DB_QUEUE_LIMIT` | `10` / `0` | Pool size / queue (0 = unlimited) |
| `DB_CONNECT_TIMEOUT_MS` | `10000` | |
| `DB_QUERY_TIMEOUT_MS` | `30000` | A `SELECT` that runs longer is cancelled by MySQL (`max_execution_time`) |
| `DB_SSL`, `DB_SSL_CA_PATH`, `DB_SSL_REJECT_UNAUTHORIZED` | off / none / `true` | TLS to MySQL |
| `JWT_ACCESS_SECRET` | **required** (32+ chars) | HS256 signing secret |
| `ACCESS_TOKEN_TTL_MINUTES` | `15` | |
| `JWT_ISSUER` / `JWT_AUDIENCE` | `APP_NAME` / `APP_NAME-clients` | |
| `REFRESH_TOKEN_TTL_DAYS` | `7` | |
| `REFRESH_TOKEN_REUSE_LEEWAY_SECONDS` | `10` | Benign parallel-use window |
| `REFRESH_COOKIE_NAME` | `refresh_token` | |
| `REFRESH_COOKIE_SECURE` | `true` in production | |
| `REFRESH_COOKIE_SAMESITE` | `strict` | `strict`, `lax`, `none` (`none` requires Secure) |
| `REFRESH_COOKIE_DOMAIN` | none | |
| `BCRYPT_ROUNDS` | `12` | 4-15; at least 10 in production |
| `SECURITY_ANSWER_PEPPER` | **required** (32+ chars) | HMAC pepper for security answers |
| `SECURITY_MAX_FAILED_ATTEMPTS` | `5` | Wrong recovery attempts before the lock |
| `SECURITY_LOCK_MINUTES` | `15` | Lock duration |
| `PASSWORD_RESET_TOKEN_TTL_MINUTES` | `10` | |
| `SUPER_ADMIN_NAME` / `SUPER_ADMIN_EMAIL` | **required** | Synced into `users.user_id = 1` at every startup |
| `SUPER_ADMIN_PASSWORD_HASH` | **required** | bcrypt hash (`npm run hash-password`), single-quoted |
| `RATE_LIMIT_ENABLED` | `true` | |
| `RATE_LIMIT_WINDOW_MS` | `900000` | 15 minutes |
| `RATE_LIMIT_MAX` / `AUTH_RATE_LIMIT_MAX` / `LOGIN_RATE_LIMIT_MAX` / `RECOVERY_RATE_LIMIT_MAX` | `600` / `100` / `10` / `10` | See the table in section 12 |
| `CLEANUP_INTERVAL_MINUTES` | `60` | Token purge job; `0` disables it |

---

## 14. Adding a new module

A complete example: a `tasks` module where each user manages their own tasks. Every file below was run against this baseline.

**1. The table.** Append it to `database/mysql/schema.sql` (follow the conventions in [section 6](#6-database): UTC `DATETIME(6)`, soft delete, a foreign key to `users`), then `npm run db:reset`:

```sql
CREATE TABLE tasks (
  task_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  status ENUM('pending', 'done') NOT NULL DEFAULT 'pending',
  created_by BIGINT NOT NULL,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  created_at DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
  INDEX idx_tasks_created_by (created_by, is_deleted),
  CONSTRAINT fk_tasks_created_by FOREIGN KEY (created_by) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_ci;
```

**2. The schema** (`src/modules/tasks/tasks.schema.js`): what the request may contain. `validate()` applies it and puts the parsed values on `req.validated`.

```js
import { paginationQuerySchema, z } from '../../utils/validation.js';

export const listTasksSchema = { query: paginationQuerySchema };

export const createTaskSchema = {
  body: z.strictObject({ title: z.string().trim().min(1).max(200) }),
};

export const taskIdSchema = {
  params: z.object({
    taskId: z
      .string()
      .regex(/^[1-9]\d{0,14}$/, 'Must be a positive integer')
      .transform(Number),
  }),
};
```

**3. The service** (`src/modules/tasks/tasks.service.js`): the business rules and the SQL. Note the pattern: the account guard first, then `fetchOne` / `fetchPage` / `execute` on `this.conn`, then a plain-object result. The mapper keeps the JSON `camelCase`.

```js
import { execute, fetchOne, fetchPage, pool } from '../../database/index.js';
import { NotFoundError } from '../../errors/index.js';
import { buildPageMeta, toPagination } from '../../utils/pagination.js';
import { assertActiveAccount } from '../users/users.rules.js';

/** A database row as the API returns it: camelCase, only what the client needs. */
const toTask = (row) => ({
  taskId: row.task_id,
  title: row.title,
  status: row.status,
  createdAt: row.created_at,
});

/** Every user manages their own tasks. */
export class TasksService {
  /** @param {object} [conn=pool]  the pool, or a connection from `withTransaction` */
  constructor(conn = pool) {
    this.conn = conn;
  }

  /** The caller's tasks, newest first. */
  async list(actor, { page, limit }) {
    assertActiveAccount(actor);

    const { rows, total } = await fetchPage(
      this.conn,
      `SELECT task_id, title, status, created_at
         FROM tasks
        WHERE created_by = :userId AND is_deleted = FALSE
        ORDER BY created_at DESC, task_id DESC`,
      'SELECT COUNT(*) AS total FROM tasks WHERE created_by = :userId AND is_deleted = FALSE',
      { userId: actor.userId },
      { skip: toPagination({ page, limit }).offset, limit },
    );
    return { tasks: rows.map(toTask), meta: buildPageMeta({ page, limit, total }) };
  }

  async create(actor, { title }) {
    assertActiveAccount(actor);

    const { insertId } = await execute(
      this.conn,
      'INSERT INTO tasks (title, created_by) VALUES (:title, :userId)',
      { title, userId: actor.userId },
    );
    return this.getById(actor, insertId);
  }

  /** @throws {NotFoundError} also for somebody else's task: its existence is not revealed */
  async getById(actor, taskId) {
    assertActiveAccount(actor);

    const task = await fetchOne(
      this.conn,
      `SELECT task_id, title, status, created_at
         FROM tasks
        WHERE task_id = :taskId AND created_by = :userId AND is_deleted = FALSE`,
      { taskId, userId: actor.userId },
    );
    if (!task) throw new NotFoundError('Task not found');
    return toTask(task);
  }
}
```

**4. The router** (`src/modules/tasks/tasks.router.js`): HTTP only. `authenticate()` runs first; add `authorize(ROLES.ADMIN)` after it for admin-only routes.

```js
import { Router } from 'express';
import { authenticate } from '../../middlewares/authenticate.middleware.js';
import { validate } from '../../middlewares/validate.middleware.js';
import { ApiResponse } from '../../utils/response.js';
import { createTaskSchema, listTasksSchema, taskIdSchema } from './tasks.schema.js';
import { TasksService } from './tasks.service.js';

const router = Router();
const tasksService = new TasksService();

router.get('/', authenticate(), validate(listTasksSchema), async (req, res) => {
  const { tasks, meta } = await tasksService.list(req.user, req.validated.query);
  ApiResponse.ok(res, { message: 'Tasks fetched successfully', data: tasks, meta });
});

router.post('/', authenticate(), validate(createTaskSchema), async (req, res) => {
  const task = await tasksService.create(req.user, req.validated.body);
  ApiResponse.created(res, { message: 'Task created successfully', data: task });
});

router.get('/:taskId', authenticate(), validate(taskIdSchema), async (req, res) => {
  const task = await tasksService.getById(req.user, req.validated.params.taskId);
  ApiResponse.ok(res, { message: 'Task fetched successfully', data: task });
});

export default router;
```

**5. Mount it** in `src/modules/index.js`, the only place that knows every module:

```js
import tasksRouter from './tasks/tasks.router.js';
// ...
api.use('/tasks', tasksRouter);
```

That is all: `GET /api/v1/tasks?page=1&limit=20`, `POST /api/v1/tasks` and `GET /api/v1/tasks/:taskId` now exist, return the standard response, and are covered by authentication, validation, the error handler, rate limiting and the request log.

Things to copy from this example:

- **Ownership in the SQL.** `WHERE created_by = :userId` is part of every query, and a task that belongs to somebody else is a `404`, so its existence is not revealed.
- **Conflicts** (for example a unique title per user): catch the duplicate with `isDuplicateEntry(err, 'index_name')` and throw a `ConflictError` with your own `code`.
- **Several tables in one operation**: wrap them in `withTransaction` and build services on its `conn` ([section 7](#transactions-withtransaction)).
- **Other roles**: guards for the actor live in `users.rules.js`; "who may act on whom" rules belong in a pure policy file like `admin.policy.js`.

---

## 15. Rules we follow

**Structure**

1. Every module has `router`, `schema` and `service`. The router has no logic, the service has no HTTP (`req`, `res`, status codes).
2. Modules are mounted only in `src/modules/index.js`. Dependencies point one way: no import cycles.
3. Files: `<module>.router.js`, `.schema.js`, `.service.js`. Services are classes (`XxxService`). Database columns are `snake_case`, JSON and JavaScript are `camelCase`.
4. ES modules only; relative imports include `.js`.

**Services and SQL**

5. No ORM. Raw SQL in the service files through `src/database`: `fetchOne(this.conn, sql, { named })`. Never concatenate values; dynamic fragments come from whitelists.
6. A service is bound to one connection (`this.conn`, the pool by default). A write that touches more than one table runs in `withTransaction`, with services built on its `conn`. Hash passwords **before** the transaction, and never throw inside it for an outcome that must persist.
7. SQL states the lifecycle rules **explicitly**: `users` queries filter `is_deleted = FALSE`, and `roles` are only used while `is_active = TRUE AND is_deleted = FALSE`. List columns, no `SELECT *`.
8. Soft delete only. All timestamps are UTC; services set `updated_at` explicitly; audit columns (`created_by`, `updated_by`) are filled.
9. When two requests could race (admin actions on one user, token rotation, recovery attempts), lock the row (`FOR UPDATE`) before checking the rules.
10. A service method that acts for a user starts with the account-state guards: `assertActiveAccount(actor)` and, for self-service actions, `assertNotSuperAdmin(actor)`. The rules live in `users.rules.js`.
11. A service method reads like a short script: guard, fetch, decide, write, log, return. Put each query behind a small, well-named private method (`#getPasswordHash`) when the main method would otherwise be hard to follow, and avoid flag variables: use early `if (...) throw`.

**API**

12. Respond only with `ApiResponse.ok` / `ApiResponse.created`. Failures come only from the error handler: throw an `AppError` subclass with a stable `code`.
13. Handlers read only `req.validated.*`. Bodies use `z.strictObject`.
14. Authorization is layered: the route (`authenticate` + `authorize`), then the policy / rules in the service. The token is never trusted for roles.
15. Use the right status: `401` who are you?, `403` not allowed, `404` not found (also to hide existence), `409` conflict, `422` validation, `429` throttled, `503` temporarily unavailable.

**Security**

16. Secrets never appear in logs or responses. The only secrets ever returned are one-time temporary passwords and reset tokens, once.
17. Failures that could reveal whether an account exists use one message and the same cost.
18. Responses are `no-store`. New endpoints that handle credentials get the auth rate limiter.
19. Configuration only through `src/config`; secrets only through ENV.

**Quality**

20. `npm run lint` and `npm run format:check` must pass before merging (CI runs them). New behaviour should come with tests; this baseline ships without a test suite (see [limitations](#20-known-limitations-and-future-extensions)).

---

## 16. Decisions log

### Open questions we settled

| Question | Decision | Why |
| --- | --- | --- |
| Can an admin change a **member's** password? | Yes, as a **reset**: system-generated temporary password, shown once, forced change at next login, sessions revoked | Admins never choose or see a real password; it is the fallback when someone forgets their security answers (no e-mail) |
| Can an admin change **another admin's** password? | **No**, super admin only | A rogue or compromised admin could otherwise take over peer accounts |
| Can an admin **delete another admin**? | **No**, super admin only | Same reason |
| Can an admin **update another admin's role**? | Admins may **promote** members to admin but cannot demote; demotion is super-admin only | Matches "admins can add admins", keeps peers protected |
| Can members and admins **delete their own profile**? | Yes: soft delete, needs the password, revokes every session, frees the e-mail | The unique-active-e-mail design supports re-registration; the system is never orphaned because the super admin always exists |
| Super admin | Reserved row `user_id = 1`, credentials only in ENV (bcrypt hash), not a role | Foreign keys and audit trail need a real row; "only one" is structural |

### Other decisions

| Topic | Decision |
| --- | --- |
| Tokens | 15-minute JWT + opaque rotating refresh token in an `httpOnly` cookie, with reuse detection |
| Per-request check | `authenticate` re-reads `is_deleted`, `is_active`, role and password state from the database on every request |
| Inactive users | May sign in, refresh, log out and view their profile; everything else returns `403 ACCOUNT_INACTIVE` (explicit allow-list) |
| Admin-created users | Temporary password + `must_change_password`; no security profile until they set one after first login |
| E-mail | Immutable through every endpoint (it is the login identifier) |
| Profile | The only editable profile field is the full name |
| Rate limiting | On every auth route, layered per IP and per IP + e-mail |
| Super admin visibility | Hidden from admins (list omits it, `GET /admin/users/1` is `404`) |
| Self-service for the super admin | Not applicable; ENV is the source of truth (`403 SUPER_ADMIN_PROTECTED`) |
| Role hierarchy | Generic rule on `role_level`: manage only strictly lower levels; assign roles up to your own level |
| Sign-up | Does not auto-login; security profile mandatory |
| Change password | Revokes all sessions but keeps the calling device signed in |
| Access-token invalidation | Tokens issued before the last password change are rejected (`iat` vs `user_passwords.updated_at`) |
| Security answers | Normalised, peppered (HMAC) and bcrypt-hashed |
| Roles vs. JWT | The JWT carries no role |
| Seed data | `seed.sql` (required, idempotent) is separate from `seed.demo.sql` (development only), so production can never receive demo accounts by accident |
| `DELETE /users/me` | Carries a JSON body (`{ password }`) because deleting requires re-authentication |
| Node version | 22+ (Node 20 is end-of-life) |
| Users without an active role | Cannot sign in (`403 ROLE_NOT_ASSIGNED`); the same rule applies on token refresh and on every request |
| Recovery for inactive accounts | Refused: they look like unknown accounts, because recovery counts as "doing something" |
| `user_roles` flags | None. `is_active` / `is_deleted` exist only on `roles` |
| Account-state rules | Written once in `users.rules.js`; SQL states `is_deleted = FALSE` explicitly instead of hiding it in a generated column |
| Data layer | One file (`baseRepository.js`): `BaseRepository` and `fetchOne` / `fetchAll` / `fetchPage` / `execute` / `executeMany`, MySQL only, named `:parameters` |
| Services | Classes bound to one connection (`this.conn`), like `AuthService(conn)` in the FastAPI project |
| Database connection | `DB_URL` when set, otherwise the local credentials; the `.sql` files never name the database |
| Query timeout | `DB_QUERY_TIMEOUT_MS` as a session `max_execution_time`, set once per pooled connection |
| Slow-query logging | Not included (the FastAPI repository has none); failed statements are logged with their SQL |

---

## 17. Deployment and production checklist

**Configuration**

- [ ] `NODE_ENV=production` (turns on the configuration guards).
- [ ] Fresh `JWT_ACCESS_SECRET` and `SECURITY_ANSWER_PEPPER` (64+ random bytes each), kept in a secret store. Store the pepper safely: losing or rotating it invalidates every security answer.
- [ ] Your own `SUPER_ADMIN_NAME`, `SUPER_ADMIN_EMAIL` and `SUPER_ADMIN_PASSWORD_HASH` (`npm run hash-password`). The example hash is refused in production.
- [ ] `CORS_ORIGINS` set to your real frontend origin(s).
- [ ] `TRUST_PROXY` set to the number of proxies in front of the app (otherwise every client looks like the proxy's IP and the rate limiters share one bucket).
- [ ] Serve over **HTTPS** only (terminate TLS at the proxy). The refresh cookie is `Secure` in production.
- [ ] `REFRESH_COOKIE_SAMESITE=strict` if the frontend is same-site, otherwise `none` (then add an `Origin` / CSRF check).

**Database**

- [ ] Load the schema with `npm run db:setup` (**not** `db:setup:demo`, and never `seed.demo.sql`) using an account with DDL rights (`DB_ADMIN_*`), not the runtime user.
- [ ] The runtime user has only `SELECT, INSERT, UPDATE, DELETE`.
- [ ] Managed MySQL: set `DB_URL` (and `DB_SSL=true`). `DB_ADMIN_*` still replaces the user for the `db:*` scripts.
- [ ] TLS to MySQL when it is not on a private network (`DB_SSL=true`).
- [ ] Backups and a retention policy for `user_login_logs` (it grows forever).
- [ ] Size `DB_CONNECTION_LIMIT` as (instances × limit) ≤ MySQL `max_connections`.

**Runtime**

- [ ] Docker: the provided `Dockerfile` builds a small, non-root image with a `HEALTHCHECK` on `/health/live`. Use `/health/ready` for the orchestrator's readiness probe.
- [ ] Several instances: use a shared rate-limit store (for example `rate-limit-redis`) instead of the per-process memory store.
- [ ] Ship stdout to your log platform; alert on `error` level and on the `Refresh token reuse detected` warning.
- [ ] `SIGTERM` triggers a graceful shutdown (stops accepting, drains, closes the pool); set the orchestrator's grace period above `SHUTDOWN_TIMEOUT_MS`. Start the app with `node src/server.js` (as the Dockerfile does), **not** through `npm start`, so the signal reaches the app instead of an `npm`/shell wrapper.
- [ ] Do not reuse `docker-compose.yml` as is: it runs `NODE_ENV=development`, loads demo users and exposes MySQL on a port.

---

## 18. Frontend integration notes

- Send requests with credentials (`fetch(..., { credentials: 'include' })`, axios `withCredentials: true`) so the refresh cookie travels, and list your origin in `CORS_ORIGINS`.
- Keep the **access token in memory** (not `localStorage`). The refresh token is not reachable from JavaScript, by design.
- On app start call `POST /auth/refresh`. If it succeeds you get an access token and the user; if it returns `401`, show the login screen.
- On `401 TOKEN_EXPIRED` call `/auth/refresh` **once** (share one in-flight call between parallel requests) and retry. If refresh returns `401`, sign the user out. A `401 TOKEN_INVALID` from refresh right after another refresh is the harmless parallel-tab case: retry once.
- The `user` object returned by `login`, `refresh` and `GET /users/me` includes `mustChangePassword` (route to the change-password screen) and `hasSecurityProfile` (send users without one to set it up). `change-password` returns a fresh session (`accessToken` + new cookie) without `user`.
- Handle `403 ACCOUNT_INACTIVE` and `403 PASSWORD_CHANGE_REQUIRED` globally.
- Show `Retry-After` for `429` / `503`.
- Every failure has `error.code`: branch on the code, show `message`, and quote `requestId` when users report a problem.

---

## 19. Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| `Invalid environment configuration` on start | Copy `.env.example` to `.env`; the message lists every missing or invalid variable |
| `Cannot connect to MySQL at host:port` | Check `DB_URL` (or `DB_HOST` / `DB_PORT`), the credentials and that the database exists |
| `DB_URL: ...` error on start | The message says what is wrong (scheme, user, database name, query parameters, percent-encoding). The password is never printed |
| `DB_USER: is required when DB_URL is not set` | Set `DB_URL`, or `DB_USER` for the local database |
| `403 ROLE_NOT_ASSIGNED` at login | The user's role is missing, inactive or deleted: give them an active role (admin: change role) or re-activate the role |
| `The database schema is missing` | `npm run db:schema` |
| `Required roles are missing` | `npm run db:seed` |
| `SUPER_ADMIN_EMAIL ... is already used by another active account` | Another live user has that e-mail. Change `SUPER_ADMIN_EMAIL` or delete that account |
| `users.user_id = 1 is reserved ... has password/role rows` | Something wrote credentials/roles for id 1. Delete those rows |
| `db:*` fails with `CREATE command denied` | Set `DB_ADMIN_USER` / `DB_ADMIN_PASSWORD` (e.g. root) |
| `SUPER_ADMIN_PASSWORD_HASH: must be a bcrypt hash` | Use `npm run hash-password` and keep the single quotes (also escape `$` as `$$` if you inline it in `docker-compose.yml`) |
| `unable to determine transport target for "pino-pretty"` | Running without dev dependencies: set `LOG_PRETTY=false` |
| Cookie not stored by the browser | Frontend must send credentials; origin must be in `CORS_ORIGINS`; `Secure` cookies need HTTPS (not on plain `http://` outside localhost); cross-site needs `SameSite=none` + `Secure` |
| `401 TOKEN_INVALID` right after a password change/reset | By design: older access tokens are invalidated |
| Everything is rate limited behind a proxy | Set `TRUST_PROXY` correctly |
| bcrypt fails to install | Ensure build tools are available, or swap to `bcryptjs` (same `hash` / `compare` API) in `src/utils/password.js` |

---

## 20. Known limitations and future extensions

- **Access-token invalidation granularity is one second** (JWT `iat` is in seconds). A token minted in the same second as a password change survives until it expires (15 minutes at most).
- **Super-admin password rotation** does not revoke that account's existing sessions (it has no `user_passwords` row to timestamp). To force a sign-out: `UPDATE refresh_tokens SET revoked_at = UTC_TIMESTAMP(6) WHERE user_id = 1 AND revoked_at IS NULL;` (access tokens expire within 15 minutes).
- **Rate limit store is per process**: use Redis (or similar) when running several instances.
- **Security questions are weaker than e-mail / MFA recovery.** Consider TOTP-based MFA.
- **No audit columns on `users`** (`updated_at`, `updated_by`, `deleted_at`, `deleted_by`); profile edits and deletions are only visible in the application log. Add them with a migration if you need that.
- **No migration tool**: `schema.sql` is the installer. Adopt one (Flyway, Liquibase, `umzug`, ...) before the first schema change in production.
- **Search uses `LIKE '%term%'`** (a table scan). Fine for thousands of users; use `FULLTEXT` or prefix search beyond that. Pagination is offset-based.
- **Login-failure lockout is IP + e-mail rate limiting only** (by design, to avoid lock-out attacks).
- **No OpenAPI/Swagger document** and no e-mail, SSO or multi-tenancy (the `sso_id` columns are an unused extension point).
- **No retention job for `user_login_logs`.**
- **No automated tests are shipped.** Add them (for example with `node:test` and `supertest`) before relying on this baseline; integration tests need a dedicated MySQL database that they may drop.
