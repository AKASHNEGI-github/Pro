"""
Security helpers: password hashing and JWT tokens.
No database or HTTP code here, only reusable tools.

Two jobs live in this file:
1. Passwords: hash them before saving, and check them at login.
2. Tokens: create a JWT after login, and read it on later requests.
"""

import hashlib
import secrets
import os
from datetime import datetime, timedelta, timezone

import jwt                       # PyJWT: creates and verifies tokens
from dotenv import load_dotenv   # reads the .env file
from pwdlib import PasswordHash  # password hashing library

# Load the values from .env into environment variables
load_dotenv()

# ---------------------------------------------------------------
# Settings (read from .env so secrets never sit inside the code)
# ---------------------------------------------------------------

# Read the raw value. It can be None if the variable is missing in .env.
_secret_key = os.getenv("JWT_SECRET_KEY")

# Fail fast: better to crash at startup than run with no secret key
if not _secret_key:
    raise RuntimeError("JWT_SECRET_KEY environment variable is not set")

# After the check above, the type checker knows this is a plain `str`
JWT_SECRET_KEY: str = _secret_key

# Signing method. Defaults to HS256 if missing in .env.
ALGORITHM: str = os.getenv("JWT_ALGORITHM", "HS256")

# How long a token stays valid. int() converts the string to a number.
ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", "30"))

REFRESH_TOKEN_EXPIRE_DAYS: int = int(os.getenv("JWT_REFRESH_TOKEN_EXPIRE_DAYS", "7"))

# ---------------------------------------------------------------
# Password hashing
# ---------------------------------------------------------------

# Hasher with safe default settings (Argon2). Argon2 is slow on purpose,
# which makes it very hard for attackers to guess passwords.
password_hash = PasswordHash.recommended()


def hash_password(plain_password: str) -> str:
    """Turn a plain password into a hash. Only the hash is stored in the DB.

    A hash is one-way: you cannot turn it back into the password.
    A random "salt" is added automatically, so two users with the same
    password get different hashes.
    """
    return password_hash.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Check if a plain password matches the stored hash.

    Used at login. It hashes the typed password the same way and compares.
    Returns True if they match, otherwise False.
    """
    return password_hash.verify(plain_password, hashed_password)


# ---------------------------------------------------------------
# JWT tokens
# ---------------------------------------------------------------

def create_access_token(user_id: int) -> str:
    """Create a signed token that identifies the user and expires soon."""
    # Expiry time = now + lifetime. We use UTC so server timezone doesn't matter.
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    # The payload is the data stored inside the token.
    # It is only encoded, not encrypted, so never put passwords or secrets here.
    payload = {
        "sub": str(user_id),  # "sub" (subject) = who the token belongs to (must be a string)
        "exp": expire,        # "exp" = when the token stops working (PyJWT checks it for us)
    }

    # Sign the payload with the secret key. The result looks like:
    # header.payload.signature
    # If anyone changes the payload, the signature no longer matches.
    return jwt.encode(payload, JWT_SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict:
    """Read a token. Raises jwt.InvalidTokenError if it is fake or expired.

    jwt.decode automatically checks:
    - the signature is valid (the token was not changed)
    - the "exp" time has not passed
    Returns the payload, e.g. {"sub": "1", "exp": ...}.
    """
    # algorithms=[...] is a safety rule: only accept the algorithm we expect
    return jwt.decode(token, JWT_SECRET_KEY, algorithms=[ALGORITHM])

# ---------------------------------------------------------------
# JWT Refresh token
# ---------------------------------------------------------------

def hash_refresh_token(raw_token: str) -> str:
    """Hash the refresh token so a DB leak doesn't expose usable tokens."""
    # .encode() converts the text token into bytes, because hashlib only accepts bytes
    # sha256() scrambles the bytes into a fixed-length fingerprint (one-way, can't be reversed)
    # .hexdigest() turns that fingerprint into a readable 64-character text string
    # The same token always gives the same hash, so we can find it in the DB later
    return hashlib.sha256(raw_token.encode()).hexdigest()


def create_refresh_token() -> tuple[str, str, datetime]:
    """Return (raw_token, token_hash, expires_at). Only the hash is stored."""
    # Generate a random, unguessable string (48 random bytes, made URL-safe).
    # This is the real token that the client receives and keeps.
    raw_token = secrets.token_urlsafe(48)

    # Expiry = current UTC time + 7 days (from .env).
    # After this time, the token is no longer valid.
    expires_at = datetime.now(timezone.utc) + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)

    # Return 3 values:
    # 1. raw_token  -> sent to the client (never stored in the DB)
    # 2. token hash -> stored in the DB (safe even if the DB leaks)
    # 3. expires_at -> stored in the DB to check expiry later
    return raw_token, hash_refresh_token(raw_token), expires_at