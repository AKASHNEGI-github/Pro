"""
Database configuration.

Creates the SQLAlchemy engine (connection to PostgreSQL), the session
factory, the Base class for ORM models, and the `get_db` dependency.
"""
import os

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

# Load variables from the .env file into environment variables
load_dotenv()

# Read the connection string from .env
DATABASE_URL = os.getenv("DATABASE_URL")

# Raise an error if the DATABASE_URL is not set
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL environment variable is not set")

# The engine manages the connection pool to the database
engine = create_engine(DATABASE_URL)

# Each request gets its own session created from this factory
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)

class Base(DeclarativeBase):
    """Base class for all ORM models."""


def get_db():
    """
    FastAPI dependency that yields a DB session per request and
    always closes it afterwards, even if an error occurs.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()