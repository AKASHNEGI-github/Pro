"""
Book router (controller).

Only handles HTTP concerns: URLs, status codes, and request/response
models. All real logic is delegated to BookService.
"""
from typing import List

from fastapi import APIRouter, Depends, status

from app.modules.auth.dependencies import CurrentUser, get_current_user
from app.modules.books.dependencies import BookServiceDep
from app.modules.books.schemas import BookCreate, BookResponse, BookUpdate

router = APIRouter(prefix="/books", tags=["Books"])


# Needs current_user.id to set the owner, so keep CurrentUser
@router.post("/", response_model=BookResponse, status_code=status.HTTP_201_CREATED)
def create_book(payload: BookCreate, service: BookServiceDep, current_user: CurrentUser):
    # The owner comes from the token, not from the client
    return service.create_book(payload, current_user.id)


# Login required, but we don't need the user object, so use a route-level guard
@router.get(
    "/",
    response_model=List[BookResponse],
    dependencies=[Depends(get_current_user)],
)
def list_books(service: BookServiceDep):
    return service.list_books()


# Login required, but we don't need the user object, so use a route-level guard
@router.get(
    "/{book_id}",
    response_model=BookResponse,
    dependencies=[Depends(get_current_user)],
)
def get_book(book_id: int, service: BookServiceDep):
    return service.get_book(book_id)


# Needs current_user.id for the ownership check, so keep CurrentUser
@router.put("/{book_id}", response_model=BookResponse)
def update_book(
    book_id: int, payload: BookUpdate, service: BookServiceDep, current_user: CurrentUser
):
    # The service checks that current_user owns this book
    return service.update_book(book_id, payload, current_user.id)


# Needs current_user.id for the ownership check, so keep CurrentUser
@router.delete("/{book_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_book(book_id: int, service: BookServiceDep, current_user: CurrentUser):
    service.delete_book(book_id, current_user.id)