"""
Book service layer.

All business logic and database work for books lives here.
The router only calls these methods and returns the result.
"""
from typing import List

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models import Book, User  # book service
from app.modules.books.schemas import BookCreate, BookUpdate


class BookService:
    def __init__(self, db: Session):
        # The DB session is injected so the service stays easy to test
        self.db = db

    @staticmethod
    def _ensure_owner(book: Book, user_id: int) -> None:
        """Raise 403 if the book does not belong to this user."""
        if book.owner_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only modify your own books",
            )

    def create_book(self, payload: BookCreate, owner_id: int) -> Book:
        """Create a book owned by the logged-in user."""
        # No owner check needed: the owner is the user from the token
        book = Book(**payload.model_dump(), owner_id=owner_id)
        self.db.add(book)
        self.db.commit()
        self.db.refresh(book)
        return book

    def list_books(self) -> List[Book]:
        """Return all books."""
        return self.db.query(Book).all()

    def get_book(self, book_id: int) -> Book:
        """Return one book or raise 404 if not found."""
        book = self.db.query(Book).filter(Book.id == book_id).first()
        if not book:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Book not found"
            )
        return book

    def update_book(self, book_id: int, payload: BookUpdate, current_user_id: int) -> Book:
        """Update a book, but only if the logged-in user owns it."""
        book = self.get_book(book_id)           # 404 if the book doesn't exist
        self._ensure_owner(book, current_user_id)  # 403 if it's not theirs

        for field, value in payload.model_dump(exclude_unset=True).items():
            setattr(book, field, value)

        self.db.commit()
        self.db.refresh(book)
        return book

    def delete_book(self, book_id: int, current_user_id: int) -> None:
        """Delete a book, but only if the logged-in user owns it."""
        book = self.get_book(book_id)
        self._ensure_owner(book, current_user_id)

        self.db.delete(book)
        self.db.commit()