"""Pydantic schemas for books (request/response validation)."""
from typing import Optional

from pydantic import BaseModel, ConfigDict


class BookCreate(BaseModel):
    """Data required to create a book. The owner comes from the token."""
    title: str
    author: str
    description: Optional[str] = None
    published_year: Optional[int] = None


class BookUpdate(BaseModel):
    """All fields optional - only the provided ones get updated."""
    title: Optional[str] = None
    author: Optional[str] = None
    description: Optional[str] = None
    published_year: Optional[int] = None


class BookResponse(BaseModel):
    """Data returned to the client."""
    id: int
    title: str
    author: str
    description: Optional[str] = None
    published_year: Optional[int] = None
    owner_id: int

    model_config = ConfigDict(from_attributes=True)
