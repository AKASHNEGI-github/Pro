"""
Shared dependency for the books module.
Kept in its own file so the router stays focused on HTTP only,
and other modules can reuse it without importing books/router.py.
"""
from typing import Annotated

from fastapi import Depends
from sqlalchemy.orm import Session

from app.config.database import get_db
from app.modules.books.service import BookService


def get_book_service(db: Session = Depends(get_db)) -> BookService:
    """Build a BookService with a fresh DB session."""
    return BookService(db)


# Declared once, reused in every endpoint that needs BookService
BookServiceDep = Annotated[BookService, Depends(get_book_service)]