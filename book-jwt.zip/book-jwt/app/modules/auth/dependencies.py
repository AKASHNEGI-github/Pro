"""
Dependency that protects routes (the "guard").

How to use it:
- Add `current_user: CurrentUser` to an endpoint when you need the user object.
- Or add `dependencies=[Depends(get_current_user)]` to the route when you
  only need the login check.
Either way, a valid token is required, otherwise the API returns 401.
"""
from typing import Annotated

import jwt # used to catch token errors
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.config.database import get_db
from app.config.security import decode_access_token
from app.models import User
from app.modules.auth.service import AuthService

# This object does two jobs:
# 1. At runtime: reads the "Authorization: Bearer <token>" header from the
#    request and gives us just the token string. If the header is missing,
#    FastAPI automatically returns 401.
# 2. In Swagger (/docs): adds the Authorize button and tells it that
#    users log in at "/auth/login".

bearer_scheme = HTTPBearer()


def get_current_user(
    # credentials.credentials holds just the token string
    credentials: Annotated[HTTPAuthorizationCredentials, Depends(bearer_scheme)],
    # FastAPI runs get_db and passes a fresh database session here
    db: Annotated[Session, Depends(get_db)],
) -> User:
    """Read the token, find the user, and return them. Otherwise raise 401."""
    token = credentials.credentials # The token string from the "Authorization" header

    # One reusable error. We use the same message for every failure so
    # attackers can't tell WHY the token was rejected.
    # The "WWW-Authenticate" header is the standard way to tell the client
    # that a Bearer token is required.
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        # Step 1: verify the signature and expiry, and get the payload back.
        # Example payload: {"sub": "1", "exp": 1735000000}
        payload = decode_access_token(token)

        # Step 2: "sub" holds the user id we stored when creating the token
        user_id = payload.get("sub")
        if user_id is None:
            # Token is valid but has no user id inside, so reject it
            raise credentials_error
    except jwt.InvalidTokenError:
        # decode_access_token raises this when the token is fake,
        # damaged (signature mismatch), or expired
        raise credentials_error

    # Step 3: the token is valid, but the user may have been deleted since it
    # was issued, so check the database.
    # "sub" is stored as a string, so convert it back to int.
    # db.get() looks up a row by primary key.
    user = db.get(User, int(user_id))
    if user is None:
        raise credentials_error

    # Step 4: hand the User object to the endpoint
    return user

def get_auth_service(db: Annotated[Session, Depends(get_db)]) -> AuthService:
    """Build an AuthService with a fresh DB session."""
    return AuthService(db)


AuthServiceDep = Annotated[AuthService, Depends(get_auth_service)]

CurrentUser = Annotated[User, Depends(get_current_user)]