"""Auth router: the login endpoint that gives out tokens."""
from fastapi import APIRouter, status

from app.config.security import create_access_token
from app.modules.auth.dependencies import AuthServiceDep
from app.modules.auth.schemas import LoginRequest, RefreshRequest, Token
from app.modules.users.dependencies import UserServiceDep
from app.modules.users.schemas import UserCreate, UserResponse

router = APIRouter(prefix="/auth", tags=["Auth"])

# Public: registration, no token needed
@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def create_user(payload: UserCreate, service: UserServiceDep):
    return service.create_user(payload)

@router.post("/login", response_model=Token)
def login(
    payload: LoginRequest, user_service: UserServiceDep, auth_service: AuthServiceDep
):
    user = user_service.authenticate_user(payload.email, payload.password)
    return auth_service.create_tokens(user.id)

@router.post("/refresh", response_model=Token)
def refresh(payload: RefreshRequest, auth_service: AuthServiceDep):
    return auth_service.refresh(payload.refresh_token)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(payload: RefreshRequest, auth_service: AuthServiceDep):
    auth_service.logout(payload.refresh_token)