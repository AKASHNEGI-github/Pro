"""Auth service: issues, rotates and revokes refresh tokens."""
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.config.security import (
    create_access_token,
    create_refresh_token,
    hash_refresh_token,
)
from app.models import RefreshToken
from app.modules.auth.schemas import Token


class AuthService:
    def __init__(self, db: Session):
        # The DB session is injected, same pattern as UserService and BookService
        self.db = db

    def create_tokens(self, user_id: int) -> Token:
        """Create an access token + a new refresh token (stored hashed)."""
        # Generate the refresh token. We get 3 things back:
        # raw_token  -> goes to the client
        # token_hash -> goes to the DB
        # expires_at -> goes to the DB (now + 7 days)
        raw_token, token_hash, expires_at = create_refresh_token()

        # Save only the HASH in the refresh_tokens table, never the raw token
        self.db.add(
            RefreshToken(token_hash=token_hash, user_id=user_id, expires_at=expires_at)
        )
        self.db.commit()  # write the new row to the database

        # Send both tokens to the client:
        # access_token  -> a signed JWT (not stored anywhere on the server)
        # refresh_token -> the RAW token (the only copy the client will ever see)
        return Token(
            access_token=create_access_token(user_id), refresh_token=raw_token
        )

    def _find(self, raw_token: str) -> RefreshToken | None:
        """Look up a refresh token row using the raw token from the client."""
        # The DB has only hashes, so hash the raw token first,
        # then search for a row with the same hash.
        # Returns the row if found, otherwise None.
        return (
            self.db.query(RefreshToken)
            .filter(RefreshToken.token_hash == hash_refresh_token(raw_token))
            .first()
        )

    def refresh(self, raw_token: str) -> Token:
        """Validate the refresh token, delete it (rotation), issue a new pair."""
        # Step 1: find the token's row in the DB (None if it doesn't exist)
        record = self._find(raw_token)

        # Step 2: reject if the token is unknown OR already expired
        if record is None or record.expires_at < datetime.now(timezone.utc):
            if record is not None:  # expired: clean it up
                # The row exists but is expired, so delete it to keep the table tidy
                self.db.delete(record)
                self.db.commit()
            # Same error for "not found" and "expired" so attackers learn nothing
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired refresh token",
                headers={"WWW-Authenticate": "Bearer"},
            )

        # Step 3: the token is valid. Remember whose token it was.
        user_id = record.user_id

        # Step 4: rotation. Delete the used token so it can never be used twice.
        # If a thief copied it, it stops working after the real user refreshes.
        self.db.delete(record)  # old token can never be used again
        self.db.commit()

        # Step 5: issue a brand new access token + refresh token pair
        return self.create_tokens(user_id)

    def logout(self, raw_token: str) -> None:
        """Revoke the refresh token. Silent if it doesn't exist."""
        # Find the row for this raw token
        record = self._find(raw_token)

        # If found, delete it. After this, the token can't get new access tokens.
        # If not found, do nothing (no error), because the goal "token is gone"
        # is already true, and an error would reveal which tokens exist.
        if record is not None:
            self.db.delete(record)
            self.db.commit()