"""Pydantic schemas for the auth module."""
from pydantic import BaseModel, EmailStr


class LoginRequest(BaseModel):
    """Data the client sends to log in."""
    email: EmailStr
    password: str


class RefreshRequest(BaseModel):
    """Used by both /auth/refresh and /auth/logout."""
    refresh_token: str


class Token(BaseModel):
    """What the client receives after login or refresh."""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"