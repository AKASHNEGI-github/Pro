"""
Shared dependency for the users module.
Kept in its own file so other modules (like auth) can use it
without importing users/router.py.
"""
from typing import Annotated

from fastapi import Depends
from sqlalchemy.orm import Session

from app.config.database import get_db
from app.modules.users.service import UserService


def get_user_service(db: Session = Depends(get_db)) -> UserService:
    """Build a UserService with a fresh DB session."""
    return UserService(db)


# Declared once, reused in every endpoint that needs UserService
UserServiceDep = Annotated[UserService, Depends(get_user_service)]