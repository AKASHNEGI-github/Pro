"""
User service layer.

All business logic and database work for users lives here.
The router only calls these methods and returns the result.
"""
from typing import List

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.config.security import hash_password, verify_password
from app.models import User  # user service
from app.modules.users.schemas import UserCreate, UserUpdate


class UserService:
    def __init__(self, db: Session):
        # The DB session is injected so the service stays easy to test
        self.db = db

    def authenticate_user(self, email: str, password: str) -> User:
        """Check email + password. Raise 401 if either is wrong."""
        user = self.db.query(User).filter(User.email == email).first()

        # Same error for "no user" and "wrong password" so attackers can't tell which
        if not user or not verify_password(password, user.hashed_password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect email or password",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return user

    def create_user(self, payload: UserCreate) -> User:
        """Create a new user. Email must be unique."""
        if self.db.query(User).filter(User.email == payload.email).first():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already registered",
            )

        user = User(
            name=payload.name,
            email=payload.email,
            # Hash the password before saving it
            hashed_password=hash_password(payload.password),
        )
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user

    def list_users(self) -> List[User]:
        """Return all users."""
        return self.db.query(User).all()

    def get_user(self, user_id: int) -> User:
        """Return one user or raise 404 if not found."""
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )
        return user

    def update_user(self, user_id: int, payload: UserUpdate, current_user_id: int) -> User:
        """Update a user, but only if they are updating their own account."""
        # Ownership check: users can only change their own account
        if user_id != current_user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only update your own account",
            )

        user = self.get_user(user_id)  # 404 if the user doesn't exist

        # Prevent changing to an email that another user already has
        if payload.email and payload.email != user.email:
            if self.db.query(User).filter(User.email == payload.email).first():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Email already registered",
                )

        # exclude_unset=True -> skip fields the client didn't send
        for field, value in payload.model_dump(exclude_unset=True).items():
            setattr(user, field, value)

        self.db.commit()       # save changes to the database
        self.db.refresh(user)  # reload the latest data
        return user            # returned to the router, then converted by UserResponse

    def delete_user(self, user_id: int, current_user_id: int) -> None:
        """Delete a user, but only if they are deleting their own account."""
        if user_id != current_user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only delete your own account",
            )

        user = self.get_user(user_id)
        self.db.delete(user)
        self.db.commit()