"""
User router (controller).
"""
from typing import List

from fastapi import APIRouter, Depends, status

from app.modules.auth.dependencies import CurrentUser, get_current_user
from app.modules.users.dependencies import UserServiceDep
from app.modules.users.schemas import UserCreate, UserResponse, UserUpdate

router = APIRouter(prefix="/users", tags=["Users"])

# Login required, but we don't need the user object, so use a route-level guard
@router.get(
    "/",
    response_model=List[UserResponse],
    dependencies=[Depends(get_current_user)],
)
def list_users(service: UserServiceDep):
    return service.list_users()


# Login required, but we don't need the user object, so use a route-level guard
@router.get(
    "/{user_id}",
    response_model=UserResponse,
    dependencies=[Depends(get_current_user)],
)
def get_user(user_id: int, service: UserServiceDep):
    return service.get_user(user_id)


# Needs current_user.id for the ownership check, so keep CurrentUser
@router.put("/{user_id}", response_model=UserResponse)
def update_user(
    user_id: int, payload: UserUpdate, service: UserServiceDep, current_user: CurrentUser
):
    return service.update_user(user_id, payload, current_user.id)


# Needs current_user.id for the ownership check, so keep CurrentUser
@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int, service: UserServiceDep, current_user: CurrentUser):
    service.delete_user(user_id, current_user.id)