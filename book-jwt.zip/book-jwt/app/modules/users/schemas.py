"""Pydantic schemas for users (request/response validation)."""
from typing import Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class UserCreate(BaseModel):
    """Data required to create a user."""
    name: str
    email: EmailStr
    # Plain password from the client (min 5 characters). Never returned in responses.
    password: str = Field(min_length=5)


class UserUpdate(BaseModel):
    """All fields optional so the client can update only what they need."""
    name: Optional[str] = None
    email: Optional[EmailStr] = None


class UserResponse(BaseModel):
    """Data returned to the client."""
    id: int
    name: str
    email: EmailStr

    # Allows Pydantic to read data directly from SQLAlchemy objects
    model_config = ConfigDict(from_attributes=True)
