# RUN: uvicorn app.main:app --reload

from fastapi import FastAPI

from app.config.database import Base, engine
from app.modules.auth.router import router as auth_router
from app.modules.books.router import router as books_router
from app.modules.users.router import router as users_router

def create_app() -> FastAPI:
    """
    Application factory.

    Builds and configures the FastAPI app. Keeping this in a function
    makes it easy to create fresh app instances (e.g. for tests).
    """
    # Create the tables in PostgreSQL if they don't exist yet.
    # (For bigger projects, use Alembic migrations instead.)
    Base.metadata.create_all(bind=engine)

    app = FastAPI(
        title="Books API with Authentication", 
        version="1.0.0",
        swagger_ui_parameters={"persistAuthorization": True}
        )

    # Register the routers
    app.include_router(auth_router)
    app.include_router(users_router)
    app.include_router(books_router)

    @app.get("/", tags=["Health"])
    def root():
        """Simple health-check endpoint."""
        return {"message": "Books API with Authentication is running"}

    return app


# Default app instance used by uvicorn: `uvicorn app.main:app --reload`
app = create_app()