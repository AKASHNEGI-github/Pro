# Books API (FastAPI + PostgreSQL + SQLAlchemy)

## Folder structure
```
fastapi_books/
├── app/
│   ├── main.py                  # App entry point (Swagger persistAuthorization enabled)
│   ├── config/
│   │   ├── database.py          # DB engine, session, Base
│   │   └── security.py          # Password hashing + access JWT helpers + refresh token helpers (generate, SHA-256 hash)
│   ├── models/
│   │   ├── __init__.py          # Exports User, Book and RefreshToken
│   │   └── models.py            # SQLAlchemy ORM models (users, books, refresh_tokens)
│   └── modules/
│       ├── auth/
│       │   ├── router.py        # Endpoints: POST /auth/register, /auth/login, /auth/refresh, /auth/logout
│       │   ├── dependencies.py  # get_current_user guard (CurrentUser) + get_auth_service + AuthServiceDep
│       │   ├── service.py       # AuthService: create token pair, refresh (rotation), logout (revoke)
│       │   └── schemas.py       # LoginRequest, RefreshRequest, Token (access + refresh)
│       ├── books/
│       │   ├── dependencies.py  # get_book_service + BookServiceDep (keeps router HTTP-only)
│       │   ├── router.py        # HTTP endpoints (controller)
│       │   ├── service.py       # Business logic + DB queries + ownership check
│       │   └── schemas.py       # Pydantic request/response models
│       └── users/
│           ├── dependencies.py  # get_user_service + UserServiceDep (shared, avoids circular import)
│           ├── router.py        # HTTP endpoints (list, get, update, delete; registration moved to auth)
│           ├── service.py       # Business logic, password hashing, authenticate_user, create_user, ownership check
│           └── schemas.py       # UserCreate includes password
├── requirements.txt             # Includes: pyjwt, pwdlib[argon2], python-multipart
├── .env.example                 # Includes: DATABASE_URL, JWT_SECRET_KEY, JWT_ALGORITHM, JWT_ACCESS_TOKEN_EXPIRE_MINUTES, JWT_REFRESH_TOKEN_EXPIRE_DAYS
├── .env                         # Real secrets (never commit, add to .gitignore)
└── README.md
```

## Setup
1. Create a PostgreSQL database:  `CREATE DATABASE booksDB;`
2. Create a virtual env and install deps:
   ```
   python -m venv venv
   venv\Scripts\activate        # MAC: source venv/bin/activate
   pip install -r requirements.txt
   ```
3. Copy `.env.example` to `.env` and set these values:
   - `DATABASE_URL`: your PostgreSQL connection string.
   - `JWT_SECRET_KEY`: a long random string used to sign tokens. Generate one with:
     ```
     python -c "import secrets; print(secrets.token_hex(32))"
     ```
   - `JWT_ALGORITHM`: `HS256` (default).
   - `JWT_ACCESS_TOKEN_EXPIRE_MINUTES`: how long a token stays valid, e.g. `30`.
4. Run:  `uvicorn app.main:app --reload`
5. Open http://127.0.0.1:8000/docs to try the API.

> **Note:** Create a new db, bookdbjwt to learn it from scratch.

## Endpoints
| Method | URL            | Description                                      | Auth                  |
|--------|----------------|--------------------------------------------------|-----------------------|
| POST   | /auth/register | Register a new user                              | Public                |
| POST   | /auth/login    | Login and get an access + refresh token          | Public                |
| POST   | /auth/refresh  | Swap a refresh token for a new token pair        | Refresh token (body)  |
| POST   | /auth/logout   | Revoke a refresh token                           | Refresh token (body)  |
| GET    | /users/        | List users                                       | Token                 |
| GET    | /users/{id}    | Get user                                         | Token                 |
| PUT    | /users/{id}    | Update your own account                          | Token (own account)   |
| DELETE | /users/{id}    | Delete your own account                          | Token (own account)   |
| POST   | /books/        | Create book (owner = logged-in user)             | Token                 |
| GET    | /books/        | List books                                       | Token                 |
| GET    | /books/{id}    | Get book                                         | Token                 |
| PUT    | /books/{id}    | Update your own book                             | Token (owner only)    |
| DELETE | /books/{id}    | Delete your own book                             | Token (owner only)    |

## Response codes
| Code | Meaning                                                           |
|------|-------------------------------------------------------------------|
| 200  | Success                                                           |
| 201  | Created (register user, create book)                              |
| 204  | Success, no content returned (delete, logout)                     |
| 400  | Bad request (e.g. email already registered)                       |
| 401  | Missing, invalid, or expired token / wrong login / bad refresh token |
| 403  | Valid token, but you don't own this user or book                  |
| 404  | User or book not found                                            |
| 422  | Invalid request data (e.g. password too short)                    |

## How to use the API
1. Register a user with `POST /auth/register` (name, email, password of at least 5 characters).
2. Log in at `/auth/login` with your email and password. You receive an **access token** (valid 15 minutes) and a **refresh token** (valid 7 days).
3. In `/docs`, click **Authorize** and paste the access token. It is sent automatically in the `Authorization: Bearer <token>` header.
4. Call any protected endpoint. Create books with `POST /books/`. The owner is taken from your token, so you don't send an `owner_id`.
5. When the access token expires (401), call `POST /auth/refresh` with your refresh token to get a new pair. The old refresh token stops working after use (rotation), so always save the new one.
6. To log out, call `POST /auth/logout` with your refresh token. It is revoked, so no new access tokens can be issued. The current access token still works until it expires.
7. You can only update or delete your own user account and your own books. Other requests return `403`.