import { AsyncLocalStorage } from 'node:async_hooks';

/**
 * Request Context Store (AsyncLocalStorage).
 *
 * One store object lives for the whole lifetime of a request. Anything running
 * inside that request (middlewares, services, DB helpers, logger) can read it
 * without the values being passed down through every function signature.
 *
 *   { requestId, ip, userAgent, method, path, user: { userId, role } | null }
 *
 * Used for: the requestId in every log line and API response, request metadata
 * (ip / user agent) written to login logs and refresh tokens, and the acting user in logs.
 * Authorization decisions never read from here - they receive `actor` explicitly.
 */
const storage = new AsyncLocalStorage();

export const requestContext = Object.freeze({
  /** Runs `callback` with `store` as the current context. */
  run(store, callback) {
    return storage.run(store, callback);
  },

  get() {
    return storage.getStore();
  },

  getRequestId() {
    return storage.getStore()?.requestId ?? null;
  },

  /** { ip, userAgent } of the current request (nulls outside a request, e.g. in scripts). */
  getMeta() {
    const store = storage.getStore();
    return { ip: store?.ip ?? null, userAgent: store?.userAgent ?? null };
  },

  /** Called by `authenticate` once the caller is known. */
  setUser(user) {
    const store = storage.getStore();
    if (store) store.user = { userId: user.userId, role: user.role };
  },

  getUser() {
    return storage.getStore()?.user ?? null;
  },
});
