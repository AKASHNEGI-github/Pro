import compression from 'compression';
import cookieParser from 'cookie-parser';
import express from 'express';
import helmet from 'helmet';
import { config } from './config/index.js';
import { createCorsMiddleware } from './middlewares/cors.middleware.js';
import { errorHandler } from './middlewares/errorHandler.middleware.js';
import { notFoundHandler } from './middlewares/notFound.middleware.js';
import { globalLimiter } from './middlewares/rateLimiter.middleware.js';
import { requestContextMiddleware } from './middlewares/requestContext.middleware.js';
import { requestLogger } from './middlewares/requestLogger.middleware.js';
import { registerRoutes } from './modules/index.js';

/**
 * Builds the Express app (no listening, no DB connection) so tests can mount it directly.
 *
 * Middleware order matters:
 *   request context -> request logger -> security headers -> CORS -> compression -> no-store
 *   -> body / cookie parsing -> global rate limit -> routes -> 404 -> error handler
 */
export function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.set('trust proxy', config.server.trustProxy);

  app.use(requestContextMiddleware); // MUST be first: opens the Request Context Store
  app.use(requestLogger);
  app.use(helmet());
  app.use(createCorsMiddleware());
  app.use(compression());
  app.use((_req, res, next) => {
    // Responses carry tokens / temporary passwords / personal data: never cache them.
    res.set({ 'Cache-Control': 'no-store', Pragma: 'no-cache' });
    next();
  });
  app.use(express.json({ limit: config.server.bodyLimit }));
  app.use(cookieParser());
  app.use(globalLimiter);

  registerRoutes(app);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
