import { config } from '../config/index.js';
import { purgeExpiredTokens } from '../modules/auth/token.service.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('cleanup');

async function runOnce() {
  try {
    const removed = await purgeExpiredTokens();
    if (removed.refreshTokens > 0 || removed.passwordResetTokens > 0) {
      log.info(removed, 'Expired tokens purged');
    }
  } catch (err) {
    log.error({ err }, 'Token cleanup failed'); // a failed housekeeping run must never crash the API
  }
}

/**
 * Periodically deletes long-expired refresh / password-reset tokens (CLEANUP_INTERVAL_MINUTES,
 * 0 disables it). Safe with several instances: the deletes are idempotent.
 * @returns {() => void} stop function
 */
export function startCleanupJob() {
  const { intervalMs } = config.cleanup;
  if (intervalMs <= 0) {
    log.info('Cleanup job is disabled');
    return () => {};
  }
  const first = setTimeout(runOnce, 15_000);
  const timer = setInterval(runOnce, intervalMs);
  first.unref();
  timer.unref();
  return () => {
    clearTimeout(first);
    clearInterval(timer);
  };
}
