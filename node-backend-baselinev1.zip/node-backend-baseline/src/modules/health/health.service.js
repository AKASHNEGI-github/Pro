import { pingDatabase } from '../../database/index.js';
import { ServiceUnavailableError } from '../../errors/index.js';
import { createLogger } from '../../utils/logger.js';

const log = createLogger('health');

/** Liveness: the process is up and the event loop answers. No dependencies are touched. */
export function getLiveness() {
  return {
    status: 'ok',
    uptimeSeconds: Math.round(process.uptime()),
    timestamp: new Date().toISOString(),
  };
}

/** Readiness: the app can serve traffic, i.e. the database answers. */
export async function getReadiness() {
  try {
    await pingDatabase();
    return { status: 'ready', checks: { database: 'up' }, timestamp: new Date().toISOString() };
  } catch (err) {
    log.error({ err }, 'Readiness check failed');
    throw new ServiceUnavailableError('Service is not ready', {
      details: [{ check: 'database', status: 'down' }],
      meta: { retryAfterSeconds: 5 },
    });
  }
}
