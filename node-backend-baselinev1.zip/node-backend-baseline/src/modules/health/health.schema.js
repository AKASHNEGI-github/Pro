import { z } from '../../utils/validation.js';

/** The probes take no input; unknown query parameters are ignored (never an error for probes). */
export const probeSchema = {
  query: z.object({}),
};
