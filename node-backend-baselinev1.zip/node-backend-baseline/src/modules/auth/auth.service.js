import { config } from '../../config/index.js';
import { ERROR_CODES } from '../../constants/errorCodes.js';
import { ROLES, SUPER_ADMIN_USER_ID } from '../../constants/roles.js';
import { requestContext } from '../../context/requestContext.js';
import { db, isDuplicateEntry, withTransaction } from '../../database/index.js';
import { ConflictError, ForbiddenError, UnauthorizedError } from '../../errors/index.js';
import { createLogger } from '../../utils/logger.js';
import { maskEmail } from '../../utils/mask.js';
import { hashPassword, verifyAgainstDummyHash, verifyPassword } from '../../utils/password.js';
import {
  assertCurrentPassword,
  assertNotSuperAdmin,
  createUserAccount,
  findUserById,
} from '../users/users.service.js';
import { buildSecurityProfileRecord, insertSecurityProfile } from './recovery.service.js';
import {
  issueRefreshToken,
  revokeAllRefreshTokens,
  revokeRefreshToken,
  rotateRefreshToken,
  signAccessToken,
} from './token.service.js';

const log = createLogger('auth');

const emailTaken = () =>
  new ConflictError('An account with this email already exists', {
    code: ERROR_CODES.EMAIL_ALREADY_EXISTS,
  });

const invalidCredentials = () =>
  new UnauthorizedError('Invalid email or password', { code: ERROR_CODES.INVALID_CREDENTIALS });

// ---------------------------------------------------------------------
// Sign-up
// ---------------------------------------------------------------------

/**
 * Public self-registration. Always creates a MEMBER. users + user_passwords + user_roles +
 * user_security_profiles are written in ONE transaction: if any table fails, nothing remains.
 */
export async function register({ fullName, email, password, securityProfile }) {
  if (!config.server.selfRegistrationEnabled) {
    throw new ForbiddenError('Self-registration is disabled', {
      code: ERROR_CODES.REGISTRATION_DISABLED,
    });
  }

  // Cheap early exit, before spending CPU on hashing. The unique index stays the real authority.
  if (await db.queryOne('SELECT user_id FROM users WHERE email_active = ?', [email])) {
    throw emailTaken();
  }

  // CPU-heavy hashing happens BEFORE the transaction so no connection/locks are held meanwhile.
  const [passwordHash, profileRecord] = await Promise.all([
    hashPassword(password),
    buildSecurityProfileRecord(securityProfile),
  ]);

  try {
    const userId = await withTransaction(async (tx) => {
      const id = await createUserAccount(tx, {
        fullName,
        email,
        passwordHash,
        roleName: ROLES.MEMBER,
        createdBy: null, // null = self-registered
      });
      await insertSecurityProfile(tx, id, profileRecord);
      return id;
    });
    log.info({ userId }, 'User registered');
    return await findUserById(userId);
  } catch (err) {
    if (isDuplicateEntry(err, 'uq_users_email_active')) throw emailTaken(); // lost a race
    throw err;
  }
}

// ---------------------------------------------------------------------
// Login / refresh / logout
// ---------------------------------------------------------------------

async function recordFailedLogin(userId, reason) {
  const { ip } = requestContext.getMeta();
  const now = new Date();
  try {
    await db.execute(
      `INSERT INTO user_login_logs
         (user_id, login_time, login_status, failure_reason, ip_address, created_at)
       VALUES (?, ?, 'FAILURE', ?, ?, ?)`,
      [userId, now, reason, ip?.slice(0, 45) ?? null, now],
    );
  } catch (err) {
    log.error({ err }, 'Could not write the login log'); // never fail a login attempt because of this
  }
}

/**
 * Email + password login. Works for every account; the super admin's password is verified
 * against SUPER_ADMIN_PASSWORD_HASH (ENV) instead of the user_passwords table.
 * Inactive users CAN log in (they just cannot do anything afterwards); deleted users cannot.
 *
 * Unknown e-mail and wrong password are indistinguishable to the caller (same message, same cost).
 */
export async function login({ email, password }) {
  const account = await db.queryOne(
    `SELECT u.user_id, up.hash_password
       FROM users u
       LEFT JOIN user_passwords up ON up.user_id = u.user_id
      WHERE u.email_active = ?`,
    [email],
  );

  let passwordValid = false;
  let failureReason = null;

  if (!account) {
    await verifyAgainstDummyHash(password);
    failureReason = 'ACCOUNT_NOT_FOUND';
  } else {
    const hash =
      account.user_id === SUPER_ADMIN_USER_ID
        ? config.superAdmin.passwordHash
        : account.hash_password;
    if (!hash) {
      await verifyAgainstDummyHash(password);
      failureReason = 'NO_PASSWORD_SET';
    } else {
      passwordValid = await verifyPassword(password, hash);
      if (!passwordValid) failureReason = 'INVALID_PASSWORD';
    }
  }

  if (!passwordValid) {
    log.warn({ email: maskEmail(email), reason: failureReason }, 'Login failed');
    if (account) await recordFailedLogin(account.user_id, failureReason);
    throw invalidCredentials();
  }

  const { ip } = requestContext.getMeta();
  const refresh = await withTransaction(async (tx) => {
    const now = new Date();
    await tx.execute('UPDATE users SET last_login = ? WHERE user_id = ?', [now, account.user_id]);
    await tx.execute(
      `INSERT INTO user_login_logs (user_id, login_time, login_status, ip_address, created_at)
       VALUES (?, ?, 'SUCCESS', ?, ?)`,
      [account.user_id, now, ip?.slice(0, 45) ?? null, now],
    );
    return issueRefreshToken(tx, account.user_id);
  });

  const user = await findUserById(account.user_id);
  const { accessToken, expiresIn } = signAccessToken(account.user_id);
  log.info({ userId: account.user_id }, 'Login successful');

  return {
    user,
    accessToken,
    expiresIn,
    refreshToken: refresh.rawToken,
    refreshExpiresAt: refresh.expiresAt,
  };
}

/** Rotates the refresh token and issues a fresh access token. */
export async function refreshSession(rawRefreshToken) {
  const rotated = await rotateRefreshToken(rawRefreshToken);
  const user = await findUserById(rotated.userId);
  if (!user) {
    throw new UnauthorizedError('Invalid refresh token', { code: ERROR_CODES.TOKEN_INVALID });
  }
  const { accessToken, expiresIn } = signAccessToken(rotated.userId);
  return {
    user,
    accessToken,
    expiresIn,
    refreshToken: rotated.rawToken,
    refreshExpiresAt: rotated.expiresAt,
  };
}

/** Ends the current session. Idempotent. */
export async function logout(rawRefreshToken) {
  if (rawRefreshToken) await revokeRefreshToken(rawRefreshToken);
}

/** Ends every session of the user. */
export async function logoutAll(actor) {
  const revokedSessions = await revokeAllRefreshTokens(actor.userId);
  return { revokedSessions };
}

// ---------------------------------------------------------------------
// Change password (logged in)
// ---------------------------------------------------------------------

/**
 * Needs the current password. Writes the new hash, revokes EVERY refresh token and - because
 * user_passwords.updated_at moves forward - every access token issued before now. The calling
 * device stays signed in: it receives a brand-new session in the same transaction.
 * This is also how a user clears `must_change_password` after an admin reset.
 */
export async function changePassword(actor, { currentPassword, newPassword }) {
  assertNotSuperAdmin(actor);
  await assertCurrentPassword(actor.userId, currentPassword);
  const newHash = await hashPassword(newPassword);

  const refresh = await withTransaction(async (tx) => {
    await tx.execute(
      `UPDATE user_passwords
          SET hash_password = ?, must_change_password = FALSE, updated_by = ?, updated_at = ?
        WHERE user_id = ?`,
      [newHash, actor.userId, new Date(), actor.userId],
    );
    await revokeAllRefreshTokens(actor.userId, tx);
    return issueRefreshToken(tx, actor.userId);
  });

  const { accessToken, expiresIn } = signAccessToken(actor.userId);
  log.info({ userId: actor.userId }, 'Password changed');
  return {
    accessToken,
    expiresIn,
    refreshToken: refresh.rawToken,
    refreshExpiresAt: refresh.expiresAt,
  };
}
