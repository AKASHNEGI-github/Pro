import jwt from 'jsonwebtoken';
import { config } from '../../config/index.js';
import { ERROR_CODES } from '../../constants/errorCodes.js';
import { requestContext } from '../../context/requestContext.js';
import { db, withTransaction } from '../../database/index.js';
import { UnauthorizedError } from '../../errors/index.js';
import { generateOpaqueToken, sha256Hex } from '../../utils/crypto.js';
import { createLogger } from '../../utils/logger.js';

const log = createLogger('auth.tokens');

// ---------------------------------------------------------------------
// Access token: short-lived, stateless JWT (HS256). It only identifies the user (`sub`);
// role and account state are re-read from the database on every request.
// ---------------------------------------------------------------------
export function signAccessToken(userId) {
  const accessToken = jwt.sign({}, config.jwt.accessSecret, {
    algorithm: 'HS256',
    subject: String(userId),
    issuer: config.jwt.issuer,
    audience: config.jwt.audience,
    expiresIn: config.jwt.accessTtlSeconds,
  });
  return { accessToken, expiresIn: config.jwt.accessTtlSeconds };
}

/** @returns {{ userId: number, issuedAt: number }} @throws UnauthorizedError */
export function verifyAccessToken(token) {
  try {
    const payload = jwt.verify(token, config.jwt.accessSecret, {
      algorithms: ['HS256'],
      issuer: config.jwt.issuer,
      audience: config.jwt.audience,
    });
    const userId = Number(payload.sub);
    if (!Number.isSafeInteger(userId) || userId < 1) throw new Error('invalid subject');
    return { userId, issuedAt: payload.iat };
  } catch (err) {
    if (err instanceof jwt.TokenExpiredError) {
      throw new UnauthorizedError('Access token has expired', { code: ERROR_CODES.TOKEN_EXPIRED });
    }
    throw new UnauthorizedError('Invalid access token', { code: ERROR_CODES.TOKEN_INVALID });
  }
}

// ---------------------------------------------------------------------
// Refresh token: opaque random value, stored only as a SHA-256 digest, rotated on every use.
// ---------------------------------------------------------------------

/**
 * Creates and stores a new refresh token. Pass the transaction executor when this must be
 * atomic with other writes (login, rotation, password change).
 * @returns {{ rawToken: string, tokenHash: string, expiresAt: Date }}
 */
export async function issueRefreshToken(executor, userId) {
  const { userAgent } = requestContext.getMeta();
  const rawToken = generateOpaqueToken();
  const tokenHash = sha256Hex(rawToken);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + config.refreshToken.ttlMs);

  await executor.execute(
    `INSERT INTO refresh_tokens (user_id, token_hash, expires_at, user_agent, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [userId, tokenHash, expiresAt, userAgent, now, now],
  );
  return { rawToken, tokenHash, expiresAt };
}

/**
 * Exchanges a refresh token for a new one (rotation).
 *
 *   ok       -> old token revoked + replaced_by_hash set, new token issued
 *   leeway   -> the token was rotated moments ago (parallel tabs/requests): plain 401, the
 *               client simply retries with the newer cookie; nothing else is revoked
 *   reuse    -> an already-rotated token came back later = probable theft: EVERY active
 *               refresh token of that user is revoked
 *   expired / invalid -> 401
 *
 * The decision is made inside one transaction (row locked with FOR UPDATE, so two concurrent
 * requests with the same token cannot both succeed) and the exception is thrown only AFTER
 * the commit, otherwise the revocations of the "reuse" case would be rolled back.
 */
export async function rotateRefreshToken(rawToken) {
  const tokenHash = sha256Hex(rawToken);

  const outcome = await withTransaction(async (tx) => {
    const row = await tx.queryOne(
      `SELECT refresh_tokens_id, user_id, expires_at, revoked_at, replaced_by_hash
         FROM refresh_tokens
        WHERE token_hash = ?
          FOR UPDATE`,
      [tokenHash],
    );
    if (!row) return { status: 'invalid' };

    const now = new Date();

    if (row.revoked_at) {
      // Revoked by logout / password change / admin action: just invalid, nothing to escalate.
      if (row.replaced_by_hash === null) return { status: 'invalid' };

      if (now.getTime() - row.revoked_at.getTime() <= config.refreshToken.reuseLeewayMs) {
        return { status: 'leeway' };
      }
      await tx.execute(
        `UPDATE refresh_tokens SET revoked_at = ?, updated_at = ?
          WHERE user_id = ? AND revoked_at IS NULL`,
        [now, now, row.user_id],
      );
      return { status: 'reuse', userId: row.user_id };
    }

    if (row.expires_at.getTime() <= now.getTime()) return { status: 'expired' };

    const user = await tx.queryOne(
      'SELECT user_id FROM users WHERE user_id = ? AND is_deleted = FALSE',
      [row.user_id],
    );
    if (!user) {
      await tx.execute(
        'UPDATE refresh_tokens SET revoked_at = ?, updated_at = ? WHERE refresh_tokens_id = ?',
        [now, now, row.refresh_tokens_id],
      );
      return { status: 'invalid' };
    }

    const next = await issueRefreshToken(tx, row.user_id);
    await tx.execute(
      `UPDATE refresh_tokens SET revoked_at = ?, replaced_by_hash = ?, updated_at = ?
        WHERE refresh_tokens_id = ?`,
      [now, next.tokenHash, now, row.refresh_tokens_id],
    );
    return {
      status: 'ok',
      userId: row.user_id,
      rawToken: next.rawToken,
      expiresAt: next.expiresAt,
    };
  });

  switch (outcome.status) {
    case 'ok':
      return { userId: outcome.userId, rawToken: outcome.rawToken, expiresAt: outcome.expiresAt };
    case 'leeway':
      // meta.clearCookie=false: do not wipe the newer cookie the browser may already hold.
      throw new UnauthorizedError('This refresh token was just used; retry with the latest one', {
        code: ERROR_CODES.TOKEN_INVALID,
        meta: { clearCookie: false },
      });
    case 'reuse':
      log.warn(
        { userId: outcome.userId },
        'Refresh token reuse detected - all refresh tokens of the user were revoked',
      );
      throw new UnauthorizedError(
        'Refresh token reuse detected. All sessions were revoked, please sign in again',
        { code: ERROR_CODES.TOKEN_INVALID },
      );
    case 'expired':
      throw new UnauthorizedError('Refresh token has expired', { code: ERROR_CODES.TOKEN_EXPIRED });
    default:
      throw new UnauthorizedError('Invalid refresh token', { code: ERROR_CODES.TOKEN_INVALID });
  }
}

/** Logout of one session. Idempotent: unknown / already revoked tokens are ignored. */
export async function revokeRefreshToken(rawToken) {
  const now = new Date();
  await db.execute(
    'UPDATE refresh_tokens SET revoked_at = ?, updated_at = ? WHERE token_hash = ? AND revoked_at IS NULL',
    [now, now, sha256Hex(rawToken)],
  );
}

/** Revokes every active session of a user. @returns {Promise<number>} sessions revoked */
export async function revokeAllRefreshTokens(userId, executor = db) {
  const now = new Date();
  const { affectedRows } = await executor.execute(
    'UPDATE refresh_tokens SET revoked_at = ?, updated_at = ? WHERE user_id = ? AND revoked_at IS NULL',
    [now, now, userId],
  );
  return affectedRows;
}

const PURGE_BATCH = 1000;

async function deleteInBatches(sql, params) {
  let total = 0;
  for (;;) {
    const { affectedRows } = await db.execute(sql, params);
    total += affectedRows;
    if (affectedRows < PURGE_BATCH) return total;
  }
}

/**
 * Housekeeping (called by the cleanup job): physically removes tokens that expired more than
 * `retentionMs` ago. Rotated/revoked tokens are kept until they expire so that reuse
 * detection keeps working for their whole lifetime.
 */
export async function purgeExpiredTokens({ retentionMs = 24 * 60 * 60 * 1000 } = {}) {
  const cutoff = new Date(Date.now() - retentionMs);
  const refreshTokens = await deleteInBatches(
    `DELETE FROM refresh_tokens WHERE expires_at < ? LIMIT ${PURGE_BATCH}`,
    [cutoff],
  );
  const passwordResetTokens = await deleteInBatches(
    `DELETE FROM password_reset_tokens WHERE expires_at < ? LIMIT ${PURGE_BATCH}`,
    [cutoff],
  );
  return { refreshTokens, passwordResetTokens };
}
