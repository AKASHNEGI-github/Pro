import {
  dobSchema,
  emailSchema,
  existingPasswordSchema,
  fullNameSchema,
  passwordSchema,
  securityAnswerSchema,
  securityProfileInputSchema,
  z,
} from '../../utils/validation.js';

/** Request schemas of the auth module. Shape: { body?, query?, params? } for `validate()`. */

export const registerSchema = {
  body: z.strictObject({
    fullName: fullNameSchema,
    email: emailSchema,
    password: passwordSchema,
    securityProfile: securityProfileInputSchema,
  }),
};

export const loginSchema = {
  body: z.strictObject({
    email: emailSchema,
    password: existingPasswordSchema,
  }),
};

export const changePasswordSchema = {
  body: z
    .strictObject({
      currentPassword: existingPasswordSchema,
      newPassword: passwordSchema,
    })
    .refine((data) => data.currentPassword !== data.newPassword, {
      message: 'New password must be different from the current password',
      path: ['newPassword'],
    }),
};

export const saveSecurityProfileSchema = {
  body: securityProfileInputSchema.extend({ currentPassword: existingPasswordSchema }),
};

export const recoveryQuestionsSchema = {
  body: z.strictObject({ email: emailSchema }),
};

export const recoveryVerifySchema = {
  body: z.strictObject({
    email: emailSchema,
    answers: z.strictObject({
      dob: dobSchema,
      q2: securityAnswerSchema,
      q3: securityAnswerSchema,
      custom1: securityAnswerSchema.optional(),
      custom2: securityAnswerSchema.optional(),
    }),
  }),
};

export const recoveryResetSchema = {
  body: z.strictObject({
    resetToken: z.string().min(20).max(256),
    newPassword: passwordSchema,
  }),
};
