import { config } from '../../config/index.js';

const { cookie } = config.refreshToken;

const baseOptions = {
  httpOnly: true, // never readable from JavaScript
  secure: cookie.secure,
  sameSite: cookie.sameSite,
  domain: cookie.domain,
  path: cookie.path, // only sent to /api/v1/auth/*
};

export function setRefreshCookie(res, rawToken, expiresAt) {
  res.cookie(cookie.name, rawToken, { ...baseOptions, expires: expiresAt });
}

export function clearRefreshCookie(res) {
  res.clearCookie(cookie.name, baseOptions);
}

/** The raw refresh token from the request cookie, or null. */
export function readRefreshCookie(req) {
  const value = req.cookies?.[cookie.name];
  return typeof value === 'string' && value.length > 0 && value.length <= 256 ? value : null;
}
