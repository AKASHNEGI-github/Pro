import { Router } from 'express';
import { ERROR_CODES } from '../../constants/errorCodes.js';
import {
  FIXED_SECURITY_QUESTIONS,
  MAX_CUSTOM_QUESTIONS,
} from '../../constants/securityQuestions.js';
import { AppError, UnauthorizedError } from '../../errors/index.js';
import { authenticate } from '../../middlewares/authenticate.middleware.js';
import { denySuperAdmin } from '../../middlewares/authorize.middleware.js';
import {
  authLimiter,
  loginLimiter,
  recoveryLimiter,
} from '../../middlewares/rateLimiter.middleware.js';
import { validate } from '../../middlewares/validate.middleware.js';
import { sendCreated, sendSuccess } from '../../utils/response.js';
import { toSelfResponse } from '../../utils/userMapper.js';
import { clearRefreshCookie, readRefreshCookie, setRefreshCookie } from './auth.cookies.js';
import {
  changePasswordSchema,
  loginSchema,
  recoveryQuestionsSchema,
  recoveryResetSchema,
  recoveryVerifySchema,
  registerSchema,
  saveSecurityProfileSchema,
} from './auth.schema.js';
import * as authService from './auth.service.js';
import * as recoveryService from './recovery.service.js';

/**
 * Router = HTTP only: rate limit -> authenticate/authorize -> validate -> call the service ->
 * send the standard response. No business logic and no SQL in here.
 */
const router = Router();

router.use(authLimiter);

/** { accessToken, tokenType, expiresIn, user } - the refresh token goes in the cookie, never the body. */
function sessionResponse(session) {
  return {
    accessToken: session.accessToken,
    tokenType: 'Bearer',
    expiresIn: session.expiresIn,
    ...(session.user ? { user: toSelfResponse(session.user) } : {}),
  };
}

// ---- public -----------------------------------------------------------

/** The fixed recovery questions (so a sign-up form can render them before an account exists). */
router.get('/security-questions', (_req, res) => {
  sendSuccess(res, {
    message: 'Security questions fetched successfully',
    data: { fixedQuestions: FIXED_SECURITY_QUESTIONS, maxCustomQuestions: MAX_CUSTOM_QUESTIONS },
  });
});

router.post('/register', validate(registerSchema), async (req, res) => {
  const user = await authService.register(req.validated.body);
  sendCreated(res, { message: 'Account created successfully', data: toSelfResponse(user) });
});

router.post('/login', loginLimiter, validate(loginSchema), async (req, res) => {
  const session = await authService.login(req.validated.body);
  setRefreshCookie(res, session.refreshToken, session.refreshExpiresAt);
  sendSuccess(res, { message: 'Login successful', data: sessionResponse(session) });
});

router.post('/refresh', async (req, res) => {
  const refreshToken = readRefreshCookie(req);
  if (!refreshToken) {
    throw new UnauthorizedError('Refresh token is missing', { code: ERROR_CODES.TOKEN_INVALID });
  }
  try {
    const session = await authService.refreshSession(refreshToken);
    setRefreshCookie(res, session.refreshToken, session.refreshExpiresAt);
    sendSuccess(res, { message: 'Token refreshed successfully', data: sessionResponse(session) });
  } catch (err) {
    // A dead refresh token is useless: drop the cookie (except in the "just rotated" race).
    if (err instanceof AppError && err.statusCode === 401 && err.meta?.clearCookie !== false) {
      clearRefreshCookie(res);
    }
    throw err;
  }
});

/** Idempotent and public: it only needs the cookie, so it works even with an expired access token. */
router.post('/logout', async (req, res) => {
  await authService.logout(readRefreshCookie(req));
  clearRefreshCookie(res);
  sendSuccess(res, { message: 'Logged out successfully' });
});

// ---- authenticated ----------------------------------------------------

router.post(
  '/logout-all',
  authenticate({ allowInactive: true, allowPasswordChangePending: true }),
  async (req, res) => {
    const result = await authService.logoutAll(req.user);
    clearRefreshCookie(res);
    sendSuccess(res, { message: 'Logged out from all devices', data: result });
  },
);

router.post(
  '/change-password',
  authenticate({ allowPasswordChangePending: true }),
  denySuperAdmin,
  validate(changePasswordSchema),
  async (req, res) => {
    const session = await authService.changePassword(req.user, req.validated.body);
    setRefreshCookie(res, session.refreshToken, session.refreshExpiresAt);
    sendSuccess(res, {
      message: 'Password changed successfully. Other devices were signed out',
      data: sessionResponse(session),
    });
  },
);

router.get('/security-profile', authenticate(), denySuperAdmin, async (req, res) => {
  const data = await recoveryService.getSecurityProfileStatus(req.user);
  sendSuccess(res, { message: 'Security profile fetched successfully', data });
});

router.put(
  '/security-profile',
  authenticate(),
  denySuperAdmin,
  validate(saveSecurityProfileSchema),
  async (req, res) => {
    const data = await recoveryService.saveSecurityProfile(req.user, req.validated.body);
    sendSuccess(res, { message: 'Security profile saved successfully', data });
  },
);

// ---- forgot password (public, no e-mail) -------------------------------

router.post(
  '/forgot-password/questions',
  recoveryLimiter,
  validate(recoveryQuestionsSchema),
  async (req, res) => {
    const data = await recoveryService.getRecoveryQuestions(req.validated.body.email);
    sendSuccess(res, { message: 'Security questions fetched successfully', data });
  },
);

router.post(
  '/forgot-password/verify',
  recoveryLimiter,
  validate(recoveryVerifySchema),
  async (req, res) => {
    const data = await recoveryService.verifyRecoveryAnswers(req.validated.body);
    sendSuccess(res, {
      message: 'Answers verified. Use the reset token to set a new password',
      data,
    });
  },
);

router.post(
  '/forgot-password/reset',
  recoveryLimiter,
  validate(recoveryResetSchema),
  async (req, res) => {
    await recoveryService.resetPasswordWithToken(req.validated.body);
    sendSuccess(res, { message: 'Password reset successfully. You can now sign in' });
  },
);

export default router;
