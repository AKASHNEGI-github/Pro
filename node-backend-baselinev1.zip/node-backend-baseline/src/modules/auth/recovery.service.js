import { config } from '../../config/index.js';
import { ERROR_CODES } from '../../constants/errorCodes.js';
import { SUPER_ADMIN_USER_ID } from '../../constants/roles.js';
import {
  FIXED_SECURITY_QUESTIONS,
  SECURITY_QUESTION_KEYS,
} from '../../constants/securityQuestions.js';
import { requestContext } from '../../context/requestContext.js';
import { db, withTransaction } from '../../database/index.js';
import { BadRequestError, TooManyRequestsError, UnauthorizedError } from '../../errors/index.js';
import { generateOpaqueToken, sha256Hex } from '../../utils/crypto.js';
import { createLogger } from '../../utils/logger.js';
import { hashPassword, verifyAgainstDummyHash } from '../../utils/password.js';
import { assertCurrentPassword, assertNotSuperAdmin } from '../users/users.service.js';
import { hashAnswer, verifyAnswer } from './securityAnswers.js';
import { revokeAllRefreshTokens } from './token.service.js';

const log = createLogger('auth.recovery');

const invalidAnswers = () =>
  new UnauthorizedError('The security answers are incorrect', {
    code: ERROR_CODES.INVALID_SECURITY_ANSWERS,
  });

function lockedError(retryAfterSeconds) {
  return new TooManyRequestsError(
    'Too many incorrect attempts. Password recovery is temporarily locked for this account',
    { code: ERROR_CODES.ACCOUNT_LOCKED, meta: { retryAfterSeconds } },
  );
}

function customQuestionsFromRow(row) {
  const questions = [];
  if (row.custom_question_1) {
    questions.push({ key: SECURITY_QUESTION_KEYS.CUSTOM_1, question: row.custom_question_1 });
  }
  if (row.custom_question_2) {
    questions.push({ key: SECURITY_QUESTION_KEYS.CUSTOM_2, question: row.custom_question_2 });
  }
  return questions;
}

// ---------------------------------------------------------------------
// Security profile (set at sign-up, changeable afterwards)
// ---------------------------------------------------------------------

/**
 * Hashes all answers (slow, CPU-bound -> do it BEFORE opening a transaction).
 * @param {{ dob: string, q2: string, q3: string, customQuestions: {question, answer}[] }} input
 */
export async function buildSecurityProfileRecord({ dob, q2, q3, customQuestions }) {
  const [dobHash, q2Hash, q3Hash, ...customHashes] = await Promise.all([
    hashAnswer(SECURITY_QUESTION_KEYS.DOB, dob),
    hashAnswer(SECURITY_QUESTION_KEYS.Q2, q2),
    hashAnswer(SECURITY_QUESTION_KEYS.Q3, q3),
    ...customQuestions.map((item, index) => hashAnswer(`custom${index + 1}`, item.answer)),
  ]);
  return {
    dobHash,
    q2Hash,
    q3Hash,
    custom: customQuestions.map((item, index) => ({
      question: item.question,
      hash: customHashes[index],
    })),
  };
}

function profileColumns(record) {
  const [first, second] = record.custom;
  return [
    record.dobHash,
    record.q2Hash,
    record.q3Hash,
    first?.question ?? null,
    first?.hash ?? null,
    second?.question ?? null,
    second?.hash ?? null,
  ];
}

export async function insertSecurityProfile(executor, userId, record) {
  const now = new Date();
  await executor.execute(
    `INSERT INTO user_security_profiles
       (user_id, dob_hash, answer_q2_hash, answer_q3_hash,
        custom_question_1, custom_answer_1_hash, custom_question_2, custom_answer_2_hash,
        failed_attempts, locked_until, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, NULL, ?, ?)`,
    [userId, ...profileColumns(record), now, now],
  );
}

async function replaceSecurityProfile(executor, userId, record) {
  await executor.execute(
    `UPDATE user_security_profiles
        SET dob_hash = ?, answer_q2_hash = ?, answer_q3_hash = ?,
            custom_question_1 = ?, custom_answer_1_hash = ?,
            custom_question_2 = ?, custom_answer_2_hash = ?,
            failed_attempts = 0, locked_until = NULL, updated_at = ?
      WHERE user_id = ?`,
    [...profileColumns(record), new Date(), userId],
  );
}

/** Whether the user has a recovery profile, and which custom questions they wrote. */
export async function getSecurityProfileStatus(actor) {
  assertNotSuperAdmin(actor);
  const row = await db.queryOne(
    `SELECT custom_question_1, custom_question_2, updated_at
       FROM user_security_profiles WHERE user_id = ?`,
    [actor.userId],
  );
  return {
    isConfigured: Boolean(row),
    fixedQuestions: FIXED_SECURITY_QUESTIONS,
    customQuestions: row ? customQuestionsFromRow(row) : [],
    updatedAt: row?.updated_at ?? null,
  };
}

/**
 * Create or replace the caller's recovery profile. Needs the CURRENT password: the recovery
 * answers are a second way into the account, so a stolen access token alone must not be able
 * to change them. Resets the failed-attempt counter and any lock.
 */
export async function saveSecurityProfile(actor, { currentPassword, ...profile }) {
  assertNotSuperAdmin(actor);
  await assertCurrentPassword(actor.userId, currentPassword);
  const record = await buildSecurityProfileRecord(profile);

  await withTransaction(async (tx) => {
    const existing = await tx.queryOne(
      'SELECT user_id FROM user_security_profiles WHERE user_id = ? FOR UPDATE',
      [actor.userId],
    );
    if (existing) await replaceSecurityProfile(tx, actor.userId, record);
    else await insertSecurityProfile(tx, actor.userId, record);
  });

  log.info({ userId: actor.userId }, 'Security profile saved');
  return getSecurityProfileStatus(actor);
}

// ---------------------------------------------------------------------
// Forgot password (no e-mail involved)
//   1. questions -> the questions the user has to answer
//   2. verify    -> every answer correct => a 10-minute, single-use reset token
//   3. reset     -> token + new password
// ---------------------------------------------------------------------

/**
 * Step 1. To avoid revealing which e-mails are registered, unknown accounts (and accounts
 * without a profile) receive the three fixed questions, exactly like a real account that
 * has no custom questions.
 */
export async function getRecoveryQuestions(email) {
  const row = await db.queryOne(
    `SELECT usp.custom_question_1, usp.custom_question_2
       FROM users u
       JOIN user_security_profiles usp ON usp.user_id = u.user_id
      WHERE u.email_active = ? AND u.user_id <> ?`,
    [email, SUPER_ADMIN_USER_ID],
  );
  return { questions: [...FIXED_SECURITY_QUESTIONS, ...(row ? customQuestionsFromRow(row) : [])] };
}

/** True only if EVERY question the user has was answered correctly. */
async function allAnswersCorrect(profile, answers) {
  const checks = [
    verifyAnswer(SECURITY_QUESTION_KEYS.DOB, answers.dob, profile.dob_hash),
    verifyAnswer(SECURITY_QUESTION_KEYS.Q2, answers.q2, profile.answer_q2_hash),
    verifyAnswer(SECURITY_QUESTION_KEYS.Q3, answers.q3, profile.answer_q3_hash),
  ];
  if (profile.custom_question_1) {
    checks.push(
      answers.custom1
        ? verifyAnswer(
            SECURITY_QUESTION_KEYS.CUSTOM_1,
            answers.custom1,
            profile.custom_answer_1_hash,
          )
        : false,
    );
  }
  if (profile.custom_question_2) {
    checks.push(
      answers.custom2
        ? verifyAnswer(
            SECURITY_QUESTION_KEYS.CUSTOM_2,
            answers.custom2,
            profile.custom_answer_2_hash,
          )
        : false,
    );
  }
  return (await Promise.all(checks)).every(Boolean);
}

/**
 * Step 2. The profile row is locked (FOR UPDATE) while the answers are checked, so parallel
 * guesses are serialised and cannot slip past the failed-attempt counter. After
 * SECURITY_MAX_FAILED_ATTEMPTS wrong tries the account is locked for SECURITY_LOCK_MINUTES.
 *
 * Failures are recorded (committed) first and only then turned into an exception.
 */
export async function verifyRecoveryAnswers({ email, answers }) {
  const { ip } = requestContext.getMeta();

  const account = await db.queryOne(
    'SELECT user_id FROM users WHERE email_active = ? AND user_id <> ?',
    [email, SUPER_ADMIN_USER_ID],
  );
  if (!account) {
    await verifyAgainstDummyHash('timing-equalisation'); // same cost as a real check
    throw invalidAnswers();
  }

  const outcome = await withTransaction(async (tx) => {
    const profile = await tx.queryOne(
      `SELECT dob_hash, answer_q2_hash, answer_q3_hash,
              custom_question_1, custom_answer_1_hash, custom_question_2, custom_answer_2_hash,
              failed_attempts, locked_until
         FROM user_security_profiles
        WHERE user_id = ?
          FOR UPDATE`,
      [account.user_id],
    );
    if (!profile) return { status: 'no_profile' };

    const now = new Date();
    if (profile.locked_until && profile.locked_until.getTime() > now.getTime()) {
      return {
        status: 'locked',
        retryAfterSeconds: Math.ceil((profile.locked_until.getTime() - now.getTime()) / 1000),
      };
    }

    if (await allAnswersCorrect(profile, answers)) {
      await tx.execute(
        `UPDATE user_security_profiles
            SET failed_attempts = 0, locked_until = NULL, updated_at = ? WHERE user_id = ?`,
        [now, account.user_id],
      );
      // only ONE reset token may be alive at a time
      await tx.execute(
        'UPDATE password_reset_tokens SET used_at = ? WHERE user_id = ? AND used_at IS NULL',
        [now, account.user_id],
      );
      const resetToken = generateOpaqueToken();
      const expiresAt = new Date(now.getTime() + config.recovery.resetTokenTtlMs);
      await tx.execute(
        `INSERT INTO password_reset_tokens (user_id, token_hash, expires_at, requested_ip, created_at)
         VALUES (?, ?, ?, ?, ?)`,
        [account.user_id, sha256Hex(resetToken), expiresAt, ip, now],
      );
      return { status: 'verified', resetToken, expiresAt };
    }

    const attempts = profile.failed_attempts + 1;
    if (attempts >= config.recovery.maxFailedAttempts) {
      await tx.execute(
        `UPDATE user_security_profiles
            SET failed_attempts = 0, locked_until = ?, updated_at = ? WHERE user_id = ?`,
        [new Date(now.getTime() + config.recovery.lockMs), now, account.user_id],
      );
      return {
        status: 'locked',
        retryAfterSeconds: Math.ceil(config.recovery.lockMs / 1000),
        justLocked: true,
      };
    }
    await tx.execute(
      'UPDATE user_security_profiles SET failed_attempts = ?, updated_at = ? WHERE user_id = ?',
      [attempts, now, account.user_id],
    );
    return { status: 'wrong' };
  });

  switch (outcome.status) {
    case 'verified':
      return {
        resetToken: outcome.resetToken,
        expiresAt: outcome.expiresAt,
        expiresInSeconds: Math.round(config.recovery.resetTokenTtlMs / 1000),
      };
    case 'locked':
      if (outcome.justLocked) {
        log.warn({ userId: account.user_id }, 'Password recovery locked after too many failures');
      }
      throw lockedError(outcome.retryAfterSeconds);
    case 'no_profile':
      await verifyAgainstDummyHash('timing-equalisation');
      throw invalidAnswers();
    default:
      throw invalidAnswers();
  }
}

/**
 * Step 3. Consumes the single-use token, sets the new password, revokes every session and
 * every access token issued before now (user_passwords.updated_at moves forward).
 */
export async function resetPasswordWithToken({ resetToken, newPassword }) {
  const newHash = await hashPassword(newPassword);
  const tokenHash = sha256Hex(resetToken);

  const outcome = await withTransaction(async (tx) => {
    const row = await tx.queryOne(
      `SELECT prt.password_reset_tokens_id, prt.user_id, prt.expires_at, prt.used_at
         FROM password_reset_tokens prt
         JOIN users u ON u.user_id = prt.user_id AND u.is_deleted = FALSE
        WHERE prt.token_hash = ?
          FOR UPDATE`,
      [tokenHash],
    );
    const now = new Date();
    if (!row || row.used_at || row.expires_at.getTime() <= now.getTime()) {
      return { status: 'invalid' };
    }

    await tx.execute(
      'UPDATE password_reset_tokens SET used_at = ? WHERE password_reset_tokens_id = ?',
      [now, row.password_reset_tokens_id],
    );
    const { affectedRows } = await tx.execute(
      `UPDATE user_passwords
          SET hash_password = ?, must_change_password = FALSE, updated_by = ?, updated_at = ?
        WHERE user_id = ?`,
      [newHash, row.user_id, now, row.user_id],
    );
    if (affectedRows === 0) return { status: 'invalid' };

    await revokeAllRefreshTokens(row.user_id, tx);
    return { status: 'ok', userId: row.user_id };
  });

  if (outcome.status !== 'ok') {
    throw new BadRequestError('The reset token is invalid or has expired', {
      code: ERROR_CODES.RESET_TOKEN_INVALID,
    });
  }
  log.info({ userId: outcome.userId }, 'Password reset through security questions');
}
