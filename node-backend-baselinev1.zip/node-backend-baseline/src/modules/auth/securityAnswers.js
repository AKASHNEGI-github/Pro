import { config } from '../../config/index.js';
import { hmacSha256Hex } from '../../utils/crypto.js';
import { hashPassword, verifyPassword } from '../../utils/password.js';

/**
 * Security answers are low-entropy secrets (a date of birth has ~35k plausible values), so a
 * plain bcrypt hash would be crackable offline if the database leaked. Defence in depth:
 *
 *   1. normalise    trim, collapse whitespace, Unicode NFKC, lower-case   ("  Delhi " == "delhi")
 *   2. pepper       HMAC-SHA256 with SECURITY_ANSWER_PEPPER (lives in ENV, NOT in the database),
 *                   bound to the question key so identical answers never share a digest
 *   3. bcrypt       slow, salted hash of that digest (a 64-char hex digest also sidesteps
 *                   bcrypt's 72-byte input limit)
 *
 * Rotating the pepper invalidates every stored answer (users must set their profile again).
 */
export function normalizeAnswer(value) {
  return String(value).normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
}

export function digestAnswer(questionKey, value) {
  return hmacSha256Hex(config.recovery.pepper, `sa:v1:${questionKey}:${normalizeAnswer(value)}`);
}

export function hashAnswer(questionKey, value) {
  return hashPassword(digestAnswer(questionKey, value));
}

export function verifyAnswer(questionKey, value, hash) {
  return verifyPassword(digestAnswer(questionKey, value), hash);
}
