import { ERROR_CODES } from '../../constants/errorCodes.js';
import { SUPER_ADMIN_USER_ID } from '../../constants/roles.js';
import { db, isDuplicateEntry, withTransaction } from '../../database/index.js';
import { ConflictError, NotFoundError } from '../../errors/index.js';
import { generateTemporaryPassword } from '../../utils/crypto.js';
import { createLogger } from '../../utils/logger.js';
import { hashPassword } from '../../utils/password.js';
import { buildPageMeta, toPagination } from '../../utils/pagination.js';
import { containsPattern, limitParam } from '../../utils/sql.js';
import { mapUserRow } from '../../utils/userMapper.js';
import { revokeAllRefreshTokens } from '../auth/token.service.js';
import {
  createUserAccount,
  findUserById,
  softDeleteUser,
  userNotFound,
} from '../users/users.service.js';
import { ADMIN_ACTIONS, assertCanAssignRole, assertCanManageUser } from './admin.policy.js';

const log = createLogger('admin');

const emailTaken = () =>
  new ConflictError('An account with this email already exists', {
    code: ERROR_CODES.EMAIL_ALREADY_EXISTS,
  });

const roleNotFound = () =>
  new NotFoundError('Role not found', { code: ERROR_CODES.ROLE_NOT_FOUND });

/** Only whitelisted columns can ever reach ORDER BY. */
const SORT_COLUMNS = Object.freeze({
  createdAt: 'u.created_at',
  fullName: 'u.full_name',
  email: 'u.email',
  lastLogin: 'u.last_login',
});

async function findAssignableRole(roleName) {
  return db.fetchOne(
    `SELECT role_id, role_name, role_level FROM roles
      WHERE role_name = ? AND is_active = TRUE AND is_deleted = FALSE`,
    [roleName],
    roleNotFound,
  );
}

/**
 * Locks the target row (SELECT ... FOR UPDATE) so concurrent admin actions on the same user are
 * serialised, then loads it. The policy check that follows therefore always sees current data.
 */
async function loadTargetForUpdate(tx, userId) {
  const locked = await tx.queryOne(
    'SELECT user_id FROM users WHERE user_id = ? AND is_deleted = FALSE FOR UPDATE',
    [userId],
  );
  if (!locked) throw userNotFound();
  return findUserById(userId, tx);
}

// ---------------------------------------------------------------------
// Read
// ---------------------------------------------------------------------

/** Paginated, filterable, sortable user list. The super admin is only visible to itself. */
export async function listUsers(actor, query) {
  const { page, limit, search, role, isActive, sortBy, sortOrder } = query;
  const { offset } = toPagination({ page, limit });

  const where = ['u.is_deleted = FALSE'];
  const params = [];

  if (!actor.isSuperAdmin) {
    where.push('u.user_id <> ?');
    params.push(SUPER_ADMIN_USER_ID);
  }
  if (isActive !== undefined) {
    where.push('u.is_active = ?');
    params.push(isActive);
  }
  if (role) {
    where.push('r.role_name = ?');
    params.push(role);
  }
  if (search) {
    where.push("(u.full_name LIKE ? ESCAPE '\\\\' OR u.email LIKE ? ESCAPE '\\\\')");
    const pattern = containsPattern(search);
    params.push(pattern, pattern);
  }

  const whereSql = where.join(' AND ');
  const fromSql = `FROM users u
    LEFT JOIN user_roles ur ON ur.user_id = u.user_id AND ur.is_active = TRUE AND ur.is_deleted = FALSE
    LEFT JOIN roles r ON r.role_id = ur.role_id AND r.is_active = TRUE AND r.is_deleted = FALSE`;
  const direction = sortOrder === 'asc' ? 'ASC' : 'DESC';

  const [rows, total] = await Promise.all([
    db.queryAll(
      `SELECT u.user_id, u.full_name, u.email, u.is_active, u.last_login, u.created_at,
              r.role_name, r.role_level
         ${fromSql}
        WHERE ${whereSql}
        ORDER BY ${SORT_COLUMNS[sortBy]} ${direction}, u.user_id ASC
        LIMIT ? OFFSET ?`,
      [...params, limitParam(limit), limitParam(offset)],
    ),
    db.queryScalar(`SELECT COUNT(*) ${fromSql} WHERE ${whereSql}`, params),
  ]);

  return { users: rows.map(mapUserRow), meta: buildPageMeta({ page, limit, total }) };
}

export async function getUser(actor, userId) {
  const target = await findUserById(userId);
  if (!target) throw userNotFound();
  assertCanManageUser(actor, target, ADMIN_ACTIONS.VIEW);
  return target;
}

// ---------------------------------------------------------------------
// Write (every mutation: lock target -> policy check -> write, in one transaction)
// ---------------------------------------------------------------------

/**
 * Creates a user with the chosen role. There is no e-mail service, so the system generates a
 * temporary password and returns it ONCE; the user is forced to change it at first login.
 */
export async function createUser(actor, { fullName, email, role }) {
  const roleRow = await findAssignableRole(role);
  assertCanAssignRole(actor, roleRow.role_level);

  if (await db.queryOne('SELECT user_id FROM users WHERE email_active = ?', [email])) {
    throw emailTaken();
  }

  const temporaryPassword = generateTemporaryPassword();
  const passwordHash = await hashPassword(temporaryPassword);

  try {
    const userId = await withTransaction((tx) =>
      createUserAccount(tx, {
        fullName,
        email,
        passwordHash,
        mustChangePassword: true,
        roleName: roleRow.role_name,
        createdBy: actor.userId,
      }),
    );
    log.info({ targetUserId: userId, role }, 'User created by admin');
    return { user: await findUserById(userId), temporaryPassword };
  } catch (err) {
    if (isDuplicateEntry(err, 'uq_users_email_active')) throw emailTaken();
    throw err;
  }
}

/** Profile = full name only. The e-mail is immutable (it is the login identifier). */
export async function updateUser(actor, userId, { fullName }) {
  return withTransaction(async (tx) => {
    const target = await loadTargetForUpdate(tx, userId);
    assertCanManageUser(actor, target, ADMIN_ACTIONS.UPDATE_PROFILE);
    await tx.execute('UPDATE users SET full_name = ? WHERE user_id = ?', [fullName, userId]);
    return findUserById(userId, tx);
  });
}

/** Activate / deactivate. A deactivated user can still sign in but cannot do anything. */
export async function setUserActive(actor, userId, isActive) {
  return withTransaction(async (tx) => {
    const target = await loadTargetForUpdate(tx, userId);
    assertCanManageUser(actor, target, ADMIN_ACTIONS.SET_STATUS);
    await tx.execute('UPDATE users SET is_active = ? WHERE user_id = ?', [isActive, userId]);
    log.info({ targetUserId: userId, isActive }, 'User activation changed');
    return findUserById(userId, tx);
  });
}

/**
 * Change a user's role (always an UPDATE of the single user_roles row). Takes effect on the
 * user's very next request because roles are re-read from the database on every request.
 */
export async function changeUserRole(actor, userId, role) {
  const roleRow = await findAssignableRole(role);

  return withTransaction(async (tx) => {
    const target = await loadTargetForUpdate(tx, userId);
    assertCanManageUser(actor, target, ADMIN_ACTIONS.CHANGE_ROLE);
    assertCanAssignRole(actor, roleRow.role_level);

    if (target.role !== roleRow.role_name) {
      const now = new Date();
      const { affectedRows } = await tx.execute(
        `UPDATE user_roles SET role_id = ?, assigned_at = ?, updated_by = ?, updated_at = ?
          WHERE user_id = ?`,
        [roleRow.role_id, now, actor.userId, now, userId],
      );
      if (affectedRows === 0) {
        await tx.execute(
          `INSERT INTO user_roles
             (user_id, role_id, assigned_at, created_by, created_at, updated_by, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [userId, roleRow.role_id, now, actor.userId, now, actor.userId, now],
        );
      }
      log.info(
        { targetUserId: userId, from: target.role, to: roleRow.role_name },
        'User role changed',
      );
    }
    return findUserById(userId, tx);
  });
}

/**
 * Admin password RESET (an admin never chooses or sees a real password): generates a temporary
 * password, forces a change at next login, revokes every session and clears any recovery lock.
 */
export async function resetUserPassword(actor, userId) {
  const temporaryPassword = generateTemporaryPassword();
  const passwordHash = await hashPassword(temporaryPassword);

  await withTransaction(async (tx) => {
    const target = await loadTargetForUpdate(tx, userId);
    assertCanManageUser(actor, target, ADMIN_ACTIONS.RESET_PASSWORD);

    const now = new Date();
    const { affectedRows } = await tx.execute(
      `UPDATE user_passwords
          SET hash_password = ?, must_change_password = TRUE, updated_by = ?, updated_at = ?
        WHERE user_id = ?`,
      [passwordHash, actor.userId, now, userId],
    );
    if (affectedRows === 0) {
      await tx.execute(
        `INSERT INTO user_passwords
           (user_id, hash_password, must_change_password, created_by, created_at, updated_by, updated_at)
         VALUES (?, ?, TRUE, ?, ?, ?, ?)`,
        [userId, passwordHash, actor.userId, now, actor.userId, now],
      );
    }

    await revokeAllRefreshTokens(userId, tx);
    await tx.execute(
      `UPDATE user_security_profiles SET failed_attempts = 0, locked_until = NULL, updated_at = ?
        WHERE user_id = ?`,
      [now, userId],
    );
    await tx.execute(
      'UPDATE password_reset_tokens SET used_at = ? WHERE user_id = ? AND used_at IS NULL',
      [now, userId],
    );
  });

  log.info({ targetUserId: userId }, 'Password reset by admin');
  return { temporaryPassword };
}

/** Soft delete + revoke all sessions. */
export async function deleteUser(actor, userId) {
  await withTransaction(async (tx) => {
    const target = await loadTargetForUpdate(tx, userId);
    assertCanManageUser(actor, target, ADMIN_ACTIONS.DELETE);
    await softDeleteUser(tx, userId);
  });
  log.info({ targetUserId: userId }, 'User deleted by admin');
}
