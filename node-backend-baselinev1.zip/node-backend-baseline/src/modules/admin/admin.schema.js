import { ASSIGNABLE_ROLES } from '../../constants/roles.js';
import {
  emailSchema,
  fullNameSchema,
  paginationQuerySchema,
  userIdParamSchema,
  z,
} from '../../utils/validation.js';

const roleSchema = z.enum(ASSIGNABLE_ROLES, {
  error: `Role must be one of: ${ASSIGNABLE_ROLES.join(', ')}`,
});

export const listUsersSchema = {
  query: paginationQuerySchema.extend({
    search: z.string().trim().min(1).max(100).optional(),
    role: roleSchema.optional(),
    isActive: z
      .enum(['true', 'false'], { error: 'isActive must be "true" or "false"' })
      .transform((value) => value === 'true')
      .optional(),
    sortBy: z.enum(['createdAt', 'fullName', 'email', 'lastLogin']).default('createdAt'),
    sortOrder: z.enum(['asc', 'desc']).default('desc'),
  }),
};

export const userIdSchema = { params: userIdParamSchema };

export const createUserSchema = {
  body: z.strictObject({
    fullName: fullNameSchema,
    email: emailSchema,
    role: roleSchema,
  }),
};

export const updateUserSchema = {
  params: userIdParamSchema,
  body: z.strictObject({ fullName: fullNameSchema }),
};

export const changeRoleSchema = {
  params: userIdParamSchema,
  body: z.strictObject({ role: roleSchema }),
};

export const setStatusSchema = {
  params: userIdParamSchema,
  body: z.strictObject({ isActive: z.boolean({ error: 'isActive must be a boolean' }) }),
};
