import { ERROR_CODES } from '../../constants/errorCodes.js';
import { ForbiddenError } from '../../errors/index.js';
import { userNotFound } from '../users/users.service.js';

/**
 * Instance-level authorization for the admin endpoints: may THIS actor perform THIS action on
 * THAT user? (Route-level "is the caller an admin at all?" is `authorize(ROLES.ADMIN)`.)
 *
 * Pure functions - no I/O - so the whole rule set is unit-tested as a table.
 *
 * Hierarchy: super_admin > admin > member  (roles.role_level; super admin = 1000 in code)
 *
 *  1. The super admin account is HIDDEN from everyone but the super admin (reads as "not found")
 *     and is untouchable through the API for everyone, itself included: ENV owns it.
 *  2. Nobody uses the admin endpoints on their own account (use /users/me instead),
 *     which prevents self-lockout and self-escalation. Viewing yourself is harmless.
 *  3. The super admin may manage every other account.
 *  4. Everyone else may only manage users ranked STRICTLY BELOW them (admin -> member only).
 *     Admins can still VIEW other admins, but cannot edit, deactivate, reset, delete or demote them.
 *  5. A role can only be assigned if its level is <= the actor's own level. Combined with (4)
 *     this gives exactly the agreed behaviour: an admin may create admins and promote
 *     members to admin, but never demote or touch an existing admin.
 */
export const ADMIN_ACTIONS = Object.freeze({
  VIEW: 'view',
  UPDATE_PROFILE: 'update_profile',
  SET_STATUS: 'set_status',
  CHANGE_ROLE: 'change_role',
  RESET_PASSWORD: 'reset_password',
  DELETE: 'delete',
});

export function assertCanManageUser(actor, target, action) {
  if (target.isSuperAdmin) {
    if (!actor.isSuperAdmin) throw userNotFound();
    if (action === ADMIN_ACTIONS.VIEW) return;
    throw new ForbiddenError(
      'The super admin account is managed through environment configuration, not the API',
      { code: ERROR_CODES.SUPER_ADMIN_PROTECTED },
    );
  }

  if (target.userId === actor.userId) {
    if (action === ADMIN_ACTIONS.VIEW) return;
    throw new ForbiddenError(
      'You cannot perform this action on your own account here; use the /users/me endpoints',
      { code: ERROR_CODES.SELF_ACTION_NOT_ALLOWED },
    );
  }

  if (actor.isSuperAdmin) return;
  if (action === ADMIN_ACTIONS.VIEW) return;
  if (actor.roleLevel > target.roleLevel) return;

  throw new ForbiddenError('You can only manage users ranked below your own role', {
    code: ERROR_CODES.INSUFFICIENT_ROLE,
  });
}

export function assertCanAssignRole(actor, roleLevel) {
  if (actor.isSuperAdmin || (roleLevel ?? 0) <= actor.roleLevel) return;
  throw new ForbiddenError('You cannot assign a role higher than your own', {
    code: ERROR_CODES.INSUFFICIENT_ROLE,
  });
}
