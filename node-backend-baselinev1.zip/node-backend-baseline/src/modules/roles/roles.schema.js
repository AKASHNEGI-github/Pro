import { z } from '../../utils/validation.js';

export const listRolesSchema = {
  query: z.object({
    // ?assignable=true -> only the roles the caller is allowed to assign
    assignable: z
      .enum(['true', 'false'], { error: 'assignable must be "true" or "false"' })
      .transform((value) => value === 'true')
      .optional(),
  }),
};
