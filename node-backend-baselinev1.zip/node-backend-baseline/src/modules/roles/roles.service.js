import { db } from '../../database/index.js';

/**
 * Assignable roles from the database, each flagged with whether THIS caller may assign it
 * (role_level <= the caller's own level; the super admin may assign every role).
 */
export async function listRoles(actor, { assignable } = {}) {
  const rows = await db.queryAll(
    `SELECT role_id, role_name, role_level, description
       FROM roles
      WHERE is_active = TRUE AND is_deleted = FALSE
      ORDER BY role_level ASC, role_name ASC`,
  );
  const roles = rows.map((row) => ({
    roleId: row.role_id,
    roleName: row.role_name,
    roleLevel: row.role_level,
    description: row.description,
    assignable: actor.isSuperAdmin || (row.role_level ?? 0) <= actor.roleLevel,
  }));
  return assignable === undefined ? roles : roles.filter((role) => role.assignable === assignable);
}
