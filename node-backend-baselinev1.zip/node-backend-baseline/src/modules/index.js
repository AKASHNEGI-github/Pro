import { Router } from 'express';
import { config } from '../config/index.js';
import adminRouter from './admin/admin.router.js';
import authRouter from './auth/auth.router.js';
import healthRouter from './health/health.router.js';
import rolesRouter from './roles/roles.router.js';
import usersRouter from './users/users.router.js';

/**
 * The only place that knows every module. To add a module: create src/modules/<name>/
 * with <name>.router.js, <name>.schema.js and <name>.service.js, then mount it here.
 *
 *   /health                     infrastructure probes (unversioned)
 *   /api/v1/auth                sign-up, login, tokens, password change, recovery
 *   /api/v1/users               self-service (/users/me)
 *   /api/v1/admin               user management (/admin/users...)
 *   /api/v1/roles               assignable roles
 */
export function registerRoutes(app) {
  app.use('/health', healthRouter);

  const api = Router();
  api.use('/auth', authRouter);
  api.use('/users', usersRouter);
  api.use('/admin', adminRouter);
  api.use('/roles', rolesRouter);
  app.use(config.server.apiPrefix, api);
}
