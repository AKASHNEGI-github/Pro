import { existingPasswordSchema, fullNameSchema, z } from '../../utils/validation.js';

export const updateProfileSchema = {
  // Only the full name is editable. The e-mail is immutable; unknown keys are rejected (422).
  body: z.strictObject({ fullName: fullNameSchema }),
};

export const deleteAccountSchema = {
  body: z.strictObject({ password: existingPasswordSchema }),
};
