import { ERROR_CODES } from '../../constants/errorCodes.js';
import { db, withTransaction } from '../../database/index.js';
import {
  BadRequestError,
  ForbiddenError,
  InternalServerError,
  NotFoundError,
} from '../../errors/index.js';
import { verifyAgainstDummyHash, verifyPassword } from '../../utils/password.js';
import { createLogger } from '../../utils/logger.js';
import { mapUserRow } from '../../utils/userMapper.js';
import { revokeAllRefreshTokens } from '../auth/token.service.js';

const log = createLogger('users');

/**
 * Base query for "a user with everything we need to authorize and display them":
 * role, password state (must change / last changed) and whether a recovery profile exists.
 */
const USER_SELECT = `
  SELECT u.user_id, u.full_name, u.email, u.is_active, u.last_login, u.created_at,
         r.role_name, r.role_level,
         up.must_change_password, up.updated_at AS password_changed_at,
         usp.user_id AS security_profile_user_id
    FROM users u
    LEFT JOIN user_roles ur ON ur.user_id = u.user_id AND ur.is_active = TRUE AND ur.is_deleted = FALSE
    LEFT JOIN roles r ON r.role_id = ur.role_id AND r.is_active = TRUE AND r.is_deleted = FALSE
    LEFT JOIN user_passwords up ON up.user_id = u.user_id
    LEFT JOIN user_security_profiles usp ON usp.user_id = u.user_id`;

export const userNotFound = () =>
  new NotFoundError('User not found', { code: ERROR_CODES.USER_NOT_FOUND });

/** Non-deleted user by id (internal model), or null. Pass `tx` to read inside a transaction. */
export async function findUserById(userId, executor = db) {
  const row = await executor.queryOne(
    `${USER_SELECT} WHERE u.user_id = ? AND u.is_deleted = FALSE`,
    [userId],
  );
  return mapUserRow(row);
}

/**
 * Defence in depth: routes already use `denySuperAdmin`, but the services refuse too.
 * The super admin's identity and credentials are owned by ENV, never by the API.
 */
export function assertNotSuperAdmin(actor) {
  if (actor.isSuperAdmin) {
    throw new ForbiddenError(
      'The super admin account is managed through environment configuration, not the API',
      { code: ERROR_CODES.SUPER_ADMIN_PROTECTED },
    );
  }
}

/** Throws INVALID_CURRENT_PASSWORD (400) unless `plain` matches the user's stored password. */
export async function assertCurrentPassword(userId, plain) {
  const row = await db.queryOne('SELECT hash_password FROM user_passwords WHERE user_id = ?', [
    userId,
  ]);
  const valid = row
    ? await verifyPassword(plain, row.hash_password)
    : await verifyAgainstDummyHash(plain);
  if (!valid) {
    throw new BadRequestError('The current password is incorrect', {
      code: ERROR_CODES.INVALID_CURRENT_PASSWORD,
    });
  }
}

/**
 * Creates the user + password + role rows. MUST run inside a transaction (pass `tx`) so a
 * failure in any table leaves nothing behind. Sign-up and admin "create user" both use it.
 *
 * @param {object} tx
 * @param {object} input
 * @param {string} input.fullName
 * @param {string} input.email          already normalised (trimmed, lower-case)
 * @param {string} input.passwordHash   bcrypt hash (hash BEFORE opening the transaction)
 * @param {boolean} [input.mustChangePassword=false]
 * @param {string} input.roleName       'member' | 'admin'
 * @param {number|null} [input.createdBy=null]  null = self-registered
 * @returns {Promise<number>} the new user_id
 */
export async function createUserAccount(
  tx,
  { fullName, email, passwordHash, mustChangePassword = false, roleName, createdBy = null },
) {
  const now = new Date();

  const { insertId: userId } = await tx.execute(
    `INSERT INTO users (full_name, email, is_active, created_by, created_at)
     VALUES (?, ?, TRUE, ?, ?)`,
    [fullName, email, createdBy, now],
  );

  await tx.execute(
    `INSERT INTO user_passwords
       (user_id, hash_password, must_change_password, created_by, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [userId, passwordHash, mustChangePassword, createdBy, now, now],
  );

  const role = await tx.fetchOne(
    'SELECT role_id FROM roles WHERE role_name = ? AND is_active = TRUE AND is_deleted = FALSE',
    [roleName],
    () =>
      new InternalServerError(`Role "${roleName}" is not configured`, {
        code: ERROR_CODES.ROLE_NOT_FOUND,
      }),
  );

  await tx.execute(
    `INSERT INTO user_roles (user_id, role_id, assigned_at, created_by, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [userId, role.role_id, now, createdBy, now, now],
  );

  return userId;
}

/**
 * Soft delete (is_deleted = TRUE) + revoke every session. Runs inside the caller's transaction.
 * The row stays for history; thanks to the generated `email_active` column the e-mail is
 * immediately free for a new account.
 */
export async function softDeleteUser(tx, userId) {
  const { affectedRows } = await tx.execute(
    'UPDATE users SET is_deleted = TRUE WHERE user_id = ? AND is_deleted = FALSE',
    [userId],
  );
  if (affectedRows === 0) throw userNotFound();
  await revokeAllRefreshTokens(userId, tx);
}

// ---------------------------------------------------------------------
// Self-service (/users/me)
// ---------------------------------------------------------------------

/** Update own profile. Only the full name is editable - the e-mail is immutable by design. */
export async function updateOwnProfile(actor, { fullName }) {
  assertNotSuperAdmin(actor);
  await db.execute('UPDATE users SET full_name = ? WHERE user_id = ? AND is_deleted = FALSE', [
    fullName,
    actor.userId,
  ]);
  return findUserById(actor.userId);
}

/** Delete own account (soft). Requires the current password. */
export async function deleteOwnAccount(actor, { password }) {
  assertNotSuperAdmin(actor);
  await assertCurrentPassword(actor.userId, password);
  await withTransaction((tx) => softDeleteUser(tx, actor.userId));
  log.info({ userId: actor.userId }, 'Account deleted by its owner');
}
