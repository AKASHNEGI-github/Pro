import { ERROR_CODES } from '../constants/errorCodes.js';
import { BadRequestError, ConflictError, ServiceUnavailableError } from '../errors/index.js';

/** True for a unique-key violation, optionally for one specific index name. */
export function isDuplicateEntry(err, indexName) {
  if (err?.code !== 'ER_DUP_ENTRY') return false;
  return indexName ? String(err.sqlMessage ?? '').includes(indexName) : true;
}

export function isDeadlock(err) {
  return err?.code === 'ER_LOCK_DEADLOCK';
}

const CONNECTION_ERROR_CODES = new Set([
  'ECONNREFUSED',
  'ECONNRESET',
  'ETIMEDOUT',
  'ENOTFOUND',
  'EPIPE',
  'PROTOCOL_CONNECTION_LOST',
  'POOL_CLOSED',
  'ER_CON_COUNT_ERROR',
  'ER_SERVER_SHUTDOWN',
]);

/**
 * Translates a raw MySQL/driver error into an AppError for the global error handler.
 * Services should still catch the errors they expect (e.g. a duplicate e-mail) and throw a
 * specific exception; this is the safety net for everything else.
 * @returns {AppError|null} null when the error is not a database error we recognise.
 */
export function mapDatabaseError(err) {
  if (!err || typeof err !== 'object') return null;

  // mysql2 throws a plain Error (no `code`) when work reaches a pool that was already ended,
  // e.g. an in-flight request during graceful shutdown. That is "unavailable", not "a bug".
  if (err.code === undefined && /pool is closed/i.test(String(err.message))) {
    return new ServiceUnavailableError('The database is currently unavailable', {
      cause: err,
      meta: { retryAfterSeconds: 5 },
    });
  }

  if (typeof err.code !== 'string') return null;

  if (err.code === 'ER_DUP_ENTRY') {
    return new ConflictError('Resource already exists', { code: ERROR_CODES.CONFLICT, cause: err });
  }
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    return new BadRequestError('A referenced resource does not exist', { cause: err });
  }
  if (err.code === 'ER_ROW_IS_REFERENCED_2') {
    return new ConflictError('The resource is still referenced by other records', { cause: err });
  }
  if (err.code === 'ER_LOCK_DEADLOCK' || err.code === 'ER_LOCK_WAIT_TIMEOUT') {
    return new ServiceUnavailableError('The system is busy, please retry', {
      cause: err,
      meta: { retryAfterSeconds: 1 },
    });
  }
  if (CONNECTION_ERROR_CODES.has(err.code)) {
    return new ServiceUnavailableError('The database is currently unavailable', {
      cause: err,
      meta: { retryAfterSeconds: 5 },
    });
  }
  return null;
}
