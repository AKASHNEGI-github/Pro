import { setTimeout as sleep } from 'node:timers/promises';
import { createLogger } from '../utils/logger.js';
import { isDeadlock } from './errors.js';
import { createExecutor } from './executor.js';
import { pool } from './pool.js';

const log = createLogger('db');

/**
 * Runs `work(tx)` inside ONE database transaction.
 *
 *  - `tx` has the same helpers as `db` (queryOne, queryAll, fetchOne, fetchAll, execute, ...),
 *    all bound to the transaction's connection.
 *  - If `work` resolves, the transaction is committed and its value is returned.
 *  - If `work` throws (or any statement fails), everything written through `tx` is rolled
 *    back and the error is re-thrown.
 *  - Deadlocks (ER_LOCK_DEADLOCK) are retried automatically, so `work` must be safe to run again:
 *    do password hashing / external calls BEFORE opening the transaction.
 *
 * Do NOT throw from inside `work` for an outcome that must stay committed (e.g. recording a
 * failed attempt). Return a status from `work`, and throw after the transaction has committed.
 *
 * Nested transactions are not supported (there is deliberately no `tx.withTransaction`).
 */
export async function withTransaction(work, { maxDeadlockRetries = 2 } = {}) {
  for (let attempt = 0; ; attempt += 1) {
    const connection = await pool.getConnection();
    let open = true;
    let discardConnection = false;

    try {
      await connection.beginTransaction();
      const result = await work(createExecutor(connection, { isOpen: () => open }));
      await connection.commit();
      return result;
    } catch (err) {
      try {
        await connection.rollback();
      } catch (rollbackError) {
        discardConnection = true; // the connection is in an unknown state: never reuse it
        log.error({ err: rollbackError }, 'Rollback failed; discarding the connection');
      }
      if (isDeadlock(err) && attempt < maxDeadlockRetries) {
        log.warn({ attempt: attempt + 1 }, 'Deadlock detected; retrying the transaction');
        await sleep(25 * (attempt + 1));
        continue;
      }
      throw err;
    } finally {
      open = false;
      if (discardConnection) connection.destroy();
      else connection.release();
    }
  }
}
