import { config } from '../config/index.js';
import { NotFoundError } from '../errors/index.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('db');

const compact = (sql) => sql.replace(/\s+/g, ' ').trim().slice(0, 300);

/** `notFound` may be an Error instance, a factory returning one, or just a message. */
function resolveNotFound(notFound) {
  if (notFound instanceof Error) return notFound;
  if (typeof notFound === 'function') return notFound();
  return new NotFoundError(typeof notFound === 'string' ? notFound : 'Resource not found');
}

/**
 * Builds the set of query helpers on top of anything that has `.execute(sql, params)`:
 * the connection pool (auto-commit) or a single connection inside a transaction.
 * Both expose the SAME interface, so a service function can take an `executor`
 * argument and work identically inside and outside a transaction.
 *
 * Every statement is a prepared statement: values are ALWAYS passed as `params`,
 * never concatenated into the SQL string.
 *
 * Naming rule:
 *   query*  -> lenient: "nothing found" is a normal outcome ([] / null / null)
 *   fetch*  -> strict : "nothing found" throws (NotFoundError by default)
 */
export function createExecutor(runner, { isOpen = () => true } = {}) {
  async function run(sql, params = []) {
    if (!isOpen()) {
      throw new Error('This transaction has already finished; its executor can no longer be used');
    }
    const startedAt = process.hrtime.bigint();
    try {
      const [result] = await runner.execute(sql, params);
      return result;
    } finally {
      const durationMs = Number(process.hrtime.bigint() - startedAt) / 1e6;
      if (durationMs >= config.db.slowQueryMs) {
        log.warn({ durationMs: Math.round(durationMs), sql: compact(sql) }, 'Slow query');
      } else if (log.isLevelEnabled('debug')) {
        log.debug({ durationMs: Math.round(durationMs), sql: compact(sql) }, 'Query executed');
      }
    }
  }

  async function queryAll(sql, params) {
    const rows = await run(sql, params);
    if (!Array.isArray(rows)) throw new TypeError('queryAll() expects a SELECT statement');
    return rows;
  }

  /** First row, or null. Add `LIMIT 1` to the SQL when the query can match several rows. */
  async function queryOne(sql, params) {
    const rows = await queryAll(sql, params);
    return rows[0] ?? null;
  }

  /** First column of the first row (COUNT(*), EXISTS, ...), or null. */
  async function queryScalar(sql, params) {
    const row = await queryOne(sql, params);
    return row ? Object.values(row)[0] : null;
  }

  async function fetchAll(sql, params, notFound) {
    const rows = await queryAll(sql, params);
    if (rows.length === 0) throw resolveNotFound(notFound);
    return rows;
  }

  async function fetchOne(sql, params, notFound) {
    const row = await queryOne(sql, params);
    if (!row) throw resolveNotFound(notFound);
    return row;
  }

  /**
   * INSERT / UPDATE / DELETE.
   * `affectedRows` counts MATCHED rows (the driver sets the FOUND_ROWS flag), so an UPDATE that
   * writes identical values still reports 1.
   */
  async function execute(sql, params) {
    const result = await run(sql, params);
    return {
      affectedRows: result.affectedRows,
      insertId: result.insertId,
      changedRows: result.changedRows,
    };
  }

  return Object.freeze({ queryAll, queryOne, queryScalar, fetchAll, fetchOne, execute });
}
