import { createExecutor } from './executor.js';
import { pool, pingDatabase, closePool } from './pool.js';

/** Auto-commit executor backed by the pool. Use `withTransaction` for multi-table writes. */
export const db = createExecutor(pool);

export const { queryAll, queryOne, queryScalar, fetchAll, fetchOne, execute } = db;

export { withTransaction } from './transaction.js';
export { pool, pingDatabase, closePool };
export { isDuplicateEntry, isDeadlock, mapDatabaseError } from './errors.js';
