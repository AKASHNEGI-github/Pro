import fs from 'node:fs';
import mysql from 'mysql2/promise';
import { config } from '../config/index.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('db');

function buildSslOptions() {
  const { ssl } = config.db;
  if (!ssl.enabled) return undefined;
  return {
    minVersion: 'TLSv1.2',
    rejectUnauthorized: ssl.rejectUnauthorized,
    ...(ssl.caPath ? { ca: fs.readFileSync(ssl.caPath) } : {}),
  };
}

/**
 * Single shared connection pool. All timestamps in the schema are UTC, so the
 * driver is told to read/write UTC (timezone: 'Z') and every new connection
 * switches its session time zone to UTC as well.
 */
export const pool = mysql.createPool({
  host: config.db.host,
  port: config.db.port,
  user: config.db.user,
  password: config.db.password,
  database: config.db.database,
  waitForConnections: true,
  connectionLimit: config.db.connectionLimit,
  queueLimit: config.db.queueLimit,
  connectTimeout: config.db.connectTimeoutMs,
  charset: 'utf8mb4',
  timezone: 'Z',
  supportBigNumbers: true, // BIGINT ids come back as numbers (strings only above 2^53)
  bigNumberStrings: false,
  dateStrings: false,
  enableKeepAlive: true,
  keepAliveInitialDelay: 10000,
  ssl: buildSslOptions(),
});

pool.on('connection', (connection) => {
  connection.query("SET time_zone = '+00:00'", (err) => {
    if (err) log.error({ err }, 'Could not set the session time zone to UTC');
  });
});

/** Cheap liveness probe used by startup checks and GET /health/ready. */
export async function pingDatabase() {
  await pool.query('SELECT 1');
}

export async function closePool() {
  await pool.end();
}
