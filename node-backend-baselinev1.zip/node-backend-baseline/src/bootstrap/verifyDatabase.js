import { config } from '../config/index.js';
import { ROLES } from '../constants/roles.js';
import { db, pingDatabase } from '../database/index.js';

const REQUIRED_ROLES = [ROLES.ADMIN, ROLES.MEMBER];

/**
 * Fail fast at startup with an actionable message instead of failing on the first request:
 * the database must be reachable, the schema must exist and the seeded roles must be present.
 */
export async function verifyDatabase() {
  const { host, port, database } = config.db;

  try {
    await pingDatabase();
  } catch (err) {
    throw new Error(
      `Cannot connect to MySQL at ${host}:${port} (database "${database}"): ${err.code ?? err.message}`,
      { cause: err },
    );
  }

  let rows;
  try {
    rows = await db.queryAll(
      `SELECT role_name FROM roles
        WHERE role_name IN (?, ?) AND is_active = TRUE AND is_deleted = FALSE`,
      REQUIRED_ROLES,
    );
  } catch (err) {
    if (err.code === 'ER_NO_SUCH_TABLE') {
      throw new Error('The database schema is missing. Run: npm run db:schema', { cause: err });
    }
    throw err;
  }

  const found = new Set(rows.map((row) => row.role_name));
  const missing = REQUIRED_ROLES.filter((role) => !found.has(role));
  if (missing.length > 0) {
    throw new Error(`Required roles are missing (${missing.join(', ')}). Run: npm run db:seed`);
  }
}
