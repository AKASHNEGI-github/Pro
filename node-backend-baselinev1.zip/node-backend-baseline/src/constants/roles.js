/**
 * Role model
 *   super_admin  virtual role: exactly one account (user_id = 1), credentials in ENV only.
 *                It is NOT a row in the `roles` table, so it can never be assigned.
 *   admin        user management            (roles.role_level = 2)
 *   member       default role on sign-up    (roles.role_level = 1)
 */
export const ROLES = Object.freeze({
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  MEMBER: 'member',
});

/** Roles that can be stored in the database / assigned through the API. */
export const ASSIGNABLE_ROLES = Object.freeze([ROLES.ADMIN, ROLES.MEMBER]);

/** The reserved users.user_id of the super admin. */
export const SUPER_ADMIN_USER_ID = 1;

/** Higher than any database role level, so the hierarchy check always favours the super admin. */
export const SUPER_ADMIN_ROLE_LEVEL = 1000;
