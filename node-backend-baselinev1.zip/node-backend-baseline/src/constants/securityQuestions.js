/**
 * Password-recovery questions (no email service is used).
 *
 *  - Questions 1-3 are FIXED for everyone: date of birth + two questions defined here.
 *    Only their (peppered + bcrypt-hashed) answers are stored.
 *  - Questions 4-5 are OPTIONAL and written by the user; the question text is stored too.
 */
export const SECURITY_QUESTION_KEYS = Object.freeze({
  DOB: 'dob',
  Q2: 'q2',
  Q3: 'q3',
  CUSTOM_1: 'custom1',
  CUSTOM_2: 'custom2',
});

export const FIXED_SECURITY_QUESTIONS = Object.freeze([
  Object.freeze({
    key: SECURITY_QUESTION_KEYS.DOB,
    question: 'What is your date of birth?',
    answerFormat: 'YYYY-MM-DD',
  }),
  Object.freeze({
    key: SECURITY_QUESTION_KEYS.Q2,
    question: 'In which city were you born?',
    answerFormat: 'text',
  }),
  Object.freeze({
    key: SECURITY_QUESTION_KEYS.Q3,
    question: 'What was the name of your first school?',
    answerFormat: 'text',
  }),
]);

export const MAX_CUSTOM_QUESTIONS = 2;
