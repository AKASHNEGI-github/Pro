import bcrypt from 'bcrypt';
import { config } from '../config/index.js';

export function hashPassword(plain) {
  return bcrypt.hash(plain, config.password.bcryptRounds);
}

export function verifyPassword(plain, hash) {
  return bcrypt.compare(plain, hash);
}

let dummyHashPromise;

/**
 * Burns the same CPU time as a real password check and always resolves `false`.
 * Used when the account does not exist so response timing does not reveal
 * whether an email is registered (user enumeration via timing).
 */
export async function verifyAgainstDummyHash(plain) {
  dummyHashPromise ??= bcrypt.hash('timing-equalisation-dummy', config.password.bcryptRounds);
  await bcrypt.compare(plain, await dummyHashPromise);
  return false;
}
