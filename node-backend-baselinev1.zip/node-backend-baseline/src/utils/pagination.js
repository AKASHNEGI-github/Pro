/** Converts validated { page, limit } into SQL-friendly values. */
export function toPagination({ page, limit }) {
  return { page, limit, offset: (page - 1) * limit };
}

/** Standard `meta` block for paginated lists. */
export function buildPageMeta({ page, limit, total }) {
  return { page, limit, total, totalPages: Math.ceil(total / limit) };
}
