/** Escapes %, _ and \ so user input is matched literally inside a LIKE pattern. */
export function escapeLike(value) {
  return String(value).replace(/[\\%_]/g, (char) => `\\${char}`);
}

/** "%term%" with the term escaped. Always pair with: LIKE ? ESCAPE '\\\\' */
export function containsPattern(value) {
  return `%${escapeLike(value)}%`;
}

/**
 * LIMIT/OFFSET are bound as strings: MySQL 8.0.22+ rejects JS numbers (sent as DOUBLE)
 * for these placeholders in prepared statements with some driver versions.
 */
export function limitParam(value) {
  return String(Math.trunc(Number(value)));
}
