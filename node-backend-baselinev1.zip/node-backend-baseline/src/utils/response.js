import { requestContext } from '../context/requestContext.js';

/**
 * Standard API response - exactly two shapes. The HTTP status code is the
 * source of truth, so the body does not repeat it.
 *
 * Success:  { success: true,  message, data, meta?, requestId }
 * Failure:  { success: false, message, error: { code, details? }, requestId }
 */

export function buildSuccessBody({ message = 'Success', data = null, meta } = {}) {
  const body = { success: true, message, data };
  if (meta !== undefined) body.meta = meta;
  body.requestId = requestContext.getRequestId();
  return body;
}

export function buildFailureBody({ message, code, details }) {
  const error = { code };
  if (details !== undefined && details !== null) error.details = details;
  return { success: false, message, error, requestId: requestContext.getRequestId() };
}

/** sendSuccess(res, { statusCode = 200, message, data, meta }) */
export function sendSuccess(res, { statusCode = 200, ...body } = {}) {
  return res.status(statusCode).json(buildSuccessBody(body));
}

export function sendCreated(res, options = {}) {
  return sendSuccess(res, { ...options, statusCode: 201 });
}

/** Used by the global error handler only - services/routers throw exceptions instead. */
export function sendFailure(res, { statusCode, ...body }) {
  return res.status(statusCode).json(buildFailureBody(body));
}
