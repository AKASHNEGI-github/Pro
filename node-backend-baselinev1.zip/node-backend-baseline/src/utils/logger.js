import pino from 'pino';
import { config } from '../config/index.js';
import { requestContext } from '../context/requestContext.js';

/** Keys that must never reach the logs, at the top level or one level deep. */
const SENSITIVE_KEYS = [
  'password',
  'newPassword',
  'currentPassword',
  'confirmPassword',
  'temporaryPassword',
  'hash_password',
  'accessToken',
  'refreshToken',
  'resetToken',
  'token',
  'authorization',
  'cookie',
  'answers',
  'securityProfile',
];

const redactPaths = [
  ...SENSITIVE_KEYS,
  ...SENSITIVE_KEYS.map((key) => `*.${key}`),
  'req.headers.authorization',
  'req.headers.cookie',
];

const options = {
  level: config.log.level,
  base: { service: config.app.name, env: config.env },
  timestamp: pino.stdTimeFunctions.isoTime,
  formatters: { level: (label) => ({ level: label }) },
  redact: { paths: redactPaths, censor: '[REDACTED]' },
  // Adds requestId (+ userId once authenticated) to EVERY log line written during a request.
  mixin() {
    const store = requestContext.get();
    if (!store) return {};
    return store.user
      ? { requestId: store.requestId, userId: store.user.userId }
      : { requestId: store.requestId };
  },
};

// Pretty output is for development only (pino-pretty is a devDependency).
const transport = config.log.pretty
  ? pino.transport({
      target: 'pino-pretty',
      options: {
        colorize: true,
        translateTime: 'SYS:HH:MM:ss.l',
        ignore: 'pid,hostname,service,env',
      },
    })
  : undefined;

export const logger = pino(options, transport);

/** Child logger tagged with the module name: createLogger('auth'). */
export function createLogger(moduleName) {
  return logger.child({ module: moduleName });
}
