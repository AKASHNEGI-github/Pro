import { z } from 'zod';
import { MAX_CUSTOM_QUESTIONS } from '../constants/securityQuestions.js';

/**
 * Reusable zod building blocks shared by every module's *.schema.js file.
 * Importing this file also installs friendlier global error messages.
 */
z.config({
  customError: (issue) => {
    if (issue.code === 'invalid_type') {
      return issue.input === undefined ? 'This field is required' : `Expected ${issue.expected}`;
    }
    if (issue.code === 'unrecognized_keys') return 'Unrecognized field';
    return undefined; // fall back to zod's default message
  },
});

export { z };

/** bcrypt only uses the first 72 BYTES of the input, so longer passwords are refused. */
export const PASSWORD_MAX_BYTES = 72;

export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .refine(
    (value) => Buffer.byteLength(value, 'utf8') <= PASSWORD_MAX_BYTES,
    `Password must be at most ${PASSWORD_MAX_BYTES} bytes`,
  )
  .refine((value) => /[a-z]/.test(value), 'Password must contain a lowercase letter')
  .refine((value) => /[A-Z]/.test(value), 'Password must contain an uppercase letter')
  .refine((value) => /\d/.test(value), 'Password must contain a digit')
  .refine((value) => /[^A-Za-z0-9]/.test(value), 'Password must contain a special character');

/** Credential being *checked* (login, "current password"): no policy, just sane bounds. */
export const existingPasswordSchema = z
  .string()
  .min(1, 'Password is required')
  .max(PASSWORD_MAX_BYTES, `Password must be at most ${PASSWORD_MAX_BYTES} characters`);

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .min(1, 'Email is required')
  .max(150, 'Email must be at most 150 characters')
  .email('Invalid email address');

export const fullNameSchema = z
  .string()
  .trim()
  .min(2, 'Full name must be at least 2 characters')
  .max(100, 'Full name must be at most 100 characters')
  .refine((value) => !/\p{Cc}/u.test(value), 'Full name contains invalid characters')
  .transform((value) => value.replace(/\s+/g, ' '));

/** Path parameter holding a positive integer id, e.g. /users/:userId */
export const userIdParamSchema = z.object({
  userId: z
    .string()
    .regex(/^[1-9]\d{0,14}$/, 'Must be a positive integer')
    .transform(Number),
});

export const paginationQuerySchema = z.object({
  page: z.coerce.number().int().min(1).max(1_000_000).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

// ---------------------------------------------------------------------
// Security-question building blocks
// ---------------------------------------------------------------------
function isValidPastDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  if (Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) return false;
  return date.getUTCFullYear() >= 1900 && date.getTime() <= Date.now();
}

export const dobSchema = z
  .string()
  .trim()
  .refine(isValidPastDate, 'Date of birth must be a valid past date in YYYY-MM-DD format');

export const securityAnswerSchema = z
  .string()
  .trim()
  .min(2, 'Answer must be at least 2 characters')
  .max(100, 'Answer must be at most 100 characters');

export const customQuestionSchema = z
  .string()
  .trim()
  .min(10, 'Question must be at least 10 characters')
  .max(200, 'Question must be at most 200 characters');

/** The recovery profile as submitted at sign-up and by PUT /auth/security-profile. */
export const securityProfileInputSchema = z.strictObject({
  dob: dobSchema,
  q2: securityAnswerSchema,
  q3: securityAnswerSchema,
  customQuestions: z
    .array(z.strictObject({ question: customQuestionSchema, answer: securityAnswerSchema }))
    .max(MAX_CUSTOM_QUESTIONS, `At most ${MAX_CUSTOM_QUESTIONS} custom questions are allowed`)
    .default([]),
});
