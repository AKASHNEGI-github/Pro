import { ROLES, SUPER_ADMIN_ROLE_LEVEL, SUPER_ADMIN_USER_ID } from '../constants/roles.js';

/**
 * DB row (snake_case) -> internal user model (camelCase).
 * The super admin has no user_roles row: its role is derived from the reserved user_id.
 */
export function mapUserRow(row) {
  if (!row) return null;
  const isSuperAdmin = row.user_id === SUPER_ADMIN_USER_ID;
  return {
    userId: row.user_id,
    fullName: row.full_name,
    email: row.email,
    role: isSuperAdmin ? ROLES.SUPER_ADMIN : (row.role_name ?? null),
    roleLevel: isSuperAdmin ? SUPER_ADMIN_ROLE_LEVEL : (row.role_level ?? 0),
    isSuperAdmin,
    isActive: Boolean(row.is_active),
    lastLogin: row.last_login ?? null,
    createdAt: row.created_at,
    mustChangePassword: Boolean(row.must_change_password),
    hasSecurityProfile: row.security_profile_user_id != null,
    passwordChangedAt: row.password_changed_at ?? null,
  };
}

/** Public shape returned in lists and admin endpoints. */
export function toUserResponse(user) {
  return {
    userId: user.userId,
    fullName: user.fullName,
    email: user.email,
    role: user.role,
    isActive: user.isActive,
    lastLogin: user.lastLogin,
    createdAt: user.createdAt,
  };
}

/** Shape returned to the account owner (login, refresh, /users/me). */
export function toSelfResponse(user) {
  return {
    ...toUserResponse(user),
    mustChangePassword: user.mustChangePassword,
    hasSecurityProfile: user.hasSecurityProfile,
  };
}
