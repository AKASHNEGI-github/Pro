import crypto from 'node:crypto';

export function sha256Hex(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

export function hmacSha256Hex(key, message) {
  return crypto.createHmac('sha256', key).update(message).digest('hex');
}

/** URL-safe random opaque token (default 48 bytes = 384 bits -> 64 chars). */
export function generateOpaqueToken(bytes = 48) {
  return crypto.randomBytes(bytes).toString('base64url');
}

// Ambiguous characters (I, O, l, 0, 1) are left out so it can be read out / typed reliably.
const UPPER = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const LOWER = 'abcdefghijkmnopqrstuvwxyz';
const DIGITS = '23456789';
const SPECIAL = '@#$%&*+=?!';

const pick = (alphabet) => alphabet[crypto.randomInt(alphabet.length)];

/**
 * Cryptographically secure temporary password that always satisfies the password policy
 * (lower + upper + digit + special). Used for admin-created users and admin resets.
 */
export function generateTemporaryPassword(length = 16) {
  const all = UPPER + LOWER + DIGITS + SPECIAL;
  const chars = [pick(UPPER), pick(LOWER), pick(DIGITS), pick(SPECIAL)];
  while (chars.length < length) chars.push(pick(all));
  for (let i = chars.length - 1; i > 0; i -= 1) {
    const j = crypto.randomInt(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join('');
}
