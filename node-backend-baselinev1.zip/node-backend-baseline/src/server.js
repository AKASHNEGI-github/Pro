import { createApp } from './app.js';
import { ensureSuperAdmin } from './bootstrap/superAdmin.js';
import { verifyDatabase } from './bootstrap/verifyDatabase.js';
import { config } from './config/index.js';
import { closePool } from './database/index.js';
import { startCleanupJob } from './jobs/cleanup.job.js';
import { logger } from './utils/logger.js';

let server;
let stopCleanup = () => {};
let shuttingDown = false;

/** Stop accepting requests, let in-flight ones finish, close the DB pool, then exit. */
async function shutdown(reason, exitCode = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ reason }, 'Shutting down');

  const forceTimer = setTimeout(() => {
    logger.error('Graceful shutdown timed out; forcing exit');
    process.exit(1);
  }, config.server.shutdownTimeoutMs);
  forceTimer.unref();

  stopCleanup();

  const closeResources = async () => {
    try {
      await closePool();
    } catch (err) {
      logger.error({ err }, 'Error while closing the database pool');
    }
    process.exit(exitCode);
  };

  if (!server) return closeResources();
  server.close((err) => {
    if (err) logger.error({ err }, 'Error while closing the HTTP server');
    closeResources();
  });
  server.closeIdleConnections?.();
  return undefined;
}

async function main() {
  await verifyDatabase(); // reachable + schema + seeded roles
  await ensureSuperAdmin(); // users.user_id = 1 <- ENV

  const app = createApp();
  server = app.listen(config.server.port, config.server.host, () => {
    logger.info(
      { host: config.server.host, port: config.server.port },
      `API ready at http://${config.server.host}:${config.server.port}${config.server.apiPrefix}`,
    );
  });
  server.on('error', (err) => {
    logger.fatal({ err }, 'HTTP server error');
    shutdown('server error', 1);
  });

  stopCleanup = startCleanupJob();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (reason) => {
  logger.fatal({ err: reason }, 'Unhandled promise rejection');
  shutdown('unhandledRejection', 1);
});
process.on('uncaughtException', (err) => {
  logger.fatal({ err }, 'Uncaught exception');
  shutdown('uncaughtException', 1);
});

main().catch((err) => {
  logger.fatal({ err }, `Failed to start: ${err.message}`);
  setTimeout(() => process.exit(1), 200); // give the logger a moment to flush
});
