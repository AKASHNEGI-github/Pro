import { randomUUID } from 'node:crypto';
import { requestContext } from '../context/requestContext.js';

// Only accept a client-supplied id if it is short and boring (it ends up in logs and headers).
const SAFE_REQUEST_ID = /^[A-Za-z0-9._-]{8,128}$/;

/**
 * MUST be the first middleware: it opens the Request Context Store for the whole request,
 * assigns the requestId (X-Request-Id in -> out, or a fresh UUID) and echoes it back.
 */
export function requestContextMiddleware(req, res, next) {
  const incoming = req.get('x-request-id');
  const requestId = incoming && SAFE_REQUEST_ID.test(incoming) ? incoming : randomUUID();
  res.setHeader('X-Request-Id', requestId);

  const store = {
    requestId,
    ip: req.ip ?? req.socket?.remoteAddress ?? null,
    userAgent: req.get('user-agent')?.slice(0, 512) ?? null,
    method: req.method,
    path: req.path,
    user: null,
  };
  requestContext.run(store, next);
}
