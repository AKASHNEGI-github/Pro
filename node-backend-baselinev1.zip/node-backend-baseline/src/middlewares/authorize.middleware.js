import { ERROR_CODES } from '../constants/errorCodes.js';
import { ROLES } from '../constants/roles.js';
import { ForbiddenError, UnauthorizedError } from '../errors/index.js';

const KNOWN_ROLES = new Set(Object.values(ROLES));

/**
 * Route-level RBAC (what may your ROLE do?). Use after `authenticate()`.
 *
 *   router.use(authenticate(), authorize(ROLES.ADMIN))
 *
 * The super admin has no restrictions, so it always passes. Instance-level rules ("may this
 * admin touch THAT user?") live in the admin policy and are enforced by the service.
 */
export function authorize(...allowedRoles) {
  for (const role of allowedRoles) {
    if (!KNOWN_ROLES.has(role)) throw new Error(`authorize(): unknown role "${role}"`);
  }
  const allowed = new Set(allowedRoles);

  return (req, _res, next) => {
    if (!req.user) return next(new UnauthorizedError());
    if (req.user.isSuperAdmin || allowed.has(req.user.role)) return next();
    return next(
      new ForbiddenError('You do not have the required role for this action', {
        code: ERROR_CODES.INSUFFICIENT_ROLE,
      }),
    );
  };
}

/**
 * For self-service endpoints that do not apply to the super admin (change password, update
 * profile, delete account...): its credentials and identity are owned by ENV, not the API.
 */
export function denySuperAdmin(req, _res, next) {
  if (req.user?.isSuperAdmin) {
    return next(
      new ForbiddenError(
        'The super admin account is managed through environment configuration, not the API',
        { code: ERROR_CODES.SUPER_ADMIN_PROTECTED },
      ),
    );
  }
  return next();
}
