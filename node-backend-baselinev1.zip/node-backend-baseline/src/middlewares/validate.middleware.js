import { ValidationError } from '../errors/index.js';

/** zod issues -> [{ field, message }] (the `details` of a VALIDATION_ERROR). */
export function formatZodIssues(error) {
  const details = [];
  for (const issue of error.issues) {
    if (issue.code === 'unrecognized_keys') {
      for (const key of issue.keys) {
        details.push({ field: [...issue.path, key].join('.'), message: 'Unrecognized field' });
      }
    } else {
      details.push({ field: issue.path.join('.'), message: issue.message });
    }
  }
  return details;
}

/**
 * Validates request parts against zod schemas (the module's *.schema.js file):
 *
 *   router.post('/x', validate({ body: schema, query: schema, params: schema }), handler)
 *
 * On success the parsed (typed, trimmed, defaulted, unknown-keys-handled) values are placed
 * on `req.validated.{body,query,params}`. Handlers must read ONLY from `req.validated`.
 * (Express 5 makes req.query read-only, so the parsed copy lives on its own property.)
 * On failure every issue of every part is reported at once as a 422 ValidationError.
 */
export function validate(schemas) {
  const parts = ['params', 'query', 'body'].filter((part) => schemas[part]);

  return (req, _res, next) => {
    const validated = {};
    const details = [];

    for (const part of parts) {
      const input = part === 'body' ? (req.body ?? {}) : req[part];
      const result = schemas[part].safeParse(input);
      if (result.success) validated[part] = result.data;
      else details.push(...formatZodIssues(result.error));
    }

    if (details.length > 0) return next(new ValidationError('Validation failed', { details }));
    req.validated = validated;
    return next();
  };
}
