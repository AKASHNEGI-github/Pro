import { ERROR_CODES } from '../constants/errorCodes.js';
import { NotFoundError } from '../errors/index.js';

export function notFoundHandler(req, _res, next) {
  next(
    new NotFoundError(`Route ${req.method} ${req.path.slice(0, 120)} not found`, {
      code: ERROR_CODES.ROUTE_NOT_FOUND,
    }),
  );
}
