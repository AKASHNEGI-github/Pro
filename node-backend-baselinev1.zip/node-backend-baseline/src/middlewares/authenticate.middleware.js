import { ERROR_CODES } from '../constants/errorCodes.js';
import { requestContext } from '../context/requestContext.js';
import { ForbiddenError, UnauthorizedError } from '../errors/index.js';
import { verifyAccessToken } from '../modules/auth/token.service.js';
import { findUserById } from '../modules/users/users.service.js';

const BEARER = /^Bearer\s+(\S+)$/i;

/**
 * Authentication (who are you?).
 *
 * 1. Verifies the Bearer access token (signature, expiry, issuer, audience).
 * 2. Re-reads the user from the database on EVERY request, so deactivation, deletion, role
 *    changes and password changes take effect immediately instead of at token expiry.
 *    Nothing about the user's role or state is ever trusted from the token itself.
 * 3. Enforces account state with a safe default - routes must opt in to relax it:
 *      allowInactive              inactive users (is_active = false) may call this route
 *      allowPasswordChangePending users who must change their password may call this route
 *
 * Sets `req.user` (internal user model) and the acting user in the Request Context Store.
 */
export function authenticate({ allowInactive = false, allowPasswordChangePending = false } = {}) {
  return async (req, _res, next) => {
    const match = BEARER.exec(req.get('authorization') ?? '');
    if (!match) {
      throw new UnauthorizedError('Authentication required', { code: ERROR_CODES.UNAUTHORIZED });
    }

    const { userId, issuedAt } = verifyAccessToken(match[1]);
    const user = await findUserById(userId);

    if (!user) {
      throw new UnauthorizedError('The access token is no longer valid', {
        code: ERROR_CODES.TOKEN_INVALID,
      });
    }

    // Tokens issued before the last password change/reset are dead.
    if (user.passwordChangedAt && issuedAt < Math.floor(user.passwordChangedAt.getTime() / 1000)) {
      throw new UnauthorizedError('The access token is no longer valid, please sign in again', {
        code: ERROR_CODES.TOKEN_INVALID,
      });
    }

    if (!user.isSuperAdmin && !user.role) {
      throw new ForbiddenError('No active role is assigned to this account', {
        code: ERROR_CODES.ROLE_NOT_ASSIGNED,
      });
    }
    if (!user.isActive && !allowInactive) {
      throw new ForbiddenError('Your account is inactive. Please contact an administrator.', {
        code: ERROR_CODES.ACCOUNT_INACTIVE,
      });
    }
    if (user.mustChangePassword && !allowPasswordChangePending) {
      throw new ForbiddenError('You must change your password before continuing', {
        code: ERROR_CODES.PASSWORD_CHANGE_REQUIRED,
      });
    }

    req.user = user;
    requestContext.setUser(user);
    return next();
  };
}
