import { requestContext } from '../context/requestContext.js';
import { createLogger } from '../utils/logger.js';

const log = createLogger('http');

function levelFor(statusCode, path) {
  if (statusCode >= 500) return 'error';
  if (statusCode >= 400) return 'warn';
  return path.startsWith('/health') ? 'debug' : 'info'; // keep probes out of the info stream
}

/** One structured log line per request, written when the response has been sent. */
export function requestLogger(req, res, next) {
  const startedAt = process.hrtime.bigint();
  const context = requestContext.get();
  const path = req.originalUrl.split('?')[0]; // never log query strings (may hold search terms)

  // 'finish' fires from the socket, outside our async context -> re-enter it so the
  // logger's mixin can still attach requestId / userId.
  res.on('finish', () => {
    const durationMs = Math.round(Number(process.hrtime.bigint() - startedAt) / 1e6);
    requestContext.run(context, () => {
      log[levelFor(res.statusCode, path)](
        { method: req.method, path, statusCode: res.statusCode, durationMs, ip: req.ip },
        'Request completed',
      );
    });
  });

  res.on('close', () => {
    if (res.writableFinished) return;
    requestContext.run(context, () => {
      log.warn({ method: req.method, path }, 'Client closed the connection before the response');
    });
  });

  next();
}
