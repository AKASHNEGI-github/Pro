import cors from 'cors';
import { config } from '../config/index.js';
import { ERROR_CODES } from '../constants/errorCodes.js';
import { ForbiddenError } from '../errors/index.js';

/**
 * Explicit allow-list (CORS_ORIGINS). Requests without an Origin header (curl, server-to-server,
 * same-origin) are not subject to CORS and pass. Credentials are enabled because the refresh
 * token travels in an httpOnly cookie, which is why a wildcard origin is never allowed.
 */
export function createCorsMiddleware() {
  const allowedOrigins = new Set(config.cors.origins);

  return cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.has(origin)) return callback(null, true);
      return callback(
        new ForbiddenError('This origin is not allowed by the CORS policy', {
          code: ERROR_CODES.CORS_ORIGIN_NOT_ALLOWED,
        }),
      );
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-Id'],
    exposedHeaders: ['X-Request-Id', 'Retry-After', 'RateLimit', 'RateLimit-Policy'],
    maxAge: 600,
  });
}
