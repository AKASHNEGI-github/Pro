import { ERROR_CODES } from '../constants/errorCodes.js';
import { AppError } from './AppError.js';

/**
 * One class per HTTP status we use. Every constructor has the same shape:
 *   new XxxError(message?, { code?, details?, cause?, meta? })
 */
function defineHttpError(name, statusCode, defaultMessage, defaultCode) {
  const HttpError = class extends AppError {
    constructor(message = defaultMessage, options = {}) {
      super(message, { code: defaultCode, ...options, statusCode });
    }
  };
  Object.defineProperty(HttpError, 'name', { value: name });
  return HttpError;
}

export const BadRequestError = defineHttpError(
  'BadRequestError',
  400,
  'Bad request',
  ERROR_CODES.BAD_REQUEST,
);
export const UnauthorizedError = defineHttpError(
  'UnauthorizedError',
  401,
  'Authentication required',
  ERROR_CODES.UNAUTHORIZED,
);
export const ForbiddenError = defineHttpError(
  'ForbiddenError',
  403,
  'You do not have permission to perform this action',
  ERROR_CODES.FORBIDDEN,
);
export const NotFoundError = defineHttpError(
  'NotFoundError',
  404,
  'Resource not found',
  ERROR_CODES.NOT_FOUND,
);
export const ConflictError = defineHttpError(
  'ConflictError',
  409,
  'Resource already exists',
  ERROR_CODES.CONFLICT,
);
export const PayloadTooLargeError = defineHttpError(
  'PayloadTooLargeError',
  413,
  'Request payload is too large',
  ERROR_CODES.PAYLOAD_TOO_LARGE,
);
export const ValidationError = defineHttpError(
  'ValidationError',
  422,
  'Validation failed',
  ERROR_CODES.VALIDATION_ERROR,
);
export const TooManyRequestsError = defineHttpError(
  'TooManyRequestsError',
  429,
  'Too many requests, please try again later',
  ERROR_CODES.RATE_LIMITED,
);
export const InternalServerError = defineHttpError(
  'InternalServerError',
  500,
  'Something went wrong',
  ERROR_CODES.INTERNAL_ERROR,
);
export const ServiceUnavailableError = defineHttpError(
  'ServiceUnavailableError',
  503,
  'Service temporarily unavailable',
  ERROR_CODES.SERVICE_UNAVAILABLE,
);
