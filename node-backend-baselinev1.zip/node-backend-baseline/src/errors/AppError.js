import { ERROR_CODES } from '../constants/errorCodes.js';

/**
 * Base class of every error the application throws on purpose ("operational" errors).
 * The global error handler turns an AppError into the standard failure response:
 *   HTTP status = statusCode, body.message = message, body.error = { code, details? }
 */
export class AppError extends Error {
  /**
   * @param {string} message  Safe, human-readable message (it is sent to the client).
   * @param {object} [options]
   * @param {number} [options.statusCode=500]
   * @param {string} [options.code]        Stable machine-readable code (see ERROR_CODES).
   * @param {Array}  [options.details]     Public extra info, e.g. validation issues.
   * @param {Error}  [options.cause]       Original error (logged, never sent to the client).
   * @param {object} [options.meta]        Internal-only data for handlers (never sent).
   * @param {boolean}[options.isOperational=true]
   */
  constructor(message, options = {}) {
    const {
      statusCode = 500,
      code = ERROR_CODES.INTERNAL_ERROR,
      details,
      cause,
      meta,
      isOperational = true,
    } = options;
    super(message, cause ? { cause } : undefined);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.meta = meta;
    this.isOperational = isOperational;
    Error.captureStackTrace?.(this, this.constructor);
  }
}
