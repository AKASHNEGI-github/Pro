import readline from 'node:readline';
import bcrypt from 'bcrypt';
import { passwordSchema } from '../src/utils/validation.js';

/**
 * Generates the bcrypt hash for SUPER_ADMIN_PASSWORD_HASH.
 *   npm run hash-password                     (prompts, input hidden)
 *   npm run hash-password -- 'Secret@123'     (argument: visible in shell history!)
 *   npm run hash-password -- --rounds=13
 */
const args = process.argv.slice(2);
const roundsArg = args.find((arg) => arg.startsWith('--rounds='));
const rounds = roundsArg ? Number(roundsArg.split('=')[1]) : 12;
const passwordArg = args.find((arg) => !arg.startsWith('--'));

if (!Number.isInteger(rounds) || rounds < 10 || rounds > 15) {
  console.error('--rounds must be an integer between 10 and 15');
  process.exit(1);
}

function promptHidden(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
      terminal: true,
    });
    let muted = false;
    rl._writeToOutput = (text) => {
      if (!muted) rl.output.write(text);
    };
    rl.question(question, (answer) => {
      rl.close();
      process.stdout.write('\n');
      resolve(answer);
    });
    muted = true;
  });
}

const password = passwordArg ?? (await promptHidden('Super admin password: '));

const check = passwordSchema.safeParse(password);
if (!check.success) {
  console.error('Password does not meet the policy:');
  for (const issue of check.error.issues) console.error(`  - ${issue.message}`);
  process.exit(1);
}

const hash = await bcrypt.hash(password, rounds);
console.log(`\nbcrypt hash (cost ${rounds}):\n${hash}\n`);
console.log(
  'Put this in your .env / secret store (keep the single quotes - the hash contains "$"):\n',
);
console.log(`SUPER_ADMIN_PASSWORD_HASH='${hash}'\n`);
