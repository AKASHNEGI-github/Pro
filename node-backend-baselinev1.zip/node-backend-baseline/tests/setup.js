/**
 * Loaded with `node --import ./tests/setup.js` BEFORE any test file, so the application's
 * config sees a complete, hermetic environment. Explicit environment variables always win.
 *
 * Database credentials are NOT defaulted here: provide them through real environment
 * variables, a `.env.test` file (see .env.test.example) or the regular `.env`.
 */
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';

dotenv.config({ path: '.env.test', quiet: true });

const defaults = {
  NODE_ENV: 'test',
  LOG_LEVEL: 'silent',
  LOG_PRETTY: 'false',
  RATE_LIMIT_ENABLED: 'false',
  BCRYPT_ROUNDS: '4', // fast hashing in tests
  CLEANUP_INTERVAL_MINUTES: '0',
  CORS_ORIGINS: 'http://localhost:5173',
  SELF_REGISTRATION_ENABLED: 'true',
  ACCESS_TOKEN_TTL_MINUTES: '15',
  REFRESH_TOKEN_TTL_DAYS: '7',
  REFRESH_TOKEN_REUSE_LEEWAY_SECONDS: '10',
  REFRESH_COOKIE_SAMESITE: 'strict',
  SECURITY_MAX_FAILED_ATTEMPTS: '5',
  SECURITY_LOCK_MINUTES: '15',
  PASSWORD_RESET_TOKEN_TTL_MINUTES: '10',
  JWT_ACCESS_SECRET: 'test-access-secret-test-access-secret-0123456789',
  SECURITY_ANSWER_PEPPER: 'test-pepper-test-pepper-test-pepper-0123456789',
  SUPER_ADMIN_NAME: 'Test Super Admin',
  SUPER_ADMIN_EMAIL: 'root@test.example',
  SUPER_ADMIN_PASSWORD_HASH: bcrypt.hashSync('SuperAdmin@12345', 4),
};

for (const [key, value] of Object.entries(defaults)) process.env[key] ??= value;

// Integration tests DROP and re-create this database. It is forced to a dedicated name so the
// development database can never be touched, whatever DB_NAME says.
process.env.DB_NAME = process.env.TEST_DB_NAME || 'node_backend_baseline_test';
