import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  digestAnswer,
  hashAnswer,
  normalizeAnswer,
  verifyAnswer,
} from '../../src/modules/auth/securityAnswers.js';

describe('security answers', () => {
  it('normalises case, surrounding/inner whitespace and Unicode forms', () => {
    assert.equal(normalizeAnswer('  New    York '), 'new york');
    assert.equal(normalizeAnswer('DEHRADUN'), 'dehradun');
    assert.equal(normalizeAnswer('ＡＢＣ'), 'abc'); // full-width letters (NFKC)
  });

  it('equivalent answers produce the same digest', () => {
    assert.equal(digestAnswer('q2', ' Dehradun '), digestAnswer('q2', 'dehradun'));
  });

  it('the digest is bound to the question key (same answer, different question)', () => {
    assert.notEqual(digestAnswer('q2', 'delhi'), digestAnswer('q3', 'delhi'));
  });

  it('the digest is a 64-char hex HMAC (also avoids bcrypt 72-byte truncation)', () => {
    assert.match(digestAnswer('dob', '1990-05-21'), /^[0-9a-f]{64}$/);
    const long = 'x'.repeat(100);
    assert.notEqual(digestAnswer('q2', long), digestAnswer('q2', `${long}y`));
  });

  it('round-trips through bcrypt, ignoring case/whitespace, rejecting wrong answers', async () => {
    const hash = await hashAnswer('q2', 'Dehradun');
    assert.match(hash, /^\$2[aby]\$/);
    assert.equal(await verifyAnswer('q2', '  dehradun ', hash), true);
    assert.equal(await verifyAnswer('q2', 'Mumbai', hash), false);
    assert.equal(await verifyAnswer('q3', 'Dehradun', hash), false); // wrong question key
  });
});
