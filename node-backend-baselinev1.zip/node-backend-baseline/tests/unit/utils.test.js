import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { maskEmail } from '../../src/utils/mask.js';
import { buildPageMeta, toPagination } from '../../src/utils/pagination.js';
import { containsPattern, escapeLike, limitParam } from '../../src/utils/sql.js';
import { mapUserRow, toSelfResponse, toUserResponse } from '../../src/utils/userMapper.js';

describe('sql helpers', () => {
  it('escapeLike neutralises LIKE wildcards and the escape character', () => {
    assert.equal(escapeLike('50%_off\\'), '50\\%\\_off\\\\');
    assert.equal(containsPattern('a_b'), '%a\\_b%');
  });
  it('limitParam binds numbers as integer strings', () => {
    assert.equal(limitParam(20), '20');
    assert.equal(limitParam('40'), '40');
  });
});

describe('pagination helpers', () => {
  it('computes offset and meta', () => {
    assert.deepEqual(toPagination({ page: 3, limit: 20 }), { page: 3, limit: 20, offset: 40 });
    assert.deepEqual(buildPageMeta({ page: 1, limit: 20, total: 41 }), {
      page: 1,
      limit: 20,
      total: 41,
      totalPages: 3,
    });
    assert.equal(buildPageMeta({ page: 1, limit: 20, total: 0 }).totalPages, 0);
  });
});

describe('mask + user mapper', () => {
  it('masks e-mails for logs', () => {
    assert.equal(maskEmail('john@example.com'), 'j***@example.com');
    assert.equal(maskEmail('nonsense'), '***');
  });

  it('maps rows, deriving super_admin from the reserved id', () => {
    const row = {
      user_id: 1,
      full_name: 'Root',
      email: 'r@x.com',
      is_active: 1,
      created_at: new Date(0),
    };
    const superAdmin = mapUserRow(row);
    assert.equal(superAdmin.role, 'super_admin');
    assert.equal(superAdmin.isSuperAdmin, true);
    assert.ok(superAdmin.roleLevel > 2);

    const member = mapUserRow({
      ...row,
      user_id: 9,
      role_name: 'member',
      role_level: 1,
      must_change_password: 1,
    });
    assert.equal(member.role, 'member');
    assert.equal(member.isActive, true);
    assert.equal(member.mustChangePassword, true);
  });

  it('public responses never contain sensitive internals', () => {
    const user = mapUserRow({
      user_id: 9,
      full_name: 'A B',
      email: 'a@b.com',
      is_active: 1,
      role_name: 'member',
      role_level: 1,
      created_at: new Date(0),
      password_changed_at: new Date(0),
    });
    assert.deepEqual(Object.keys(toUserResponse(user)).sort(), [
      'createdAt',
      'email',
      'fullName',
      'isActive',
      'lastLogin',
      'role',
      'userId',
    ]);
    assert.ok('mustChangePassword' in toSelfResponse(user));
    assert.ok(!('passwordChangedAt' in toSelfResponse(user)));
    assert.ok(!('roleLevel' in toSelfResponse(user)));
  });
});
