import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { listUsersSchema } from '../../src/modules/admin/admin.schema.js';
import {
  changePasswordSchema,
  recoveryVerifySchema,
  registerSchema,
} from '../../src/modules/auth/auth.schema.js';
import {
  dobSchema,
  emailSchema,
  fullNameSchema,
  paginationQuerySchema,
  passwordSchema,
  userIdParamSchema,
} from '../../src/utils/validation.js';

const ok = (schema, value) => schema.safeParse(value).success;

describe('passwordSchema (policy)', () => {
  it('accepts a compliant password', () => assert.ok(ok(passwordSchema, 'Passw0rd!x')));

  for (const [label, value] of [
    ['too short', 'Sh0rt!A'],
    ['no lowercase', 'PASSWORD1!'],
    ['no uppercase', 'password1!'],
    ['no digit', 'Password!!'],
    ['no special char', 'Passw0rdxx'],
    ['over 72 bytes (bcrypt limit)', `Aa1!${'x'.repeat(70)}`],
  ]) {
    it(`rejects: ${label}`, () => assert.equal(ok(passwordSchema, value), false));
  }

  it('counts BYTES, not characters, for the bcrypt limit', () => {
    const multiByte = `Aa1!${'é'.repeat(35)}`; // 39 chars but 74 bytes
    assert.equal(ok(passwordSchema, multiByte), false);
  });

  it('reports every broken rule at once', () => {
    const result = passwordSchema.safeParse('abc');
    assert.equal(result.success, false);
    assert.ok(result.error.issues.length >= 3);
  });
});

describe('field schemas', () => {
  it('email: trims, lower-cases, rejects garbage', () => {
    assert.equal(emailSchema.parse('  John.Doe@Example.COM '), 'john.doe@example.com');
    assert.equal(ok(emailSchema, 'not-an-email'), false);
    assert.equal(ok(emailSchema, `${'a'.repeat(150)}@x.com`), false);
  });

  it('fullName: trims and collapses whitespace; rejects too short / control chars', () => {
    assert.equal(fullNameSchema.parse('  Aditi    Singh '), 'Aditi Singh');
    assert.equal(ok(fullNameSchema, 'A'), false);
    assert.equal(ok(fullNameSchema, 'Bad\u0000Name'), false);
  });

  it('dob: only real, past dates in YYYY-MM-DD', () => {
    assert.ok(ok(dobSchema, '1990-05-21'));
    assert.ok(ok(dobSchema, '2000-02-29'));
    for (const bad of ['1990-02-30', '2999-01-01', '21-05-1990', '1899-12-31', '1990-5-1', 'abc']) {
      assert.equal(ok(dobSchema, bad), false, bad);
    }
  });

  it('userId param: positive integers only', () => {
    assert.equal(userIdParamSchema.parse({ userId: '12' }).userId, 12);
    for (const bad of ['0', '-1', '1e3', '12abc', '', '1.5', '9'.repeat(20)]) {
      assert.equal(ok(userIdParamSchema, { userId: bad }), false, bad);
    }
  });

  it('pagination: defaults, coercion and bounds', () => {
    assert.deepEqual(paginationQuerySchema.parse({}), { page: 1, limit: 20 });
    assert.deepEqual(paginationQuerySchema.parse({ page: '3', limit: '50' }), {
      page: 3,
      limit: 50,
    });
    assert.equal(ok(paginationQuerySchema, { limit: '101' }), false);
    assert.equal(ok(paginationQuerySchema, { page: '0' }), false);
  });
});

describe('request schemas', () => {
  const validRegistration = {
    fullName: 'Test User',
    email: 'Test@Example.com',
    password: 'Passw0rd!x',
    securityProfile: { dob: '1990-05-21', q2: 'Dehradun', q3: 'St Joseph' },
  };

  it('register: valid payload, normalised and defaulted', () => {
    const data = registerSchema.body.parse(validRegistration);
    assert.equal(data.email, 'test@example.com');
    assert.deepEqual(data.securityProfile.customQuestions, []);
  });

  it('register: security profile is mandatory', () => {
    const { securityProfile: _omit, ...withoutProfile } = validRegistration;
    assert.equal(ok(registerSchema.body, withoutProfile), false);
  });

  it('register: unknown fields are rejected (no mass assignment of role/isActive)', () => {
    const result = registerSchema.body.safeParse({ ...validRegistration, role: 'admin' });
    assert.equal(result.success, false);
    assert.equal(result.error.issues[0].code, 'unrecognized_keys');
  });

  it('register: at most 2 custom questions', () => {
    const question = { question: 'What was my first pet called?', answer: 'Bruno' };
    const base = validRegistration.securityProfile;
    assert.ok(
      ok(registerSchema.body, {
        ...validRegistration,
        securityProfile: { ...base, customQuestions: [question, question] },
      }),
    );
    assert.equal(
      ok(registerSchema.body, {
        ...validRegistration,
        securityProfile: { ...base, customQuestions: [question, question, question] },
      }),
      false,
    );
  });

  it('change password: new password must differ from the current one', () => {
    const same = changePasswordSchema.body.safeParse({
      currentPassword: 'Passw0rd!x',
      newPassword: 'Passw0rd!x',
    });
    assert.equal(same.success, false);
    assert.deepEqual(same.error.issues[0].path, ['newPassword']);
    assert.ok(
      ok(changePasswordSchema.body, { currentPassword: 'Passw0rd!x', newPassword: 'N3w-Passw0rd' }),
    );
  });

  it('recovery verify: a malformed DOB is a validation error, not a failed attempt', () => {
    const result = recoveryVerifySchema.body.safeParse({
      email: 'a@b.com',
      answers: { dob: '31/12/1990', q2: 'x1', q3: 'y1' },
    });
    assert.equal(result.success, false);
  });

  it('admin list query: coerces isActive and whitelists sort fields', () => {
    const parsed = listUsersSchema.query.parse({
      isActive: 'true',
      sortBy: 'email',
      sortOrder: 'asc',
    });
    assert.equal(parsed.isActive, true);
    assert.equal(ok(listUsersSchema.query, { sortBy: 'password' }), false);
    assert.equal(ok(listUsersSchema.query, { role: 'super_admin' }), false);
    assert.equal(listUsersSchema.query.parse({}).sortBy, 'createdAt');
  });
});
