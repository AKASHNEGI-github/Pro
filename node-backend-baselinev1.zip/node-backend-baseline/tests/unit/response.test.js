import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { requestContext } from '../../src/context/requestContext.js';
import { buildFailureBody, buildSuccessBody } from '../../src/utils/response.js';

describe('standard API response', () => {
  it('success: { success, message, data, requestId } - no meta unless given', () => {
    const body = requestContext.run({ requestId: 'req-1' }, () =>
      buildSuccessBody({ message: 'Fetched', data: { id: 1 } }),
    );
    assert.deepEqual(body, {
      success: true,
      message: 'Fetched',
      data: { id: 1 },
      requestId: 'req-1',
    });
  });

  it('success: data defaults to null and meta is included for paginated lists', () => {
    const meta = { page: 1, limit: 20, total: 0, totalPages: 0 };
    const body = requestContext.run({ requestId: 'req-2' }, () => buildSuccessBody({ meta }));
    assert.equal(body.success, true);
    assert.equal(body.data, null);
    assert.deepEqual(body.meta, meta);
  });

  it('failure: { success:false, message, error:{ code, details? }, requestId }', () => {
    const body = requestContext.run({ requestId: 'req-3' }, () =>
      buildFailureBody({
        message: 'Validation failed',
        code: 'VALIDATION_ERROR',
        details: [{ field: 'email', message: 'Invalid email address' }],
      }),
    );
    assert.deepEqual(body, {
      success: false,
      message: 'Validation failed',
      error: {
        code: 'VALIDATION_ERROR',
        details: [{ field: 'email', message: 'Invalid email address' }],
      },
      requestId: 'req-3',
    });
  });

  it('failure: details are omitted when absent', () => {
    const body = buildFailureBody({ message: 'Nope', code: 'NOT_FOUND' });
    assert.deepEqual(body.error, { code: 'NOT_FOUND' });
  });

  it('requestId is null outside a request', () => {
    assert.equal(buildSuccessBody({}).requestId, null);
  });
});
