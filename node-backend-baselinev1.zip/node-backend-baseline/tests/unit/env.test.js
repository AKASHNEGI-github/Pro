import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { EXAMPLE_SUPER_ADMIN_HASH, parseEnv } from '../../src/config/env.js';

const fakeHash = `$2b$12$${'a'.repeat(53)}`;
const base = {
  DB_USER: 'app',
  JWT_ACCESS_SECRET: 'j'.repeat(40),
  SECURITY_ANSWER_PEPPER: 'p'.repeat(40),
  SUPER_ADMIN_NAME: 'Root',
  SUPER_ADMIN_EMAIL: 'Root@Example.com',
  SUPER_ADMIN_PASSWORD_HASH: fakeHash,
};
const production = { ...base, NODE_ENV: 'production' };

describe('environment validation', () => {
  it('accepts a minimal valid environment and applies defaults', () => {
    const result = parseEnv(base);
    assert.equal(result.ok, true);
    assert.equal(result.data.PORT, 3000);
    assert.equal(result.data.NODE_ENV, 'development');
    assert.equal(result.data.BCRYPT_ROUNDS, 12);
    assert.equal(result.data.SUPER_ADMIN_EMAIL, 'root@example.com'); // normalised
  });

  it('lists every missing / invalid variable', () => {
    const result = parseEnv({ PORT: 'abc', SUPER_ADMIN_PASSWORD_HASH: 'plain-text' });
    assert.equal(result.ok, false);
    const text = result.errors.join('\n');
    for (const name of [
      'PORT',
      'DB_USER',
      'JWT_ACCESS_SECRET',
      'SECURITY_ANSWER_PEPPER',
      'SUPER_ADMIN_EMAIL',
      'SUPER_ADMIN_PASSWORD_HASH',
    ]) {
      assert.match(text, new RegExp(name), name);
    }
  });

  it('refuses short secrets', () => {
    assert.equal(parseEnv({ ...base, JWT_ACCESS_SECRET: 'short' }).ok, false);
  });

  it('the super admin password must be a bcrypt hash, never plain text', () => {
    assert.equal(parseEnv({ ...base, SUPER_ADMIN_PASSWORD_HASH: 'SuperAdmin@12345' }).ok, false);
  });

  it('SameSite=none requires a Secure cookie', () => {
    const result = parseEnv({
      ...base,
      REFRESH_COOKIE_SAMESITE: 'none',
      REFRESH_COOKIE_SECURE: 'false',
    });
    assert.equal(result.ok, false);
  });

  describe('production guards', () => {
    it('accepts a properly configured production environment', () => {
      assert.equal(parseEnv(production).ok, true);
    });
    it('rejects CHANGE_ME placeholder secrets', () => {
      const result = parseEnv({ ...production, JWT_ACCESS_SECRET: `CHANGE_ME_${'x'.repeat(30)}` });
      assert.equal(result.ok, false);
    });
    it('rejects the public example super admin hash', () => {
      const result = parseEnv({
        ...production,
        SUPER_ADMIN_PASSWORD_HASH: EXAMPLE_SUPER_ADMIN_HASH,
      });
      assert.equal(result.ok, false);
      assert.match(result.errors.join(' '), /example hash/);
    });
    it('rejects weak bcrypt cost and wildcard CORS', () => {
      assert.equal(parseEnv({ ...production, BCRYPT_ROUNDS: '8' }).ok, false);
      assert.equal(parseEnv({ ...production, CORS_ORIGINS: '*' }).ok, false);
    });
    it('the same weak values are tolerated in development', () => {
      assert.equal(
        parseEnv({
          ...base,
          BCRYPT_ROUNDS: '8',
          SUPER_ADMIN_PASSWORD_HASH: EXAMPLE_SUPER_ADMIN_HASH,
        }).ok,
        true,
      );
    });
  });
});
