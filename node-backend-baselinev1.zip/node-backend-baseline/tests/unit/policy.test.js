import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  ADMIN_ACTIONS,
  assertCanAssignRole,
  assertCanManageUser,
} from '../../src/modules/admin/admin.policy.js';

const superAdmin = { userId: 1, role: 'super_admin', roleLevel: 1000, isSuperAdmin: true };
const admin = { userId: 2, role: 'admin', roleLevel: 2, isSuperAdmin: false };
const otherAdmin = { userId: 4, role: 'admin', roleLevel: 2, isSuperAdmin: false };
const member = { userId: 3, role: 'member', roleLevel: 1, isSuperAdmin: false };

const { VIEW, UPDATE_PROFILE, SET_STATUS, CHANGE_ROLE, RESET_PASSWORD, DELETE } = ADMIN_ACTIONS;
const MUTATIONS = [UPDATE_PROFILE, SET_STATUS, CHANGE_ROLE, RESET_PASSWORD, DELETE];

const allowed = (actor, target, action) =>
  assert.doesNotThrow(() => assertCanManageUser(actor, target, action));

function denied(actor, target, action, statusCode, code) {
  assert.throws(
    () => assertCanManageUser(actor, target, action),
    (err) => err.statusCode === statusCode && err.code === code,
    `${actor.role} -> ${action} -> ${target.role}#${target.userId}`,
  );
}

describe('admin policy: who may act on whom', () => {
  describe('super admin', () => {
    for (const action of MUTATIONS) {
      it(`may ${action} an admin and a member`, () => {
        allowed(superAdmin, admin, action);
        allowed(superAdmin, member, action);
      });
      it(`can NOT ${action} its own (ENV-managed) account`, () => {
        denied(superAdmin, superAdmin, action, 403, 'SUPER_ADMIN_PROTECTED');
      });
    }
    it('may view everyone, itself included', () => {
      for (const target of [admin, member, superAdmin]) allowed(superAdmin, target, VIEW);
    });
  });

  describe('admin', () => {
    for (const action of MUTATIONS) {
      it(`may ${action} a member`, () => allowed(admin, member, action));
      it(`can NOT ${action} another admin`, () => {
        denied(admin, otherAdmin, action, 403, 'INSUFFICIENT_ROLE');
      });
      it(`can NOT ${action} itself through the admin endpoints`, () => {
        denied(admin, admin, action, 403, 'SELF_ACTION_NOT_ALLOWED');
      });
      it(`cannot even see the super admin when trying to ${action} it (404)`, () => {
        denied(admin, superAdmin, action, 404, 'USER_NOT_FOUND');
      });
    }
    it('may VIEW members, other admins and itself', () => {
      for (const target of [member, otherAdmin, admin]) allowed(admin, target, VIEW);
    });
    it('can NOT view the super admin (404, indistinguishable from a missing user)', () => {
      denied(admin, superAdmin, VIEW, 404, 'USER_NOT_FOUND');
    });
  });

  describe('member (defensive: routes already block members)', () => {
    for (const action of MUTATIONS) {
      it(`can NOT ${action} another member`, () => {
        denied(member, { ...member, userId: 9 }, action, 403, 'INSUFFICIENT_ROLE');
      });
    }
  });
});

describe('admin policy: which roles may be assigned', () => {
  it('super admin can assign any role', () => {
    assert.doesNotThrow(() => assertCanAssignRole(superAdmin, 2));
    assert.doesNotThrow(() => assertCanAssignRole(superAdmin, 1));
  });
  it('admin can assign admin (create admins / promote) and member', () => {
    assert.doesNotThrow(() => assertCanAssignRole(admin, 2));
    assert.doesNotThrow(() => assertCanAssignRole(admin, 1));
  });
  it('admin can NOT assign a role above its own level', () => {
    assert.throws(
      () => assertCanAssignRole(admin, 3),
      (err) => err.statusCode === 403 && err.code === 'INSUFFICIENT_ROLE',
    );
  });
});
