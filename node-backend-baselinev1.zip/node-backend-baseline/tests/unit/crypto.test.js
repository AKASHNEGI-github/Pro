import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  generateOpaqueToken,
  generateTemporaryPassword,
  hmacSha256Hex,
  sha256Hex,
} from '../../src/utils/crypto.js';
import { passwordSchema } from '../../src/utils/validation.js';

describe('crypto utils', () => {
  it('sha256Hex matches the standard test vector', () => {
    assert.equal(
      sha256Hex('abc'),
      'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',
    );
  });

  it('hmacSha256Hex depends on the key', () => {
    assert.notEqual(hmacSha256Hex('k1', 'm'), hmacSha256Hex('k2', 'm'));
    assert.equal(hmacSha256Hex('k1', 'm'), hmacSha256Hex('k1', 'm'));
  });

  it('opaque tokens are URL-safe, 64 chars by default, and unique', () => {
    const tokens = new Set(Array.from({ length: 200 }, () => generateOpaqueToken()));
    assert.equal(tokens.size, 200);
    for (const token of tokens) assert.match(token, /^[A-Za-z0-9_-]{64}$/);
  });

  it('temporary passwords always satisfy the password policy and are unique', () => {
    const seen = new Set();
    for (let i = 0; i < 300; i += 1) {
      const password = generateTemporaryPassword();
      assert.equal(password.length, 16);
      assert.ok(passwordSchema.safeParse(password).success, password);
      assert.doesNotMatch(password, /[IOl01]/); // no look-alike characters
      seen.add(password);
    }
    assert.equal(seen.size, 300);
  });
});
