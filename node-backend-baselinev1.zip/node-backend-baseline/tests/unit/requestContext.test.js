import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { describe, it } from 'node:test';
import { requestContext } from '../../src/context/requestContext.js';

describe('request context store', () => {
  it('is empty outside a request', () => {
    assert.equal(requestContext.get(), undefined);
    assert.equal(requestContext.getRequestId(), null);
    assert.deepEqual(requestContext.getMeta(), { ip: null, userAgent: null });
    assert.equal(requestContext.getUser(), null);
  });

  it('propagates through awaits, timers and nested calls', async () => {
    await requestContext.run({ requestId: 'r1', ip: '10.0.0.1', userAgent: 'jest' }, async () => {
      await sleep(5);
      assert.equal(requestContext.getRequestId(), 'r1');
      await Promise.all([
        sleep(2),
        Promise.resolve().then(() => assert.equal(requestContext.getRequestId(), 'r1')),
      ]);
      assert.deepEqual(requestContext.getMeta(), { ip: '10.0.0.1', userAgent: 'jest' });
    });
  });

  it('isolates concurrent requests from each other', async () => {
    const seen = [];
    await Promise.all(
      ['a', 'b', 'c'].map((id, index) =>
        requestContext.run({ requestId: id }, async () => {
          await sleep(10 - index * 3);
          seen.push([id, requestContext.getRequestId()]);
        }),
      ),
    );
    for (const [expected, actual] of seen) assert.equal(actual, expected);
  });

  it('stores the authenticated user for logging', async () => {
    await requestContext.run({ requestId: 'r2' }, async () => {
      requestContext.setUser({ userId: 7, role: 'admin', email: 'secret@example.com' });
      await sleep(1);
      assert.deepEqual(requestContext.getUser(), { userId: 7, role: 'admin' }); // no e-mail kept
    });
  });
});
