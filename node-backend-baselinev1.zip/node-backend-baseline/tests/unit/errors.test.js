import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import {
  AppError,
  BadRequestError,
  ConflictError,
  ForbiddenError,
  InternalServerError,
  NotFoundError,
  PayloadTooLargeError,
  ServiceUnavailableError,
  TooManyRequestsError,
  UnauthorizedError,
  ValidationError,
} from '../../src/errors/index.js';

const cases = [
  [BadRequestError, 400, 'BAD_REQUEST'],
  [UnauthorizedError, 401, 'UNAUTHORIZED'],
  [ForbiddenError, 403, 'FORBIDDEN'],
  [NotFoundError, 404, 'NOT_FOUND'],
  [ConflictError, 409, 'CONFLICT'],
  [PayloadTooLargeError, 413, 'PAYLOAD_TOO_LARGE'],
  [ValidationError, 422, 'VALIDATION_ERROR'],
  [TooManyRequestsError, 429, 'RATE_LIMITED'],
  [InternalServerError, 500, 'INTERNAL_ERROR'],
  [ServiceUnavailableError, 503, 'SERVICE_UNAVAILABLE'],
];

describe('custom exception classes', () => {
  for (const [ErrorClass, statusCode, code] of cases) {
    it(`${ErrorClass.name} -> HTTP ${statusCode} / ${code}`, () => {
      const err = new ErrorClass();
      assert.ok(err instanceof AppError);
      assert.ok(err instanceof Error);
      assert.equal(err.statusCode, statusCode);
      assert.equal(err.code, code);
      assert.equal(err.name, ErrorClass.name);
      assert.ok(err.message.length > 0);
      assert.equal(err.isOperational, true);
    });
  }

  it('accepts a custom message, code, details, cause and meta', () => {
    const cause = new Error('root cause');
    const err = new NotFoundError('User not found', {
      code: 'USER_NOT_FOUND',
      details: [{ field: 'userId', message: 'unknown' }],
      cause,
      meta: { retryAfterSeconds: 3 },
    });
    assert.equal(err.message, 'User not found');
    assert.equal(err.code, 'USER_NOT_FOUND');
    assert.deepEqual(err.details, [{ field: 'userId', message: 'unknown' }]);
    assert.equal(err.cause, cause);
    assert.deepEqual(err.meta, { retryAfterSeconds: 3 });
  });

  it('keeps its HTTP status even if someone tries to override it', () => {
    const err = new NotFoundError('x', { statusCode: 200 });
    assert.equal(err.statusCode, 404);
  });

  it('captures a stack trace', () => {
    assert.match(new ConflictError().stack, /ConflictError/);
  });
});
