import { runTasks } from '../../scripts/lib/dbTasks.js';

/** Drops and re-creates the TEST database (schema + required seed + demo users). */
export async function resetTestDatabase() {
  await runTasks(['drop', 'schema', 'seed', 'seed-demo'], process.env);
}
