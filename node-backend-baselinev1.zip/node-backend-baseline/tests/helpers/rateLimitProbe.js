/**
 * Run as a CHILD PROCESS by tests/integration/http.test.js with rate limiting switched on
 * (the main test process runs with it off). Prints one JSON line with what it observed.
 */
import request from 'supertest';
import { createApp } from '../../src/app.js';
import { closePool } from '../../src/database/index.js';

const app = createApp();
const login = (email) =>
  request(app).post('/api/v1/auth/login').send({ email, password: 'Wrong@12345' });

const statuses = [];
let last;
for (let i = 0; i < 5; i += 1) {
  last = await login('ghost@example.com');
  statuses.push(last.status);
}
const otherAccount = await login('someone.else@example.com');
const health = await request(app).get('/health');

console.log(
  JSON.stringify({
    statuses,
    body: last.body,
    retryAfter: last.headers['retry-after'],
    rateLimitHeader: last.headers.ratelimit ?? null,
    otherAccountStatus: otherAccount.status,
    healthStatus: health.status,
  }),
);
await closePool();
