import assert from 'node:assert/strict';
import request from 'supertest';
import { createApp } from '../../src/app.js';
import { ensureSuperAdmin } from '../../src/bootstrap/superAdmin.js';
import { closePool } from '../../src/database/index.js';
import { resetTestDatabase } from './db.js';

export const API = '/api/v1';
export const app = createApp();
export const http = () => request(app);

/** Seeded accounts (seed.sql + seed.demo.sql + test env). */
export const CREDS = Object.freeze({
  superAdmin: { email: 'root@test.example', password: 'SuperAdmin@12345' },
  admin: { email: 'demo.admin@example.com', password: 'Admin@12345' },
  member: { email: 'demo.member@example.com', password: 'Member@12345' },
});

export async function bootstrapTestEnvironment() {
  await resetTestDatabase();
  await ensureSuperAdmin(); // what server.js does at startup: sync users.user_id = 1 from ENV
}

export async function shutdownTestEnvironment() {
  try {
    await closePool();
  } catch (err) {
    if (!/closed/i.test(err.message)) throw err; // a test may already have closed the pool
  }
}

export const bearer = (token) => ({ Authorization: `Bearer ${token}` });

/** "refresh_token=abc" (name=value) from a response's Set-Cookie, or null. */
export function refreshCookie(res) {
  const header = res.headers['set-cookie']?.find((value) => value.startsWith('refresh_token='));
  return header ? header.split(';')[0] : null;
}

export const rawToken = (cookie) => cookie.split('=')[1];

export const login = (credentials) => http().post(`${API}/auth/login`).send(credentials);

export async function loginOk(credentials) {
  const res = await login(credentials);
  assert.equal(res.status, 200, JSON.stringify(res.body));
  return {
    res,
    token: res.body.data.accessToken,
    cookie: refreshCookie(res),
    user: res.body.data.user,
  };
}

let sequence = 0;

export function newRegistration(overrides = {}) {
  sequence += 1;
  return {
    fullName: `Test User ${sequence}`,
    email: `user${sequence}.${Date.now()}@example.com`,
    password: 'Passw0rd!x',
    securityProfile: {
      dob: '1990-05-21',
      q2: 'Dehradun',
      q3: 'St Joseph Academy',
      customQuestions: [{ question: 'What was the name of my first pet?', answer: 'Bruno' }],
    },
    ...overrides,
  };
}

/** Registers a member through the API. @returns {{ payload, user }} */
export async function registerUser(overrides = {}) {
  const payload = newRegistration(overrides);
  const res = await http().post(`${API}/auth/register`).send(payload);
  assert.equal(res.status, 201, JSON.stringify(res.body));
  return { payload, user: res.body.data };
}

/** Registers and logs in a fresh member. */
export async function freshSession(overrides = {}) {
  const { payload, user } = await registerUser(overrides);
  const session = await loginOk({ email: payload.email, password: payload.password });
  return { payload, user, ...session };
}

export function expectFailure(res, status, code) {
  assert.equal(res.status, status, JSON.stringify(res.body));
  assert.equal(res.body.success, false);
  assert.equal(res.body.error.code, code, JSON.stringify(res.body));
  assert.ok(res.body.requestId);
}
