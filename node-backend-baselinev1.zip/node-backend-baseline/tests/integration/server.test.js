import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import { after, before, describe, it } from 'node:test';
import { bootstrapTestEnvironment, shutdownTestEnvironment } from '../helpers/app.js';

before(bootstrapTestEnvironment);
after(shutdownTestEnvironment);

/** Starts the REAL entrypoint (src/server.js) as a child process. */
function startServer(envOverrides = {}) {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ['--import', './tests/setup.js', 'src/server.js'], {
    env: {
      ...process.env,
      PORT: String(port),
      HOST: '127.0.0.1',
      LOG_LEVEL: 'info',
      ...envOverrides,
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const output = { stdout: '', stderr: '' };
  child.stdout.on('data', (chunk) => (output.stdout += chunk));
  child.stderr.on('data', (chunk) => (output.stderr += chunk));
  const exited = new Promise((resolve) =>
    child.on('exit', (code, signal) => resolve({ code, signal })),
  );
  return { child, port, output, exited };
}

async function waitFor(url, { timeoutMs = 15000 } = {}) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(url);
      if (res.ok) return res;
    } catch {
      /* not listening yet */
    }
    await sleep(100);
  }
  throw new Error(`Timed out waiting for ${url}`);
}

describe('server process', () => {
  it('starts, serves traffic and shuts down gracefully on SIGTERM (exit code 0)', async () => {
    const { child, port, output, exited } = startServer();
    try {
      const res = await waitFor(`http://127.0.0.1:${port}/health/ready`);
      assert.equal((await res.json()).data.checks.database, 'up');

      child.kill('SIGTERM');
      const { code } = await exited;
      assert.equal(code, 0, output.stdout + output.stderr);
      assert.match(output.stdout, /Shutting down/);
      assert.match(output.stdout, /Super admin account is ready/);
    } finally {
      child.kill('SIGKILL');
    }
  });

  it('writes structured JSON logs carrying requestId (and never secrets)', async () => {
    const { child, port, output, exited } = startServer();
    try {
      await waitFor(`http://127.0.0.1:${port}/health/ready`);
      const res = await fetch(`http://127.0.0.1:${port}/api/v1/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Request-Id': 'trace-log-test-1' },
        body: JSON.stringify({ email: 'ghost@example.com', password: 'Sup3r-Secret-Passw0rd!' }),
      });
      assert.equal(res.status, 401);
      child.kill('SIGTERM');
      await exited;

      const lines = output.stdout
        .trim()
        .split('\n')
        .map((line) => JSON.parse(line));
      const tagged = lines.filter((line) => line.requestId === 'trace-log-test-1');
      assert.ok(
        tagged.some((line) => line.msg === 'Login failed'),
        'service log line carries the requestId',
      );
      assert.ok(tagged.some((line) => line.msg === 'Request completed' && line.statusCode === 401));
      assert.ok(
        !output.stdout.includes('Sup3r-Secret-Passw0rd!'),
        'the password must never be logged',
      );
      assert.ok(!output.stdout.includes('ghost@example.com'), 'e-mails are masked in logs');
    } finally {
      child.kill('SIGKILL');
    }
  });

  it('refuses to start on an invalid environment and lists what is wrong', async () => {
    const { output, exited } = startServer({
      JWT_ACCESS_SECRET: 'too-short',
      SUPER_ADMIN_PASSWORD_HASH: 'plain',
    });
    const { code } = await exited;
    assert.equal(code, 1);
    assert.match(output.stderr, /Invalid environment configuration/);
    assert.match(output.stderr, /JWT_ACCESS_SECRET/);
    assert.match(output.stderr, /SUPER_ADMIN_PASSWORD_HASH/);
  });

  it('refuses to start when the database cannot be reached (fail fast, clear message)', async () => {
    const { output, exited } = startServer({ DB_PORT: '1' });
    const { code } = await exited;
    assert.equal(code, 1);
    assert.match(output.stdout, /Cannot connect to MySQL/);
  });

  it('refuses to start in production with the public example credentials', async () => {
    const { output, exited } = startServer({
      NODE_ENV: 'production',
      SUPER_ADMIN_PASSWORD_HASH: '$2b$12$GVo/84BFVjH1Llj2dHuj7uicTXF7UkZoyxqCjemsvBEY.eQKNBczG',
    });
    const { code } = await exited;
    assert.equal(code, 1);
    assert.match(output.stderr, /example hash/);
  });
});
