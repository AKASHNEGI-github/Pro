import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { db, queryOne, queryScalar } from '../../src/database/index.js';
import {
  API,
  bearer,
  bootstrapTestEnvironment,
  CREDS,
  expectFailure,
  http,
  login,
  loginOk,
  refreshCookie,
  shutdownTestEnvironment,
} from '../helpers/app.js';

let superToken;
let adminToken;
let memberToken;
let adminId;

before(async () => {
  await bootstrapTestEnvironment();
  superToken = (await loginOk(CREDS.superAdmin)).token;
  const admin = await loginOk(CREDS.admin);
  adminToken = admin.token;
  adminId = admin.user.userId;
  memberToken = (await loginOk(CREDS.member)).token;
});
after(shutdownTestEnvironment);

let sequence = 0;
const get = (token, path) => http().get(`${API}${path}`).set(bearer(token));
const post = (token, path, body) => http().post(`${API}${path}`).set(bearer(token)).send(body);
const patch = (token, path, body) => http().patch(`${API}${path}`).set(bearer(token)).send(body);
const del = (token, path) => http().delete(`${API}${path}`).set(bearer(token));

/** Creates a user through the API as `token`. */
async function createUser(token, { role = 'member', fullName = 'Created User' } = {}) {
  sequence += 1;
  const email = `created.${sequence}.${Date.now()}@example.com`;
  const res = await post(token, '/admin/users', { fullName, email, role });
  assert.equal(res.status, 201, JSON.stringify(res.body));
  return {
    email,
    user: res.body.data.user,
    temporaryPassword: res.body.data.temporaryPassword,
    res,
  };
}

/** Creates a user AND completes the forced password change, so it is fully usable. */
async function createActiveUser(token, options) {
  const created = await createUser(token, options);
  const session = await loginOk({ email: created.email, password: created.temporaryPassword });
  const newPassword = 'Act1ve-Passw0rd!';
  const changed = await post(session.token, '/auth/change-password', {
    currentPassword: created.temporaryPassword,
    newPassword,
  });
  assert.equal(changed.status, 200, JSON.stringify(changed.body));
  return {
    ...created,
    password: newPassword,
    token: changed.body.data.accessToken,
    cookie: refreshCookie(changed),
  };
}

describe('route-level authorization', () => {
  it('members get 403 INSUFFICIENT_ROLE, anonymous callers 401', async () => {
    for (const [method, path] of [
      ['get', '/admin/users'],
      ['post', '/admin/users'],
      ['get', '/admin/users/2'],
      ['get', '/roles'],
    ]) {
      expectFailure(
        await http()[method](`${API}${path}`).set(bearer(memberToken)).send({}),
        403,
        'INSUFFICIENT_ROLE',
      );
      expectFailure(await http()[method](`${API}${path}`).send({}), 401, 'UNAUTHORIZED');
    }
  });
});

describe('GET /admin/users', () => {
  it('an admin sees everyone EXCEPT the super admin; the super admin sees all', async () => {
    const asAdmin = await get(adminToken, '/admin/users?limit=100');
    assert.equal(asAdmin.status, 200);
    const ids = asAdmin.body.data.map((u) => u.userId);
    assert.ok(ids.includes(2) && ids.includes(3));
    assert.ok(!ids.includes(1), 'the super admin must be hidden from admins');

    const asSuper = await get(superToken, '/admin/users?limit=100');
    assert.ok(asSuper.body.data.some((u) => u.userId === 1 && u.role === 'super_admin'));
    assert.equal(asSuper.body.meta.total, asAdmin.body.meta.total + 1);
  });

  it('paginates with a meta block', async () => {
    for (let i = 0; i < 4; i += 1) await createUser(adminToken);
    const page1 = await get(
      adminToken,
      '/admin/users?page=1&limit=2&sortBy=createdAt&sortOrder=asc',
    );
    const page2 = await get(
      adminToken,
      '/admin/users?page=2&limit=2&sortBy=createdAt&sortOrder=asc',
    );
    const { meta } = page1.body;
    assert.equal(page1.body.data.length, 2);
    assert.equal(meta.page, 1);
    assert.equal(meta.limit, 2);
    assert.equal(meta.totalPages, Math.ceil(meta.total / 2));
    assert.notDeepEqual(
      page1.body.data.map((u) => u.userId),
      page2.body.data.map((u) => u.userId),
    );
    assert.ok(Number(page1.body.data[0].userId) < Number(page2.body.data[0].userId));
  });

  it('filters by role, activation and search; sorts; never leaks sensitive fields', async () => {
    const { user } = await createUser(adminToken, { fullName: 'Zebra Searchable', role: 'admin' });
    await patch(superToken, `/admin/users/${user.userId}/status`, { isActive: false });

    const admins = await get(adminToken, '/admin/users?role=admin&limit=100');
    assert.ok(admins.body.data.every((u) => u.role === 'admin'));

    const inactive = await get(adminToken, '/admin/users?isActive=false&limit=100');
    assert.ok(inactive.body.data.every((u) => u.isActive === false));
    assert.ok(inactive.body.data.some((u) => u.userId === user.userId));

    const found = await get(adminToken, '/admin/users?search=zebra search');
    assert.equal(found.body.data.length, 1);
    assert.equal(found.body.data[0].userId, user.userId);
    assert.deepEqual(Object.keys(found.body.data[0]).sort(), [
      'createdAt',
      'email',
      'fullName',
      'isActive',
      'lastLogin',
      'role',
      'userId',
    ]);

    const byEmail = await get(
      adminToken,
      `/admin/users?search=${encodeURIComponent(user.email.toUpperCase())}`,
    );
    assert.equal(byEmail.body.data.length, 1);

    const sorted = await get(adminToken, '/admin/users?sortBy=fullName&sortOrder=asc&limit=100');
    const names = sorted.body.data.map((u) => u.fullName);
    assert.deepEqual(
      names,
      [...names].sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'accent' })),
    );
  });

  it('search treats % and _ literally (LIKE wildcards are escaped)', async () => {
    await createUser(adminToken, { fullName: 'Fifty 50% Off' });
    const percent = await get(adminToken, `/admin/users?search=${encodeURIComponent('50%')}`);
    assert.equal(percent.body.data.length, 1);
    const wildcardOnly = await get(adminToken, `/admin/users?search=${encodeURIComponent('%')}`);
    assert.equal(
      wildcardOnly.body.data.length,
      1,
      '"%" must match the literal percent sign only, not everything',
    );
    const underscore = await get(adminToken, `/admin/users?search=${encodeURIComponent('_')}`);
    assert.equal(underscore.body.data.length, 0);
  });

  it('rejects bad query parameters (422) - including SQL-injection attempts in sortBy', async () => {
    for (const query of [
      'limit=0',
      'limit=101',
      'page=abc',
      'role=super_admin',
      'isActive=maybe',
      'sortBy=password',
      'sortBy=email;DROP TABLE users',
    ]) {
      expectFailure(await get(adminToken, `/admin/users?${query}`), 422, 'VALIDATION_ERROR');
    }
  });

  it('excludes soft-deleted users', async () => {
    const { user } = await createUser(adminToken, { fullName: 'Soon Deleted' });
    await del(adminToken, `/admin/users/${user.userId}`);
    const res = await get(adminToken, '/admin/users?search=Soon Deleted');
    assert.equal(res.body.data.length, 0);
  });
});

describe('POST /admin/users (create)', () => {
  it('an admin creates a member: temporary password returned ONCE, change forced at first login', async () => {
    const { user, temporaryPassword, res, email } = await createUser(adminToken, {
      fullName: 'New Member',
    });
    assert.equal(user.role, 'member');
    assert.equal(user.isActive, true);
    assert.equal(temporaryPassword.length, 16);
    assert.match(res.body.message, /only once/);
    assert.ok(!('mustChangePassword' in user));

    // audit trail + secure storage
    const row = await queryOne('SELECT created_by FROM users WHERE user_id = ?', [user.userId]);
    assert.equal(row.created_by, adminId);
    const password = await queryOne(
      'SELECT hash_password, must_change_password, created_by FROM user_passwords WHERE user_id = ?',
      [user.userId],
    );
    assert.match(password.hash_password, /^\$2[aby]\$/);
    assert.equal(Boolean(password.must_change_password), true);
    assert.equal(password.created_by, adminId);
    const role = await queryOne('SELECT created_by FROM user_roles WHERE user_id = ?', [
      user.userId,
    ]);
    assert.equal(role.created_by, adminId);
    assert.equal(
      await queryScalar('SELECT COUNT(*) FROM user_security_profiles WHERE user_id = ?', [
        user.userId,
      ]),
      0,
    );

    // the password is never retrievable again
    assert.ok(
      !JSON.stringify((await get(adminToken, `/admin/users/${user.userId}`)).body).includes(
        temporaryPassword,
      ),
    );

    // first login -> forced change
    const session = await loginOk({ email, password: temporaryPassword });
    assert.equal(session.user.mustChangePassword, true);
    assert.equal(session.user.hasSecurityProfile, false);
    assert.equal((await get(session.token, '/users/me')).status, 200); // allowed
    expectFailure(
      await patch(session.token, '/users/me', { fullName: 'Other Name' }),
      403,
      'PASSWORD_CHANGE_REQUIRED',
    );
    expectFailure(
      await get(session.token, '/auth/security-profile'),
      403,
      'PASSWORD_CHANGE_REQUIRED',
    );

    const changed = await post(session.token, '/auth/change-password', {
      currentPassword: temporaryPassword,
      newPassword: 'My-Own-Passw0rd',
    });
    assert.equal(changed.status, 200);
    const token = changed.body.data.accessToken;
    assert.equal((await get(token, '/users/me')).body.data.mustChangePassword, false);
    assert.equal((await patch(token, '/users/me', { fullName: 'Other Name' })).status, 200);

    // ...and then the user sets their recovery profile (admin-created users start without one)
    const profile = await http().put(`${API}/auth/security-profile`).set(bearer(token)).send({
      currentPassword: 'My-Own-Passw0rd',
      dob: '1991-02-03',
      q2: 'Pune',
      q3: 'Fergusson',
      customQuestions: [],
    });
    assert.equal(profile.status, 200);
    assert.equal((await get(token, '/users/me')).body.data.hasSecurityProfile, true);
  });

  it('an admin CAN create another admin; the super admin can create both', async () => {
    assert.equal((await createUser(adminToken, { role: 'admin' })).user.role, 'admin');
    assert.equal((await createUser(superToken, { role: 'admin' })).user.role, 'admin');
    assert.equal((await createUser(superToken, { role: 'member' })).user.role, 'member');
  });

  it('409 for a duplicate e-mail, 422 for unknown / unassignable roles and bad input', async () => {
    const { email } = await createUser(adminToken);
    expectFailure(
      await post(adminToken, '/admin/users', {
        fullName: 'Dup',
        email: email.toUpperCase(),
        role: 'member',
      }),
      409,
      'EMAIL_ALREADY_EXISTS',
    );
    expectFailure(
      await post(adminToken, '/admin/users', {
        fullName: 'Dup',
        email: CREDS.superAdmin.email,
        role: 'member',
      }),
      409,
      'EMAIL_ALREADY_EXISTS',
    );
    for (const role of ['super_admin', 'ghost', undefined]) {
      expectFailure(
        await post(adminToken, '/admin/users', { fullName: 'X Y', email: 'x.y@example.com', role }),
        422,
        'VALIDATION_ERROR',
      );
    }
    expectFailure(
      await post(adminToken, '/admin/users', {
        fullName: 'X Y',
        email: 'x.y@example.com',
        role: 'member',
        password: 'chosen',
      }),
      422,
      'VALIDATION_ERROR',
    );
  });
});

describe('role changes: admins may promote, only the super admin may demote', () => {
  it("an admin promotes a member to admin - effective on the member's very next request", async () => {
    const member = await createActiveUser(adminToken);
    expectFailure(await get(member.token, '/admin/users'), 403, 'INSUFFICIENT_ROLE');

    const res = await patch(adminToken, `/admin/users/${member.user.userId}/role`, {
      role: 'admin',
    });
    assert.equal(res.status, 200);
    assert.equal(res.body.data.role, 'admin');

    // SAME access token as before: the role is re-read from the database on every request
    assert.equal((await get(member.token, '/admin/users')).status, 200);
    const row = await queryOne('SELECT updated_by, role_id FROM user_roles WHERE user_id = ?', [
      member.user.userId,
    ]);
    assert.equal(row.updated_by, adminId);
    assert.equal(
      await queryScalar('SELECT COUNT(*) FROM user_roles WHERE user_id = ?', [member.user.userId]),
      1,
      'still exactly one role row (UPDATE, not insert)',
    );
  });

  it('an admin can NOT demote another admin (403 INSUFFICIENT_ROLE); nothing changes', async () => {
    const other = await createUser(adminToken, { role: 'admin' });
    expectFailure(
      await patch(adminToken, `/admin/users/${other.user.userId}/role`, { role: 'member' }),
      403,
      'INSUFFICIENT_ROLE',
    );
    assert.equal(
      (await get(adminToken, `/admin/users/${other.user.userId}`)).body.data.role,
      'admin',
    );
  });

  it('the super admin demotes an admin - which takes effect immediately', async () => {
    const other = await createActiveUser(superToken, { role: 'admin' });
    assert.equal((await get(other.token, '/admin/users')).status, 200);
    const res = await patch(superToken, `/admin/users/${other.user.userId}/role`, {
      role: 'member',
    });
    assert.equal(res.body.data.role, 'member');
    expectFailure(await get(other.token, '/admin/users'), 403, 'INSUFFICIENT_ROLE');
  });

  it('setting the role a user already has is an idempotent no-op', async () => {
    const { user } = await createUser(adminToken);
    const res = await patch(adminToken, `/admin/users/${user.userId}/role`, { role: 'member' });
    assert.equal(res.status, 200);
    assert.equal(res.body.data.role, 'member');
  });

  it('super_admin can never be assigned, and nobody changes their own role', async () => {
    const { user } = await createUser(adminToken);
    expectFailure(
      await patch(superToken, `/admin/users/${user.userId}/role`, { role: 'super_admin' }),
      422,
      'VALIDATION_ERROR',
    );
    expectFailure(
      await patch(adminToken, `/admin/users/${adminId}/role`, { role: 'admin' }),
      403,
      'SELF_ACTION_NOT_ALLOWED',
    );
    expectFailure(
      await patch(superToken, '/admin/users/1/role', { role: 'member' }),
      403,
      'SUPER_ADMIN_PROTECTED',
    );
  });
});

describe('the other admin actions follow the same hierarchy', () => {
  const actions = (id) => [
    ['patch', `/admin/users/${id}`, { fullName: 'Renamed Person' }],
    ['patch', `/admin/users/${id}/status`, { isActive: false }],
    ['post', `/admin/users/${id}/reset-password`, undefined],
    ['delete', `/admin/users/${id}`, undefined],
  ];

  it('an admin can NOT update, deactivate, reset or delete another admin', async () => {
    const other = await createUser(adminToken, { role: 'admin' });
    for (const [method, path, body] of actions(other.user.userId)) {
      expectFailure(
        await http()[method](`${API}${path}`).set(bearer(adminToken)).send(body),
        403,
        'INSUFFICIENT_ROLE',
      );
    }
    const still = (await get(adminToken, `/admin/users/${other.user.userId}`)).body.data;
    assert.equal(still.fullName, 'Created User');
    assert.equal(still.isActive, true);
  });

  it('an admin can NOT use the admin endpoints on their own account', async () => {
    for (const [method, path, body] of actions(adminId)) {
      expectFailure(
        await http()[method](`${API}${path}`).set(bearer(adminToken)).send(body),
        403,
        'SELF_ACTION_NOT_ALLOWED',
      );
    }
  });

  it('the super admin is invisible to admins (404) and untouchable by everyone (403)', async () => {
    expectFailure(await get(adminToken, '/admin/users/1'), 404, 'USER_NOT_FOUND');
    for (const [method, path, body] of actions(1)) {
      expectFailure(
        await http()[method](`${API}${path}`).set(bearer(adminToken)).send(body),
        404,
        'USER_NOT_FOUND',
      );
      expectFailure(
        await http()[method](`${API}${path}`).set(bearer(superToken)).send(body),
        403,
        'SUPER_ADMIN_PROTECTED',
      );
    }
    const self = await get(superToken, '/admin/users/1');
    assert.equal(self.status, 200);
    assert.equal(self.body.data.role, 'super_admin');
  });

  it('an admin sees other admins read-only', async () => {
    const other = await createUser(superToken, { role: 'admin' });
    const res = await get(adminToken, `/admin/users/${other.user.userId}`);
    assert.equal(res.status, 200);
    assert.equal(res.body.data.role, 'admin');
  });

  it('unknown or malformed ids: 404 / 422', async () => {
    expectFailure(await get(adminToken, '/admin/users/999999'), 404, 'USER_NOT_FOUND');
    expectFailure(await del(adminToken, '/admin/users/999999'), 404, 'USER_NOT_FOUND');
    for (const id of ['abc', '0', '-1', '1.5'])
      expectFailure(await get(adminToken, `/admin/users/${id}`), 422, 'VALIDATION_ERROR');
  });
});

describe('activate / deactivate', () => {
  it('a deactivated member can still sign in, see their profile and sign out - but nothing else', async () => {
    const member = await createActiveUser(adminToken);
    const off = await patch(adminToken, `/admin/users/${member.user.userId}/status`, {
      isActive: false,
    });
    assert.equal(off.status, 200);
    assert.equal(off.body.data.isActive, false);
    assert.match(off.body.message, /deactivated/);

    // existing access token is affected at once
    expectFailure(
      await patch(member.token, '/users/me', { fullName: 'Blocked Name' }),
      403,
      'ACCOUNT_INACTIVE',
    );
    const relog = await loginOk({ email: member.email, password: member.password });
    assert.equal(relog.user.isActive, false);
    assert.equal((await get(relog.token, '/users/me')).status, 200);
    assert.equal((await http().post(`${API}/auth/logout`).set('Cookie', relog.cookie)).status, 200);

    const on = await patch(adminToken, `/admin/users/${member.user.userId}/status`, {
      isActive: true,
    });
    assert.match(on.body.message, /activated/);
    assert.equal(
      (await patch(member.token, '/users/me', { fullName: 'Allowed Name' })).status,
      200,
    );
  });

  it('isActive must be a real boolean', async () => {
    const { user } = await createUser(adminToken);
    expectFailure(
      await patch(adminToken, `/admin/users/${user.userId}/status`, { isActive: 'false' }),
      422,
      'VALIDATION_ERROR',
    );
  });
});

describe('update profile (admin)', () => {
  it('updates the name only; the e-mail is immutable here too', async () => {
    const { user } = await createUser(adminToken);
    const res = await patch(adminToken, `/admin/users/${user.userId}`, {
      fullName: '  Renamed   Person ',
    });
    assert.equal(res.status, 200);
    assert.equal(res.body.data.fullName, 'Renamed Person');
    expectFailure(
      await patch(adminToken, `/admin/users/${user.userId}`, {
        fullName: 'Renamed Person',
        email: 'new@example.com',
      }),
      422,
      'VALIDATION_ERROR',
    );
  });

  it('the super admin may update an admin', async () => {
    const { user } = await createUser(superToken, { role: 'admin' });
    assert.equal(
      (await patch(superToken, `/admin/users/${user.userId}`, { fullName: 'Admin Renamed' }))
        .status,
      200,
    );
  });
});

describe('reset password (admin)', () => {
  it('generates a temporary password, forces a change, revokes sessions, clears the recovery lock', async () => {
    const member = await createActiveUser(adminToken);
    // give the user a recovery profile, then lock it as if someone had been guessing answers
    const profile = await http()
      .put(`${API}/auth/security-profile`)
      .set(bearer(member.token))
      .send({
        currentPassword: member.password,
        dob: '1992-04-05',
        q2: 'Surat',
        q3: 'City School',
        customQuestions: [],
      });
    assert.equal(profile.status, 200);
    await db.execute(
      'UPDATE user_security_profiles SET failed_attempts = 3, locked_until = ? WHERE user_id = ?',
      [new Date(Date.now() + 600_000), member.user.userId],
    );

    const res = await post(adminToken, `/admin/users/${member.user.userId}/reset-password`);
    assert.equal(res.status, 200);
    const { temporaryPassword } = res.body.data;
    assert.equal(temporaryPassword.length, 16);
    assert.match(res.body.message, /only once/);

    expectFailure(
      await http().post(`${API}/auth/refresh`).set('Cookie', member.cookie),
      401,
      'TOKEN_INVALID',
    );
    expectFailure(
      await login({ email: member.email, password: member.password }),
      401,
      'INVALID_CREDENTIALS',
    );
    const session = await loginOk({ email: member.email, password: temporaryPassword });
    assert.equal(session.user.mustChangePassword, true);

    const row = await queryOne('SELECT updated_by FROM user_passwords WHERE user_id = ?', [
      member.user.userId,
    ]);
    assert.equal(row.updated_by, adminId);
    const lock = await queryOne(
      'SELECT failed_attempts, locked_until FROM user_security_profiles WHERE user_id = ?',
      [member.user.userId],
    );
    assert.equal(lock.failed_attempts, 0);
    assert.equal(lock.locked_until, null);
  });

  it('after an admin reset the user is back in business once they pick a new password', async () => {
    const member = await createActiveUser(adminToken);
    const { temporaryPassword } = (
      await post(adminToken, `/admin/users/${member.user.userId}/reset-password`)
    ).body.data;
    const session = await loginOk({ email: member.email, password: temporaryPassword });
    const changed = await post(session.token, '/auth/change-password', {
      currentPassword: temporaryPassword,
      newPassword: 'Fr3sh-Passw0rd!',
    });
    assert.equal(changed.status, 200);
    assert.equal(
      (await get(changed.body.data.accessToken, '/users/me')).body.data.mustChangePassword,
      false,
    );
  });

  it("the super admin can reset an admin's password", async () => {
    const { user } = await createUser(superToken, { role: 'admin' });
    assert.equal(
      (await post(superToken, `/admin/users/${user.userId}/reset-password`)).status,
      200,
    );
  });
});

describe('delete user (soft)', () => {
  it('an admin deletes a member: sessions die, history stays, the e-mail becomes reusable', async () => {
    const member = await createActiveUser(adminToken);
    const res = await del(adminToken, `/admin/users/${member.user.userId}`);
    assert.equal(res.status, 200);

    const row = await queryOne('SELECT is_deleted FROM users WHERE user_id = ?', [
      member.user.userId,
    ]);
    assert.equal(Boolean(row.is_deleted), true);
    expectFailure(await get(member.token, '/users/me'), 401, 'TOKEN_INVALID');
    expectFailure(
      await http().post(`${API}/auth/refresh`).set('Cookie', member.cookie),
      401,
      'TOKEN_INVALID',
    );
    expectFailure(
      await login({ email: member.email, password: member.password }),
      401,
      'INVALID_CREDENTIALS',
    );
    expectFailure(
      await get(adminToken, `/admin/users/${member.user.userId}`),
      404,
      'USER_NOT_FOUND',
    );
    expectFailure(
      await del(adminToken, `/admin/users/${member.user.userId}`),
      404,
      'USER_NOT_FOUND',
    );

    const again = await post(adminToken, '/admin/users', {
      fullName: 'Same Email',
      email: member.email,
      role: 'member',
    });
    assert.equal(again.status, 201);
  });

  it('the super admin deletes an admin', async () => {
    const { user } = await createUser(superToken, { role: 'admin' });
    assert.equal((await del(superToken, `/admin/users/${user.userId}`)).status, 200);
  });
});

describe('GET /roles', () => {
  it('lists the assignable roles with a per-caller "assignable" flag', async () => {
    const asAdmin = await get(adminToken, '/roles');
    assert.equal(asAdmin.status, 200);
    assert.deepEqual(
      asAdmin.body.data.map((r) => [r.roleName, r.roleLevel, r.assignable]),
      [
        ['member', 1, true],
        ['admin', 2, true],
      ],
    );
    assert.ok(!asAdmin.body.data.some((r) => r.roleName === 'super_admin'));
    const asSuper = await get(superToken, '/roles');
    assert.ok(asSuper.body.data.every((r) => r.assignable));
  });

  it('?assignable=true keeps only what the caller may assign; bad values are a 422', async () => {
    const res = await get(adminToken, '/roles?assignable=true');
    assert.deepEqual(
      res.body.data.map((r) => r.roleName),
      ['member', 'admin'],
    );
    assert.deepEqual((await get(adminToken, '/roles?assignable=false')).body.data, []);
    expectFailure(await get(adminToken, '/roles?assignable=maybe'), 422, 'VALIDATION_ERROR');
  });
});
