import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import {
  db,
  fetchAll,
  fetchOne,
  pool,
  queryAll,
  queryOne,
  queryScalar,
  withTransaction,
} from '../../src/database/index.js';
import { AppError, NotFoundError } from '../../src/errors/index.js';
import { createUserAccount } from '../../src/modules/users/users.service.js';
import { insertSecurityProfile } from '../../src/modules/auth/recovery.service.js';
import { bootstrapTestEnvironment, shutdownTestEnvironment } from '../helpers/app.js';

before(bootstrapTestEnvironment);
after(shutdownTestEnvironment);

describe('query helpers', () => {
  it('queryAll returns rows or an empty array', async () => {
    const roles = await queryAll('SELECT role_name FROM roles ORDER BY role_level');
    assert.deepEqual(
      roles.map((r) => r.role_name),
      ['member', 'admin'],
    );
    assert.deepEqual(await queryAll('SELECT * FROM roles WHERE role_name = ?', ['nope']), []);
  });

  it('queryOne returns the first row or null', async () => {
    assert.equal(
      (await queryOne('SELECT role_name FROM roles WHERE role_id = ?', [2])).role_name,
      'admin',
    );
    assert.equal(await queryOne('SELECT * FROM roles WHERE role_id = ?', [999]), null);
  });

  it('queryScalar returns the first column of the first row', async () => {
    assert.equal(await queryScalar('SELECT COUNT(*) FROM roles'), 2);
    assert.equal(await queryScalar('SELECT 1 FROM roles WHERE role_id = ?', [999]), null);
  });

  it('fetchOne / fetchAll are strict: they throw when nothing is found', async () => {
    assert.equal(
      (await fetchOne('SELECT * FROM roles WHERE role_id = ?', [1])).role_name,
      'member',
    );
    assert.equal((await fetchAll('SELECT * FROM roles')).length, 2);

    await assert.rejects(
      () => fetchOne('SELECT * FROM roles WHERE role_id = ?', [999]),
      NotFoundError,
    );
    await assert.rejects(
      () => fetchAll('SELECT * FROM roles WHERE role_id = ?', [999]),
      NotFoundError,
    );
  });

  it('fetchOne accepts a message, a factory or a ready-made Error', async () => {
    const sql = 'SELECT * FROM roles WHERE role_id = ?';
    await assert.rejects(() => fetchOne(sql, [999], 'Role is gone'), {
      message: 'Role is gone',
      statusCode: 404,
    });
    await assert.rejects(
      () => fetchOne(sql, [999], () => new AppError('custom', { statusCode: 418, code: 'TEAPOT' })),
      { statusCode: 418, code: 'TEAPOT' },
    );
    await assert.rejects(() => fetchOne(sql, [999], new RangeError('boom')), RangeError);
  });

  it('execute reports insertId and affectedRows', async () => {
    const insert = await db.execute(
      `INSERT INTO roles (role_name, role_level, description, created_by) VALUES (?, ?, ?, 1)`,
      ['tmp-role', 9, 'temporary'],
    );
    assert.ok(insert.insertId > 2);
    assert.equal(insert.affectedRows, 1);
    const del = await db.execute('DELETE FROM roles WHERE role_id = ?', [insert.insertId]);
    assert.equal(del.affectedRows, 1);
  });

  it('values are always bound, never interpolated (SQL injection stays inert)', async () => {
    const evil = "x'; DROP TABLE roles; --";
    assert.equal(await queryOne('SELECT * FROM roles WHERE role_name = ?', [evil]), null);
    assert.equal(await queryScalar('SELECT COUNT(*) FROM roles'), 2); // table still there
  });

  it('undefined params fail loudly instead of becoming NULL silently', async () => {
    await assert.rejects(
      () => queryOne('SELECT * FROM roles WHERE role_id = ?', [undefined]),
      /undefined/,
    );
  });

  it('queryAll refuses non-SELECT statements', async () => {
    await assert.rejects(
      () => queryAll('UPDATE roles SET role_level = role_level WHERE role_id = ?', [1]),
      TypeError,
    );
  });

  it('every connection runs in UTC and Dates round-trip exactly', async () => {
    assert.equal(await queryScalar('SELECT @@session.time_zone'), '+00:00');
    const moment = new Date('2026-03-04T05:06:07.123Z');
    await db.execute('UPDATE users SET last_login = ? WHERE user_id = 1', [moment]);
    const row = await queryOne('SELECT last_login FROM users WHERE user_id = 1');
    assert.equal(row.last_login.toISOString(), moment.toISOString());
  });
});

describe('transactions', () => {
  const countUsers = (email) => queryScalar('SELECT COUNT(*) FROM users WHERE email = ?', [email]);

  it('commits everything when the callback resolves, and returns its value', async () => {
    const email = 'tx.commit@example.com';
    const userId = await withTransaction(async (tx) =>
      createUserAccount(tx, {
        fullName: 'Tx Commit',
        email,
        passwordHash: '$2b$04$x',
        roleName: 'member',
      }),
    );
    assert.ok(userId > 0);
    assert.equal(await countUsers(email), 1);
    assert.equal(
      await queryScalar('SELECT COUNT(*) FROM user_passwords WHERE user_id = ?', [userId]),
      1,
    );
    assert.equal(
      await queryScalar('SELECT COUNT(*) FROM user_roles WHERE user_id = ?', [userId]),
      1,
    );
  });

  it('rolls back EVERY table when a later statement fails (the sign-up scenario)', async () => {
    const email = 'tx.rollback@example.com';
    let createdId;
    await assert.rejects(
      () =>
        withTransaction(async (tx) => {
          createdId = await createUserAccount(tx, {
            fullName: 'Tx Rollback',
            email,
            passwordHash: '$2b$04$x',
            roleName: 'member',
          });
          // 4th table fails: dob_hash is NOT NULL
          await insertSecurityProfile(tx, createdId, {
            dobHash: null,
            q2Hash: 'a',
            q3Hash: 'b',
            custom: [],
          });
        }),
      (err) => err.code === 'ER_BAD_NULL_ERROR',
    );
    assert.ok(createdId > 0, 'the user row WAS inserted inside the transaction');
    assert.equal(await countUsers(email), 0);
    for (const table of ['users', 'user_passwords', 'user_roles', 'user_security_profiles']) {
      assert.equal(
        await queryScalar(`SELECT COUNT(*) FROM ${table} WHERE user_id = ?`, [createdId]),
        0,
        `${table} must be rolled back`,
      );
    }
  });

  it('rolls back when the callback throws its own exception, and re-throws it', async () => {
    const email = 'tx.throw@example.com';
    await assert.rejects(
      () =>
        withTransaction(async (tx) => {
          await tx.execute('INSERT INTO users (full_name, email, created_by) VALUES (?, ?, 1)', [
            'T',
            email,
          ]);
          throw new AppError('business rule failed', { statusCode: 409, code: 'RULE' });
        }),
      { code: 'RULE' },
    );
    assert.equal(await countUsers(email), 0);
  });

  it('retries automatically on deadlock, discarding the failed attempt', async () => {
    const email = 'tx.deadlock@example.com';
    let attempts = 0;
    await withTransaction(async (tx) => {
      attempts += 1;
      await tx.execute('INSERT INTO users (full_name, email, created_by) VALUES (?, ?, 1)', [
        'T',
        email,
      ]);
      if (attempts === 1) throw Object.assign(new Error('simulated'), { code: 'ER_LOCK_DEADLOCK' });
    });
    assert.equal(attempts, 2);
    assert.equal(await countUsers(email), 1); // exactly one row: the first attempt was rolled back
  });

  it('the transaction executor cannot be used after the transaction finished', async () => {
    let leaked;
    await withTransaction(async (tx) => {
      leaked = tx;
    });
    await assert.rejects(() => leaked.queryOne('SELECT 1'), /already finished/);
  });

  it('never leaks connections, even when every transaction fails', async () => {
    const limit = pool.pool.config.connectionLimit;
    for (let i = 0; i < limit * 3; i += 1) {
      await assert.rejects(() =>
        withTransaction(async () => {
          throw new Error('fail');
        }),
      );
    }
    assert.equal(await queryScalar('SELECT 1'), 1);
  });

  it('isolates concurrent transactions until commit', async () => {
    const email = 'tx.isolation@example.com';
    let release;
    const gate = new Promise((resolve) => {
      release = resolve;
    });
    const slow = withTransaction(async (tx) => {
      await tx.execute('INSERT INTO users (full_name, email, created_by) VALUES (?, ?, 1)', [
        'T',
        email,
      ]);
      await gate;
    });
    await new Promise((resolve) => setTimeout(resolve, 50));
    assert.equal(await countUsers(email), 0); // not visible before commit
    release();
    await slow;
    assert.equal(await countUsers(email), 1);
  });
});
