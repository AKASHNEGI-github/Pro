import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { after, before, describe, it } from 'node:test';
import jwt from 'jsonwebtoken';
import { config } from '../../src/config/index.js';
import { db, queryAll, queryOne, queryScalar } from '../../src/database/index.js';
import { sha256Hex } from '../../src/utils/crypto.js';
import {
  API,
  bearer,
  bootstrapTestEnvironment,
  CREDS,
  expectFailure,
  freshSession,
  http,
  login,
  loginOk,
  newRegistration,
  rawToken,
  refreshCookie,
  registerUser,
  shutdownTestEnvironment,
} from '../helpers/app.js';

before(bootstrapTestEnvironment);
after(shutdownTestEnvironment);

const refresh = (cookie) => {
  const req = http().post(`${API}/auth/refresh`);
  return cookie ? req.set('Cookie', cookie) : req;
};

describe('POST /auth/register', () => {
  it('creates a MEMBER and writes all four tables', async () => {
    const { payload, user } = await registerUser();

    assert.equal(user.role, 'member');
    assert.equal(user.email, payload.email);
    assert.equal(user.isActive, true);
    assert.equal(user.mustChangePassword, false);
    assert.equal(user.hasSecurityProfile, true);
    assert.ok(!('password' in user) && !('hash_password' in user));

    const row = await queryOne('SELECT * FROM users WHERE email = ?', [payload.email]);
    assert.equal(row.created_by, null, 'NULL created_by = self-registered');

    const password = await queryOne('SELECT * FROM user_passwords WHERE user_id = ?', [
      row.user_id,
    ]);
    assert.match(password.hash_password, /^\$2[aby]\$/);
    assert.ok(!password.hash_password.includes(payload.password));
    assert.equal(Boolean(password.must_change_password), false);

    const role = await queryOne(
      'SELECT r.role_name FROM user_roles ur JOIN roles r ON r.role_id = ur.role_id WHERE ur.user_id = ?',
      [row.user_id],
    );
    assert.equal(role.role_name, 'member');

    const profile = await queryOne('SELECT * FROM user_security_profiles WHERE user_id = ?', [
      row.user_id,
    ]);
    for (const hash of [
      profile.dob_hash,
      profile.answer_q2_hash,
      profile.answer_q3_hash,
      profile.custom_answer_1_hash,
    ]) {
      assert.match(hash, /^\$2[aby]\$/);
    }
    assert.ok(!profile.dob_hash.includes('1990'));
    assert.equal(profile.custom_question_1, payload.securityProfile.customQuestions[0].question);
    assert.equal(profile.custom_question_2, null);
    assert.equal(profile.failed_attempts, 0);
  });

  it('does not sign the user in (no cookie, no tokens)', async () => {
    const res = await http().post(`${API}/auth/register`).send(newRegistration());
    assert.equal(res.status, 201);
    assert.equal(res.headers['set-cookie'], undefined);
    assert.ok(!('accessToken' in res.body.data));
  });

  it('rejects a duplicate e-mail, case-insensitively (409 EMAIL_ALREADY_EXISTS)', async () => {
    const { payload } = await registerUser();
    const res = await http()
      .post(`${API}/auth/register`)
      .send({ ...newRegistration(), email: payload.email.toUpperCase() });
    expectFailure(res, 409, 'EMAIL_ALREADY_EXISTS');
  });

  it('rejects the super admin e-mail', async () => {
    const res = await http()
      .post(`${API}/auth/register`)
      .send(newRegistration({ email: CREDS.superAdmin.email }));
    expectFailure(res, 409, 'EMAIL_ALREADY_EXISTS');
  });

  it('survives a race: two simultaneous sign-ups with the same e-mail -> one 201, one 409', async () => {
    const payload = newRegistration();
    const results = await Promise.all([
      http().post(`${API}/auth/register`).send(payload),
      http().post(`${API}/auth/register`).send(payload),
    ]);
    assert.deepEqual(results.map((r) => r.status).sort(), [201, 409]);
    assert.equal(
      await queryScalar('SELECT COUNT(*) FROM users WHERE email = ?', [payload.email]),
      1,
    );
  });

  it('422 with field-level details for invalid input', async () => {
    const res = await http()
      .post(`${API}/auth/register`)
      .send({ fullName: 'A', email: 'nope', password: 'weak' });
    expectFailure(res, 422, 'VALIDATION_ERROR');
    const fields = res.body.error.details.map((d) => d.field);
    for (const field of ['fullName', 'email', 'password', 'securityProfile'])
      assert.ok(fields.includes(field), field);
  });

  it('cannot self-assign a role or flags (mass assignment is rejected)', async () => {
    const res = await http()
      .post(`${API}/auth/register`)
      .send({ ...newRegistration(), role: 'admin', isActive: false });
    expectFailure(res, 422, 'VALIDATION_ERROR');
    assert.deepEqual(res.body.error.details.map((d) => d.field).sort(), ['isActive', 'role']);
  });

  it('GET /auth/security-questions is public and lists the fixed questions', async () => {
    const res = await http().get(`${API}/auth/security-questions`);
    assert.equal(res.status, 200);
    assert.deepEqual(
      res.body.data.fixedQuestions.map((q) => q.key),
      ['dob', 'q2', 'q3'],
    );
    assert.equal(res.body.data.maxCustomQuestions, 2);
  });
});

describe('POST /auth/login', () => {
  it('returns an access token + user, and sets the refresh token as an httpOnly cookie only', async () => {
    const { payload } = await registerUser();
    const res = await login({ email: payload.email.toUpperCase(), password: payload.password });

    assert.equal(res.status, 200);
    assert.equal(res.body.success, true);
    assert.equal(res.body.data.tokenType, 'Bearer');
    assert.equal(res.body.data.expiresIn, 900);
    assert.equal(res.body.data.user.email, payload.email);
    assert.ok(
      !JSON.stringify(res.body).includes('refresh'),
      'refresh token must never be in the body',
    );

    const cookie = res.headers['set-cookie'].find((c) => c.startsWith('refresh_token='));
    assert.match(cookie, /HttpOnly/i);
    assert.match(cookie, /SameSite=Strict/i);
    assert.match(cookie, /Path=\/api\/v1\/auth/);

    // the stored value is a SHA-256 digest of the cookie value, never the value itself
    const raw = rawToken(refreshCookie(res));
    const stored = await queryOne('SELECT token_hash FROM refresh_tokens WHERE token_hash = ?', [
      sha256Hex(raw),
    ]);
    assert.ok(stored);
    assert.equal(
      await queryScalar('SELECT COUNT(*) FROM refresh_tokens WHERE token_hash = ?', [raw]),
      0,
    );
  });

  it('updates last_login and writes SUCCESS / FAILURE login logs', async () => {
    const { payload, user } = await registerUser();
    await login({ email: payload.email, password: 'Wrong@12345' });
    await loginOk({ email: payload.email, password: payload.password });

    const logs = await queryAll(
      'SELECT login_status, failure_reason, ip_address FROM user_login_logs WHERE user_id = ? ORDER BY user_login_logs_id',
      [user.userId],
    );
    assert.deepEqual(
      logs.map((l) => l.login_status),
      ['FAILURE', 'SUCCESS'],
    );
    assert.equal(logs[0].failure_reason, 'INVALID_PASSWORD');
    assert.ok(logs[1].ip_address);
    assert.ok(
      (await queryOne('SELECT last_login FROM users WHERE user_id = ?', [user.userId])).last_login,
    );
  });

  it('wrong password and unknown e-mail look identical (no user enumeration)', async () => {
    const { payload } = await registerUser();
    const wrong = await login({ email: payload.email, password: 'Wrong@12345' });
    const unknown = await login({ email: 'nobody@example.com', password: 'Wrong@12345' });
    expectFailure(wrong, 401, 'INVALID_CREDENTIALS');
    expectFailure(unknown, 401, 'INVALID_CREDENTIALS');
    assert.equal(wrong.body.message, unknown.body.message);
  });

  it('an INACTIVE user can sign in, view their profile and sign out - nothing else', async () => {
    const { payload, user, token, cookie } = await freshSession();
    await db.execute('UPDATE users SET is_active = FALSE WHERE user_id = ?', [user.userId]);

    assert.equal((await login({ email: payload.email, password: payload.password })).status, 200);

    const me = await http().get(`${API}/users/me`).set(bearer(token));
    assert.equal(me.status, 200);
    assert.equal(me.body.data.isActive, false);

    expectFailure(
      await http().patch(`${API}/users/me`).set(bearer(token)).send({ fullName: 'Changed Name' }),
      403,
      'ACCOUNT_INACTIVE',
    );
    expectFailure(
      await http()
        .post(`${API}/auth/change-password`)
        .set(bearer(token))
        .send({ currentPassword: payload.password, newPassword: 'N3w-Passw0rd' }),
      403,
      'ACCOUNT_INACTIVE',
    );
    assert.equal((await refresh(cookie)).status, 200);
    assert.equal((await http().post(`${API}/auth/logout`).set('Cookie', cookie)).status, 200);
  });

  it('a soft-deleted user cannot sign in', async () => {
    const { payload, user } = await registerUser();
    await db.execute('UPDATE users SET is_deleted = TRUE WHERE user_id = ?', [user.userId]);
    expectFailure(
      await login({ email: payload.email, password: payload.password }),
      401,
      'INVALID_CREDENTIALS',
    );
  });

  it('the SUPER ADMIN signs in with the ENV credentials (no password row exists)', async () => {
    const { user, token } = await loginOk(CREDS.superAdmin);
    assert.equal(user.userId, 1);
    assert.equal(user.role, 'super_admin');
    assert.equal(user.email, CREDS.superAdmin.email);
    assert.equal(user.fullName, 'Test Super Admin'); // synced from SUPER_ADMIN_NAME at startup

    assert.equal(await queryScalar('SELECT COUNT(*) FROM user_passwords WHERE user_id = 1'), 0);
    assert.equal(await queryScalar('SELECT COUNT(*) FROM user_roles WHERE user_id = 1'), 0);

    const me = await http().get(`${API}/users/me`).set(bearer(token));
    assert.equal(me.body.data.role, 'super_admin');
  });

  it('a wrong super admin password fails like any other', async () => {
    expectFailure(
      await login({ email: CREDS.superAdmin.email, password: 'Wrong@12345' }),
      401,
      'INVALID_CREDENTIALS',
    );
  });

  it('the super admin cannot use the self-service credential endpoints (ENV owns them)', async () => {
    const { token } = await loginOk(CREDS.superAdmin);
    for (const [method, path, body] of [
      [
        'post',
        '/auth/change-password',
        { currentPassword: 'SuperAdmin@12345', newPassword: 'N3w-Passw0rd' },
      ],
      ['get', '/auth/security-profile'],
      ['patch', '/users/me', { fullName: 'Hacked Name' }],
      ['delete', '/users/me', { password: 'SuperAdmin@12345' }],
    ]) {
      const res = await http()[method](`${API}${path}`).set(bearer(token)).send(body);
      expectFailure(res, 403, 'SUPER_ADMIN_PROTECTED');
    }
  });
});

describe('access token verification', () => {
  const sign = (overrides = {}, secret = config.jwt.accessSecret, options = {}) =>
    jwt.sign({ ...overrides }, secret, {
      algorithm: 'HS256',
      subject: '3',
      issuer: config.jwt.issuer,
      audience: config.jwt.audience,
      ...options,
    });
  const me = (token) => http().get(`${API}/users/me`).set(bearer(token));

  it('401 UNAUTHORIZED without a token / with a malformed header', async () => {
    expectFailure(await http().get(`${API}/users/me`), 401, 'UNAUTHORIZED');
    expectFailure(
      await http().get(`${API}/users/me`).set('Authorization', 'Token abc'),
      401,
      'UNAUTHORIZED',
    );
  });

  it('401 TOKEN_INVALID for garbage, a wrong secret, wrong audience or alg=none', async () => {
    expectFailure(await me('garbage'), 401, 'TOKEN_INVALID');
    expectFailure(
      await me(sign({}, 'another-secret-another-secret-another-secret', { expiresIn: 60 })),
      401,
      'TOKEN_INVALID',
    );
    expectFailure(
      await me(sign({}, undefined, { expiresIn: 60, audience: 'someone-else' })),
      401,
      'TOKEN_INVALID',
    );
    const header = Buffer.from('{"alg":"none","typ":"JWT"}').toString('base64url');
    const body = Buffer.from(
      JSON.stringify({
        sub: '3',
        iss: config.jwt.issuer,
        aud: config.jwt.audience,
        exp: 9999999999,
      }),
    ).toString('base64url');
    expectFailure(await me(`${header}.${body}.`), 401, 'TOKEN_INVALID');
  });

  it('401 TOKEN_EXPIRED for an expired token', async () => {
    const token = sign({ exp: Math.floor(Date.now() / 1000) - 60 });
    expectFailure(await me(token), 401, 'TOKEN_EXPIRED');
  });

  it('401 TOKEN_INVALID when the user no longer exists / was deleted', async () => {
    const { token, user } = await freshSession();
    assert.equal((await me(token)).status, 200);
    await db.execute('UPDATE users SET is_deleted = TRUE WHERE user_id = ?', [user.userId]);
    expectFailure(await me(token), 401, 'TOKEN_INVALID');
    expectFailure(
      await me(sign({}, undefined, { expiresIn: 60, subject: '999999' })),
      401,
      'TOKEN_INVALID',
    );
  });

  it('the token carries only the subject - never a role (roles are read from the DB)', async () => {
    const { token } = await freshSession();
    const claims = jwt.decode(token);
    assert.deepEqual(Object.keys(claims).sort(), ['aud', 'exp', 'iat', 'iss', 'sub']);
  });
});

describe('refresh token rotation', () => {
  it('rotates on every use: new cookie, old row revoked + linked to its replacement', async () => {
    const { cookie, user } = await freshSession();
    const res = await refresh(cookie);
    assert.equal(res.status, 200);
    assert.equal(res.body.data.user.userId, user.userId);
    assert.ok(res.body.data.accessToken);

    const next = refreshCookie(res);
    assert.ok(next && next !== cookie);

    const oldRow = await queryOne(
      'SELECT revoked_at, replaced_by_hash FROM refresh_tokens WHERE token_hash = ?',
      [sha256Hex(rawToken(cookie))],
    );
    assert.ok(oldRow.revoked_at);
    assert.equal(oldRow.replaced_by_hash, sha256Hex(rawToken(next)));
    const newRow = await queryOne('SELECT revoked_at FROM refresh_tokens WHERE token_hash = ?', [
      sha256Hex(rawToken(next)),
    ]);
    assert.equal(newRow.revoked_at, null);
  });

  it('401 when the cookie is missing or unknown', async () => {
    expectFailure(await refresh(null), 401, 'TOKEN_INVALID');
    expectFailure(await refresh('refresh_token=does-not-exist'), 401, 'TOKEN_INVALID');
  });

  it('401 TOKEN_EXPIRED for an expired refresh token (and the cookie is cleared)', async () => {
    const { cookie } = await freshSession();
    await db.execute('UPDATE refresh_tokens SET expires_at = ? WHERE token_hash = ?', [
      new Date(Date.now() - 1000),
      sha256Hex(rawToken(cookie)),
    ]);
    const res = await refresh(cookie);
    expectFailure(res, 401, 'TOKEN_EXPIRED');
    assert.match(res.headers['set-cookie'][0], /refresh_token=;/);
  });

  it('replaying a just-rotated token (parallel tabs) is a benign 401: nothing else is revoked, cookie untouched', async () => {
    const { cookie } = await freshSession();
    const first = await refresh(cookie);
    const newest = refreshCookie(first);

    const replay = await refresh(cookie);
    expectFailure(replay, 401, 'TOKEN_INVALID');
    assert.equal(replay.headers['set-cookie'], undefined, 'must not wipe the newer cookie');

    assert.equal((await refresh(newest)).status, 200, 'the newest token still works');
  });

  it("REUSE of an old rotated token revokes ALL of the user's sessions (theft detection)", async () => {
    const { cookie: first, user, payload } = await freshSession();
    const second = await loginOk({ email: payload.email, password: payload.password }); // another device
    const rotated = await refresh(first);
    const newest = refreshCookie(rotated);

    // age the rotation beyond the leeway window
    await db.execute('UPDATE refresh_tokens SET revoked_at = ? WHERE token_hash = ?', [
      new Date(Date.now() - 60_000),
      sha256Hex(rawToken(first)),
    ]);

    const replay = await refresh(first);
    expectFailure(replay, 401, 'TOKEN_INVALID');
    assert.match(replay.body.message, /reuse/i);
    assert.match(replay.headers['set-cookie'][0], /refresh_token=;/);

    expectFailure(await refresh(newest), 401, 'TOKEN_INVALID');
    expectFailure(await refresh(second.cookie), 401, 'TOKEN_INVALID');
    assert.equal(
      await queryScalar(
        'SELECT COUNT(*) FROM refresh_tokens WHERE user_id = ? AND revoked_at IS NULL',
        [user.userId],
      ),
      0,
    );
  });

  it('parallel refreshes with the SAME cookie: exactly one wins', async () => {
    const { cookie } = await freshSession();
    const results = await Promise.all(Array.from({ length: 6 }, () => refresh(cookie)));
    assert.deepEqual(results.map((r) => r.status).sort(), [200, 401, 401, 401, 401, 401]);
  });

  it('a deleted user can no longer refresh', async () => {
    const { cookie, user } = await freshSession();
    await db.execute('UPDATE users SET is_deleted = TRUE WHERE user_id = ?', [user.userId]);
    expectFailure(await refresh(cookie), 401, 'TOKEN_INVALID');
  });
});

describe('logout', () => {
  it('revokes the session: the refresh token stops working; idempotent and cookie-only', async () => {
    const { cookie } = await freshSession();
    const out = await http().post(`${API}/auth/logout`).set('Cookie', cookie);
    assert.equal(out.status, 200);
    assert.match(out.headers['set-cookie'][0], /refresh_token=;/);
    expectFailure(await refresh(cookie), 401, 'TOKEN_INVALID');

    assert.equal((await http().post(`${API}/auth/logout`).set('Cookie', cookie)).status, 200);
    assert.equal((await http().post(`${API}/auth/logout`)).status, 200); // no cookie at all
  });

  it('logout-all revokes every session of the user', async () => {
    const { payload, token, cookie } = await freshSession();
    const other = await loginOk({ email: payload.email, password: payload.password });

    const res = await http().post(`${API}/auth/logout-all`).set(bearer(token));
    assert.equal(res.status, 200);
    assert.equal(res.body.data.revokedSessions, 2);
    expectFailure(await refresh(cookie), 401, 'TOKEN_INVALID');
    expectFailure(await refresh(other.cookie), 401, 'TOKEN_INVALID');

    expectFailure(await http().post(`${API}/auth/logout-all`), 401, 'UNAUTHORIZED');
  });
});

describe('POST /auth/change-password', () => {
  const change = (token, body) =>
    http().post(`${API}/auth/change-password`).set(bearer(token)).send(body);

  it('400 INVALID_CURRENT_PASSWORD, 422 for a weak or identical new password', async () => {
    const { payload, token } = await freshSession();
    expectFailure(
      await change(token, { currentPassword: 'Wrong@12345', newPassword: 'N3w-Passw0rd' }),
      400,
      'INVALID_CURRENT_PASSWORD',
    );
    expectFailure(
      await change(token, { currentPassword: payload.password, newPassword: 'weak' }),
      422,
      'VALIDATION_ERROR',
    );
    expectFailure(
      await change(token, { currentPassword: payload.password, newPassword: payload.password }),
      422,
      'VALIDATION_ERROR',
    );
  });

  it('changes the password, signs OTHER devices out, kills older access tokens, keeps THIS device signed in', async () => {
    const { payload, token: oldToken, cookie: thisDevice } = await freshSession();
    const otherDevice = await loginOk({ email: payload.email, password: payload.password });
    await sleep(1100); // access-token invalidation has 1-second granularity (JWT `iat`)

    const res = await change(oldToken, {
      currentPassword: payload.password,
      newPassword: 'N3w-Passw0rd',
    });
    assert.equal(res.status, 200);
    const newToken = res.body.data.accessToken;
    const newCookie = refreshCookie(res);
    assert.ok(newToken && newCookie);

    expectFailure(await http().get(`${API}/users/me`).set(bearer(oldToken)), 401, 'TOKEN_INVALID');
    expectFailure(
      await http().get(`${API}/users/me`).set(bearer(otherDevice.token)),
      401,
      'TOKEN_INVALID',
    );
    expectFailure(await refresh(thisDevice), 401, 'TOKEN_INVALID');
    expectFailure(await refresh(otherDevice.cookie), 401, 'TOKEN_INVALID');

    assert.equal((await http().get(`${API}/users/me`).set(bearer(newToken))).status, 200);
    assert.equal((await refresh(newCookie)).status, 200);

    expectFailure(
      await login({ email: payload.email, password: payload.password }),
      401,
      'INVALID_CREDENTIALS',
    );
    assert.equal((await login({ email: payload.email, password: 'N3w-Passw0rd' })).status, 200);
  });
});

describe('security profile', () => {
  const profileBody = (currentPassword, overrides = {}) => ({
    currentPassword,
    dob: '1985-01-15',
    q2: 'Mumbai',
    q3: 'Doon School',
    customQuestions: [],
    ...overrides,
  });

  it("GET shows whether it is configured and the user's own custom questions (never answers)", async () => {
    const { token, payload } = await freshSession();
    const res = await http().get(`${API}/auth/security-profile`).set(bearer(token));
    assert.equal(res.status, 200);
    assert.equal(res.body.data.isConfigured, true);
    assert.deepEqual(res.body.data.customQuestions, [
      { key: 'custom1', question: payload.securityProfile.customQuestions[0].question },
    ]);
    assert.ok(!JSON.stringify(res.body).includes('hash'));
  });

  it('PUT needs the current password and REPLACES every answer (old ones stop working)', async () => {
    const { token, payload } = await freshSession();
    expectFailure(
      await http()
        .put(`${API}/auth/security-profile`)
        .set(bearer(token))
        .send(profileBody('Wrong@12345')),
      400,
      'INVALID_CURRENT_PASSWORD',
    );

    const res = await http()
      .put(`${API}/auth/security-profile`)
      .set(bearer(token))
      .send(profileBody(payload.password));
    assert.equal(res.status, 200);
    assert.deepEqual(res.body.data.customQuestions, []);

    const verify = (answers) =>
      http().post(`${API}/auth/forgot-password/verify`).send({ email: payload.email, answers });
    expectFailure(
      await verify({ dob: '1990-05-21', q2: 'Dehradun', q3: 'St Joseph Academy' }),
      401,
      'INVALID_SECURITY_ANSWERS',
    );
    assert.equal(
      (await verify({ dob: '1985-01-15', q2: 'Mumbai', q3: 'Doon School' })).status,
      200,
    );
  });
});

describe('forgot password (security questions, no e-mail)', () => {
  const ask = (email) => http().post(`${API}/auth/forgot-password/questions`).send({ email });
  const verify = (email, answers) =>
    http().post(`${API}/auth/forgot-password/verify`).send({ email, answers });
  const reset = (resetToken, newPassword) =>
    http().post(`${API}/auth/forgot-password/reset`).send({ resetToken, newPassword });
  const rightAnswers = {
    dob: '1990-05-21',
    q2: 'Dehradun',
    q3: 'St Joseph Academy',
    custom1: 'Bruno',
  };

  it("questions: fixed three + the user's custom ones; unknown e-mails get a same-shaped answer", async () => {
    const { payload } = await registerUser();
    const real = await ask(payload.email);
    assert.deepEqual(
      real.body.data.questions.map((q) => q.key),
      ['dob', 'q2', 'q3', 'custom1'],
    );
    assert.equal(
      real.body.data.questions[3].question,
      payload.securityProfile.customQuestions[0].question,
    );

    const noCustom = await registerUser({
      securityProfile: { dob: '1990-05-21', q2: 'Delhi', q3: 'DPS', customQuestions: [] },
    });
    const real2 = await ask(noCustom.payload.email);
    const unknown = await ask('ghost@example.com');
    assert.deepEqual(
      unknown.body.data,
      real2.body.data,
      'unknown account is indistinguishable from one without custom questions',
    );
    assert.deepEqual(
      unknown.body.data.questions.map((q) => q.key),
      ['dob', 'q2', 'q3'],
    );
  });

  it('full flow: verify -> single-use 10-minute token -> reset -> old sessions and password are dead', async () => {
    const { payload, cookie } = await freshSession();

    const verified = await verify(payload.email, {
      dob: '1990-05-21',
      q2: '  DEHRADUN ',
      q3: 'st joseph  academy',
      custom1: 'bruno',
    });
    assert.equal(verified.status, 200);
    const { resetToken, expiresInSeconds } = verified.body.data;
    assert.equal(expiresInSeconds, 600);
    assert.ok(resetToken.length >= 40);

    const stored = await queryOne('SELECT * FROM password_reset_tokens WHERE token_hash = ?', [
      sha256Hex(resetToken),
    ]);
    assert.ok(stored && stored.used_at === null);
    assert.equal(
      await queryScalar('SELECT COUNT(*) FROM password_reset_tokens WHERE token_hash = ?', [
        resetToken,
      ]),
      0,
      'only the hash is stored',
    );
    assert.ok(Math.abs(stored.expires_at.getTime() - (Date.now() + 600_000)) < 15_000);

    expectFailure(await reset(resetToken, 'weak'), 422, 'VALIDATION_ERROR');
    const done = await reset(resetToken, 'Br4nd-New-Passw0rd');
    assert.equal(done.status, 200);

    expectFailure(await reset(resetToken, 'An0ther-Passw0rd!'), 400, 'RESET_TOKEN_INVALID'); // single use
    expectFailure(await refresh(cookie), 401, 'TOKEN_INVALID'); // sessions revoked
    expectFailure(
      await login({ email: payload.email, password: payload.password }),
      401,
      'INVALID_CREDENTIALS',
    );
    assert.equal(
      (await login({ email: payload.email, password: 'Br4nd-New-Passw0rd' })).status,
      200,
    );
  });

  it('every answer must be right; a wrong or missing one is a generic 401', async () => {
    const { payload } = await registerUser();
    for (const answers of [
      { ...rightAnswers, dob: '1990-05-22' },
      { ...rightAnswers, q2: 'Delhi' },
      { ...rightAnswers, custom1: 'Rex' },
      { dob: '1990-05-21', q2: 'Dehradun', q3: 'St Joseph Academy' }, // custom answer missing
    ]) {
      expectFailure(await verify(payload.email, answers), 401, 'INVALID_SECURITY_ANSWERS');
    }
  });

  it('locks the account for 15 minutes after 5 wrong attempts - even correct answers are refused', async () => {
    const { payload, user } = await registerUser();
    const wrong = { ...rightAnswers, q2: 'Nowhere' };

    for (let attempt = 1; attempt <= 4; attempt += 1) {
      expectFailure(await verify(payload.email, wrong), 401, 'INVALID_SECURITY_ANSWERS');
    }
    assert.equal(
      await queryScalar('SELECT failed_attempts FROM user_security_profiles WHERE user_id = ?', [
        user.userId,
      ]),
      4,
    );

    const fifth = await verify(payload.email, wrong);
    expectFailure(fifth, 429, 'ACCOUNT_LOCKED');
    assert.ok(Number(fifth.headers['retry-after']) > 800);

    expectFailure(await verify(payload.email, rightAnswers), 429, 'ACCOUNT_LOCKED');
    const profile = await queryOne(
      'SELECT failed_attempts, locked_until FROM user_security_profiles WHERE user_id = ?',
      [user.userId],
    );
    assert.ok(Math.abs(profile.locked_until.getTime() - (Date.now() + 15 * 60_000)) < 15_000);

    // the lock expires on its own
    await db.execute('UPDATE user_security_profiles SET locked_until = ? WHERE user_id = ?', [
      new Date(Date.now() - 1000),
      user.userId,
    ]);
    assert.equal((await verify(payload.email, rightAnswers)).status, 200);
    assert.equal(
      await queryScalar('SELECT failed_attempts FROM user_security_profiles WHERE user_id = ?', [
        user.userId,
      ]),
      0,
    );
  });

  it('parallel guessing cannot slip past the lockout (the profile row is locked while checking)', async () => {
    const { payload } = await registerUser();
    const wrong = { ...rightAnswers, q2: 'Nowhere' };
    const results = await Promise.all(
      Array.from({ length: 12 }, () => verify(payload.email, wrong)),
    );
    const statuses = results.map((r) => r.status);
    assert.equal(statuses.filter((s) => s === 401).length, 4);
    assert.equal(statuses.filter((s) => s === 429).length, 8);
  });

  it('unknown e-mail, super admin and accounts without a profile get the same generic 401', async () => {
    expectFailure(await verify('ghost@example.com', rightAnswers), 401, 'INVALID_SECURITY_ANSWERS');
    expectFailure(
      await verify(CREDS.superAdmin.email, rightAnswers),
      401,
      'INVALID_SECURITY_ANSWERS',
    );
    await db.execute('DELETE FROM user_security_profiles WHERE user_id = 3'); // demo member
    expectFailure(await verify(CREDS.member.email, rightAnswers), 401, 'INVALID_SECURITY_ANSWERS');
  });

  it('a malformed date of birth is a 422 and does NOT count as a failed attempt', async () => {
    const { payload, user } = await registerUser();
    expectFailure(
      await verify(payload.email, { ...rightAnswers, dob: '21/05/1990' }),
      422,
      'VALIDATION_ERROR',
    );
    assert.equal(
      await queryScalar('SELECT failed_attempts FROM user_security_profiles WHERE user_id = ?', [
        user.userId,
      ]),
      0,
    );
  });

  it('a reset token expires, and a new verification invalidates the previous token', async () => {
    const { payload } = await registerUser();
    const first = (await verify(payload.email, rightAnswers)).body.data.resetToken;
    const second = (await verify(payload.email, rightAnswers)).body.data.resetToken;
    expectFailure(await reset(first, 'Br4nd-New-Passw0rd'), 400, 'RESET_TOKEN_INVALID'); // superseded

    await db.execute('UPDATE password_reset_tokens SET expires_at = ? WHERE token_hash = ?', [
      new Date(Date.now() - 1000),
      sha256Hex(second),
    ]);
    expectFailure(await reset(second, 'Br4nd-New-Passw0rd'), 400, 'RESET_TOKEN_INVALID');
    expectFailure(await reset('x'.repeat(40), 'Br4nd-New-Passw0rd'), 400, 'RESET_TOKEN_INVALID');
  });
});
