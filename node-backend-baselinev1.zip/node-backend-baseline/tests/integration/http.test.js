import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { after, before, describe, it } from 'node:test';
import { closePool } from '../../src/database/index.js';
import {
  API,
  bearer,
  bootstrapTestEnvironment,
  CREDS,
  expectFailure,
  http,
  loginOk,
  shutdownTestEnvironment,
} from '../helpers/app.js';

const run = promisify(execFile);

before(bootstrapTestEnvironment);
after(shutdownTestEnvironment);

describe('health', () => {
  it('liveness at /health and /health/live, readiness checks the database', async () => {
    for (const path of ['/health', '/health/live']) {
      const res = await http().get(path);
      assert.equal(res.status, 200);
      assert.equal(res.body.data.status, 'ok');
    }
    const ready = await http().get('/health/ready');
    assert.equal(ready.status, 200);
    assert.deepEqual(ready.body.data.checks, { database: 'up' });
  });
});

describe('standard response + error handling', () => {
  it('every response carries a requestId, echoed in the X-Request-Id header', async () => {
    const ok = await http().get('/health');
    assert.ok(ok.body.requestId);
    assert.equal(ok.headers['x-request-id'], ok.body.requestId);

    const fail = await http().get(`${API}/nope`);
    assert.equal(fail.headers['x-request-id'], fail.body.requestId);
  });

  it('adopts a sane client request id, replaces a hostile one', async () => {
    const good = await http().get('/health').set('X-Request-Id', 'trace-abc-12345');
    assert.equal(good.body.requestId, 'trace-abc-12345');
    const bad = await http().get('/health').set('X-Request-Id', 'bad id with spaces\t<script>');
    assert.notEqual(bad.body.requestId, 'bad id with spaces\t<script>');
    assert.match(bad.body.requestId, /^[0-9a-f-]{36}$/);
  });

  it('unknown routes -> 404 ROUTE_NOT_FOUND in the standard failure shape', async () => {
    const res = await http().get(`${API}/does/not/exist`);
    expectFailure(res, 404, 'ROUTE_NOT_FOUND');
    assert.deepEqual(Object.keys(res.body), ['success', 'message', 'error', 'requestId']);
  });

  it('malformed JSON -> 400, oversized body -> 413, wrong content type -> 422 (never a 500)', async () => {
    const malformed = await http()
      .post(`${API}/auth/login`)
      .set('Content-Type', 'application/json')
      .send('{"email": ');
    expectFailure(malformed, 400, 'BAD_REQUEST');

    const huge = await http()
      .post(`${API}/auth/login`)
      .send({ email: 'a@b.com', password: 'x'.repeat(200_000) });
    expectFailure(huge, 413, 'PAYLOAD_TOO_LARGE');

    const text = await http()
      .post(`${API}/auth/login`)
      .set('Content-Type', 'text/plain')
      .send('email=a');
    expectFailure(text, 422, 'VALIDATION_ERROR');
  });

  it('unexpected errors never leak internals: generic 500 body', async () => {
    // Break the DB behind the app's back for one request: dropping a table makes a query fail
    // with a raw MySQL error that no service expects.
    const { token } = await loginOk(CREDS.admin);
    const { db } = await import('../../src/database/index.js');
    await db.execute('RENAME TABLE roles TO roles_hidden');
    try {
      const res = await http().get(`${API}/roles`).set(bearer(token));
      expectFailure(res, 500, 'INTERNAL_ERROR');
      assert.equal(res.body.message, 'Something went wrong');
      assert.ok(
        !JSON.stringify(res.body).match(/roles|ER_|sql|select/i),
        'no SQL / table names in the response',
      );
    } finally {
      await db.execute('RENAME TABLE roles_hidden TO roles');
    }
  });
});

describe('security headers, caching and CORS', () => {
  it('sets hardening headers, hides the framework, forbids caching', async () => {
    const res = await http().get('/health');
    assert.equal(res.headers['x-content-type-options'], 'nosniff');
    assert.equal(res.headers['x-powered-by'], undefined);
    assert.match(res.headers['strict-transport-security'], /max-age/);
    assert.equal(res.headers['cache-control'], 'no-store');
  });

  it('an allow-listed origin gets CORS headers with credentials', async () => {
    const res = await http().get('/health').set('Origin', 'http://localhost:5173');
    assert.equal(res.status, 200);
    assert.equal(res.headers['access-control-allow-origin'], 'http://localhost:5173');
    assert.equal(res.headers['access-control-allow-credentials'], 'true');
    assert.match(res.headers['access-control-expose-headers'], /X-Request-Id/);
  });

  it('answers a pre-flight request for an allowed origin', async () => {
    const res = await http()
      .options(`${API}/auth/login`)
      .set('Origin', 'http://localhost:5173')
      .set('Access-Control-Request-Method', 'POST')
      .set('Access-Control-Request-Headers', 'content-type,authorization');
    assert.equal(res.status, 204);
    assert.match(res.headers['access-control-allow-methods'], /POST/);
  });

  it('a foreign origin is refused with the standard 403 body, and gets no CORS headers', async () => {
    const res = await http().get('/health').set('Origin', 'https://evil.example');
    expectFailure(res, 403, 'CORS_ORIGIN_NOT_ALLOWED');
    assert.equal(res.headers['access-control-allow-origin'], undefined);
  });
});

describe('rate limiting (enabled in a child process)', () => {
  it('blocks the 4th failed login for the same IP+e-mail with a 429 in the standard shape', async () => {
    const { stdout } = await run(
      process.execPath,
      ['--import', './tests/setup.js', 'tests/helpers/rateLimitProbe.js'],
      { env: { ...process.env, RATE_LIMIT_ENABLED: 'true', LOGIN_RATE_LIMIT_MAX: '3' } },
    );
    const result = JSON.parse(stdout.trim().split('\n').pop());

    assert.deepEqual(result.statuses, [401, 401, 401, 429, 429]);
    assert.equal(result.body.success, false);
    assert.equal(result.body.error.code, 'RATE_LIMITED');
    assert.ok(Number(result.retryAfter) > 0);
    assert.ok(result.rateLimitHeader, 'standard RateLimit header is sent');
    assert.equal(result.otherAccountStatus, 401, 'a different e-mail has its own bucket');
    assert.equal(
      result.healthStatus,
      200,
      'health probes are not rate limited by the login limiter',
    );
  });
});

describe('when the database is unavailable', () => {
  it('readiness answers 503 SERVICE_UNAVAILABLE with Retry-After (and never crashes)', async () => {
    await closePool(); // simulate the outage; must be the LAST test of this file
    const res = await http().get('/health/ready');
    expectFailure(res, 503, 'SERVICE_UNAVAILABLE');
    assert.equal(res.headers['retry-after'], '5');
    assert.deepEqual(res.body.error.details, [{ check: 'database', status: 'down' }]);

    const live = await http().get('/health/live');
    assert.equal(live.status, 200, 'liveness does not depend on the database');

    const login = await http()
      .post(`${API}/auth/login`)
      .send({ email: 'a@b.com', password: 'Passw0rd!x' });
    expectFailure(login, 503, 'SERVICE_UNAVAILABLE');
  });
});
