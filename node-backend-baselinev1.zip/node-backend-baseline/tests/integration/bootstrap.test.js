import assert from 'node:assert/strict';
import { after, before, beforeEach, describe, it } from 'node:test';
import { ensureSuperAdmin } from '../../src/bootstrap/superAdmin.js';
import { verifyDatabase } from '../../src/bootstrap/verifyDatabase.js';
import { db, pool, queryOne, queryScalar } from '../../src/database/index.js';
import { purgeExpiredTokens } from '../../src/modules/auth/token.service.js';
import { bootstrapTestEnvironment, CREDS, shutdownTestEnvironment } from '../helpers/app.js';

before(bootstrapTestEnvironment);
after(shutdownTestEnvironment);

const superAdminRow = () =>
  queryOne(
    'SELECT full_name, email, is_active, is_deleted, created_by FROM users WHERE user_id = 1',
  );

describe('ensureSuperAdmin (runs at every startup)', () => {
  beforeEach(bootstrapTestEnvironment);

  it('is a no-op when the row already matches ENV', async () => {
    assert.equal(await ensureSuperAdmin(), 'unchanged');
    const row = await superAdminRow();
    assert.equal(row.email, CREDS.superAdmin.email);
    assert.equal(row.full_name, 'Test Super Admin');
    assert.equal(row.created_by, null);
  });

  it('creates the reserved row when the seed was never loaded', async () => {
    // remove the row the way an empty database would look (FKs from roles are re-satisfied right after)
    const connection = await pool.getConnection();
    try {
      await connection.query('SET FOREIGN_KEY_CHECKS = 0');
      await connection.query('DELETE FROM users WHERE user_id = 1');
      await connection.query('SET FOREIGN_KEY_CHECKS = 1');
    } finally {
      connection.release();
    }
    assert.equal(await superAdminRow(), null);

    assert.equal(await ensureSuperAdmin(), 'created');
    assert.equal((await superAdminRow()).email, CREDS.superAdmin.email);
  });

  it('re-syncs name and e-mail from ENV and revives a deactivated/deleted row', async () => {
    await db.execute(
      "UPDATE users SET full_name = 'Old Name', email = 'old@example.com', is_active = FALSE, is_deleted = TRUE WHERE user_id = 1",
    );
    assert.equal(await ensureSuperAdmin(), 'updated');
    const row = await superAdminRow();
    assert.equal(row.full_name, 'Test Super Admin');
    assert.equal(row.email, CREDS.superAdmin.email);
    assert.equal(Boolean(row.is_active), true);
    assert.equal(Boolean(row.is_deleted), false);
  });

  it('refuses to start if the reserved id has a password / role / security-profile row', async () => {
    await db.execute("INSERT INTO user_passwords (user_id, hash_password) VALUES (1, '$2b$04$x')");
    await assert.rejects(() => ensureSuperAdmin(), /reserved for the super admin/);
    await db.execute('DELETE FROM user_passwords WHERE user_id = 1');

    await db.execute('INSERT INTO user_roles (user_id, role_id) VALUES (1, 1)');
    await assert.rejects(() => ensureSuperAdmin(), /reserved for the super admin/);
    await db.execute('DELETE FROM user_roles WHERE user_id = 1');

    assert.equal(await ensureSuperAdmin(), 'unchanged'); // healthy again
  });

  it('fails with a clear message when another ACTIVE account already uses SUPER_ADMIN_EMAIL', async () => {
    await db.execute("UPDATE users SET email = 'moved.away@example.com' WHERE user_id = 1");
    await db.execute('INSERT INTO users (full_name, email, created_by) VALUES (?, ?, 1)', [
      'Squatter',
      CREDS.superAdmin.email,
    ]);
    await assert.rejects(() => ensureSuperAdmin(), /already used by another active account/);
  });

  it('a DELETED account with the same e-mail does not block it (soft delete frees the e-mail)', async () => {
    await db.execute("UPDATE users SET email = 'moved.away@example.com' WHERE user_id = 1");
    await db.execute(
      'INSERT INTO users (full_name, email, is_deleted, created_by) VALUES (?, ?, TRUE, 1)',
      ['Former', CREDS.superAdmin.email],
    );
    assert.equal(await ensureSuperAdmin(), 'updated');
  });
});

describe('verifyDatabase (startup check)', () => {
  beforeEach(bootstrapTestEnvironment);

  it('passes on a correctly installed database', async () => {
    await assert.doesNotReject(() => verifyDatabase());
  });

  it('names the missing roles and the command that fixes it', async () => {
    await db.execute("UPDATE roles SET is_deleted = TRUE WHERE role_name = 'admin'");
    await assert.rejects(
      () => verifyDatabase(),
      /Required roles are missing \(admin\).*npm run db:seed/,
    );
  });

  it('tells you to run the schema when the tables are missing', async () => {
    await db.execute('RENAME TABLE roles TO roles_hidden');
    try {
      await assert.rejects(() => verifyDatabase(), /schema is missing.*npm run db:schema/);
    } finally {
      await db.execute('RENAME TABLE roles_hidden TO roles');
    }
  });
});

describe('purgeExpiredTokens (cleanup job)', () => {
  beforeEach(bootstrapTestEnvironment);

  it('deletes tokens that expired more than a day ago; keeps valid, rotated-but-valid and recently expired ones', async () => {
    const day = 24 * 60 * 60 * 1000;
    const at = (offsetMs) => new Date(Date.now() + offsetMs);

    const refresh = async (hash, expiresAt, revokedAt = null) =>
      db.execute(
        'INSERT INTO refresh_tokens (user_id, token_hash, expires_at, revoked_at) VALUES (3, ?, ?, ?)',
        [hash.padEnd(64, '0'), expiresAt, revokedAt],
      );
    await refresh('a-long-expired', at(-3 * day));
    await refresh('b-long-expired-revoked', at(-2 * day), at(-3 * day));
    await refresh('c-recently-expired', at(-60 * 60 * 1000));
    await refresh('d-valid', at(5 * day));
    await refresh('e-valid-but-rotated', at(5 * day), at(-1000)); // must stay: reuse detection needs it

    const reset = async (hash, expiresAt) =>
      db.execute(
        'INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES (3, ?, ?)',
        [hash.padEnd(64, '0'), expiresAt],
      );
    await reset('f-long-expired', at(-3 * day));
    await reset('g-valid', at(10 * 60 * 1000));

    const removed = await purgeExpiredTokens();
    assert.deepEqual(removed, { refreshTokens: 2, passwordResetTokens: 1 });
    assert.equal(await queryScalar('SELECT COUNT(*) FROM refresh_tokens'), 3);
    assert.equal(await queryScalar('SELECT COUNT(*) FROM password_reset_tokens'), 1);
  });
});
