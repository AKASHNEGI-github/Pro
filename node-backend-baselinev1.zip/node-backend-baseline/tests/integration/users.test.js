import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { queryOne, queryScalar } from '../../src/database/index.js';
import {
  API,
  bearer,
  bootstrapTestEnvironment,
  CREDS,
  expectFailure,
  freshSession,
  http,
  login,
  loginOk,
  newRegistration,
  shutdownTestEnvironment,
} from '../helpers/app.js';

before(bootstrapTestEnvironment);
after(shutdownTestEnvironment);

describe('GET /users/me', () => {
  it("returns the caller's own profile (and nothing sensitive)", async () => {
    const { token, payload } = await freshSession();
    const res = await http().get(`${API}/users/me`).set(bearer(token));
    assert.equal(res.status, 200);
    assert.equal(res.body.message, 'Profile fetched successfully');
    assert.deepEqual(Object.keys(res.body.data).sort(), [
      'createdAt',
      'email',
      'fullName',
      'hasSecurityProfile',
      'isActive',
      'lastLogin',
      'mustChangePassword',
      'role',
      'userId',
    ]);
    assert.equal(res.body.data.email, payload.email);
    assert.equal(res.body.data.role, 'member');
  });

  it('works for every role', async () => {
    for (const [creds, role] of [
      [CREDS.member, 'member'],
      [CREDS.admin, 'admin'],
      [CREDS.superAdmin, 'super_admin'],
    ]) {
      const { token } = await loginOk(creds);
      const res = await http().get(`${API}/users/me`).set(bearer(token));
      assert.equal(res.body.data.role, role);
    }
  });
});

describe('PATCH /users/me', () => {
  const patch = (token, body) => http().patch(`${API}/users/me`).set(bearer(token)).send(body);

  it('updates the full name (trimmed, whitespace collapsed)', async () => {
    const { token, user } = await freshSession();
    const res = await patch(token, { fullName: '  Aditi    Singh  ' });
    assert.equal(res.status, 200);
    assert.equal(res.body.data.fullName, 'Aditi Singh');
    assert.equal(
      (await queryOne('SELECT full_name FROM users WHERE user_id = ?', [user.userId])).full_name,
      'Aditi Singh',
    );
  });

  it('the e-mail is immutable - and so is everything else except the name', async () => {
    const { token, user, payload } = await freshSession();
    for (const field of ['email', 'role', 'isActive', 'userId', 'mustChangePassword']) {
      const res = await patch(token, { fullName: 'Valid Name', [field]: 'x' });
      expectFailure(res, 422, 'VALIDATION_ERROR');
      assert.equal(res.body.error.details[0].field, field);
    }
    const row = await queryOne('SELECT email FROM users WHERE user_id = ?', [user.userId]);
    assert.equal(row.email, payload.email);
  });

  it('validates the name', async () => {
    const { token } = await freshSession();
    expectFailure(await patch(token, { fullName: 'A' }), 422, 'VALIDATION_ERROR');
    expectFailure(await patch(token, {}), 422, 'VALIDATION_ERROR');
  });

  it('works for an admin on their own account too', async () => {
    const { token } = await loginOk(CREDS.admin);
    assert.equal((await patch(token, { fullName: 'Demo Admin' })).status, 200);
  });
});

describe('DELETE /users/me (soft delete, needs the password)', () => {
  const remove = (token, body) => http().delete(`${API}/users/me`).set(bearer(token)).send(body);

  it('requires the correct password', async () => {
    const { token } = await freshSession();
    expectFailure(
      await remove(token, { password: 'Wrong@12345' }),
      400,
      'INVALID_CURRENT_PASSWORD',
    );
    expectFailure(await remove(token, {}), 422, 'VALIDATION_ERROR');
    assert.equal((await http().get(`${API}/users/me`).set(bearer(token))).status, 200); // still there
  });

  it('soft-deletes, revokes every session, ends the access token, frees the e-mail', async () => {
    const { token, cookie, user, payload } = await freshSession();
    const other = await loginOk({ email: payload.email, password: payload.password });

    const res = await remove(token, { password: payload.password });
    assert.equal(res.status, 200);
    assert.match(res.headers['set-cookie'][0], /refresh_token=;/);

    // history is kept: the row stays, flagged
    const row = await queryOne(
      'SELECT is_deleted, email, email_active FROM users WHERE user_id = ?',
      [user.userId],
    );
    assert.equal(Boolean(row.is_deleted), true);
    assert.equal(row.email, payload.email);
    assert.equal(row.email_active, null);
    assert.equal(
      await queryScalar('SELECT COUNT(*) FROM user_passwords WHERE user_id = ?', [user.userId]),
      1,
    );
    assert.equal(
      await queryScalar(
        'SELECT COUNT(*) FROM refresh_tokens WHERE user_id = ? AND revoked_at IS NULL',
        [user.userId],
      ),
      0,
    );

    expectFailure(await http().get(`${API}/users/me`).set(bearer(token)), 401, 'TOKEN_INVALID');
    expectFailure(
      await http().post(`${API}/auth/refresh`).set('Cookie', cookie),
      401,
      'TOKEN_INVALID',
    );
    expectFailure(
      await http().post(`${API}/auth/refresh`).set('Cookie', other.cookie),
      401,
      'TOKEN_INVALID',
    );
    expectFailure(
      await login({ email: payload.email, password: payload.password }),
      401,
      'INVALID_CREDENTIALS',
    );

    // the e-mail is immediately free: a NEW account can register with it
    const again = await http()
      .post(`${API}/auth/register`)
      .send(newRegistration({ email: payload.email, password: 'Different1!pw' }));
    assert.equal(again.status, 201);
    assert.notEqual(again.body.data.userId, user.userId);
    assert.equal(
      await queryScalar('SELECT COUNT(*) FROM users WHERE email = ?', [payload.email]),
      2,
    );
    assert.equal((await login({ email: payload.email, password: 'Different1!pw' })).status, 200);
    expectFailure(
      await login({ email: payload.email, password: payload.password }),
      401,
      'INVALID_CREDENTIALS',
    );
  });

  it('an admin may delete their own account too', async () => {
    // create a throw-away admin through the super admin
    const { token: superToken } = await loginOk(CREDS.superAdmin);
    const created = await http()
      .post(`${API}/admin/users`)
      .set(bearer(superToken))
      .send({ fullName: 'Throwaway Admin', email: 'throwaway.admin@example.com', role: 'admin' });
    assert.equal(created.status, 201);
    const { temporaryPassword } = created.body.data;
    const session = await loginOk({
      email: 'throwaway.admin@example.com',
      password: temporaryPassword,
    });
    const changed = await http()
      .post(`${API}/auth/change-password`)
      .set(bearer(session.token))
      .send({ currentPassword: temporaryPassword, newPassword: 'Th4w-Away-Passw0rd' });
    assert.equal(changed.status, 200);
    const res = await remove(changed.body.data.accessToken, { password: 'Th4w-Away-Passw0rd' });
    assert.equal(res.status, 200);
  });
});
