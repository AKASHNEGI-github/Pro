-- =====================================================================
-- Required seed data (safe for every environment, idempotent)
--
--   1. user_id = 1  -> the reserved SUPER ADMIN row.
--      The name/email below are placeholders: on every start the
--      application overwrites them from SUPER_ADMIN_NAME / SUPER_ADMIN_EMAIL.
--      This row has NO password row, NO role row and NO security profile -
--      the password lives only in ENV (SUPER_ADMIN_PASSWORD_HASH).
--   2. roles        -> member (level 1), admin (level 2).
--      There is deliberately no "super_admin" role.
--
-- Demo accounts live in seed.demo.sql (development only).
-- =====================================================================
USE node_backend_baseline;

INSERT INTO users (user_id, full_name, email, is_active, created_by)
VALUES (1, 'Super Admin', 'super.admin@example.com', TRUE, NULL)
ON DUPLICATE KEY UPDATE user_id = user_id;

INSERT INTO roles (role_id, role_name, role_level, description, created_by) VALUES
  (1, 'member', 1, 'Default role for every self-registered user. Can manage only their own account.', 1),
  (2, 'admin',  2, 'Manages users (create, update, activate/deactivate, delete members, promote members to admin).', 1)
ON DUPLICATE KEY UPDATE description = VALUES(description), role_level = VALUES(role_level);
