/**
 * End-to-end API test (plain Node, no framework). Needs the API running + a seeded database:
 *   npm run db:setup && npm run dev      (in another terminal)
 *   npm run test:smoke
 * Env: API_URL (default http://localhost:5000/api/v1), ADMIN_EMAIL, ADMIN_PASSWORD.
 */
const BASE = process.env.API_URL || 'http://localhost:5000/api/v1';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@example.com';
const SEED_PW = process.env.ADMIN_PASSWORD || 'Admin@12345';
const NEW_PW = 'Passw0rd-Strong1';
const run = Date.now().toString(36);

let passed = 0;
const failures = [];
const check = (label, cond, extra) => {
    if (cond) { passed += 1; return; }
    failures.push(`${label}${extra ? `  -> ${typeof extra === 'string' ? extra : JSON.stringify(extra)}` : ''}`);
    console.log(`  ✖ ${label}`);
};
const section = (t) => console.log(`\n▸ ${t}`);

class Client {
    constructor(name) { this.name = name; this.token = null; this.refreshCookie = null; }
    async call(method, path, { body, form, auth = true, cookie = true } = {}) {
        const headers = {};
        if (auth && this.token) headers.Authorization = `Bearer ${this.token}`;
        if (cookie && this.refreshCookie) headers.Cookie = `refresh_token=${this.refreshCookie}`;
        let payload;
        if (form) payload = form;
        else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
        const res = await fetch(`${BASE}${path}`, { method, headers, body: payload });
        const sc = res.headers.getSetCookie?.() ?? [];
        const rt = sc.find((c) => c.startsWith('refresh_token='));
        if (rt) { const v = rt.split(';')[0].split('=')[1]; this.refreshCookie = v || null; this.lastSetCookie = rt; }
        let json = null;
        try { json = await res.json(); } catch { /* non-json */ }
        return { status: res.status, body: json, data: json?.data, code: json?.error?.code, headers: res.headers };
    }
    get = (p, o) => this.call('GET', p, o);
    post = (p, body, o) => this.call('POST', p, { body, ...o });
    patch = (p, body, o) => this.call('PATCH', p, { body, ...o });
    del = (p, o) => this.call('DELETE', p, o);
    async login(email, password) {
        const r = await this.post('/auth/login', { email, password }, { auth: false });
        if (r.status === 200) this.token = r.data.accessToken;
        return r;
    }
    /** login with a temporary password, then choose a real one (as the UI forces) */
    async onboard(email, temp) {
        const r = await this.login(email, temp);
        if (r.status !== 200) throw new Error(`login failed for ${email}: ${JSON.stringify(r.body)}`);
        if (r.data.user.mustChangePassword) {
            const c = await this.post('/auth/change-password', { currentPassword: temp, newPassword: NEW_PW });
            this.token = c.data.accessToken;
        }
        return this;
    }
}

const png = () => new Blob([Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64')], { type: 'image/png' });
const day = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);

async function main() {
    const email = (n) => `${n}.${run}@test.dev`;
    const TEMP = 'Temp-pass-123';

    // ------------------------------------------------------------------ basics
    section('Basics, envelope, auth required');
    const anon = new Client('anon');
    let r = await anon.get('/workspaces');
    check('unauthenticated -> 401 AUTH_REQUIRED', r.status === 401 && r.code === 'AUTH_REQUIRED', r.body);
    check('error envelope has success=false + requestId', r.body.success === false && typeof r.body.requestId === 'string');
    r = await anon.post('/auth/login', { email: 'bad', password: '' }, { auth: false });
    check('login validation -> 422 with details', r.status === 422 && Array.isArray(r.body.error.details) && r.body.error.details.length >= 1, r.body);
    r = await anon.post('/auth/login', { email: ADMIN_EMAIL, password: 'wrong-password-1' }, { auth: false });
    check('wrong password -> 401 INVALID_CREDENTIALS', r.status === 401 && r.code === 'INVALID_CREDENTIALS', r.body);
    r = await anon.post('/auth/login', { email: 'nobody@nowhere.dev', password: 'whatever123' }, { auth: false });
    check('unknown email gives the SAME generic error', r.status === 401 && r.code === 'INVALID_CREDENTIALS');

    // ------------------------------------------------------------------ admin login + forced password change
    section('Org Admin sign-in, forced password change, refresh rotation');
    const admin = new Client('admin');
    r = await admin.login(ADMIN_EMAIL, SEED_PW);
    let currentAdminPw = SEED_PW;
    if (r.status !== 200) { r = await admin.login(ADMIN_EMAIL, `${NEW_PW}-admin`); currentAdminPw = `${NEW_PW}-admin`; }
    check('admin can log in', r.status === 200, r.body);
    check('login sets httpOnly refresh cookie', /HttpOnly/i.test(admin.lastSetCookie ?? '') && /Path=\/api\/v1\/auth/i.test(admin.lastSetCookie ?? ''), admin.lastSetCookie);
    check('login body has accessToken but NOT refreshToken', Boolean(r.data?.accessToken) && !('refreshToken' in r.data));
    check('me exposes global permissions', r.data.user.permissions.includes('workspace.create') && r.data.user.permissions.includes('user.manage'));

    if (r.data.user.mustChangePassword) {
        const blocked = await admin.get('/workspaces');
        check('temporary password blocks the API (403 PASSWORD_CHANGE_REQUIRED)', blocked.status === 403 && blocked.code === 'PASSWORD_CHANGE_REQUIRED', blocked.body);
        check('...but /auth/me still works', (await admin.get('/auth/me')).status === 200);
        const weak = await admin.post('/auth/change-password', { currentPassword: currentAdminPw, newPassword: 'short' });
        check('weak new password -> 422', weak.status === 422);
        const same = await admin.post('/auth/change-password', { currentPassword: currentAdminPw, newPassword: currentAdminPw });
        check('reusing the same password -> 422', same.status === 422);
        const oldToken = admin.token;
        const ch = await admin.post('/auth/change-password', { currentPassword: currentAdminPw, newPassword: `${NEW_PW}-admin` });
        check('change-password succeeds and returns a new session', ch.status === 200 && ch.data.user.mustChangePassword === false, ch.body);
        const stale = await new Client('x').call('GET', '/workspaces', { auth: false });
        admin.token = ch.data.accessToken;
        const reuse = await (async () => { const c = new Client('old'); c.token = oldToken; return c.get('/workspaces'); })();
        check('old access token is invalidated after password change', reuse.status === 401 && reuse.code === 'SESSION_INVALID', reuse.body);
        check('(sanity) anon still 401', stale.status === 401);
    }

    r = await admin.get('/nope');
    check('unknown route -> 404 ROUTE_NOT_FOUND', r.status === 404 && r.code === 'ROUTE_NOT_FOUND', r.body);
    const before = admin.refreshCookie;
    r = await admin.post('/auth/refresh', undefined, { auth: false });
    check('refresh returns new access token', r.status === 200 && Boolean(r.data.accessToken), r.body);
    check('refresh token is rotated', admin.refreshCookie && admin.refreshCookie !== before);
    admin.token = r.data.accessToken;
    const noCookie = await new Client('nc').post('/auth/refresh', undefined, { auth: false });
    check('refresh without cookie -> 401', noCookie.status === 401 && noCookie.code === 'REFRESH_TOKEN_MISSING');

    // ------------------------------------------------------------------ create users + workspace
    section('Org Admin creates users and a workspace');
    const mk = async (name) => (await admin.post('/admin/users', { name, email: email(name.toLowerCase()), password: TEMP })).data;
    const users = {};
    for (const n of ['Alice', 'Bob', 'Cara', 'Dan', 'Frank']) users[n] = await mk(n);
    check('admin created 5 users', Object.values(users).every((u) => u?.id));
    r = await admin.post('/admin/users', { name: 'Dup', email: email('alice'), password: TEMP });
    check('duplicate email -> 409', r.status === 409, r.body);
    r = await admin.get('/admin/users?limit=2&page=1');
    check('admin users list is paginated', r.status === 200 && r.body.meta?.limit === 2 && r.body.meta.total >= 5, r.body.meta);

    const form = new FormData();
    form.append('name', `Acme ${run}`); form.append('slug', `acme-${run}`); form.append('ownerEmail', email('alice')); form.append('logo', png(), 'logo.png');
    r = await admin.call('POST', '/workspaces', { form });
    check('create workspace (multipart + logo) -> 201', r.status === 201, r.body);
    const acme = r.data;
    check('workspace owner is Alice', acme.ownerId === users.Alice.id);
    check('logo stored under /uploads', /\/uploads\/logos\/.+\.png$/.test(acme.image_url), acme.image_url);
    const img = await fetch(acme.image_url);
    check('uploaded logo is publicly served as an image', img.status === 200 && img.headers.get('content-type') === 'image/png');
    const f2 = new FormData(); f2.append('name', 'Dup slug'); f2.append('slug', `acme-${run}`);
    r = await admin.call('POST', '/workspaces', { form: f2 });
    check('duplicate slug -> 409 SLUG_TAKEN', r.status === 409 && r.code === 'SLUG_TAKEN', r.body);
    const f3 = new FormData(); f3.append('name', 'Bad file'); f3.append('logo', new Blob(['<script>alert(1)</script>'], { type: 'text/html' }), 'x.html');
    r = await admin.call('POST', '/workspaces', { form: f3 });
    check('non-image upload rejected -> 400', r.status === 400 && r.code === 'INVALID_FILE_TYPE', r.body);

    const f4 = new FormData(); f4.append('name', `Beta ${run}`); f4.append('slug', `beta-${run}`); f4.append('ownerEmail', email('frank'));
    const beta = (await admin.call('POST', '/workspaces', { form: f4 })).data;
    check('second workspace created (owner Frank)', beta?.id && beta.ownerId === users.Frank.id);

    // ------------------------------------------------------------------ members / onboarding
    section('Workspace onboarding (no email service) + who may create what');
    const alice = await new Client('alice').onboard(email('alice'), TEMP);
    const bob = await new Client('bob').onboard(email('bob'), TEMP);
    const cara = await new Client('cara').onboard(email('cara'), TEMP);
    const dan = await new Client('dan').onboard(email('dan'), TEMP);
    const frank = await new Client('frank').onboard(email('frank'), TEMP);

    const roles = (await alice.get(`/workspaces/${acme.id}/roles`)).data;
    const wsMemberRole = roles.find((x) => x.systemKey === 'WORKSPACE_MEMBER');
    const wsAdminRole = roles.find((x) => x.systemKey === 'WORKSPACE_ADMIN');
    const pmRole = roles.find((x) => x.systemKey === 'PROJECT_MANAGER');
    const pmemberRole = roles.find((x) => x.systemKey === 'PROJECT_MEMBER');
    check('roles endpoint lists built-in roles', wsMemberRole && wsAdminRole && pmRole && pmemberRole);

    r = await alice.get(`/workspaces/${acme.id}/members/lookup?email=${encodeURIComponent(email('bob'))}`);
    check('lookup: existing account found, not yet a member', r.data.exists === true && r.data.alreadyMember === false, r.body);
    for (const n of ['Bob', 'Cara', 'Dan']) {
        r = await alice.post(`/workspaces/${acme.id}/members`, { email: email(n.toLowerCase()) });
        check(`Alice onboards existing user ${n}`, r.status === 201 && r.data.role.name === 'Workspace Member', r.body);
    }
    r = await alice.post(`/workspaces/${acme.id}/members`, { email: email('bob') });
    check('adding an existing member -> 409 ALREADY_MEMBER', r.status === 409 && r.code === 'ALREADY_MEMBER');
    r = await alice.post(`/workspaces/${acme.id}/members`, { email: email('eve') });
    check('new account without name/password -> 422', r.status === 422, r.body);
    r = await alice.post(`/workspaces/${acme.id}/members`, { email: email('eve'), name: 'Eve', password: TEMP });
    check('new account created + onboarded in one step', r.status === 201 && r.data.user.email === email('eve'), r.body);
    const eveId = r.data.userId;
    r = await bob.post(`/workspaces/${acme.id}/members`, { email: email('frank') });
    check('plain member cannot onboard users -> 403', r.status === 403, r.body);
    r = await frank.get(`/workspaces/${acme.id}`);
    check('ISOLATION: non-member gets 404 for another workspace', r.status === 404, r.body);
    r = await frank.get('/workspaces');
    check('ISOLATION: Frank only lists his own workspace', r.data.length === 1 && r.data[0].id === beta.id, r.data);

    const fd = new FormData(); fd.append('name', 'Nope');
    check('member cannot create a workspace -> 403', (await bob.call('POST', '/workspaces', { form: fd })).status === 403);
    check('Workspace Admin (owner) cannot create a workspace either -> 403', (await alice.call('POST', '/workspaces', { form: (() => { const x = new FormData(); x.append('name', 'Nope'); return x; })() })).status === 403);
    r = await bob.post(`/workspaces/${acme.id}/projects`, { name: 'Bob project', team_lead: users.Bob.id });
    check('member cannot create a project -> 403', r.status === 403, r.body);

    // ------------------------------------------------------------------ projects
    section('Projects: per-project membership');
    const mkProject = (c, name, lead, members) => c.post(`/workspaces/${acme.id}/projects`, { name, description: 'd', team_lead: lead, member_ids: members, start_date: day(-1), end_date: day(30), status: 'ACTIVE', priority: 'HIGH' });
    r = await mkProject(alice, 'Project A', users.Bob.id, [users.Cara.id]);
    check('admin creates Project A (lead Bob, member Cara)', r.status === 201, r.body);
    const A = r.data;
    check('lead has Project Manager role, others Project Member', A.members.find((m) => m.userId === users.Bob.id).role.name === 'Project Manager' && A.members.find((m) => m.userId === users.Cara.id).role.name === 'Project Member');
    r = await mkProject(alice, 'Project B', users.Alice.id, [users.Dan.id]);
    const B = r.data;
    check('Project B created (lead Alice, member Dan)', r.status === 201 && B?.id, r.body);
    r = await mkProject(alice, 'Bad', users.Frank.id, []);
    check('lead from another workspace rejected -> 400 NOT_WORKSPACE_MEMBER', r.status === 400 && r.code === 'NOT_WORKSPACE_MEMBER', r.body);
    r = await alice.post(`/workspaces/${acme.id}/projects`, { name: 'Dates', team_lead: users.Alice.id, start_date: day(5), end_date: day(1) });
    check('end before start -> 422', r.status === 422, r.body);

    r = await cara.get(`/projects/${B.id}`);
    check('Cara (member of A only) cannot see Project B -> 404', r.status === 404, r.body);
    r = await cara.get(`/projects/${B.id}/tasks`);
    check('...nor its tasks -> 404', r.status === 404);
    r = await cara.get(`/workspaces/${acme.id}/overview`);
    check('Cara overview contains only Project A', r.status === 200 && r.data.projects.length === 1 && r.data.projects[0].id === A.id, r.data?.projects?.map((p) => p.name));
    const caraPerms = r.data.projects[0].permissions;
    check('Cara project permissions are limited', caraPerms.includes('task.create') && !caraPerms.includes('task.delete') && !caraPerms.includes('project.update'), caraPerms);
    r = await cara.get(`/workspaces/${acme.id}/activity?limit=50`);
    check('Cara activity feed excludes Project B', r.status === 200 && r.data.length > 0 && !r.data.some((a) => a.projectId === B.id), r.data?.map((a) => a.projectName));
    r = await alice.get(`/workspaces/${acme.id}/overview`);
    check('Workspace Admin sees both projects', r.data.projects.length === 2 && r.data.members.length === 5, [r.data.projects.length, r.data.members.length]);
    r = await admin.get(`/workspaces/${acme.id}/overview`);
    check('Org Admin (not a member) sees everything too', r.status === 200 && r.data.projects.length === 2);
    r = await dan.get(`/workspaces/${acme.id}/overview`);
    check('Dan sees only Project B', r.data.projects.length === 1 && r.data.projects[0].id === B.id);

    r = await bob.post(`/projects/${A.id}/members`, { email: email('frank') });
    check('PM cannot add a user from another workspace -> 404 NOT_IN_WORKSPACE', r.status === 404 && r.code === 'NOT_IN_WORKSPACE', r.body);
    r = await bob.post(`/projects/${A.id}/members`, { email: email('dan') });
    check('PM adds a workspace member (Dan) to Project A', r.status === 201 && r.data.role.name === 'Project Member', r.body);
    r = await bob.post(`/projects/${A.id}/members`, { email: email('dan') });
    check('adding twice -> 409', r.status === 409);
    r = await cara.post(`/projects/${A.id}/members`, { email: email('eve') });
    check('plain project member cannot add members -> 403', r.status === 403, r.body);
    r = await bob.del(`/projects/${A.id}`);
    check('Project Manager cannot delete the project -> 403', r.status === 403, r.body);
    r = await bob.patch(`/projects/${A.id}`, { team_lead: users.Cara.id });
    check('Project Manager cannot change the team lead -> 403', r.status === 403);
    r = await bob.patch(`/projects/${A.id}`, { progress: 55, description: undefined });
    check('Project Manager edits the project (progress 55)', r.status === 200 && r.data.progress === 55 && r.data.description === 'd', r.body);
    r = await cara.patch(`/projects/${A.id}`, { progress: 99 });
    check('Project Member cannot edit the project -> 403', r.status === 403);

    // ------------------------------------------------------------------ tasks
    section('Tasks: assignment, ownership, closed projects, bulk delete');
    const mkTask = (c, pid, body) => c.post(`/projects/${pid}/tasks`, { title: 'T', due_date: day(7), ...body });
    r = await mkTask(cara, A.id, { title: 'Cara own', assigneeId: users.Cara.id });
    check('member creates a task assigned to herself', r.status === 201 && r.data.assignee?.id === users.Cara.id, r.body);
    const tCara = r.data;
    r = await mkTask(cara, A.id, { assigneeId: users.Bob.id });
    check('member cannot assign to someone else -> 403', r.status === 403, r.body);
    r = await mkTask(bob, A.id, { title: 'Bob->Cara', assigneeId: users.Cara.id });
    check('PM assigns a task to Cara', r.status === 201);
    const tBobToCara = r.data;
    r = await mkTask(bob, A.id, { assigneeId: eveId });
    check('assignee must be in the project -> 400', r.status === 400 && r.code === 'ASSIGNEE_NOT_IN_PROJECT', r.body);
    r = await mkTask(bob, A.id, { title: 'Unassigned' });
    const tFree = r.data;
    r = await cara.patch(`/tasks/${tFree.id}`, { title: 'hijack' });
    check('member cannot edit a task that is not hers -> 403', r.status === 403, r.body);
    r = await cara.patch(`/tasks/${tCara.id}`, { status: 'IN_PROGRESS' });
    check('member updates status of her own task', r.status === 200 && r.data.status === 'IN_PROGRESS');
    r = await cara.patch(`/tasks/${tBobToCara.id}`, { status: 'DONE' });
    check('assignee can update a task assigned to her; completedAt is set', r.status === 200 && Boolean(r.data.completedAt), r.body);
    r = await cara.patch(`/tasks/${tCara.id}`, { assigneeId: users.Bob.id });
    check('member cannot re-assign to someone else -> 403', r.status === 403);
    r = await mkTask(cara, A.id, { due_date: undefined, title: 'x' });
    check('missing due_date -> 422', r.status === 422, r.body);
    r = await cara.del(`/tasks/${tCara.id}`);
    check('member cannot delete tasks -> 403', r.status === 403);
    r = await dan.get(`/tasks/${tCara.id}`);
    check('Dan (A member now) can view the task', r.status === 200);
    r = await mkTask(alice, B.id, { title: 'B task' });
    const tB = r.data;
    r = await bob.post(`/projects/${A.id}/tasks/bulk-delete`, { taskIds: [tFree.id, tB.id] });
    check('bulk delete with a task from ANOTHER project -> 404, nothing deleted', r.status === 404 && r.code === 'TASKS_NOT_FOUND', r.body);
    check('...the valid task still exists', (await bob.get(`/tasks/${tFree.id}`)).status === 200);
    r = await bob.post(`/projects/${A.id}/tasks/bulk-delete`, { taskIds: [tFree.id] });
    check('bulk delete within the project works', r.status === 200 && r.data.deleted === 1, r.body);
    r = await bob.get(`/projects/${A.id}/tasks?status=DONE`);
    check('task list filter + pagination meta', r.status === 200 && r.data.length === 1 && r.body.meta.total === 1, r.body);
    r = await bob.get(`/projects/${A.id}/tasks?search=${encodeURIComponent("%' OR 1=1 --")}`);
    check('SQL-injection style search returns nothing, no error', r.status === 200 && r.data.length === 0, r.body);

    // comments
    section('Comments');
    r = await cara.post(`/tasks/${tCara.id}/comments`, { content: 'Working on it' });
    check('member comments', r.status === 201 && r.data.user.id === users.Cara.id);
    const cmC = r.data;
    r = await bob.post(`/tasks/${tCara.id}/comments`, { content: 'Thanks' });
    const cmB = r.data;
    r = await cara.del(`/comments/${cmB.id}`);
    check("cannot delete someone else's comment -> 403", r.status === 403);
    r = await cara.patch(`/comments/${cmB.id}`, { content: 'edit' });
    check("cannot edit someone else's comment -> 403", r.status === 403);
    r = await cara.patch(`/comments/${cmC.id}`, { content: 'Edited' });
    check('author edits own comment', r.status === 200 && r.data.edited === true);
    r = await bob.del(`/comments/${cmC.id}`);
    check('Project Manager deletes any comment', r.status === 200);
    r = await frank.get(`/tasks/${tCara.id}/comments`);
    check('outsider cannot read comments -> 404', r.status === 404);

    // closed project
    section('Closed projects are read-only');
    r = await alice.patch(`/projects/${A.id}`, { status: 'COMPLETED' });
    check('admin marks Project A COMPLETED', r.status === 200);
    r = await mkTask(cara, A.id, { title: 'late' });
    check('member cannot create tasks in a completed project -> 403 PROJECT_READ_ONLY', r.status === 403 && r.code === 'PROJECT_READ_ONLY', r.body);
    r = await cara.post(`/tasks/${tCara.id}/comments`, { content: 'late' });
    check('...nor comment', r.status === 403 && r.code === 'PROJECT_READ_ONLY');
    r = await mkTask(bob, A.id, { title: 'manager ok' });
    check('Project Manager can still work in it', r.status === 201);
    await alice.patch(`/projects/${A.id}`, { status: 'ACTIVE' });

    // ------------------------------------------------------------------ member removal rules
    section('Removal rules');
    r = await bob.del(`/projects/${A.id}/members/${users.Bob.id}`);
    check('team lead cannot be removed from the project -> 409', r.status === 409 && r.code === 'IS_TEAM_LEAD', r.body);
    r = await alice.del(`/workspaces/${acme.id}/members/${users.Bob.id}`);
    check('workspace member who leads a project cannot be removed -> 409', r.status === 409 && r.code === 'IS_TEAM_LEAD', r.body);
    r = await alice.del(`/workspaces/${acme.id}/members/${users.Alice.id}`);
    check('workspace owner cannot be removed -> 409 OWNER_PROTECTED', r.status === 409 && r.code === 'OWNER_PROTECTED', r.body);
    r = await alice.patch(`/workspaces/${acme.id}/members/${users.Alice.id}`, { roleId: wsMemberRole.id });
    check('nobody can change their own role -> 403', r.status === 403 && r.code === 'SELF_ROLE_CHANGE');
    r = await bob.del(`/projects/${A.id}/members/${users.Cara.id}`);
    check('PM removes Cara from Project A (1 task un-assigned)', r.status === 200 && r.data.unassignedTasks >= 1, r.body);
    r = await bob.get(`/tasks/${tCara.id}`);
    check('her task survives, now unassigned', r.status === 200 && r.data.assigneeId === null, r.body);
    r = await cara.get(`/projects/${A.id}`);
    check('Cara can no longer see Project A -> 404', r.status === 404);

    r = await bob.post(`/projects/${A.id}/members`, { userId: users.Cara.id });
    r = await alice.patch(`/projects/${A.id}`, { team_lead: users.Cara.id });
    check('admin changes the team lead to Cara', r.status === 200 && r.data.team_lead === users.Cara.id, r.body);
    check('new lead became Project Manager, old lead became Project Member',
        r.data.members.find((m) => m.userId === users.Cara.id).role.name === 'Project Manager' && r.data.members.find((m) => m.userId === users.Bob.id).role.name === 'Project Member');
    r = await alice.del(`/workspaces/${acme.id}/members/${users.Bob.id}`);
    check('Bob (no longer lead) can now be removed from the workspace', r.status === 200, r.body);
    r = await bob.get(`/workspaces/${acme.id}`);
    check('removed member loses access immediately -> 404', r.status === 404);

    // ------------------------------------------------------------------ custom roles
    section('Custom roles (RBAC)');
    r = await dan.post(`/workspaces/${acme.id}/roles`, { name: 'Xylophone', scope: 'PROJECT', permissionKeys: ['task.view'] });
    check('member cannot manage roles -> 403', r.status === 403);
    r = await alice.post(`/workspaces/${acme.id}/roles`, { name: 'Hacker', scope: 'PROJECT', permissionKeys: ['user.manage'] });
    check('global permission cannot be put in a workspace role -> 400', r.status === 400 && r.code === 'INVALID_PERMISSIONS', r.body);
    r = await alice.post(`/workspaces/${acme.id}/roles`, { name: 'Reviewer', description: 'Can read and comment', scope: 'PROJECT', permissionKeys: ['task.view', 'comment.create'] });
    check('admin creates custom project role "Reviewer"', r.status === 201 && r.data.permissions.includes('project.view'), r.body);
    const reviewer = r.data;
    r = await alice.post(`/workspaces/${acme.id}/roles`, { name: 'reviewer', scope: 'PROJECT', permissionKeys: [] });
    check('role names are unique (case-insensitive) -> 409', r.status === 409);
    r = await alice.patch(`/workspaces/${acme.id}/roles/${pmRole.id}`, { name: 'Boss' });
    check('built-in roles cannot be edited -> 403', r.status === 403 && r.code === 'SYSTEM_ROLE_IMMUTABLE');
    r = await alice.patch(`/projects/${A.id}/members/${users.Dan.id}`, { roleId: reviewer.id });
    check('assign custom role to Dan in Project A', r.status === 200 && r.data.role.name === 'Reviewer', r.body);
    r = await mkTask(dan, A.id, { title: 'nope' });
    check('Dan (Reviewer) cannot create tasks -> 403', r.status === 403);
    r = await dan.post(`/tasks/${tCara.id}/comments`, { content: 'Looks fine' });
    check('...but can comment', r.status === 201);
    r = await alice.del(`/workspaces/${acme.id}/roles/${reviewer.id}`);
    check('role in use cannot be deleted -> 409 ROLE_IN_USE', r.status === 409 && r.code === 'ROLE_IN_USE', r.body);
    r = await alice.patch(`/workspaces/${acme.id}/roles/${reviewer.id}`, { permissionKeys: ['task.view', 'comment.create', 'task.create'] });
    check('editing a role takes effect immediately', r.status === 200);
    r = await mkTask(dan, A.id, { title: 'now allowed' });
    check('Dan can now create tasks (permissions are read live)', r.status === 201, r.body);
    r = await alice.post(`/workspaces/${acme.id}/members`, { email: email('frank'), roleId: reviewer.id });
    check('a project role cannot be used as a workspace role -> 400', r.status === 400 && r.code === 'INVALID_ROLE', r.body);

    // privilege escalation
    section('Privilege escalation & admin protections');
    r = await alice.patch(`/workspaces/${acme.id}/members/${users.Cara.id}`, { roleId: wsAdminRole.id });
    check('owner promotes Cara to Workspace Admin', r.status === 200);
    r = await cara.del(`/workspaces/${acme.id}/members/${users.Alice.id}`);
    check('an admin cannot remove the owner -> 409', r.status === 409);
    r = await cara.patch(`/workspaces/${acme.id}/members/${users.Dan.id}`, { roleId: wsAdminRole.id });
    check('admin promotes Dan (allowed: she holds those permissions)', r.status === 200);
    r = await dan.del(`/workspaces/${acme.id}/members/${users.Cara.id}`);
    check('non-owner admin cannot remove another Workspace Admin -> 403 OWNER_ONLY', r.status === 403 && r.code === 'OWNER_ONLY', r.body);
    await alice.patch(`/workspaces/${acme.id}/members/${users.Dan.id}`, { roleId: wsMemberRole.id });

    // password reset rules
    section('Password reset rules (no email service)');
    r = await alice.post(`/workspaces/${acme.id}/members/${eveId}/reset-password`, { newPassword: 'Another-Temp-9' });
    check('admin resets the password of an account she created that never logged in', r.status === 200, r.body);
    r = await alice.post(`/workspaces/${acme.id}/members/${users.Dan.id}/reset-password`, { newPassword: 'Another-Temp-9' });
    check('...but not of an account someone else created -> 403', r.status === 403 && r.code === 'PASSWORD_RESET_NOT_ALLOWED', r.body);
    r = await alice.post(`/admin/users/${users.Dan.id}/reset-password`, { newPassword: 'Another-Temp-9' });
    check('workspace admin cannot use the org-level reset -> 403', r.status === 403);
    r = await admin.post(`/admin/users/${users.Dan.id}/reset-password`, { newPassword: 'Another-Temp-9' });
    check('Org Admin resets any password', r.status === 200);
    r = await dan.get('/workspaces');
    check("reset invalidates the user's existing session", r.status === 401 && r.code === 'SESSION_INVALID', r.body);
    r = await new Client('d2').login(email('dan'), 'Another-Temp-9');
    check('user signs in with the temporary password and is told to change it', r.status === 200 && r.data.user.mustChangePassword === true);

    // lockout
    section('Brute-force lockout');
    const victim = new Client('v');
    let last;
    for (let i = 0; i < 5; i += 1) last = await victim.login(email('cara'), 'wrong-wrong-1');
    r = await victim.login(email('cara'), NEW_PW);
    check('account locks after repeated failures (even with the right password) -> 429', r.status === 429 && r.code === 'ACCOUNT_LOCKED', [last.status, r.status, r.body]);

    // admin user management
    section('Org Admin: deactivate, protections');
    r = await admin.patch(`/admin/users/${users.Frank.id}`, { isActive: false });
    check('cannot deactivate a workspace owner -> 409 OWNS_WORKSPACES', r.status === 409 && r.code === 'OWNS_WORKSPACES', r.body);
    r = await admin.patch(`/admin/users/${users.Dan.id}`, { isActive: false });
    check('admin deactivates Dan', r.status === 200 && r.data.isActive === false);
    r = await new Client('d3').login(email('dan'), 'Another-Temp-9');
    check('deactivated user cannot sign in -> 403', r.status === 403 && r.code === 'ACCOUNT_DEACTIVATED', r.body);
    const me = (await admin.get('/auth/me')).data;
    r = await admin.patch(`/admin/users/${me.id}`, { isActive: false });
    check('admin cannot deactivate themselves -> 400', r.status === 400);
    r = await alice.get('/admin/users');
    check('workspace admin cannot reach /admin -> 403', r.status === 403);

    // activity feed
    section('Activity feed visibility');
    r = await alice.get(`/workspaces/${acme.id}/activity?limit=50`);
    check('admin sees Project B activity', r.data.some((a) => a.projectId === B.id));

    // profile
    section('Profile');
    r = await alice.patch('/users/me', { name: 'Alice Renamed' });
    check('update profile name', r.status === 200 && r.data.name === 'Alice Renamed');
    const av = new FormData(); av.append('avatar', png(), 'me.png');
    r = await alice.call('POST', '/users/me/avatar', { form: av });
    check('upload avatar', r.status === 200 && /\/uploads\/avatars\//.test(r.data.image) && r.data.hasCustomImage === true, r.body);
    r = await alice.del('/users/me/avatar');
    check('remove avatar falls back to generated initials', r.status === 200 && /\/avatar\//.test(r.data.image), r.body);
    const svg = await fetch(r.data.image);
    check('initials avatar is served as SVG', svg.status === 200 && /svg/.test(svg.headers.get('content-type')));

    // logout + session
    section('Logout / refresh reuse');
    const sess = new Client('sess');
    await sess.login(email('alice'), NEW_PW);
    const stale = sess.refreshCookie;
    r = await sess.post('/auth/refresh', undefined, { auth: false });
    check('refresh rotates', r.status === 200 && sess.refreshCookie !== stale);
    const afterRotate = sess.refreshCookie;
    r = await sess.post('/auth/logout', undefined, { auth: false });
    check('logout ok', r.status === 200);
    sess.refreshCookie = afterRotate;
    r = await sess.post('/auth/refresh', undefined, { auth: false });
    check('refresh token is dead after logout -> 401', r.status === 401, r.body);

    // workspace deletion
    section('Workspace deletion');
    r = await cara.del(`/workspaces/${acme.id}`);
    check('admin who is not the owner cannot delete the workspace -> 403 OWNER_ONLY', r.status === 403 && r.code === 'OWNER_ONLY', r.body);
    r = await alice.del(`/workspaces/${acme.id}`);
    check('owner deletes the workspace (everything cascades)', r.status === 200, r.body);
    r = await alice.get(`/projects/${A.id}`);
    check('its projects are gone -> 404', r.status === 404);
    r = await admin.get('/workspaces');
    check('listing no longer shows it', !r.data.some((w) => w.id === acme.id));
    await admin.del(`/workspaces/${beta.id}`);

    // restore the shared admin so reruns of this script keep working
    const logout = await admin.post('/auth/logout', undefined, { auth: false });
    check('admin logout', logout.status === 200);
}

try {
    await main();
} catch (err) {
    failures.push(`Test run crashed: ${err.stack}`);
}

console.log(`\n${passed} checks passed, ${failures.length} failed`);
if (failures.length) {
    console.log('\nFailures:');
    failures.forEach((f) => console.log(` - ${f}`));
    process.exit(1);
}
