import pg from 'pg';
import { env } from '../config/env.js';
import { getContext, runWithContext } from '../core/context.js';
import { logger } from '../core/logger.js';

// DATE columns come back as 'YYYY-MM-DD' strings (no timezone shifting); BIGINT/COUNT as numbers.
pg.types.setTypeParser(1082, (v) => v);
pg.types.setTypeParser(20, (v) => parseInt(v, 10));

export const pool = new pg.Pool({
    connectionString: env.databaseUrl,
    ssl: env.dbSsl ? { rejectUnauthorized: false } : undefined,
    max: env.dbPoolMax,
    idleTimeoutMillis: 30_000,
});
pool.on('error', (err) => logger.error('Unexpected PostgreSQL pool error', { message: err.message }));

// Inside db.transaction() the request context carries the tx client, so every
// service call transparently joins the same transaction.
const executor = () => getContext()?.client ?? pool;

/**
 * All SQL goes through here as parameterized statements ($1, $2 ...). Values are
 * NEVER concatenated into the SQL text, which is what makes the queries injection-safe.
 */
export const query = (text, params = []) => executor().query(text, params);
export const rows = async (text, params = []) => (await query(text, params)).rows;
export const first = async (text, params = []) => (await query(text, params)).rows[0] ?? null;

export async function transaction(fn) {
    const parent = getContext();
    if (parent?.client) return fn(); // already inside a transaction: join it

    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const result = await runWithContext({ ...(parent ?? {}), client }, fn);
        await client.query('COMMIT');
        return result;
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        throw err;
    } finally {
        client.release();
    }
}

export const closePool = () => pool.end();
export const db = { query, rows, first, transaction };
