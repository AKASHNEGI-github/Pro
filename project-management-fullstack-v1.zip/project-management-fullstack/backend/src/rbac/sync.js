import { db } from '../db/pool.js';
import { PERMISSIONS, PERMISSION_KEYS, SYSTEM_ROLES } from './permissions.js';

const systemRoleIdCache = new Map();

/** Idempotently makes the DB match the permission catalog + built-in roles defined in code. */
export async function syncRbac() {
    await db.transaction(async () => {
        for (const p of PERMISSIONS) {
            await db.query(
                `INSERT INTO permissions (key, scope, category, description) VALUES ($1, $2, $3, $4)
                 ON CONFLICT (key) DO UPDATE SET scope = EXCLUDED.scope, category = EXCLUDED.category, description = EXCLUDED.description`,
                [p.key, p.scope, p.category, p.description],
            );
        }
        await db.query('DELETE FROM permissions WHERE key <> ALL($1::text[])', [PERMISSION_KEYS]);

        for (const role of SYSTEM_ROLES) {
            const saved = await db.first(
                `INSERT INTO roles (system_key, name, description, scope) VALUES ($1, $2, $3, $4)
                 ON CONFLICT (system_key) DO UPDATE SET name = EXCLUDED.name, description = EXCLUDED.description, scope = EXCLUDED.scope
                 RETURNING id`,
                [role.key, role.name, role.description, role.scope],
            );
            await db.query('DELETE FROM role_permissions WHERE role_id = $1', [saved.id]);
            if (role.permissions.length) {
                await db.query(
                    `INSERT INTO role_permissions (role_id, permission_id)
                     SELECT $1, id FROM permissions WHERE key = ANY($2::text[])`,
                    [saved.id, role.permissions],
                );
            }
        }
    });
    systemRoleIdCache.clear();
}

/** Returns the id of a built-in role (cached). */
export async function systemRoleId(systemKey) {
    if (systemRoleIdCache.has(systemKey)) return systemRoleIdCache.get(systemKey);
    const row = await db.first('SELECT id FROM roles WHERE system_key = $1', [systemKey]);
    if (!row) throw new Error(`System role ${systemKey} is missing. Run "npm run db:migrate" first.`);
    systemRoleIdCache.set(systemKey, row.id);
    return row.id;
}
