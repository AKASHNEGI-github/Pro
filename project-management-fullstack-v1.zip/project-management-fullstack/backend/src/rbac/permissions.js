/**
 * The permission catalog and the built-in (system) roles. This file is the single source of truth:
 * `syncRbac()` upserts it into the database on migrate / seed / server boot.
 *
 * Scope = the lowest level where a permission is meaningful:
 *   GLOBAL    -> only global roles may hold it
 *   WORKSPACE -> workspace-level actions (also grantable to global roles)
 *   PROJECT   -> project/task/comment actions. Held through a *project* role it applies to that project;
 *                held through a *workspace* or *global* role it applies to every project in scope.
 */
const def = (key, scope, category, description) => ({ key, scope, category, description });

export const PERMISSIONS = [
    // ---- Organization (global roles only)
    def('workspace.create', 'GLOBAL', 'Organization', 'Create new workspaces'),
    def('user.manage', 'GLOBAL', 'Organization', 'Manage every user account (create, deactivate, reset passwords, set global role)'),

    // ---- Workspace
    def('workspace.view', 'WORKSPACE', 'Workspace', 'View the workspace'),
    def('workspace.update', 'WORKSPACE', 'Workspace', 'Edit workspace name, logo and description'),
    def('workspace.delete', 'WORKSPACE', 'Workspace', 'Delete the workspace (owner only)'),
    def('workspace.member.view', 'WORKSPACE', 'Workspace members', 'See the workspace member list'),
    def('workspace.member.add', 'WORKSPACE', 'Workspace members', 'Onboard users into the workspace'),
    def('workspace.member.update_role', 'WORKSPACE', 'Workspace members', 'Change a member\'s workspace role'),
    def('workspace.member.remove', 'WORKSPACE', 'Workspace members', 'Remove members from the workspace'),
    def('workspace.member.reset_password', 'WORKSPACE', 'Workspace members', 'Set the initial password of accounts you created'),
    def('role.view', 'WORKSPACE', 'Roles', 'View roles and permissions'),
    def('role.manage', 'WORKSPACE', 'Roles', 'Create, edit and delete custom roles'),
    def('project.create', 'WORKSPACE', 'Projects', 'Create projects in the workspace'),

    // ---- Project
    def('project.view', 'PROJECT', 'Projects', 'View the project, its analytics and calendar'),
    def('project.update', 'PROJECT', 'Projects', 'Edit project details, status and progress'),
    def('project.delete', 'PROJECT', 'Projects', 'Delete the project'),
    def('project.lead.change', 'PROJECT', 'Projects', 'Change the team lead'),
    def('project.member.add', 'PROJECT', 'Project members', 'Add workspace members to the project'),
    def('project.member.update_role', 'PROJECT', 'Project members', 'Change a project member\'s role'),
    def('project.member.remove', 'PROJECT', 'Project members', 'Remove members from the project'),

    // ---- Tasks
    def('task.view', 'PROJECT', 'Tasks', 'View tasks'),
    def('task.create', 'PROJECT', 'Tasks', 'Create tasks'),
    def('task.update', 'PROJECT', 'Tasks', 'Edit any task (including status)'),
    def('task.update_own', 'PROJECT', 'Tasks', 'Edit tasks you created or are assigned to'),
    def('task.assign', 'PROJECT', 'Tasks', 'Assign or reassign tasks to anyone'),
    def('task.delete', 'PROJECT', 'Tasks', 'Delete tasks'),

    // ---- Comments
    def('comment.create', 'PROJECT', 'Comments', 'Comment on tasks (and edit/delete your own comments)'),
    def('comment.delete', 'PROJECT', 'Comments', 'Delete anyone\'s comments'),
];

export const PERMISSION_KEYS = PERMISSIONS.map((p) => p.key);
export const permissionsByScope = (...scopes) => PERMISSIONS.filter((p) => scopes.includes(p.scope)).map((p) => p.key);

/** The permission every role at a level must contain, otherwise members could not even see where they belong. */
export const BASE_VIEW_PERMISSION = { WORKSPACE: 'workspace.view', PROJECT: 'project.view' };

export const SYSTEM_ROLE_KEYS = {
    ORG_ADMIN: 'ORG_ADMIN',
    USER: 'USER',
    WORKSPACE_ADMIN: 'WORKSPACE_ADMIN',
    WORKSPACE_MEMBER: 'WORKSPACE_MEMBER',
    PROJECT_MANAGER: 'PROJECT_MANAGER',
    PROJECT_MEMBER: 'PROJECT_MEMBER',
};

export const SYSTEM_ROLES = [
    {
        key: 'ORG_ADMIN', name: 'Org Admin', scope: 'GLOBAL',
        description: 'Full access to the whole organization, every workspace and project.',
        permissions: PERMISSION_KEYS,
    },
    {
        key: 'USER', name: 'User', scope: 'GLOBAL',
        description: 'Regular account. Access comes only from workspace and project roles.',
        permissions: [],
    },
    {
        key: 'WORKSPACE_ADMIN', name: 'Workspace Admin', scope: 'WORKSPACE',
        description: 'Manages the workspace, its members, roles and all of its projects.',
        permissions: permissionsByScope('WORKSPACE', 'PROJECT'),
    },
    {
        key: 'WORKSPACE_MEMBER', name: 'Workspace Member', scope: 'WORKSPACE',
        description: 'Belongs to the workspace and sees only the projects they are added to.',
        permissions: ['workspace.view', 'workspace.member.view', 'role.view'],
    },
    {
        key: 'PROJECT_MANAGER', name: 'Project Manager', scope: 'PROJECT',
        description: 'Runs a project: edits it, manages its members and all of its tasks.',
        permissions: permissionsByScope('PROJECT').filter((k) => !['project.delete', 'project.lead.change'].includes(k)),
    },
    {
        key: 'PROJECT_MEMBER', name: 'Project Member', scope: 'PROJECT',
        description: 'Works on the project: creates tasks, updates their own tasks and comments.',
        permissions: ['project.view', 'task.view', 'task.create', 'task.update_own', 'comment.create'],
    },
];
