import { asyncHandler } from '../core/asyncHandler.js';
import { getContext } from '../core/context.js';
import { assertPermission, resolveScope } from './authz.js';

/**
 * Route guard.
 *   authorize('project.update', { project: 'projectId' })
 *   authorize(['task.update', 'task.update_own'], { task: 'taskId' })
 *   authorize('workspace.create')                       // global permission, no resource
 * Stores { scope, permissions } on the request context for the service layer.
 */
export const authorize = (keys, from = {}) =>
    asyncHandler(async (req, res, next) => {
        const scope = await resolveScope({
            workspaceId: from.workspace ? req.params[from.workspace] : undefined,
            projectId: from.project ? req.params[from.project] : undefined,
            taskId: from.task ? req.params[from.task] : undefined,
            commentId: from.comment ? req.params[from.comment] : undefined,
        });
        const permissions = await assertPermission(keys, scope);
        const ctx = getContext();
        ctx.scope = scope;
        ctx.permissions = permissions;
        next();
    });

export const scopeOf = () => getContext()?.scope ?? {};
export const permissionsOf = () => getContext()?.permissions ?? new Set();
