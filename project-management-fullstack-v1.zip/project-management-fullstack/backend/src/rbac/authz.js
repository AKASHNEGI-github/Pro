import { db } from '../db/pool.js';
import { getContext, currentUser } from '../core/context.js';
import { ForbiddenException, NotFoundException } from '../core/exceptions.js';

/**
 * Effective permissions = global role  UNION  workspace role (if member)  UNION  project role (if member).
 * Permissions come from the database on every request (cached per request only), so role changes apply immediately.
 */
export async function loadPermissions({ workspaceId = null, projectId = null } = {}) {
    const ctx = getContext();
    const userId = currentUser().id;
    const cacheKey = `${userId}:${workspaceId ?? ''}:${projectId ?? ''}`;
    const cached = ctx?.permCache?.get(cacheKey);
    if (cached) return cached;

    const rows = await db.rows(
        `SELECT DISTINCT p.key
           FROM (
                 SELECT rp.permission_id FROM users u
                   JOIN role_permissions rp ON rp.role_id = u.global_role_id
                  WHERE u.id = $1
                 UNION ALL
                 SELECT rp.permission_id FROM workspace_members wm
                   JOIN role_permissions rp ON rp.role_id = wm.role_id
                  WHERE wm.user_id = $1 AND wm.workspace_id = $2::uuid
                 UNION ALL
                 SELECT rp.permission_id FROM project_members pm
                   JOIN role_permissions rp ON rp.role_id = pm.role_id
                  WHERE pm.user_id = $1 AND pm.project_id = $3::uuid
                ) g
           JOIN permissions p ON p.id = g.permission_id`,
        [userId, workspaceId, projectId],
    );
    const perms = new Set(rows.map((r) => r.key));
    ctx?.permCache?.set(cacheKey, perms);
    return perms;
}

/** Call after changing roles/memberships inside a request, so later checks in the same request see the change. */
export const clearPermissionCache = () => getContext()?.permCache?.clear();

/** Turns a route's ids (workspace / project / task / comment) into { workspaceId, projectId, taskId }. */
export async function resolveScope({ workspaceId, projectId, taskId, commentId } = {}) {
    if (commentId) {
        const row = await db.first(
            `SELECT t.id AS task_id, t.project_id, p.workspace_id
               FROM comments c JOIN tasks t ON t.id = c.task_id JOIN projects p ON p.id = t.project_id
              WHERE c.id = $1`,
            [commentId],
        );
        if (!row) throw new NotFoundException('Comment not found', 'COMMENT_NOT_FOUND');
        return { workspaceId: row.workspace_id, projectId: row.project_id, taskId: row.task_id };
    }
    if (taskId) {
        const row = await db.first(
            `SELECT t.project_id, p.workspace_id FROM tasks t JOIN projects p ON p.id = t.project_id WHERE t.id = $1`,
            [taskId],
        );
        if (!row) throw new NotFoundException('Task not found', 'TASK_NOT_FOUND');
        return { workspaceId: row.workspace_id, projectId: row.project_id, taskId };
    }
    if (projectId) {
        const row = await db.first('SELECT workspace_id FROM projects WHERE id = $1', [projectId]);
        if (!row) throw new NotFoundException('Project not found', 'PROJECT_NOT_FOUND');
        return { workspaceId: row.workspace_id, projectId };
    }
    if (workspaceId) {
        const row = await db.first('SELECT id FROM workspaces WHERE id = $1', [workspaceId]);
        if (!row) throw new NotFoundException('Workspace not found', 'WORKSPACE_NOT_FOUND');
        return { workspaceId };
    }
    return {};
}

const NOT_FOUND_FOR = {
    project: ['Project not found', 'PROJECT_NOT_FOUND'],
    workspace: ['Workspace not found', 'WORKSPACE_NOT_FOUND'],
};

/**
 * Requires ANY of `keys`. If the user cannot even *see* the resource, the answer is 404 (so the existence of
 * other workspaces/projects is never leaked); if they can see it but lack the permission, the answer is 403.
 * Returns the resolved permission set.
 */
export async function assertPermission(keys, scope = {}) {
    const required = [].concat(keys);
    const perms = await loadPermissions(scope);
    if (required.some((k) => perms.has(k))) return perms;

    if (scope.projectId && !perms.has('project.view')) throw new NotFoundException(...NOT_FOUND_FOR.project);
    if (scope.workspaceId && !perms.has('workspace.view')) throw new NotFoundException(...NOT_FOUND_FOR.workspace);
    throw new ForbiddenException(`You do not have permission to do this (requires: ${required.join(' or ')})`, 'FORBIDDEN');
}

/** Privilege-escalation guard: a role may only be granted if the actor already holds every permission in it. */
export function assertNoEscalation(roleKeys, actorPerms, what = 'role') {
    const missing = roleKeys.filter((k) => !actorPerms.has(k));
    if (missing.length) {
        throw new ForbiddenException(`You cannot grant this ${what}: it includes permissions you do not have`, 'PRIVILEGE_ESCALATION', { missing });
    }
}
