import { Router } from 'express';
import { authenticate } from './middleware/authenticate.js';
import authRouter from './modules/auth/auth.router.js';
import usersRouter from './modules/users/users.router.js';
import adminRouter from './modules/admin/admin.router.js';
import workspacesRouter from './modules/workspaces/workspaces.router.js';
import projectsRouter from './modules/projects/projects.router.js';
import tasksRouter from './modules/tasks/tasks.router.js';
import commentsRouter from './modules/comments/comments.router.js';
import { permissionsRouter } from './modules/roles/roles.router.js';

const router = Router();

// Public (sign-in / token refresh) -- /auth/me and /auth/change-password authenticate themselves.
router.use('/auth', authRouter);

// Everything below requires a valid access token (and a non-temporary password).
router.use(authenticate());
router.use('/users', usersRouter);
router.use('/admin', adminRouter);
router.use('/permissions', permissionsRouter);
router.use('/workspaces', workspacesRouter);
router.use('/projects', projectsRouter);
router.use('/tasks', tasksRouter);
router.use('/comments', commentsRouter);

export default router;
