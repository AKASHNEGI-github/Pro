import { getContext } from './context.js';

/**
 * Standard API envelope
 *   success: { success: true,  status, message, data, meta?, requestId }
 *   error:   { success: false, status, message, error: { code, details? }, requestId }
 */
const requestId = (res) => res.req?.id ?? getContext()?.requestId;

export const sendSuccess = (res, { status = 200, message = 'OK', data = null, meta } = {}) => {
    const body = { success: true, status, message, data };
    if (meta) body.meta = meta;
    body.requestId = requestId(res);
    return res.status(status).json(body);
};

export const ok = (res, data, message = 'OK', meta) => sendSuccess(res, { status: 200, message, data, meta });
export const created = (res, data, message = 'Created') => sendSuccess(res, { status: 201, message, data });

export const paginationMeta = ({ page, limit, total }) => ({
    page,
    limit,
    total,
    totalPages: Math.max(1, Math.ceil(total / limit)),
});

export const sendError = (res, { status = 500, message = 'Something went wrong', code = 'INTERNAL_ERROR', details } = {}) => {
    const error = { code };
    if (details !== undefined) error.details = details;
    return res.status(status).json({ success: false, status, message, error, requestId: requestId(res) });
};
