import { AsyncLocalStorage } from 'node:async_hooks';
import { UnauthorizedException } from './exceptions.js';

/**
 * Request context store (AsyncLocalStorage).
 * Holds per-request state so services never need `req`:
 *   { requestId, ip, userAgent, user, client (tx), permCache, scope, permissions }
 */
const storage = new AsyncLocalStorage();

export const runWithContext = (store, fn) => storage.run(store, fn);
export const getContext = () => storage.getStore();

export const currentUser = () => {
    const user = getContext()?.user;
    if (!user) throw new UnauthorizedException('Authentication required', 'AUTH_REQUIRED');
    return user;
};
export const currentUserId = () => getContext()?.user?.id ?? null;
export const requestMeta = () => {
    const c = getContext() ?? {};
    return { ip: c.ip ?? null, userAgent: c.userAgent ?? null, requestId: c.requestId };
};
