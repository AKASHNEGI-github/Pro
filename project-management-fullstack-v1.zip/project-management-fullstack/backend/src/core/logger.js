import { getContext } from './context.js';
import { env } from '../config/env.js';

const LEVELS = { error: 0, warn: 1, info: 2, debug: 3 };
const threshold = LEVELS[process.env.LOG_LEVEL || (env.isProd ? 'info' : 'debug')] ?? 2;

const write = (level, message, meta) => {
    if (LEVELS[level] > threshold) return;
    const rid = getContext()?.requestId;
    const line = `${new Date().toISOString()} ${level.toUpperCase().padEnd(5)}${rid ? ` [${rid.slice(0, 8)}]` : ''} ${message}`;
    const out = meta && Object.keys(meta).length ? `${line} ${JSON.stringify(meta)}` : line;
    (level === 'error' ? console.error : level === 'warn' ? console.warn : console.log)(out);
};

export const logger = {
    error: (m, meta) => write('error', m, meta),
    warn: (m, meta) => write('warn', m, meta),
    info: (m, meta) => write('info', m, meta),
    debug: (m, meta) => write('debug', m, meta),
};
