/**
 * Exception hierarchy. Every expected failure in the app is thrown as an
 * AppException subclass; the global error handler turns it into the standard
 * error response with the right HTTP status code.
 */
export class AppException extends Error {
    constructor(message, { statusCode = 500, code = 'INTERNAL_ERROR', details = undefined, cause } = {}) {
        super(message, cause ? { cause } : undefined);
        this.name = this.constructor.name;
        this.statusCode = statusCode;
        this.code = code;
        this.details = details;
        this.isOperational = true;
        Error.captureStackTrace?.(this, this.constructor);
    }
}

export class BadRequestException extends AppException {
    constructor(message = 'Bad request', code = 'BAD_REQUEST', details) {
        super(message, { statusCode: 400, code, details });
    }
}
export class UnauthorizedException extends AppException {
    constructor(message = 'Authentication required', code = 'UNAUTHORIZED', details) {
        super(message, { statusCode: 401, code, details });
    }
}
export class ForbiddenException extends AppException {
    constructor(message = 'You do not have permission to perform this action', code = 'FORBIDDEN', details) {
        super(message, { statusCode: 403, code, details });
    }
}
export class NotFoundException extends AppException {
    constructor(message = 'Resource not found', code = 'NOT_FOUND', details) {
        super(message, { statusCode: 404, code, details });
    }
}
export class ConflictException extends AppException {
    constructor(message = 'Resource conflict', code = 'CONFLICT', details) {
        super(message, { statusCode: 409, code, details });
    }
}
export class PayloadTooLargeException extends AppException {
    constructor(message = 'Payload too large', code = 'PAYLOAD_TOO_LARGE', details) {
        super(message, { statusCode: 413, code, details });
    }
}
export class ValidationException extends AppException {
    constructor(message = 'Validation failed', details = []) {
        super(message, { statusCode: 422, code: 'VALIDATION_ERROR', details });
    }
}
export class TooManyRequestsException extends AppException {
    constructor(message = 'Too many requests, please try again later', code = 'TOO_MANY_REQUESTS', details) {
        super(message, { statusCode: 429, code, details });
    }
}
export class InternalServerException extends AppException {
    constructor(message = 'Something went wrong', code = 'INTERNAL_ERROR', details) {
        super(message, { statusCode: 500, code, details });
    }
}
