import fs from 'node:fs';
import { createApp } from './app.js';
import { env } from './config/env.js';
import { closePool, db } from './db/pool.js';
import { logger } from './core/logger.js';
import { syncRbac } from './rbac/sync.js';
import { uploadRoot } from './utils/files.js';

async function main() {
    fs.mkdirSync(uploadRoot, { recursive: true });

    try {
        await db.query('SELECT 1');
    } catch (err) {
        logger.error(`Cannot connect to PostgreSQL: ${err.message}`);
        logger.error('Check DATABASE_URL in backend/.env and run "npm run db:setup" for a first-time setup.');
        process.exit(1);
    }
    try {
        await syncRbac(); // keep permissions + built-in roles in line with the code
    } catch (err) {
        logger.error(`RBAC sync failed: ${err.message}. Did you run "npm run db:migrate"?`);
        process.exit(1);
    }

    const server = createApp().listen(env.port, () => logger.info(`API listening on ${env.publicUrl}  (env: ${env.nodeEnv})`));

    const shutdown = (signal) => {
        logger.info(`${signal} received, shutting down...`);
        server.close(async () => {
            await closePool();
            process.exit(0);
        });
        setTimeout(() => process.exit(1), 10_000).unref();
    };
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
}

process.on('unhandledRejection', (reason) => logger.error('Unhandled promise rejection', { reason: String(reason?.stack ?? reason) }));
main();
