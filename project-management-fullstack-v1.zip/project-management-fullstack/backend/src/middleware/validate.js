import { ValidationException } from '../core/exceptions.js';

/** validate({ params, query, body }) with zod schemas. Parsed (coerced/trimmed) values replace the originals. */
export const validate = (schemas) => (req, res, next) => {
    const issues = [];
    for (const part of ['params', 'query', 'body']) {
        if (!schemas[part]) continue;
        const result = schemas[part].safeParse(req[part] ?? {});
        if (result.success) {
            req[part] = result.data;
        } else {
            issues.push(...result.error.issues.map((i) => ({ location: part, field: i.path.join('.'), message: i.message })));
        }
    }
    if (issues.length) return next(new ValidationException('Validation failed', issues));
    next();
};
