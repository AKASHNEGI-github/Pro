import rateLimit from 'express-rate-limit';
import { env } from '../config/env.js';
import { TooManyRequestsException } from '../core/exceptions.js';

const handler = (req, res, next) => next(new TooManyRequestsException('Too many requests, please try again later'));

export const globalLimiter = rateLimit({
    windowMs: env.rateLimit.windowMs,
    limit: env.rateLimit.max,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler,
});

/** Login / password endpoints: only FAILED attempts count against the limit. */
export const authLimiter = rateLimit({
    windowMs: env.rateLimit.windowMs,
    limit: env.rateLimit.authMax,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    skipSuccessfulRequests: true,
    handler,
});
