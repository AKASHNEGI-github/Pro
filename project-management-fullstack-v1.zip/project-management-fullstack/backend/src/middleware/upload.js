import multer from 'multer';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { env } from '../config/env.js';
import { BadRequestException } from '../core/exceptions.js';
import { getContext, runWithContext } from '../core/context.js';
import { uploadRoot } from '../utils/files.js';

// Extension comes from the validated MIME type, never from the client-supplied filename.
// SVG is intentionally excluded (script injection risk).
const MIME_EXT = { 'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp', 'image/gif': '.gif' };

/** Single-image upload to uploads/<kind>/. Re-enters the request context after multer's stream callbacks. */
export const imageUpload = (kind, field) => {
    const dir = path.join(uploadRoot, kind);
    const handler = multer({
        storage: multer.diskStorage({
            destination: (req, file, cb) => {
                fs.mkdirSync(dir, { recursive: true });
                cb(null, dir);
            },
            filename: (req, file, cb) => cb(null, `${randomUUID()}${MIME_EXT[file.mimetype]}`),
        }),
        limits: { fileSize: env.maxUploadBytes, files: 1 },
        fileFilter: (req, file, cb) =>
            MIME_EXT[file.mimetype]
                ? cb(null, true)
                : cb(new BadRequestException('Only PNG, JPEG, WEBP or GIF images are allowed', 'INVALID_FILE_TYPE')),
    }).single(field);

    return (req, res, next) => {
        const store = getContext();
        handler(req, res, (err) => (err ? next(err) : runWithContext(store, () => next())));
    };
};
