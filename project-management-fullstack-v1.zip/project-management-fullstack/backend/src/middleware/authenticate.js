import { asyncHandler } from '../core/asyncHandler.js';
import { getContext } from '../core/context.js';
import { ForbiddenException, UnauthorizedException } from '../core/exceptions.js';
import { db } from '../db/pool.js';
import { verifyAccessToken } from '../utils/tokens.js';

/**
 * Verifies the Bearer access token, then loads the user FROM THE DATABASE on every
 * request (so deactivation / password change / role change apply immediately).
 * Users with a temporary password may only reach routes that opt in via allowPasswordChangePending.
 */
export const authenticate = ({ allowPasswordChangePending = false } = {}) =>
    asyncHandler(async (req, res, next) => {
        const [scheme, token] = (req.headers.authorization || '').split(' ');
        if (scheme !== 'Bearer' || !token) throw new UnauthorizedException('Authentication required', 'AUTH_REQUIRED');

        let payload;
        try {
            payload = verifyAccessToken(token);
        } catch (err) {
            const expired = err.name === 'TokenExpiredError';
            throw new UnauthorizedException(expired ? 'Access token expired' : 'Invalid access token', expired ? 'TOKEN_EXPIRED' : 'TOKEN_INVALID');
        }

        const user = await db.first(
            `SELECT u.id, u.name, u.email, u.image_url, u.global_role_id, u.must_change_password,
                    u.token_version, u.deactivated_at, u.created_at, u.updated_at,
                    r.name AS global_role_name, r.system_key AS global_role_key
               FROM users u JOIN roles r ON r.id = u.global_role_id
              WHERE u.id = $1`,
            [payload.sub],
        );
        if (!user || user.deactivated_at || user.token_version !== payload.tv) {
            throw new UnauthorizedException('Your session is no longer valid. Please sign in again.', 'SESSION_INVALID');
        }
        if (user.must_change_password && !allowPasswordChangePending) {
            throw new ForbiddenException('You must change your temporary password before continuing', 'PASSWORD_CHANGE_REQUIRED');
        }

        const ctx = getContext();
        ctx.user = {
            id: user.id,
            name: user.name,
            email: user.email,
            imageUrl: user.image_url,
            globalRoleId: user.global_role_id,
            globalRoleName: user.global_role_name,
            globalRoleKey: user.global_role_key,
            mustChangePassword: user.must_change_password,
            createdAt: user.created_at,
        };
        req.user = ctx.user;
        next();
    });
