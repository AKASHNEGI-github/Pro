import { randomUUID } from 'node:crypto';
import { runWithContext } from '../core/context.js';
import { logger } from '../core/logger.js';

/** 1) Assign a request id (also returned as X-Request-Id). Runs first. */
export const assignRequestId = (req, res, next) => {
    const incoming = req.get('x-request-id');
    req.id = incoming && /^[\w-]{8,64}$/.test(incoming) ? incoming : randomUUID();
    res.setHeader('X-Request-Id', req.id);
    const started = process.hrtime.bigint();
    res.on('finish', () => {
        const ms = Number(process.hrtime.bigint() - started) / 1e6;
        logger.info(`${req.method} ${req.originalUrl.split('?')[0]} ${res.statusCode} ${ms.toFixed(1)}ms`, { rid: req.id.slice(0, 8) });
    });
    next();
};

/**
 * 2) Open the AsyncLocalStorage request context. Mounted AFTER body parsing, because
 * stream-based parsers can drop async context if it is opened before them.
 */
export const bindRequestContext = (req, res, next) => {
    runWithContext(
        {
            requestId: req.id,
            ip: req.ip,
            userAgent: req.get('user-agent') ?? null,
            method: req.method,
            path: req.originalUrl,
            user: null,
            permCache: new Map(),
            client: null,
        },
        () => next(),
    );
};
