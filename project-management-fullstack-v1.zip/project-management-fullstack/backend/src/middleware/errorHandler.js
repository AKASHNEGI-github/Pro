import { ZodError } from 'zod';
import { AppException, BadRequestException, ConflictException, ForbiddenException, NotFoundException, PayloadTooLargeException, ValidationException } from '../core/exceptions.js';
import { sendError } from '../core/response.js';
import { logger } from '../core/logger.js';
import { env } from '../config/env.js';
import { publicPathFor, removeUploadedFile } from '../utils/files.js';

export const notFoundHandler = (req, res, next) =>
    next(new NotFoundException(`Route ${req.method} ${req.originalUrl.split('?')[0]} does not exist`, 'ROUTE_NOT_FOUND'));

const UNIQUE_MESSAGES = {
    users_email_key: 'An account with this email already exists',
    workspaces_slug_key: 'This workspace slug is already taken',
    workspace_members_pkey: 'This user is already a member of the workspace',
    project_members_pkey: 'This user is already a member of the project',
    roles_workspace_name_uq: 'A role with this name already exists in this workspace',
};

/** Translate low-level PostgreSQL errors into meaningful HTTP exceptions. */
function fromPgError(err) {
    switch (err.code) {
        case '23505':
            return new ConflictException(UNIQUE_MESSAGES[err.constraint] ?? 'This record already exists', 'DUPLICATE_RESOURCE');
        case '23503':
            return /still referenced/i.test(err.detail ?? '')
                ? new ConflictException('This resource is still in use and cannot be removed or changed', 'RESOURCE_IN_USE')
                : new BadRequestException('A referenced resource does not exist or is not allowed here', 'INVALID_REFERENCE');
        case '23514':
            // Raised by our DB triggers (invariants such as "last admin") -> safe to show their message.
            return err.where ? new ConflictException(err.message, 'RULE_VIOLATION') : new ValidationException('A value is not allowed', [{ message: err.constraint ?? err.message }]);
        case '23502':
            return new BadRequestException('A required field is missing', 'MISSING_FIELD');
        case '22P02':
        case '22007':
        case '22008':
        case '22001':
        case '22003':
            return new BadRequestException('A value has an invalid format', 'INVALID_VALUE');
        case '40001':
        case '40P01':
            return new ConflictException('The request conflicted with another update, please retry', 'RETRY');
        default:
            return null;
    }
}

function normalize(err) {
    if (err instanceof AppException) return err;
    if (err instanceof ZodError) {
        return new ValidationException('Validation failed', err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })));
    }
    if (err?.type === 'entity.parse.failed') return new BadRequestException('Malformed JSON body', 'INVALID_JSON');
    if (err?.type === 'entity.too.large') return new PayloadTooLargeException('Request body is too large');
    if (err?.name === 'MulterError') {
        return err.code === 'LIMIT_FILE_SIZE'
            ? new PayloadTooLargeException(`File is too large (max ${Math.round(env.maxUploadBytes / 1024 / 1024)}MB)`, 'FILE_TOO_LARGE')
            : new BadRequestException(err.message, 'UPLOAD_ERROR');
    }
    if (err?.message === 'Not allowed by CORS') return new ForbiddenException('Origin not allowed', 'CORS_ERROR');
    if (typeof err?.code === 'string' && err.code.length === 5) {
        const mapped = fromPgError(err);
        if (mapped) return mapped;
    }
    return null;
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
    if (res.headersSent) return next(err);

    // The request failed: do not leave an orphaned uploaded file behind.
    if (req.file) removeUploadedFile(publicPathFor(req.file));

    const known = normalize(err);
    if (known) {
        if (known.statusCode >= 500) logger.error(known.message, { stack: known.stack });
        else logger.debug(`${known.code}: ${known.message}`);
        return sendError(res, { status: known.statusCode, message: known.message, code: known.code, details: known.details });
    }

    logger.error(`Unhandled error: ${err?.message}`, { stack: err?.stack, code: err?.code });
    return sendError(res, {
        status: 500,
        message: 'Something went wrong. Please try again later.',
        code: 'INTERNAL_ERROR',
        details: env.isProd ? undefined : { message: err?.message, stack: err?.stack?.split('\n').slice(0, 6) },
    });
}
