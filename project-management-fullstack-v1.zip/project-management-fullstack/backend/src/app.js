import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { env } from './config/env.js';
import { db } from './db/pool.js';
import { ok } from './core/response.js';
import { asyncHandler } from './core/asyncHandler.js';
import { assignRequestId, bindRequestContext } from './middleware/requestContext.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';
import { globalLimiter } from './middleware/rateLimit.js';
import { renderAvatarSvg } from './utils/avatar.js';
import { uploadRoot } from './utils/files.js';
import routes from './routes.js';

export function createApp() {
    const app = express();
    app.disable('x-powered-by');
    if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || process.env.TRUST_PROXY);

    app.use(assignRequestId);
    // Images are loaded cross-origin by the frontend, so allow that for resources (CORP) while keeping other helmet defaults.
    app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
    app.use(
        cors({
            origin: (origin, cb) => (!origin || env.clientOrigins.includes(origin) ? cb(null, true) : cb(new Error('Not allowed by CORS'))),
            credentials: true,
            methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
            exposedHeaders: ['X-Request-Id'],
            maxAge: 600,
        }),
    );

    // Static, unauthenticated assets (not rate limited, not part of the API).
    app.get('/avatar/:name.svg', (req, res) => {
        res.set({ 'Content-Type': 'image/svg+xml; charset=utf-8', 'Cache-Control': 'public, max-age=86400' });
        res.send(renderAvatarSvg(req.params.name));
    });
    app.use('/uploads', express.static(uploadRoot, { maxAge: '7d', index: false, dotfiles: 'deny', fallthrough: false }));

    app.get('/health', asyncHandler(async (req, res) => {
        await db.query('SELECT 1');
        return ok(res, { status: 'up', uptime: Math.round(process.uptime()) }, 'Healthy');
    }));

    app.use('/api', globalLimiter, (req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
    app.use(express.json({ limit: '1mb' }));
    app.use(cookieParser());
    app.use(bindRequestContext); // after body parsing: keeps AsyncLocalStorage context intact
    app.use('/api/v1', routes);

    app.use(notFoundHandler);
    app.use(errorHandler);
    return app;
}
