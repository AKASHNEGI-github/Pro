import 'dotenv/config';

const bool = (v, d = false) => (v === undefined || v === '' ? d : ['true', '1', 'yes'].includes(String(v).toLowerCase()));
const int = (v, d) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? d : Number(v));
const list = (v) => (v || '').split(',').map((s) => s.trim()).filter(Boolean);

const nodeEnv = process.env.NODE_ENV || 'development';
const isProd = nodeEnv === 'production';
const port = int(process.env.PORT, 5000);

const buildDatabaseUrl = () => {
    if (process.env.DATABASE_URL) return process.env.DATABASE_URL;
    const { DB_HOST = 'localhost', DB_PORT = '5432', DB_USER = 'postgres', DB_PASSWORD = 'postgres', DB_NAME = 'project_management' } = process.env;
    return `postgresql://${encodeURIComponent(DB_USER)}:${encodeURIComponent(DB_PASSWORD)}@${DB_HOST}:${DB_PORT}/${DB_NAME}`;
};

const DEV_SECRET = 'dev-only-access-secret-change-me-please-0123456789';
const jwtAccessSecret = process.env.JWT_ACCESS_SECRET || DEV_SECRET;
if (isProd && (jwtAccessSecret === DEV_SECRET || jwtAccessSecret.length < 32 || jwtAccessSecret.startsWith('change-me'))) {
    throw new Error('JWT_ACCESS_SECRET must be set to a strong random value (32+ chars) in production');
}

export const env = Object.freeze({
    nodeEnv,
    isProd,
    port,
    publicUrl: (process.env.API_PUBLIC_URL || `http://localhost:${port}`).replace(/\/$/, ''),
    clientOrigins: list(process.env.CLIENT_URL || 'http://localhost:5173'),

    databaseUrl: buildDatabaseUrl(),
    dbSsl: bool(process.env.DB_SSL, false),
    dbPoolMax: int(process.env.DB_POOL_MAX, 10),

    jwtAccessSecret,
    accessTokenTtlSeconds: int(process.env.ACCESS_TOKEN_TTL_MINUTES, 15) * 60,
    refreshTokenTtlDays: int(process.env.REFRESH_TOKEN_TTL_DAYS, 7),
    bcryptRounds: int(process.env.BCRYPT_ROUNDS, 12),
    maxFailedLogins: int(process.env.MAX_FAILED_LOGINS, 5),
    lockoutMinutes: int(process.env.LOCKOUT_MINUTES, 15),
    cookie: {
        sameSite: (process.env.COOKIE_SAMESITE || 'lax').toLowerCase(),
        secure: bool(process.env.COOKIE_SECURE, isProd),
        domain: process.env.COOKIE_DOMAIN || undefined,
    },

    uploadDir: process.env.UPLOAD_DIR || 'uploads',
    maxUploadBytes: int(process.env.MAX_UPLOAD_MB, 10) * 1024 * 1024,

    rateLimit: {
        windowMs: int(process.env.RATE_LIMIT_WINDOW_MINUTES, 15) * 60 * 1000,
        max: int(process.env.RATE_LIMIT_MAX, 1000),
        authMax: int(process.env.AUTH_RATE_LIMIT_MAX, 30),
    },

    seedAdmin: {
        name: process.env.SEED_ADMIN_NAME || 'Org Admin',
        email: process.env.SEED_ADMIN_EMAIL || 'admin@example.com',
        password: process.env.SEED_ADMIN_PASSWORD || 'Admin@12345',
        mustChange: bool(process.env.SEED_ADMIN_MUST_CHANGE, true),
    },
});
