import jwt from 'jsonwebtoken';
import { createHash, randomBytes } from 'node:crypto';
import { env } from '../config/env.js';

/** Short-lived access token. `tv` = user.token_version, so password changes / deactivation invalidate it. */
export const signAccessToken = (user) =>
    jwt.sign({ tv: user.token_version }, env.jwtAccessSecret, {
        subject: user.id,
        expiresIn: env.accessTokenTtlSeconds,
        issuer: 'pm-api',
    });

export const verifyAccessToken = (token) => jwt.verify(token, env.jwtAccessSecret, { issuer: 'pm-api' });

/** Refresh tokens are opaque random strings; only their SHA-256 hash is stored in the DB. */
export const generateRefreshToken = () => randomBytes(48).toString('base64url');
export const hashToken = (token) => createHash('sha256').update(token).digest('hex');
