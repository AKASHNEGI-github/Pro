/** Tiny dependency-free initials avatar (SVG). Used when a user/workspace has no uploaded image. */
const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const hue = (str) => {
    let h = 0;
    for (const ch of str) h = (h * 31 + ch.codePointAt(0)) % 360;
    return h;
};

export function renderAvatarSvg(rawName = '?') {
    const name = String(rawName).slice(0, 80).trim() || '?';
    const words = name.split(/\s+/).filter(Boolean);
    const initials = (words.length > 1 ? words[0][0] + words[words.length - 1][0] : words[0].slice(0, 2)).toUpperCase();
    const h = hue(name);
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
<rect width="64" height="64" fill="hsl(${h} 55% 45%)"/>
<text x="32" y="32" dy=".35em" text-anchor="middle" font-family="Inter,Arial,sans-serif" font-size="26" font-weight="600" fill="#fff">${esc(initials)}</text>
</svg>`;
}
