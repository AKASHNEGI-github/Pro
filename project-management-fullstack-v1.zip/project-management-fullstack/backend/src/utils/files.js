import fs from 'node:fs/promises';
import path from 'node:path';
import { env } from '../config/env.js';
import { logger } from '../core/logger.js';

export const uploadRoot = path.resolve(env.uploadDir);

/** Best-effort removal of a previously uploaded file ("/uploads/<kind>/<file>"). Never throws. */
export async function removeUploadedFile(publicPath) {
    if (!publicPath || !publicPath.startsWith('/uploads/')) return;
    const target = path.resolve(uploadRoot, publicPath.replace('/uploads/', ''));
    if (!target.startsWith(uploadRoot + path.sep)) return; // path traversal guard
    try {
        await fs.unlink(target);
    } catch (err) {
        if (err.code !== 'ENOENT') logger.warn('Could not delete uploaded file', { target, message: err.message });
    }
}

export const publicPathFor = (file) => (file ? `/uploads/${path.basename(path.dirname(file.path))}/${file.filename}` : null);
