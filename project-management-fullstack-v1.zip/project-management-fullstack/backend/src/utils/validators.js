import { z } from 'zod';

export const uuid = z.string().uuid('Must be a valid id');
export const email = z.string().trim().toLowerCase().email('Enter a valid email address').max(254);
export const name = (max = 100) => z.string().trim().min(1, 'Name is required').max(max);

/** bcrypt only uses the first 72 bytes, so cap there. */
export const password = z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(72, 'Password must be at most 72 characters')
    .regex(/[A-Za-z]/, 'Password must contain at least one letter')
    .regex(/\d/, 'Password must contain at least one number');

// Empty string -> null (clears the field). An ABSENT field stays absent, so partial PATCH updates never wipe values.
export const optionalText = (max = 2000) =>
    z.string().trim().max(max).nullish().transform((v) => (v === '' ? null : v));

/** 'YYYY-MM-DD' (also accepts a full ISO string and keeps only the date part). */
export const dateOnly = z
    .string()
    .trim()
    .transform((v) => v.slice(0, 10))
    .refine((v) => /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)), 'Must be a valid date (YYYY-MM-DD)');

export const pagination = z.object({
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(100).default(20),
});

export const idParam = (...keys) => z.object(Object.fromEntries(keys.map((k) => [k, uuid])));
