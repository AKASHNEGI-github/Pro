import { env } from '../config/env.js';

/**
 * DTO mappers. Field names intentionally mirror the frontend's data model
 * (image_url, start_date, due_date, team_lead, assigneeId, createdAt ...).
 */
export const fileUrl = (path) => {
    if (!path) return '';
    return /^https?:\/\//i.test(path) ? path : `${env.publicUrl}${path}`;
};
export const avatarUrl = (name) => `${env.publicUrl}/avatar/${encodeURIComponent(name || '?')}.svg`;
export const imageOrAvatar = (path, name) => (path ? fileUrl(path) : avatarUrl(name));

/** SQL fragment that builds a JSON user object from table alias `a` (alias is a code constant, never user input). */
export const USER_JSON = (a) =>
    `json_build_object('id', ${a}.id, 'name', ${a}.name, 'email', ${a}.email, 'imageUrl', ${a}.image_url, 'createdAt', ${a}.created_at, 'updatedAt', ${a}.updated_at)`;

export const userFromJson = (j) =>
    j && {
        id: j.id,
        name: j.name,
        email: j.email,
        image: imageOrAvatar(j.imageUrl, j.name),
        createdAt: j.createdAt,
        updatedAt: j.updatedAt,
    };

export const userDto = (r) =>
    r && {
        id: r.id,
        name: r.name,
        email: r.email,
        image: imageOrAvatar(r.image_url, r.name),
        createdAt: r.created_at,
        updatedAt: r.updated_at,
    };

export const workspaceDto = (r) => ({
    id: r.id,
    name: r.name,
    slug: r.slug,
    description: r.description,
    settings: r.settings ?? {},
    ownerId: r.owner_id,
    image_url: imageOrAvatar(r.image_url, r.name),
    createdAt: r.created_at,
    updatedAt: r.updated_at,
});

export const projectDto = (r) => ({
    id: r.id,
    name: r.name,
    description: r.description,
    priority: r.priority,
    status: r.status,
    start_date: r.start_date,
    end_date: r.end_date,
    team_lead: r.team_lead_id,
    workspaceId: r.workspace_id,
    progress: r.progress,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
});

export const taskDto = (r) => ({
    id: r.id,
    projectId: r.project_id,
    title: r.title,
    description: r.description,
    status: r.status,
    type: r.type,
    priority: r.priority,
    assigneeId: r.assignee_id,
    createdBy: r.created_by,
    due_date: r.due_date,
    completedAt: r.completed_at,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
});

export const roleRef = (id, name, systemKey) => (id ? { id, name, isSystem: Boolean(systemKey) } : null);

/** Same as USER_JSON but yields SQL NULL when the (LEFT JOINed) user row does not exist. */
export const USER_JSON_NULLABLE = (a) => `CASE WHEN ${a}.id IS NULL THEN NULL ELSE ${USER_JSON(a)} END`;

export const removedUser = () => ({ id: null, name: 'Removed user', email: '', image: avatarUrl('?'), createdAt: null, updatedAt: null });
