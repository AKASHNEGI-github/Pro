import bcrypt from 'bcryptjs';
import { env } from '../config/env.js';

export const hashPassword = (plain) => bcrypt.hash(plain, env.bcryptRounds);
export const verifyPassword = (plain, hash) => bcrypt.compare(plain, hash);

// Used when the email is unknown, so response time does not reveal which emails exist.
let dummyHash;
export const burnPasswordCheck = async (plain) => {
    dummyHash ??= await bcrypt.hash('not-a-real-password', env.bcryptRounds);
    await bcrypt.compare(plain, dummyHash);
};
