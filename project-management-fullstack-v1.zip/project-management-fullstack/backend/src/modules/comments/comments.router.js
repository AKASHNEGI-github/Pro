import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { created, ok } from '../../core/response.js';
import { validate } from '../../middleware/validate.js';
import { authorize } from '../../rbac/authorize.js';
import * as comments from './comments.service.js';
import { commentIdSchema, createCommentSchema, listCommentsSchema, updateCommentSchema } from './comments.schema.js';

/** Mounted at /tasks/:taskId/comments */
export const taskCommentsRouter = Router({ mergeParams: true });

taskCommentsRouter.get('/', validate(listCommentsSchema), authorize('task.view', { task: 'taskId' }),
    asyncHandler(async (req, res) => ok(res, await comments.listComments(req.params.taskId), 'Comments loaded')));

taskCommentsRouter.post('/', validate(createCommentSchema), authorize('comment.create', { task: 'taskId' }),
    asyncHandler(async (req, res) => created(res, await comments.createComment(req.params.taskId, req.body), 'Comment added')));

/** Mounted at /comments */
const router = Router();
const cm = { comment: 'commentId' };

router.patch('/:commentId', validate(updateCommentSchema), authorize('comment.create', cm),
    asyncHandler(async (req, res) => ok(res, await comments.updateComment(req.params.commentId, req.body), 'Comment updated')));

router.delete('/:commentId', validate(commentIdSchema), authorize(['comment.create', 'comment.delete'], cm),
    asyncHandler(async (req, res) => { await comments.deleteComment(req.params.commentId); return ok(res, null, 'Comment deleted'); }));

export default router;
