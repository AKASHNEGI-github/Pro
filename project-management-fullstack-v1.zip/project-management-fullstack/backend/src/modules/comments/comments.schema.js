import { z } from 'zod';
import { idParam } from '../../utils/validators.js';

const content = z.string().trim().min(1, 'Comment cannot be empty').max(4000);

export const listCommentsSchema = { params: idParam('taskId') };
export const createCommentSchema = { params: idParam('taskId'), body: z.object({ content }) };
export const updateCommentSchema = { params: idParam('commentId'), body: z.object({ content }) };
export const commentIdSchema = { params: idParam('commentId') };
