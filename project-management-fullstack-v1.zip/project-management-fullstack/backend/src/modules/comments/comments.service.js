import { db } from '../../db/pool.js';
import { currentUser } from '../../core/context.js';
import { ForbiddenException, NotFoundException } from '../../core/exceptions.js';
import { permissionsOf, scopeOf } from '../../rbac/authorize.js';
import { USER_JSON_NULLABLE, removedUser, userFromJson } from '../../utils/mappers.js';
import { logActivity } from '../activity/activity.service.js';
import { assertProjectWritable } from '../projects/projects.service.js';

const COMMENT_SELECT = `SELECT c.id, c.task_id, c.user_id, c.content, c.created_at, c.updated_at, ${USER_JSON_NULLABLE('u')} AS "user"
                          FROM comments c LEFT JOIN users u ON u.id = c.user_id`;

const dto = (r) => ({
    id: r.id,
    taskId: r.task_id,
    content: r.content,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    edited: r.updated_at > r.created_at,
    user: r.user ? userFromJson(r.user) : removedUser(), // comments outlive deleted users
});

export async function listComments(taskId) {
    return (await db.rows(`${COMMENT_SELECT} WHERE c.task_id = $1 ORDER BY c.created_at`, [taskId])).map(dto);
}

export async function createComment(taskId, { content }) {
    const { workspaceId, projectId } = scopeOf();
    const id = await db.transaction(async () => {
        await assertProjectWritable(projectId);
        const c = await db.first('INSERT INTO comments (task_id, user_id, content) VALUES ($1, $2, $3) RETURNING id', [taskId, currentUser().id, content]);
        const task = await db.first('SELECT title FROM tasks WHERE id = $1', [taskId]);
        await logActivity({ workspaceId, projectId, action: 'comment.created', entityType: 'comment', entityId: c.id, metadata: { taskTitle: task.title } });
        return c.id;
    });
    return dto(await db.first(`${COMMENT_SELECT} WHERE c.id = $1`, [id]));
}

async function getOwnedComment(commentId) {
    const c = await db.first('SELECT id, user_id FROM comments WHERE id = $1', [commentId]);
    if (!c) throw new NotFoundException('Comment not found', 'COMMENT_NOT_FOUND');
    return c;
}

/** Authors can edit their own comments (nobody else, not even admins). */
export async function updateComment(commentId, { content }) {
    const c = await getOwnedComment(commentId);
    if (c.user_id !== currentUser().id) throw new ForbiddenException('You can only edit your own comments', 'FORBIDDEN');
    await assertProjectWritable(scopeOf().projectId);
    await db.query('UPDATE comments SET content = $2 WHERE id = $1', [commentId, content]);
    return dto(await db.first(`${COMMENT_SELECT} WHERE c.id = $1`, [commentId]));
}

/** Authors can delete their own comments; `comment.delete` lets managers/admins delete anyone's. */
export async function deleteComment(commentId) {
    const c = await getOwnedComment(commentId);
    if (c.user_id !== currentUser().id && !permissionsOf().has('comment.delete')) {
        throw new ForbiddenException('You can only delete your own comments', 'FORBIDDEN');
    }
    await db.query('DELETE FROM comments WHERE id = $1', [commentId]);
}
