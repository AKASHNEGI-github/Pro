import { db } from '../../db/pool.js';
import { currentUser } from '../../core/context.js';
import { BadRequestException, ConflictException, ForbiddenException, NotFoundException } from '../../core/exceptions.js';
import { assertNoEscalation, clearPermissionCache } from '../../rbac/authz.js';
import { permissionsOf } from '../../rbac/authorize.js';
import { systemRoleId } from '../../rbac/sync.js';
import { BASE_VIEW_PERMISSION } from '../../rbac/permissions.js';
import { logActivity } from '../activity/activity.service.js';

const ROLE_SELECT = `
    SELECT r.id, r.system_key, r.name, r.description, r.scope, r.workspace_id, r.created_at, r.updated_at,
           COALESCE((SELECT array_agg(p.key ORDER BY p.key) FROM role_permissions rp
                      JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = r.id), '{}') AS permissions,
           CASE WHEN r.scope = 'WORKSPACE'
                THEN (SELECT count(*) FROM workspace_members wm WHERE wm.role_id = r.id AND wm.workspace_id = $1)
                ELSE (SELECT count(*) FROM project_members pm WHERE pm.role_id = r.id AND pm.workspace_id = $1)
           END AS usage_count
      FROM roles r`;

const roleDto = (r) => ({
    id: r.id,
    name: r.name,
    description: r.description,
    scope: r.scope,
    isSystem: Boolean(r.system_key),
    systemKey: r.system_key,
    workspaceId: r.workspace_id,
    permissions: r.permissions,
    usageCount: r.usage_count,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
});

/** The catalog of permissions, grouped for the role editor. */
export async function permissionCatalog() {
    const rows = await db.rows('SELECT key, scope, category, description FROM permissions ORDER BY category, key');
    return rows.filter((r) => r.scope !== 'GLOBAL');
}

export async function listRoles(workspaceId, { scope }) {
    const rows = await db.rows(
        `${ROLE_SELECT}
          WHERE r.scope IN ('WORKSPACE', 'PROJECT') AND ($2::role_scope IS NULL OR r.scope = $2::role_scope)
            AND (r.workspace_id IS NULL OR r.workspace_id = $1)
          ORDER BY r.scope, (r.system_key IS NULL), lower(r.name)`,
        [workspaceId, scope ?? null],
    );
    return rows.map(roleDto);
}

async function getRole(workspaceId, roleId) {
    const row = await db.first(`${ROLE_SELECT} WHERE r.id = $2 AND (r.workspace_id IS NULL OR r.workspace_id = $1)`, [workspaceId, roleId]);
    if (!row) throw new NotFoundException('Role not found', 'ROLE_NOT_FOUND');
    return row;
}

/** Permission keys must exist and be allowed at the role's level; the "view" permission is always included. */
async function normalizePermissionKeys(scope, keys) {
    const allowedScopes = scope === 'WORKSPACE' ? ['WORKSPACE', 'PROJECT'] : ['PROJECT'];
    const wanted = [...new Set([...keys, BASE_VIEW_PERMISSION[scope]])];
    const found = await db.rows('SELECT key FROM permissions WHERE key = ANY($1::text[]) AND scope = ANY($2::role_scope[])', [wanted, allowedScopes]);
    const foundKeys = new Set(found.map((r) => r.key));
    const invalid = wanted.filter((k) => !foundKeys.has(k));
    if (invalid.length) throw new BadRequestException('Some permissions are unknown or not allowed for this kind of role', 'INVALID_PERMISSIONS', { invalid });
    return wanted;
}

async function assertNameFree(workspaceId, scope, name, exceptRoleId = null) {
    const clash = await db.first(
        `SELECT 1 FROM roles WHERE scope = $2 AND lower(name) = lower($3) AND (workspace_id IS NULL OR workspace_id = $1)
            AND ($4::uuid IS NULL OR id <> $4::uuid)`,
        [workspaceId, scope, name, exceptRoleId],
    );
    if (clash) throw new ConflictException(`A ${scope.toLowerCase()} role named "${name}" already exists`, 'ROLE_NAME_TAKEN');
}

async function writePermissions(roleId, keys) {
    await db.query('DELETE FROM role_permissions WHERE role_id = $1', [roleId]);
    await db.query(
        `INSERT INTO role_permissions (role_id, permission_id) SELECT $1, id FROM permissions WHERE key = ANY($2::text[])`,
        [roleId, keys],
    );
}

export async function createRole(workspaceId, { name, description, scope, permissionKeys }) {
    const id = await db.transaction(async () => {
        const keys = await normalizePermissionKeys(scope, permissionKeys);
        assertNoEscalation(keys, permissionsOf(), 'role');
        await assertNameFree(workspaceId, scope, name);
        const role = await db.first(
            `INSERT INTO roles (name, description, scope, workspace_id, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING id`,
            [name, description, scope, workspaceId, currentUser().id],
        );
        await writePermissions(role.id, keys);
        await logActivity({ workspaceId, action: 'role.created', entityType: 'role', entityId: role.id, metadata: { name, scope } });
        return role.id;
    });
    return roleDto(await getRole(workspaceId, id));
}

export async function updateRole(workspaceId, roleId, patch) {
    await db.transaction(async () => {
        const role = await getRole(workspaceId, roleId);
        if (role.system_key) throw new ForbiddenException('Built-in roles cannot be modified. Create a custom role instead.', 'SYSTEM_ROLE_IMMUTABLE');

        if (patch.name && patch.name.toLowerCase() !== role.name.toLowerCase()) await assertNameFree(workspaceId, role.scope, patch.name, roleId);
        if (patch.name !== undefined || patch.description !== undefined) {
            await db.query('UPDATE roles SET name = COALESCE($2, name), description = COALESCE($3, description) WHERE id = $1', [roleId, patch.name ?? null, patch.description ?? null]);
        }
        if (patch.permissionKeys) {
            const keys = await normalizePermissionKeys(role.scope, patch.permissionKeys);
            const added = keys.filter((k) => !role.permissions.includes(k));
            assertNoEscalation(added, permissionsOf(), 'permission');
            await writePermissions(roleId, keys);
        }
        await logActivity({ workspaceId, action: 'role.updated', entityType: 'role', entityId: roleId, metadata: { name: patch.name ?? role.name } });
    });
    clearPermissionCache();
    return roleDto(await getRole(workspaceId, roleId));
}

export async function deleteRole(workspaceId, roleId) {
    await db.transaction(async () => {
        const role = await getRole(workspaceId, roleId);
        if (role.system_key) throw new ForbiddenException('Built-in roles cannot be deleted', 'SYSTEM_ROLE_IMMUTABLE');
        if (role.usage_count > 0) {
            throw new ConflictException(`This role is assigned to ${role.usage_count} member(s). Reassign them before deleting it.`, 'ROLE_IN_USE');
        }
        await db.query('DELETE FROM roles WHERE id = $1', [roleId]);
        await logActivity({ workspaceId, action: 'role.deleted', entityType: 'role', entityId: null, metadata: { name: role.name } });
    });
}

/**
 * Used by the members/projects services: validates that `roleId` (or the default built-in role) is a legal role
 * for this level and workspace, and that the actor is not handing out permissions they do not hold themselves.
 */
export async function resolveAssignableRole({ roleId, scope, workspaceId, defaultKey }) {
    const id = roleId ?? (await systemRoleId(defaultKey));
    const role = await db.first(
        `SELECT r.id, r.name, r.scope, r.workspace_id, r.system_key,
                COALESCE((SELECT array_agg(p.key) FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = r.id), '{}') AS permissions
           FROM roles r WHERE r.id = $1`,
        [id],
    );
    if (!role || role.scope !== scope || (role.workspace_id && role.workspace_id !== workspaceId)) {
        throw new BadRequestException('Invalid role for this operation', 'INVALID_ROLE');
    }
    assertNoEscalation(role.permissions, permissionsOf(), 'role');
    return role;
}
