import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { created, ok } from '../../core/response.js';
import { validate } from '../../middleware/validate.js';
import { authorize } from '../../rbac/authorize.js';
import * as roles from './roles.service.js';
import { createRoleSchema, deleteRoleSchema, listRolesSchema, updateRoleSchema } from './roles.schema.js';

/** GET /permissions : the permission catalog (any signed-in user; it is static reference data). */
export const permissionsRouter = Router();
permissionsRouter.get('/', asyncHandler(async (req, res) => ok(res, await roles.permissionCatalog(), 'Permissions loaded')));

/** Mounted at /workspaces/:workspaceId/roles */
const router = Router({ mergeParams: true });
const ws = { workspace: 'workspaceId' };

router.get('/', validate(listRolesSchema), authorize('role.view', ws),
    asyncHandler(async (req, res) => ok(res, await roles.listRoles(req.params.workspaceId, req.query), 'Roles loaded')));

router.post('/', validate(createRoleSchema), authorize('role.manage', ws),
    asyncHandler(async (req, res) => created(res, await roles.createRole(req.params.workspaceId, req.body), 'Role created')));

router.patch('/:roleId', validate(updateRoleSchema), authorize('role.manage', ws),
    asyncHandler(async (req, res) => ok(res, await roles.updateRole(req.params.workspaceId, req.params.roleId, req.body), 'Role updated')));

router.delete('/:roleId', validate(deleteRoleSchema), authorize('role.manage', ws),
    asyncHandler(async (req, res) => { await roles.deleteRole(req.params.workspaceId, req.params.roleId); return ok(res, null, 'Role deleted'); }));

export default router;
