import { z } from 'zod';
import { idParam } from '../../utils/validators.js';

const permissionKeys = z.array(z.string().min(1).max(80)).max(100);
const roleName = z.string().trim().min(2, 'Role name must be at least 2 characters').max(50);

export const listRolesSchema = {
    params: idParam('workspaceId'),
    query: z.object({ scope: z.enum(['WORKSPACE', 'PROJECT']).optional() }),
};

export const createRoleSchema = {
    params: idParam('workspaceId'),
    body: z.object({
        name: roleName,
        description: z.string().trim().max(300).optional().default(''),
        scope: z.enum(['WORKSPACE', 'PROJECT']),
        permissionKeys,
    }),
};

export const updateRoleSchema = {
    params: idParam('workspaceId', 'roleId'),
    body: z
        .object({ name: roleName.optional(), description: z.string().trim().max(300).optional(), permissionKeys: permissionKeys.optional() })
        .refine((b) => Object.keys(b).length > 0, 'Provide at least one field to update'),
};

export const deleteRoleSchema = { params: idParam('workspaceId', 'roleId') };
