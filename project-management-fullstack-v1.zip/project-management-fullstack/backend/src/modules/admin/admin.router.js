import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { created, ok } from '../../core/response.js';
import { validate } from '../../middleware/validate.js';
import { authorize } from '../../rbac/authorize.js';
import * as admin from './admin.service.js';
import { createUserSchema, listUsersSchema, resetPasswordSchema, updateUserSchema } from './admin.schema.js';

// Organization-level administration. Everything here requires the global `user.manage` permission.
const router = Router();
router.use(authorize('user.manage'));

router.get('/users', validate(listUsersSchema), asyncHandler(async (req, res) => {
    const { items, meta } = await admin.listUsers(req.query);
    return ok(res, items, 'Users loaded', meta);
}));
router.post('/users', validate(createUserSchema), asyncHandler(async (req, res) => created(res, await admin.createUser(req.body), 'User created')));
router.patch('/users/:userId', validate(updateUserSchema), asyncHandler(async (req, res) => ok(res, await admin.updateUser(req.params.userId, req.body), 'User updated')));
router.post('/users/:userId/reset-password', validate(resetPasswordSchema), asyncHandler(async (req, res) => {
    await admin.resetUserPassword(req.params.userId, req.body);
    return ok(res, null, 'Password reset. The user must change it at next sign in.');
}));
router.get('/roles', asyncHandler(async (req, res) => ok(res, await admin.listGlobalRoles(), 'Global roles loaded')));
router.get('/workspaces', asyncHandler(async (req, res) => ok(res, await admin.listAllWorkspaces(), 'Workspaces loaded')));

export default router;
