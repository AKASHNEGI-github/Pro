import { z } from 'zod';
import { email, idParam, name, password, pagination, uuid } from '../../utils/validators.js';

export const listUsersSchema = {
    query: pagination.extend({
        search: z.string().trim().max(100).optional(),
        status: z.enum(['all', 'active', 'deactivated']).default('all'),
    }),
};
export const createUserSchema = {
    body: z.object({ name: name(100), email, password, globalRoleId: uuid.optional() }),
};
export const updateUserSchema = {
    params: idParam('userId'),
    body: z
        .object({ name: name(100).optional(), globalRoleId: uuid.optional(), isActive: z.boolean().optional() })
        .refine((b) => Object.keys(b).length > 0, 'Provide at least one field to update'),
};
export const resetPasswordSchema = {
    params: idParam('userId'),
    body: z.object({ newPassword: password }),
};
