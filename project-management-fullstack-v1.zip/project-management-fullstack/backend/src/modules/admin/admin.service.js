import { db } from '../../db/pool.js';
import { currentUser } from '../../core/context.js';
import { BadRequestException, ConflictException, ForbiddenException, NotFoundException } from '../../core/exceptions.js';
import { paginationMeta } from '../../core/response.js';
import { imageOrAvatar } from '../../utils/mappers.js';
import { hashPassword } from '../../utils/password.js';
import { systemRoleId } from '../../rbac/sync.js';
import { setUserPassword } from '../users/users.service.js';

const escapeLike = (s) => s.replace(/[\\%_]/g, (c) => `\\${c}`);

const userRow = (r) => ({
    id: r.id,
    name: r.name,
    email: r.email,
    image: imageOrAvatar(r.image_url, r.name),
    globalRole: { id: r.role_id, name: r.role_name, key: r.system_key },
    isActive: !r.deactivated_at,
    mustChangePassword: r.must_change_password,
    lastLoginAt: r.last_login_at,
    workspacesCount: r.workspaces_count,
    createdAt: r.created_at,
});

const USER_SELECT = `
    SELECT u.id, u.name, u.email, u.image_url, u.deactivated_at, u.must_change_password, u.last_login_at, u.created_at,
           r.id AS role_id, r.name AS role_name, r.system_key,
           (SELECT count(*) FROM workspace_members wm WHERE wm.user_id = u.id) AS workspaces_count
      FROM users u JOIN roles r ON r.id = u.global_role_id`;

export async function listUsers({ search, status, page, limit }) {
    const like = search ? `%${escapeLike(search)}%` : null;
    const where = `WHERE ($1::text IS NULL OR u.name ILIKE $1 OR u.email::text ILIKE $1)
                     AND ($2 = 'all' OR ($2 = 'active' AND u.deactivated_at IS NULL) OR ($2 = 'deactivated' AND u.deactivated_at IS NOT NULL))`;
    const [{ total }, rows] = await Promise.all([
        db.first(`SELECT count(*) AS total FROM users u ${where}`, [like, status]),
        db.rows(`${USER_SELECT} ${where} ORDER BY u.created_at DESC LIMIT $3 OFFSET $4`, [like, status, limit, (page - 1) * limit]),
    ]);
    return { items: rows.map(userRow), meta: paginationMeta({ page, limit, total }) };
}

export async function listGlobalRoles() {
    return db.rows(`SELECT id, name, description, system_key AS "key" FROM roles WHERE scope = 'GLOBAL' ORDER BY name`);
}

export async function createUser({ name, email, password, globalRoleId }) {
    if (await db.first('SELECT 1 FROM users WHERE email = $1', [email])) {
        throw new ConflictException('An account with this email already exists', 'EMAIL_TAKEN');
    }
    const roleId = globalRoleId ?? (await systemRoleId('USER'));
    const hash = await hashPassword(password);
    const id = await db.transaction(async () => {
        const u = await db.first(
            `INSERT INTO users (name, email, global_role_id, must_change_password, created_by) VALUES ($1, $2, $3, true, $4) RETURNING id`,
            [name, email, roleId, currentUser().id],
        );
        await db.query('INSERT INTO user_credentials (user_id, password_hash) VALUES ($1, $2)', [u.id, hash]);
        return u.id;
    });
    return getUser(id);
}

async function getUser(id) {
    const row = await db.first(`${USER_SELECT} WHERE u.id = $1`, [id]);
    if (!row) throw new NotFoundException('User not found', 'USER_NOT_FOUND');
    return userRow(row);
}

export async function updateUser(userId, { name, globalRoleId, isActive }) {
    const me = currentUser();
    const target = await getUser(userId);

    if (userId === me.id) {
        if (isActive === false) throw new BadRequestException('You cannot deactivate your own account', 'SELF_DEACTIVATION');
        if (globalRoleId && globalRoleId !== target.globalRole.id) throw new ForbiddenException('You cannot change your own global role', 'SELF_ROLE_CHANGE');
    }
    if (isActive === false && target.isActive) {
        const owned = await db.rows('SELECT name FROM workspaces WHERE owner_id = $1', [userId]);
        if (owned.length) {
            throw new ConflictException(`This user owns ${owned.map((w) => `"${w.name}"`).join(', ')}. Transfer ownership first.`, 'OWNS_WORKSPACES');
        }
    }

    await db.transaction(async () => {
        await db.query(
            `UPDATE users SET name = COALESCE($2, name), global_role_id = COALESCE($3::uuid, global_role_id),
                    deactivated_at = CASE WHEN $4::boolean IS NULL THEN deactivated_at WHEN $4 THEN NULL ELSE COALESCE(deactivated_at, now()) END,
                    token_version = token_version + CASE WHEN $4 IS FALSE THEN 1 ELSE 0 END
              WHERE id = $1`,
            [userId, name ?? null, globalRoleId ?? null, isActive ?? null],
        );
        if (isActive === false) {
            await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [userId]);
        }
    });
    return getUser(userId);
}

export async function resetUserPassword(userId, { newPassword }) {
    await getUser(userId);
    await setUserPassword(userId, newPassword, { mustChange: true });
}

export async function listAllWorkspaces() {
    const rows = await db.rows(
        `SELECT w.id, w.name, w.slug, w.image_url, w.created_at, o.name AS owner_name, o.email AS owner_email,
                (SELECT count(*) FROM workspace_members m WHERE m.workspace_id = w.id) AS members_count,
                (SELECT count(*) FROM projects p WHERE p.workspace_id = w.id) AS projects_count
           FROM workspaces w JOIN users o ON o.id = w.owner_id ORDER BY lower(w.name)`,
    );
    return rows.map((r) => ({
        id: r.id, name: r.name, slug: r.slug, image_url: imageOrAvatar(r.image_url, r.name), createdAt: r.created_at,
        owner: { name: r.owner_name, email: r.owner_email }, membersCount: r.members_count, projectsCount: r.projects_count,
    }));
}
