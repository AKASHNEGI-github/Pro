import { db } from '../../db/pool.js';
import { currentUser } from '../../core/context.js';
import { BadRequestException, ConflictException, ForbiddenException, NotFoundException, ValidationException } from '../../core/exceptions.js';
import { loadPermissions } from '../../rbac/authz.js';
import { hashPassword } from '../../utils/password.js';
import { USER_JSON, roleRef, userFromJson } from '../../utils/mappers.js';
import { resolveAssignableRole } from '../roles/roles.service.js';
import { setUserPassword } from '../users/users.service.js';
import { logActivity } from '../activity/activity.service.js';

const MEMBER_SELECT = `
    SELECT wm.user_id, wm.workspace_id, wm.message, wm.joined_at, r.id AS role_id, r.name AS role_name, r.system_key,
           u.deactivated_at, ${USER_JSON('u')} AS "user",
           (SELECT count(*) FROM project_members pm WHERE pm.workspace_id = wm.workspace_id AND pm.user_id = wm.user_id) AS projects_count
      FROM workspace_members wm JOIN users u ON u.id = wm.user_id JOIN roles r ON r.id = wm.role_id`;

const memberDto = (r) => ({
    id: `${r.workspace_id}:${r.user_id}`,
    userId: r.user_id,
    workspaceId: r.workspace_id,
    message: r.message,
    joinedAt: r.joined_at,
    isActive: !r.deactivated_at,
    projectsCount: r.projects_count,
    role: roleRef(r.role_id, r.role_name, r.system_key),
    user: userFromJson(r.user),
});

async function getMember(workspaceId, userId) {
    const row = await db.first(`${MEMBER_SELECT} WHERE wm.workspace_id = $1 AND wm.user_id = $2`, [workspaceId, userId]);
    if (!row) throw new NotFoundException('This user is not a member of the workspace', 'MEMBER_NOT_FOUND');
    return row;
}

const workspaceOwnerId = async (workspaceId) => (await db.first('SELECT owner_id FROM workspaces WHERE id = $1', [workspaceId])).owner_id;

/** Only the owner (or an Org Admin) may change/remove another Workspace Admin. */
async function assertMayManageTarget(workspaceId, targetRow) {
    if (targetRow.system_key !== 'WORKSPACE_ADMIN') return;
    const me = currentUser();
    const ownerId = await workspaceOwnerId(workspaceId);
    const isGlobalAdmin = (await loadPermissions()).has('user.manage');
    if (me.id !== ownerId && !isGlobalAdmin) {
        throw new ForbiddenException('Only the workspace owner can change or remove another Workspace Admin', 'OWNER_ONLY');
    }
}

export async function listMembers(workspaceId) {
    const rows = await db.rows(`${MEMBER_SELECT} WHERE wm.workspace_id = $1 ORDER BY wm.joined_at, lower(u.name)`, [workspaceId]);
    return rows.map(memberDto);
}

/** Lets the "Add member" form know whether an account already exists (so it only asks for name + password when needed). */
export async function lookup(workspaceId, { email }) {
    const user = await db.first('SELECT id, name, email, image_url, created_at, updated_at, deactivated_at FROM users WHERE email = $1', [email]);
    if (!user) return { exists: false, alreadyMember: false, user: null };
    const member = await db.first('SELECT 1 FROM workspace_members WHERE workspace_id = $1 AND user_id = $2', [workspaceId, user.id]);
    return {
        exists: true,
        alreadyMember: Boolean(member),
        isActive: !user.deactivated_at,
        user: userFromJson({ id: user.id, name: user.name, email: user.email, imageUrl: user.image_url, createdAt: user.created_at, updatedAt: user.updated_at }),
    };
}

/**
 * Onboards a user INTO the workspace. A user must be onboarded here before they can be added to any project of this workspace.
 * Existing account -> just added. No account -> created with a temporary password (must be changed at first login).
 */
export async function addMember(workspaceId, body) {
    const me = currentUser();
    const userId = await db.transaction(async () => {
        const role = await resolveAssignableRole({ roleId: body.roleId, scope: 'WORKSPACE', workspaceId, defaultKey: 'WORKSPACE_MEMBER' });

        let user = await db.first('SELECT id, name, deactivated_at FROM users WHERE email = $1', [body.email]);
        if (user) {
            if (user.deactivated_at) throw new ConflictException('This account is deactivated and cannot be added', 'USER_DEACTIVATED');
            if (await db.first('SELECT 1 FROM workspace_members WHERE workspace_id = $1 AND user_id = $2', [workspaceId, user.id])) {
                throw new ConflictException('This user is already a member of the workspace', 'ALREADY_MEMBER');
            }
        } else {
            const issues = [];
            if (!body.name) issues.push({ location: 'body', field: 'name', message: 'Name is required for a new account' });
            if (!body.password) issues.push({ location: 'body', field: 'password', message: 'A temporary password is required for a new account' });
            if (issues.length) throw new ValidationException('Validation failed', issues);

            user = await db.first(
                `INSERT INTO users (name, email, global_role_id, must_change_password, created_by)
                 VALUES ($1, $2, (SELECT id FROM roles WHERE system_key = 'USER'), true, $3) RETURNING id, name`,
                [body.name, body.email, me.id],
            );
            await db.query('INSERT INTO user_credentials (user_id, password_hash) VALUES ($1, $2)', [user.id, await hashPassword(body.password)]);
        }

        await db.query(
            'INSERT INTO workspace_members (workspace_id, user_id, role_id, message, added_by) VALUES ($1, $2, $3, $4, $5)',
            [workspaceId, user.id, role.id, body.message ?? '', me.id],
        );
        await logActivity({ workspaceId, action: 'member.added', entityType: 'member', entityId: user.id, metadata: { name: user.name, role: role.name } });
        return user.id;
    });
    return memberDto(await getMember(workspaceId, userId));
}

export async function updateMemberRole(workspaceId, userId, { roleId }) {
    const me = currentUser();
    await db.transaction(async () => {
        const target = await getMember(workspaceId, userId);
        if (userId === me.id) throw new ForbiddenException('You cannot change your own role', 'SELF_ROLE_CHANGE');
        if (userId === (await workspaceOwnerId(workspaceId))) {
            throw new ConflictException('The workspace owner must remain a Workspace Admin. Transfer ownership first.', 'OWNER_PROTECTED');
        }
        await assertMayManageTarget(workspaceId, target);
        const role = await resolveAssignableRole({ roleId, scope: 'WORKSPACE', workspaceId });
        await db.query('UPDATE workspace_members SET role_id = $3 WHERE workspace_id = $1 AND user_id = $2', [workspaceId, userId, role.id]);
        await logActivity({ workspaceId, action: 'member.role_changed', entityType: 'member', entityId: userId, metadata: { name: target.user.name, from: target.role_name, to: role.name } });
    });
    return memberDto(await getMember(workspaceId, userId));
}

/** Removing a member also removes them from every project in the workspace and un-assigns their tasks (FK rules). */
export async function removeMember(workspaceId, userId) {
    await db.transaction(async () => {
        const target = await getMember(workspaceId, userId);
        if (userId === (await workspaceOwnerId(workspaceId))) {
            throw new ConflictException('The workspace owner cannot be removed. Transfer ownership first.', 'OWNER_PROTECTED');
        }
        await assertMayManageTarget(workspaceId, target);

        const leading = await db.rows('SELECT name FROM projects WHERE workspace_id = $1 AND team_lead_id = $2', [workspaceId, userId]);
        if (leading.length) {
            throw new ConflictException(
                `This member is the team lead of ${leading.map((p) => `"${p.name}"`).join(', ')}. Assign a new team lead first.`,
                'IS_TEAM_LEAD',
            );
        }
        await db.query('DELETE FROM workspace_members WHERE workspace_id = $1 AND user_id = $2', [workspaceId, userId]);
        await logActivity({ workspaceId, action: 'member.removed', entityType: 'member', entityId: null, metadata: { name: target.user.name } });
    });
}

/**
 * Workspace admins can only set the initial password of accounts THEY created that have never signed in
 * (prevents taking over an account that also belongs to other workspaces). Org Admins use /admin instead.
 */
export async function resetMemberPassword(workspaceId, userId, { newPassword }) {
    const me = currentUser();
    await getMember(workspaceId, userId);
    const target = await db.first('SELECT created_by, last_login_at FROM users WHERE id = $1', [userId]);
    const isGlobalAdmin = (await loadPermissions()).has('user.manage');
    if (!isGlobalAdmin && (target.created_by !== me.id || target.last_login_at)) {
        throw new ForbiddenException(
            'You can only set the password of accounts you created that have not signed in yet. Ask an Org Admin to reset it.',
            'PASSWORD_RESET_NOT_ALLOWED',
        );
    }
    if (userId === me.id) throw new BadRequestException('Use "Change password" in your profile instead', 'USE_CHANGE_PASSWORD');
    await setUserPassword(userId, newPassword, { mustChange: true });
}
