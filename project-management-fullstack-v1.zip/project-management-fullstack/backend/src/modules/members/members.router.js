import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { created, ok } from '../../core/response.js';
import { validate } from '../../middleware/validate.js';
import { authorize } from '../../rbac/authorize.js';
import * as members from './members.service.js';
import { addMemberSchema, listMembersSchema, lookupSchema, memberParamsSchema, resetMemberPasswordSchema, updateMemberRoleSchema } from './members.schema.js';

// Mounted at /workspaces/:workspaceId/members
const router = Router({ mergeParams: true });
const ws = { workspace: 'workspaceId' };

router.get('/', validate(listMembersSchema), authorize('workspace.member.view', ws),
    asyncHandler(async (req, res) => ok(res, await members.listMembers(req.params.workspaceId), 'Members loaded')));

router.get('/lookup', validate(lookupSchema), authorize('workspace.member.add', ws),
    asyncHandler(async (req, res) => ok(res, await members.lookup(req.params.workspaceId, req.query), 'Lookup complete')));

router.post('/', validate(addMemberSchema), authorize('workspace.member.add', ws),
    asyncHandler(async (req, res) => created(res, await members.addMember(req.params.workspaceId, req.body), 'Member added to the workspace')));

router.patch('/:userId', validate(updateMemberRoleSchema), authorize('workspace.member.update_role', ws),
    asyncHandler(async (req, res) => ok(res, await members.updateMemberRole(req.params.workspaceId, req.params.userId, req.body), 'Member role updated')));

router.delete('/:userId', validate(memberParamsSchema), authorize('workspace.member.remove', ws),
    asyncHandler(async (req, res) => { await members.removeMember(req.params.workspaceId, req.params.userId); return ok(res, null, 'Member removed from the workspace'); }));

router.post('/:userId/reset-password', validate(resetMemberPasswordSchema), authorize('workspace.member.reset_password', ws),
    asyncHandler(async (req, res) => { await members.resetMemberPassword(req.params.workspaceId, req.params.userId, req.body); return ok(res, null, 'Password set. The user must change it at first sign in.'); }));

export default router;
