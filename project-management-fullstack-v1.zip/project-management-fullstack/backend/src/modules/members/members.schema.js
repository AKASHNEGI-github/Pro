import { z } from 'zod';
import { email, idParam, name, password, uuid } from '../../utils/validators.js';

export const lookupSchema = { params: idParam('workspaceId'), query: z.object({ email }) };

export const addMemberSchema = {
    params: idParam('workspaceId'),
    body: z.object({
        email,
        // Only needed when no account exists yet for this email (there is no email service, so the admin sets a temporary password).
        name: name(100).optional(),
        password: password.optional(),
        roleId: uuid.optional(),
        message: z.string().trim().max(300).optional().default(''),
    }),
};

export const updateMemberRoleSchema = {
    params: idParam('workspaceId', 'userId'),
    body: z.object({ roleId: uuid }),
};
export const memberParamsSchema = { params: idParam('workspaceId', 'userId') };
export const resetMemberPasswordSchema = {
    params: idParam('workspaceId', 'userId'),
    body: z.object({ newPassword: password }),
};
export const listMembersSchema = { params: idParam('workspaceId') };
