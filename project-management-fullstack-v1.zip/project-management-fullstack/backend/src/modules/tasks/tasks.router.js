import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { created, ok } from '../../core/response.js';
import { validate } from '../../middleware/validate.js';
import { authorize } from '../../rbac/authorize.js';
import * as tasks from './tasks.service.js';
import { bulkDeleteSchema, createTaskSchema, listTasksSchema, myTasksSchema, taskIdSchema, updateTaskSchema } from './tasks.schema.js';
import { taskCommentsRouter } from '../comments/comments.router.js';

/** Mounted at /projects/:projectId/tasks */
export const projectTasksRouter = Router({ mergeParams: true });
const pr = { project: 'projectId' };

projectTasksRouter.get('/', validate(listTasksSchema), authorize('task.view', pr),
    asyncHandler(async (req, res) => {
        const { items, meta } = await tasks.listTasks(req.params.projectId, req.query);
        return ok(res, items, 'Tasks loaded', meta);
    }));

projectTasksRouter.post('/', validate(createTaskSchema), authorize('task.create', pr),
    asyncHandler(async (req, res) => created(res, await tasks.createTask(req.params.projectId, req.body), 'Task created')));

projectTasksRouter.post('/bulk-delete', validate(bulkDeleteSchema), authorize('task.delete', pr),
    asyncHandler(async (req, res) => ok(res, await tasks.bulkDelete(req.params.projectId, req.body), 'Tasks deleted')));

/** Mounted at /workspaces/:workspaceId/my-tasks */
export const myTasksRouter = Router({ mergeParams: true });
myTasksRouter.get('/', validate(myTasksSchema), authorize('workspace.view', { workspace: 'workspaceId' }),
    asyncHandler(async (req, res) => ok(res, await tasks.myTasks(req.params.workspaceId), 'Your tasks loaded')));

/** Mounted at /tasks */
const router = Router();
const tk = { task: 'taskId' };

router.get('/:taskId', validate(taskIdSchema), authorize('task.view', tk),
    asyncHandler(async (req, res) => ok(res, await tasks.getTaskById(req.params.taskId), 'Task loaded')));

router.patch('/:taskId', validate(updateTaskSchema), authorize(['task.update', 'task.update_own'], tk),
    asyncHandler(async (req, res) => ok(res, await tasks.updateTask(req.params.taskId, req.body), 'Task updated')));

router.delete('/:taskId', validate(taskIdSchema), authorize('task.delete', tk),
    asyncHandler(async (req, res) => { await tasks.deleteTask(req.params.taskId); return ok(res, null, 'Task deleted'); }));

router.use('/:taskId/comments', taskCommentsRouter);

export default router;
