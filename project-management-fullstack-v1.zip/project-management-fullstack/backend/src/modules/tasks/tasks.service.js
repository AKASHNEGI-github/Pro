import { db } from '../../db/pool.js';
import { currentUser } from '../../core/context.js';
import { BadRequestException, ForbiddenException, NotFoundException } from '../../core/exceptions.js';
import { paginationMeta } from '../../core/response.js';
import { permissionsOf, scopeOf } from '../../rbac/authorize.js';
import { USER_JSON_NULLABLE, taskDto, userFromJson } from '../../utils/mappers.js';
import { logActivity } from '../activity/activity.service.js';
import { assertProjectWritable } from '../projects/projects.service.js';

const escapeLike = (s) => s.replace(/[\\%_]/g, (c) => `\\${c}`);

const TASK_SELECT = `
    SELECT t.*, p.name AS project_name, ${USER_JSON_NULLABLE('a')} AS assignee,
           (SELECT count(*) FROM comments c WHERE c.task_id = t.id) AS comments_count
      FROM tasks t JOIN projects p ON p.id = t.project_id LEFT JOIN users a ON a.id = t.assignee_id`;

const toDto = (r) => ({
    ...taskDto(r),
    projectName: r.project_name,
    commentsCount: r.comments_count,
    assignee: r.assignee ? userFromJson(r.assignee) : null,
});

async function getTask(taskId) {
    const row = await db.first(`${TASK_SELECT} WHERE t.id = $1`, [taskId]);
    if (!row) throw new NotFoundException('Task not found', 'TASK_NOT_FOUND');
    return toDto(row);
}

/** The assignee must belong to the task's project (the DB enforces this too; this gives a clear message). */
async function assertAssignable(projectId, userId) {
    const ok = await db.first('SELECT 1 FROM project_members WHERE project_id = $1 AND user_id = $2', [projectId, userId]);
    if (!ok) throw new BadRequestException('The assignee must be a member of this project', 'ASSIGNEE_NOT_IN_PROJECT');
}

export async function listTasks(projectId, q) {
    const where = ['t.project_id = $1'];
    const params = [projectId];
    const add = (sql, value) => { params.push(value); where.push(sql.replaceAll('?', `$${params.length}`)); };
    if (q.status) add('t.status = ?', q.status);
    if (q.type) add('t.type = ?', q.type);
    if (q.priority) add('t.priority = ?', q.priority);
    if (q.assigneeId) add('t.assignee_id = ?', q.assigneeId);
    if (q.search) add(`(t.title ILIKE ? OR COALESCE(t.description, '') ILIKE ?)`, `%${escapeLike(q.search)}%`);

    const whereSql = where.join(' AND ');
    const pageParams = [...params, q.limit, (q.page - 1) * q.limit];
    const [{ total }, rows] = await Promise.all([
        db.first(`SELECT count(*) AS total FROM tasks t WHERE ${whereSql}`, params),
        db.rows(`${TASK_SELECT} WHERE ${whereSql} ORDER BY t.created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, pageParams),
    ]);
    return { items: rows.map(toDto), meta: paginationMeta({ page: q.page, limit: q.limit, total }) };
}

export const getTaskById = getTask;

export async function createTask(projectId, body) {
    const me = currentUser();
    const perms = permissionsOf();
    const { workspaceId } = scopeOf();

    const id = await db.transaction(async () => {
        await assertProjectWritable(projectId, perms);
        const assigneeId = body.assigneeId ?? null;
        if (assigneeId) {
            if (assigneeId !== me.id && !perms.has('task.assign')) {
                throw new ForbiddenException('You can only assign tasks to yourself', 'FORBIDDEN');
            }
            await assertAssignable(projectId, assigneeId);
        }
        const t = await db.first(
            `INSERT INTO tasks (project_id, title, description, status, type, priority, assignee_id, due_date, created_by)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id`,
            [projectId, body.title, body.description ?? null, body.status, body.type, body.priority, assigneeId, body.due_date, me.id],
        );
        await logActivity({ workspaceId, projectId, action: 'task.created', entityType: 'task', entityId: t.id, metadata: { title: body.title } });
        return t.id;
    });
    return getTask(id);
}

const UPDATABLE = {
    title: 'title', description: 'description', type: 'type', status: 'status',
    priority: 'priority', assigneeId: 'assignee_id', due_date: 'due_date',
};

export async function updateTask(taskId, patch) {
    const me = currentUser();
    const perms = permissionsOf();
    const { workspaceId, projectId } = scopeOf();

    await db.transaction(async () => {
        const task = await db.first('SELECT * FROM tasks WHERE id = $1 FOR UPDATE', [taskId]);

        // Without `task.update` the user only has `task.update_own`: tasks they created or are assigned to.
        if (!perms.has('task.update') && task.created_by !== me.id && task.assignee_id !== me.id) {
            throw new ForbiddenException('You can only edit tasks you created or are assigned to', 'FORBIDDEN');
        }
        await assertProjectWritable(projectId, perms);

        const assigneeChanged = 'assigneeId' in patch && (patch.assigneeId ?? null) !== task.assignee_id;
        if (assigneeChanged) {
            if (!perms.has('task.assign') && patch.assigneeId !== me.id) {
                throw new ForbiddenException('You do not have permission to assign this task to someone else', 'FORBIDDEN');
            }
            if (patch.assigneeId) await assertAssignable(projectId, patch.assigneeId);
        }

        const sets = [];
        const params = [taskId];
        for (const [key, column] of Object.entries(UPDATABLE)) {
            if (key in patch) {
                params.push(patch[key] ?? null);
                sets.push(`${column} = $${params.length}`); // column names come from the constant map, never from input
            }
        }
        await db.query(`UPDATE tasks SET ${sets.join(', ')} WHERE id = $1`, params);

        const statusChanged = patch.status && patch.status !== task.status;
        await logActivity({
            workspaceId, projectId, entityType: 'task', entityId: taskId,
            action: statusChanged ? 'task.status_changed' : assigneeChanged ? 'task.assigned' : 'task.updated',
            metadata: { title: patch.title ?? task.title, ...(statusChanged && { from: task.status, to: patch.status }) },
        });
    });
    return getTask(taskId);
}

export async function deleteTask(taskId) {
    const { workspaceId, projectId } = scopeOf();
    await db.transaction(async () => {
        await assertProjectWritable(projectId);
        const t = await db.first('DELETE FROM tasks WHERE id = $1 RETURNING title', [taskId]);
        await logActivity({ workspaceId, projectId, action: 'task.deleted', entityType: 'task', metadata: { title: t.title } });
    });
}

/** Bulk delete. Every id must belong to THIS project, otherwise nothing is deleted (stops id-guessing across projects). */
export async function bulkDelete(projectId, { taskIds }) {
    const { workspaceId } = scopeOf();
    const unique = [...new Set(taskIds)];
    return db.transaction(async () => {
        await assertProjectWritable(projectId);
        const deleted = await db.rows('DELETE FROM tasks WHERE project_id = $1 AND id = ANY($2::uuid[]) RETURNING id', [projectId, unique]);
        if (deleted.length !== unique.length) {
            throw new NotFoundException('Some of the selected tasks do not exist in this project. Nothing was deleted.', 'TASKS_NOT_FOUND');
        }
        await logActivity({ workspaceId, projectId, action: 'task.deleted', entityType: 'task', metadata: { count: deleted.length } });
        return { deleted: deleted.length };
    });
}

/** Tasks assigned to me in this workspace. */
export async function myTasks(workspaceId) {
    const rows = await db.rows(
        `${TASK_SELECT} WHERE p.workspace_id = $1 AND t.assignee_id = $2 ORDER BY (t.status = 'DONE'), t.due_date`,
        [workspaceId, currentUser().id],
    );
    return rows.map(toDto);
}
