import { z } from 'zod';
import { dateOnly, idParam, optionalText, pagination, uuid } from '../../utils/validators.js';

const status = z.enum(['TODO', 'IN_PROGRESS', 'DONE']);
const type = z.enum(['TASK', 'BUG', 'FEATURE', 'IMPROVEMENT', 'OTHER']);
const priority = z.enum(['LOW', 'MEDIUM', 'HIGH']);
const title = z.string().trim().min(1, 'Title is required').max(200);
const assignee = z.preprocess((v) => (v === '' ? null : v), uuid.nullish());

export const listTasksSchema = {
    params: idParam('projectId'),
    query: pagination.extend({ limit: z.coerce.number().int().min(1).max(200).default(100) }).extend({
        status: status.optional(),
        type: type.optional(),
        priority: priority.optional(),
        assigneeId: uuid.optional(),
        search: z.string().trim().max(100).optional(),
    }),
};

export const createTaskSchema = {
    params: idParam('projectId'),
    body: z.object({
        title,
        description: optionalText(5000),
        type: type.default('TASK'),
        status: status.default('TODO'),
        priority: priority.default('MEDIUM'),
        assigneeId: assignee,
        due_date: dateOnly,
    }),
};

export const updateTaskSchema = {
    params: idParam('taskId'),
    body: z
        .object({
            title: title.optional(),
            description: optionalText(5000),
            type: type.optional(),
            status: status.optional(),
            priority: priority.optional(),
            assigneeId: assignee,
            due_date: dateOnly.optional(),
        })
        .refine((b) => Object.keys(b).length > 0, 'Provide at least one field to update'),
};

export const taskIdSchema = { params: idParam('taskId') };
export const bulkDeleteSchema = {
    params: idParam('projectId'),
    body: z.object({ taskIds: z.array(uuid).min(1, 'Select at least one task').max(200) }),
};
export const myTasksSchema = { params: idParam('workspaceId') };
