import { randomUUID } from 'node:crypto';
import { db } from '../../db/pool.js';
import { env } from '../../config/env.js';
import { currentUser } from '../../core/context.js';
import { ForbiddenException, TooManyRequestsException, UnauthorizedException } from '../../core/exceptions.js';
import { hashPassword, verifyPassword, burnPasswordCheck } from '../../utils/password.js';
import { generateRefreshToken, hashToken, signAccessToken } from '../../utils/tokens.js';
import { getMe } from '../users/users.service.js';

const REUSE_GRACE_MS = 10_000; // tolerate two tabs refreshing with the same cookie at the same moment

/** Creates a refresh-token row (inside a session "family") and a fresh access token. */
async function createSession(user, meta, familyId = randomUUID()) {
    const refreshToken = generateRefreshToken();
    const expiresAt = new Date(Date.now() + env.refreshTokenTtlDays * 86_400_000);
    const row = await db.first(
        `INSERT INTO refresh_tokens (user_id, family_id, token_hash, expires_at, user_agent, ip)
         VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
        [user.id, familyId, hashToken(refreshToken), expiresAt, meta.userAgent?.slice(0, 300) ?? null, meta.ip ?? null],
    );
    return { refreshToken, refreshTokenId: row.id, accessToken: signAccessToken(user) };
}

const sessionResult = async (userId, session) => ({
    accessToken: session.accessToken,
    refreshToken: session.refreshToken,
    tokenType: 'Bearer',
    expiresIn: env.accessTokenTtlSeconds,
    user: await getMe(userId),
});

export async function login({ email, password }, meta) {
    const row = await db.first(
        `SELECT u.id, u.token_version, u.deactivated_at, c.password_hash, c.locked_until
           FROM users u LEFT JOIN user_credentials c ON c.user_id = u.id WHERE u.email = $1`,
        [email],
    );
    if (!row?.password_hash) {
        await burnPasswordCheck(password); // keep timing similar whether or not the email exists
        throw new UnauthorizedException('Invalid email or password', 'INVALID_CREDENTIALS');
    }
    if (row.locked_until && row.locked_until > new Date()) {
        const retryAfterSeconds = Math.ceil((row.locked_until - Date.now()) / 1000);
        throw new TooManyRequestsException('Too many failed attempts. This account is temporarily locked.', 'ACCOUNT_LOCKED', { retryAfterSeconds });
    }

    if (!(await verifyPassword(password, row.password_hash))) {
        await db.query(
            `UPDATE user_credentials
                SET failed_attempts = CASE WHEN failed_attempts + 1 >= $2 THEN 0 ELSE failed_attempts + 1 END,
                    locked_until    = CASE WHEN failed_attempts + 1 >= $2 THEN now() + make_interval(mins => $3::int) ELSE locked_until END
              WHERE user_id = $1`,
            [row.id, env.maxFailedLogins, env.lockoutMinutes],
        );
        throw new UnauthorizedException('Invalid email or password', 'INVALID_CREDENTIALS');
    }
    if (row.deactivated_at) throw new ForbiddenException('This account has been deactivated. Contact your administrator.', 'ACCOUNT_DEACTIVATED');

    const session = await db.transaction(async () => {
        await db.query('UPDATE user_credentials SET failed_attempts = 0, locked_until = NULL WHERE user_id = $1', [row.id]);
        await db.query('UPDATE users SET last_login_at = now() WHERE id = $1', [row.id]);
        await db.query(`DELETE FROM refresh_tokens WHERE user_id = $1 AND expires_at < now() - interval '1 day'`, [row.id]); // housekeeping
        return createSession(row, meta);
    });
    return sessionResult(row.id, session);
}

/** Rotates the refresh token. A token that was already used (outside the grace window) means theft: kill the whole session family. */
export async function refresh(rawToken, meta) {
    if (!rawToken) throw new UnauthorizedException('Refresh token missing', 'REFRESH_TOKEN_MISSING');

    const outcome = await db.transaction(async () => {
        const t = await db.first(
            `SELECT t.*, u.token_version, u.deactivated_at FROM refresh_tokens t JOIN users u ON u.id = t.user_id
              WHERE t.token_hash = $1 FOR UPDATE OF t`,
            [hashToken(rawToken)],
        );
        if (!t) return { error: ['Invalid refresh token', 'REFRESH_TOKEN_INVALID'] };

        if (t.revoked_at) {
            const benign = t.replaced_by_id && Date.now() - new Date(t.revoked_at).getTime() < REUSE_GRACE_MS;
            if (!benign) {
                await db.query('UPDATE refresh_tokens SET revoked_at = COALESCE(revoked_at, now()) WHERE family_id = $1', [t.family_id]);
                return { error: ['Refresh token was already used. Please sign in again.', 'REFRESH_TOKEN_REUSED'] };
            }
        } else if (new Date(t.expires_at) <= new Date()) {
            return { error: ['Refresh token expired. Please sign in again.', 'REFRESH_TOKEN_EXPIRED'] };
        }
        if (t.deactivated_at) {
            await db.query('UPDATE refresh_tokens SET revoked_at = COALESCE(revoked_at, now()) WHERE family_id = $1', [t.family_id]);
            return { error: ['This account has been deactivated', 'ACCOUNT_DEACTIVATED'] };
        }

        const session = await createSession({ id: t.user_id, token_version: t.token_version }, meta, t.family_id);
        if (!t.revoked_at) {
            await db.query('UPDATE refresh_tokens SET revoked_at = now(), replaced_by_id = $2 WHERE id = $1', [t.id, session.refreshTokenId]);
        }
        return { userId: t.user_id, session };
    });

    if (outcome.error) throw new UnauthorizedException(...outcome.error);
    return sessionResult(outcome.userId, outcome.session);
}

/** Revokes the session the cookie belongs to. Never throws (logging out twice is fine). */
export async function logout(rawToken) {
    if (!rawToken) return;
    await db.query(
        `UPDATE refresh_tokens SET revoked_at = COALESCE(revoked_at, now())
          WHERE family_id = (SELECT family_id FROM refresh_tokens WHERE token_hash = $1)`,
        [hashToken(rawToken)],
    );
}

export async function logoutAll() {
    const { id } = currentUser();
    await db.transaction(async () => {
        await db.query('UPDATE users SET token_version = token_version + 1 WHERE id = $1', [id]);
        await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [id]);
    });
}

/** Changes the caller's own password, ends all other sessions and keeps this device signed in. */
export async function changePassword({ currentPassword, newPassword }, meta) {
    const { id } = currentUser();
    const cred = await db.first('SELECT password_hash FROM user_credentials WHERE user_id = $1', [id]);
    if (!cred || !(await verifyPassword(currentPassword, cred.password_hash))) {
        throw new UnauthorizedException('Current password is incorrect', 'INVALID_CURRENT_PASSWORD');
    }
    const hash = await hashPassword(newPassword);

    const session = await db.transaction(async () => {
        await db.query(
            `UPDATE user_credentials SET password_hash = $2, password_changed_at = now(), failed_attempts = 0, locked_until = NULL WHERE user_id = $1`,
            [id, hash],
        );
        const user = await db.first('UPDATE users SET must_change_password = false, token_version = token_version + 1 WHERE id = $1 RETURNING id, token_version', [id]);
        await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [id]);
        return createSession(user, meta);
    });
    return sessionResult(id, session);
}
