import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { ok } from '../../core/response.js';
import { env } from '../../config/env.js';
import { requestMeta } from '../../core/context.js';
import { validate } from '../../middleware/validate.js';
import { authenticate } from '../../middleware/authenticate.js';
import { authLimiter } from '../../middleware/rateLimit.js';
import * as auth from './auth.service.js';
import { getMe } from '../users/users.service.js';
import { changePasswordSchema, loginSchema } from './auth.schema.js';

const router = Router();

const COOKIE = 'refresh_token';
const cookieOptions = () => ({
    httpOnly: true, // not readable from JavaScript -> not stealable via XSS
    secure: env.cookie.secure,
    sameSite: env.cookie.sameSite,
    path: '/api/v1/auth', // only sent to the auth endpoints
    domain: env.cookie.domain,
});
const setRefreshCookie = (res, token) => res.cookie(COOKIE, token, { ...cookieOptions(), maxAge: env.refreshTokenTtlDays * 86_400_000 });
const clearRefreshCookie = (res) => res.clearCookie(COOKIE, cookieOptions());

/** Refresh token goes to the httpOnly cookie only; the JSON body carries the access token + user. */
const respondWithSession = (res, result, message) => {
    setRefreshCookie(res, result.refreshToken);
    const { refreshToken, ...body } = result; // eslint-disable-line no-unused-vars
    return ok(res, body, message);
};

router.post(
    '/login',
    authLimiter,
    validate(loginSchema),
    asyncHandler(async (req, res) => respondWithSession(res, await auth.login(req.body, requestMeta()), 'Logged in successfully')),
);

router.post(
    '/refresh',
    asyncHandler(async (req, res) => {
        try {
            return respondWithSession(res, await auth.refresh(req.cookies?.[COOKIE], requestMeta()), 'Session refreshed');
        } catch (err) {
            clearRefreshCookie(res);
            throw err;
        }
    }),
);

router.post(
    '/logout',
    asyncHandler(async (req, res) => {
        await auth.logout(req.cookies?.[COOKIE]);
        clearRefreshCookie(res);
        return ok(res, null, 'Logged out');
    }),
);

// The routes below accept users who still have a temporary password (so they can change it).
router.get('/me', authenticate({ allowPasswordChangePending: true }), asyncHandler(async (req, res) => ok(res, await getMe(), 'Profile loaded')));

router.post(
    '/logout-all',
    authenticate({ allowPasswordChangePending: true }),
    asyncHandler(async (req, res) => {
        await auth.logoutAll();
        clearRefreshCookie(res);
        return ok(res, null, 'Signed out of all devices');
    }),
);

router.post(
    '/change-password',
    authLimiter,
    authenticate({ allowPasswordChangePending: true }),
    validate(changePasswordSchema),
    asyncHandler(async (req, res) => respondWithSession(res, await auth.changePassword(req.body, requestMeta()), 'Password changed successfully')),
);

export default router;
