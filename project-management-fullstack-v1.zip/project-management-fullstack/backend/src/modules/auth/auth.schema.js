import { z } from 'zod';
import { email, password } from '../../utils/validators.js';

export const loginSchema = {
    body: z.object({ email, password: z.string().min(1, 'Password is required').max(200) }),
};

export const changePasswordSchema = {
    body: z
        .object({ currentPassword: z.string().min(1, 'Current password is required').max(200), newPassword: password })
        .refine((b) => b.currentPassword !== b.newPassword, { path: ['newPassword'], message: 'New password must be different from the current one' }),
};
