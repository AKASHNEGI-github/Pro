import { z } from 'zod';
import { idParam, uuid } from '../../utils/validators.js';

export const listActivitySchema = {
    params: idParam('workspaceId'),
    query: z.object({
        limit: z.coerce.number().int().min(1).max(100).default(20),
        projectId: uuid.optional(),
    }),
};
