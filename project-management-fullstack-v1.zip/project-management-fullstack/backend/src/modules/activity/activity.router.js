import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { ok } from '../../core/response.js';
import { validate } from '../../middleware/validate.js';
import { authorize } from '../../rbac/authorize.js';
import { listActivity } from './activity.service.js';
import { listActivitySchema } from './activity.schema.js';

// mounted at /workspaces/:workspaceId/activity
const router = Router({ mergeParams: true });

router.get(
    '/',
    validate(listActivitySchema),
    authorize('workspace.view', { workspace: 'workspaceId' }),
    asyncHandler(async (req, res) => ok(res, await listActivity(req.params.workspaceId, req.query), 'Activity loaded')),
);

export default router;
