import { db } from '../../db/pool.js';
import { currentUserId } from '../../core/context.js';
import { USER_JSON_NULLABLE, userFromJson, removedUser } from '../../utils/mappers.js';
import { permissionsOf } from '../../rbac/authorize.js';

/** Append an entry to the activity feed. Call it inside the same transaction as the change it describes. */
export async function logActivity({ workspaceId, projectId = null, action, entityType, entityId = null, metadata = {} }) {
    await db.query(
        `INSERT INTO activity_logs (workspace_id, project_id, actor_id, action, entity_type, entity_id, metadata)
         VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb)`,
        [workspaceId, projectId, currentUserId(), action, entityType, entityId, JSON.stringify(metadata)],
    );
}

/** Workspace feed. Project-level entries are only shown for projects the user can view. */
export async function listActivity(workspaceId, { limit, projectId }) {
    const seeAll = permissionsOf().has('project.view');
    const rows = await db.rows(
        `SELECT a.id, a.action, a.entity_type, a.entity_id, a.project_id, a.metadata, a.created_at,
                ${USER_JSON_NULLABLE('u')} AS actor, p.name AS project_name
           FROM activity_logs a
           LEFT JOIN users u ON u.id = a.actor_id
           LEFT JOIN projects p ON p.id = a.project_id
          WHERE a.workspace_id = $1
            AND ($4::uuid IS NULL OR a.project_id = $4::uuid)
            AND (a.project_id IS NULL OR $2::boolean OR EXISTS (
                   SELECT 1 FROM project_members pm WHERE pm.project_id = a.project_id AND pm.user_id = $5))
          ORDER BY a.created_at DESC, a.id DESC
          LIMIT $3`,
        [workspaceId, seeAll, limit, projectId ?? null, currentUserId()],
    );
    return rows.map((r) => ({
        id: r.id,
        action: r.action,
        entityType: r.entity_type,
        entityId: r.entity_id,
        projectId: r.project_id,
        projectName: r.project_name,
        metadata: r.metadata,
        createdAt: r.created_at,
        actor: r.actor ? userFromJson(r.actor) : removedUser(),
    }));
}
