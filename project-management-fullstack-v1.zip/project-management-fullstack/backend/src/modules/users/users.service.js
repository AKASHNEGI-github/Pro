import { db } from '../../db/pool.js';
import { currentUser } from '../../core/context.js';
import { NotFoundException } from '../../core/exceptions.js';
import { imageOrAvatar } from '../../utils/mappers.js';
import { hashPassword } from '../../utils/password.js';
import { removeUploadedFile, publicPathFor } from '../../utils/files.js';

/** The signed-in user's profile + the permissions their GLOBAL role grants. */
export async function getMe(userId = currentUser().id) {
    const u = await db.first(
        `SELECT u.id, u.name, u.email, u.image_url, u.must_change_password, u.created_at, u.updated_at,
                r.id AS role_id, r.name AS role_name, r.system_key
           FROM users u JOIN roles r ON r.id = u.global_role_id WHERE u.id = $1`,
        [userId],
    );
    if (!u) throw new NotFoundException('User not found', 'USER_NOT_FOUND');
    const perms = await db.rows(
        `SELECT p.key FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id
          WHERE rp.role_id = $1 ORDER BY p.key`,
        [u.role_id],
    );
    return {
        id: u.id,
        name: u.name,
        email: u.email,
        image: imageOrAvatar(u.image_url, u.name),
        hasCustomImage: Boolean(u.image_url),
        mustChangePassword: u.must_change_password,
        createdAt: u.created_at,
        updatedAt: u.updated_at,
        globalRole: { id: u.role_id, name: u.role_name, key: u.system_key },
        permissions: perms.map((p) => p.key),
    };
}

export async function updateProfile({ name }) {
    await db.query('UPDATE users SET name = $2 WHERE id = $1', [currentUser().id, name]);
    return getMe();
}

export async function setAvatar(file) {
    const me = currentUser();
    const old = await db.first('SELECT image_url FROM users WHERE id = $1', [me.id]);
    await db.query('UPDATE users SET image_url = $2 WHERE id = $1', [me.id, publicPathFor(file)]);
    await removeUploadedFile(old?.image_url);
    return getMe();
}

export async function removeAvatar() {
    const me = currentUser();
    const old = await db.first('SELECT image_url FROM users WHERE id = $1', [me.id]);
    await db.query(`UPDATE users SET image_url = '' WHERE id = $1`, [me.id]);
    await removeUploadedFile(old?.image_url);
    return getMe();
}

/**
 * Sets a new password for any user (used by admin reset + workspace-admin reset).
 * The user must choose their own password at next login, and every existing session is revoked.
 */
export async function setUserPassword(userId, plainPassword, { mustChange = true } = {}) {
    const hash = await hashPassword(plainPassword);
    await db.transaction(async () => {
        await db.query(
            `INSERT INTO user_credentials (user_id, password_hash) VALUES ($1, $2)
             ON CONFLICT (user_id) DO UPDATE
                SET password_hash = EXCLUDED.password_hash, password_changed_at = now(), failed_attempts = 0, locked_until = NULL`,
            [userId, hash],
        );
        await db.query('UPDATE users SET must_change_password = $2, token_version = token_version + 1 WHERE id = $1', [userId, mustChange]);
        await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [userId]);
    });
}
