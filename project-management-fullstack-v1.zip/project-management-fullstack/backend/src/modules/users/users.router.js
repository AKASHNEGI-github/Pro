import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { BadRequestException } from '../../core/exceptions.js';
import { ok } from '../../core/response.js';
import { validate } from '../../middleware/validate.js';
import { imageUpload } from '../../middleware/upload.js';
import * as users from './users.service.js';
import { updateProfileSchema } from './users.schema.js';

const router = Router();

router.get('/me', asyncHandler(async (req, res) => ok(res, await users.getMe(), 'Profile loaded')));

router.patch('/me', validate(updateProfileSchema), asyncHandler(async (req, res) => ok(res, await users.updateProfile(req.body), 'Profile updated')));

router.post(
    '/me/avatar',
    imageUpload('avatars', 'avatar'),
    asyncHandler(async (req, res) => {
        if (!req.file) throw new BadRequestException('Choose an image to upload', 'FILE_REQUIRED');
        return ok(res, await users.setAvatar(req.file), 'Profile photo updated');
    }),
);

router.delete('/me/avatar', asyncHandler(async (req, res) => ok(res, await users.removeAvatar(), 'Profile photo removed')));

export default router;
