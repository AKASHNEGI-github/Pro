import { z } from 'zod';
import { name } from '../../utils/validators.js';

export const updateProfileSchema = { body: z.object({ name: name(100) }) };
