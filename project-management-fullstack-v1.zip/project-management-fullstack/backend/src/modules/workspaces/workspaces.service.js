import { db } from '../../db/pool.js';
import { currentUser } from '../../core/context.js';
import { BadRequestException, ConflictException, ForbiddenException, NotFoundException } from '../../core/exceptions.js';
import { loadPermissions } from '../../rbac/authz.js';
import { permissionsOf } from '../../rbac/authorize.js';
import { PERMISSIONS } from '../../rbac/permissions.js';
import { systemRoleId } from '../../rbac/sync.js';
import { USER_JSON, USER_JSON_NULLABLE, projectDto, roleRef, taskDto, userFromJson, workspaceDto } from '../../utils/mappers.js';
import { publicPathFor, removeUploadedFile } from '../../utils/files.js';
import { slugify } from '../../utils/slug.js';
import { logActivity } from '../activity/activity.service.js';

const PROJECT_PERMISSION_KEYS = new Set(PERMISSIONS.filter((p) => p.scope === 'PROJECT').map((p) => p.key));

/** Workspaces the user can see: all of them for global admins, otherwise the ones they belong to. */
export async function listMine() {
    const me = currentUser();
    const seeAll = (await loadPermissions()).has('workspace.view');
    const rows = await db.rows(
        `SELECT w.*, r.id AS role_id, r.name AS role_name, r.system_key,
                (SELECT count(*) FROM workspace_members m WHERE m.workspace_id = w.id) AS members_count
           FROM workspaces w
           LEFT JOIN workspace_members me ON me.workspace_id = w.id AND me.user_id = $1
           LEFT JOIN roles r ON r.id = me.role_id
          WHERE $2::boolean OR me.user_id IS NOT NULL
          ORDER BY lower(w.name)`,
        [me.id, seeAll],
    );
    return rows.map((r) => ({ ...workspaceDto(r), membersCount: r.members_count, myRole: roleRef(r.role_id, r.role_name, r.system_key) }));
}

async function uniqueSlug(base) {
    const root = slugify(base) || 'workspace';
    for (let i = 0; i < 20; i += 1) {
        const candidate = i === 0 ? root : `${root}-${i + 1}`;
        if (!(await db.first('SELECT 1 FROM workspaces WHERE slug = $1', [candidate]))) return candidate;
    }
    return `${root}-${Math.random().toString(36).slice(2, 7)}`;
}

export async function createWorkspace({ name, slug, description, ownerEmail }, file) {
    const me = currentUser();
    const logo = publicPathFor(file);
    const id = await db.transaction(async () => {
        if (slug) {
            if (await db.first('SELECT 1 FROM workspaces WHERE slug = $1', [slug])) throw new ConflictException('This slug is already taken', 'SLUG_TAKEN');
        }
        let ownerId = me.id;
        if (ownerEmail && ownerEmail !== me.email) {
            const owner = await db.first('SELECT id, deactivated_at FROM users WHERE email = $1', [ownerEmail]);
            if (!owner || owner.deactivated_at) throw new NotFoundException('No active user with that email. Create the account first (Org Admin > Users).', 'OWNER_NOT_FOUND');
            ownerId = owner.id;
        }
        const ws = await db.first(
            `INSERT INTO workspaces (name, slug, description, image_url, owner_id) VALUES ($1, $2, $3, $4, $5) RETURNING id`,
            [name, slug ?? (await uniqueSlug(name)), description, logo ?? '', ownerId],
        );
        await db.query(
            `INSERT INTO workspace_members (workspace_id, user_id, role_id, added_by) VALUES ($1, $2, $3, $4)`,
            [ws.id, ownerId, await systemRoleId('WORKSPACE_ADMIN'), me.id],
        );
        await logActivity({ workspaceId: ws.id, action: 'workspace.created', entityType: 'workspace', entityId: ws.id, metadata: { name } });
        return ws.id;
    });
    return getOne(id, await loadPermissions({ workspaceId: id }));
}

export async function getOne(workspaceId, perms = permissionsOf()) {
    const me = currentUser();
    const row = await db.first(
        `SELECT w.*, ${USER_JSON('o')} AS owner, r.id AS role_id, r.name AS role_name, r.system_key,
                (SELECT count(*) FROM workspace_members m WHERE m.workspace_id = w.id) AS members_count
           FROM workspaces w JOIN users o ON o.id = w.owner_id
           LEFT JOIN workspace_members me ON me.workspace_id = w.id AND me.user_id = $2
           LEFT JOIN roles r ON r.id = me.role_id
          WHERE w.id = $1`,
        [workspaceId, me.id],
    );
    if (!row) throw new NotFoundException('Workspace not found', 'WORKSPACE_NOT_FOUND');
    return {
        ...workspaceDto(row),
        owner: userFromJson(row.owner),
        membersCount: row.members_count,
        myRole: roleRef(row.role_id, row.role_name, row.system_key),
        permissions: [...perms],
    };
}

/**
 * Everything the UI needs for one workspace in a single call, shaped like the frontend's data model:
 * members, the projects THIS user may see (all of them for workspace admins, otherwise only their own),
 * each project's members and tasks, plus the effective permissions at workspace and project level.
 */
export async function getOverview(workspaceId) {
    const me = currentUser();
    const wsPerms = permissionsOf();
    const seeAllProjects = wsPerms.has('project.view');

    const base = await getOne(workspaceId, wsPerms);

    const members = wsPerms.has('workspace.member.view')
        ? await db.rows(
              `SELECT wm.user_id, wm.message, wm.joined_at, r.id AS role_id, r.name AS role_name, r.system_key, ${USER_JSON('u')} AS "user"
                 FROM workspace_members wm JOIN users u ON u.id = wm.user_id JOIN roles r ON r.id = wm.role_id
                WHERE wm.workspace_id = $1 ORDER BY wm.joined_at, lower(u.name)`,
              [workspaceId],
          )
        : [];

    const projects = await db.rows(
        `SELECT p.* FROM projects p
          WHERE p.workspace_id = $1
            AND ($2::boolean OR EXISTS (
                  SELECT 1 FROM project_members pm
                    JOIN role_permissions rp ON rp.role_id = pm.role_id
                    JOIN permissions pr ON pr.id = rp.permission_id AND pr.key = 'project.view'
                   WHERE pm.project_id = p.id AND pm.user_id = $3))
          ORDER BY p.created_at`,
        [workspaceId, seeAllProjects, me.id],
    );
    const ids = projects.map((p) => p.id);

    const [projectMembers, tasks, myProjectPerms] = ids.length
        ? await Promise.all([
              db.rows(
                  `SELECT pm.project_id, pm.user_id, r.id AS role_id, r.name AS role_name, r.system_key, ${USER_JSON('u')} AS "user"
                     FROM project_members pm JOIN users u ON u.id = pm.user_id JOIN roles r ON r.id = pm.role_id
                    WHERE pm.project_id = ANY($1::uuid[]) ORDER BY pm.added_at, lower(u.name)`,
                  [ids],
              ),
              db.rows(
                  `SELECT t.*, ${USER_JSON_NULLABLE('a')} AS assignee,
                          (SELECT count(*) FROM comments c WHERE c.task_id = t.id) AS comments_count
                     FROM tasks t LEFT JOIN users a ON a.id = t.assignee_id
                    WHERE t.project_id = ANY($1::uuid[]) ORDER BY t.created_at`,
                  [ids],
              ),
              db.rows(
                  `SELECT pm.project_id, array_agg(DISTINCT pr.key) AS keys
                     FROM project_members pm
                     JOIN role_permissions rp ON rp.role_id = pm.role_id
                     JOIN permissions pr ON pr.id = rp.permission_id
                    WHERE pm.user_id = $1 AND pm.project_id = ANY($2::uuid[]) GROUP BY pm.project_id`,
                  [me.id, ids],
              ),
          ])
        : [[], [], []];

    const workspaceWidePerms = [...wsPerms].filter((k) => PROJECT_PERMISSION_KEYS.has(k));
    const ownPerms = new Map(myProjectPerms.map((r) => [r.project_id, r.keys]));

    const projectList = projects.map((p) => {
        const perms = new Set([...workspaceWidePerms, ...(ownPerms.get(p.id) ?? [])]);
        return {
            ...projectDto(p),
            permissions: [...perms],
            members: projectMembers
                .filter((m) => m.project_id === p.id)
                .map((m) => ({ id: `${p.id}:${m.user_id}`, userId: m.user_id, projectId: p.id, role: roleRef(m.role_id, m.role_name, m.system_key), user: userFromJson(m.user) })),
            tasks: perms.has('task.view')
                ? tasks
                      .filter((t) => t.project_id === p.id)
                      .map((t) => ({ ...taskDto(t), commentsCount: t.comments_count, assignee: t.assignee ? userFromJson(t.assignee) : null }))
                : [],
        };
    });

    return {
        ...base,
        members: members.map((m) => ({
            id: `${workspaceId}:${m.user_id}`,
            userId: m.user_id,
            workspaceId,
            message: m.message,
            joinedAt: m.joined_at,
            role: roleRef(m.role_id, m.role_name, m.system_key),
            user: userFromJson(m.user),
        })),
        projects: projectList,
    };
}

export async function updateWorkspace(workspaceId, patch) {
    await db.transaction(async () => {
        if (patch.slug && (await db.first('SELECT 1 FROM workspaces WHERE slug = $1 AND id <> $2', [patch.slug, workspaceId]))) {
            throw new ConflictException('This slug is already taken', 'SLUG_TAKEN');
        }
        await db.query(
            `UPDATE workspaces SET name = COALESCE($2, name), slug = COALESCE($3, slug),
                    description = CASE WHEN $4::boolean THEN $5 ELSE description END
              WHERE id = $1`,
            [workspaceId, patch.name ?? null, patch.slug ?? null, 'description' in patch, patch.description ?? null],
        );
        await logActivity({ workspaceId, action: 'workspace.updated', entityType: 'workspace', entityId: workspaceId, metadata: { name: patch.name } });
    });
    return getOne(workspaceId);
}

export async function setLogo(workspaceId, file) {
    if (!file) throw new BadRequestException('Choose an image to upload', 'FILE_REQUIRED');
    const old = await db.first('SELECT image_url FROM workspaces WHERE id = $1', [workspaceId]);
    await db.query('UPDATE workspaces SET image_url = $2 WHERE id = $1', [workspaceId, publicPathFor(file)]);
    await removeUploadedFile(old?.image_url);
    return getOne(workspaceId);
}

export async function removeLogo(workspaceId) {
    const old = await db.first('SELECT image_url FROM workspaces WHERE id = $1', [workspaceId]);
    await db.query(`UPDATE workspaces SET image_url = '' WHERE id = $1`, [workspaceId]);
    await removeUploadedFile(old?.image_url);
    return getOne(workspaceId);
}

/** Only the owner (or an Org Admin) can delete a workspace; everything inside is removed by FK cascades. */
export async function deleteWorkspace(workspaceId) {
    const me = currentUser();
    const ws = await db.first('SELECT id, name, owner_id, image_url FROM workspaces WHERE id = $1', [workspaceId]);
    const isGlobalAdmin = (await loadPermissions()).has('workspace.delete');
    if (ws.owner_id !== me.id && !isGlobalAdmin) {
        throw new ForbiddenException('Only the workspace owner can delete the workspace', 'OWNER_ONLY');
    }
    await db.query('DELETE FROM workspaces WHERE id = $1', [workspaceId]);
    await removeUploadedFile(ws.image_url);
}

export async function transferOwnership(workspaceId, { userId }) {
    const me = currentUser();
    await db.transaction(async () => {
        const ws = await db.first('SELECT owner_id FROM workspaces WHERE id = $1 FOR UPDATE', [workspaceId]);
        const isGlobalAdmin = (await loadPermissions()).has('user.manage');
        if (ws.owner_id !== me.id && !isGlobalAdmin) throw new ForbiddenException('Only the current owner can transfer ownership', 'OWNER_ONLY');
        if (ws.owner_id === userId) throw new BadRequestException('That user already owns this workspace', 'ALREADY_OWNER');

        const member = await db.first(
            `SELECT u.name, u.deactivated_at FROM workspace_members wm JOIN users u ON u.id = wm.user_id WHERE wm.workspace_id = $1 AND wm.user_id = $2`,
            [workspaceId, userId],
        );
        if (!member) throw new BadRequestException('The new owner must already be a member of this workspace', 'NOT_A_MEMBER');
        if (member.deactivated_at) throw new BadRequestException('The new owner account is deactivated', 'USER_DEACTIVATED');

        await db.query('UPDATE workspace_members SET role_id = $3 WHERE workspace_id = $1 AND user_id = $2', [workspaceId, userId, await systemRoleId('WORKSPACE_ADMIN')]);
        await db.query('UPDATE workspaces SET owner_id = $2 WHERE id = $1', [workspaceId, userId]);
        await logActivity({ workspaceId, action: 'workspace.ownership_transferred', entityType: 'workspace', entityId: workspaceId, metadata: { to: member.name } });
    });
    return getOne(workspaceId, await loadPermissions({ workspaceId }));
}
