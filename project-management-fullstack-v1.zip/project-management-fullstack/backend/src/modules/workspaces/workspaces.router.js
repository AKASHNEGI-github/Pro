import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { created, ok } from '../../core/response.js';
import { validate } from '../../middleware/validate.js';
import { imageUpload } from '../../middleware/upload.js';
import { authorize } from '../../rbac/authorize.js';
import * as ws from './workspaces.service.js';
import { createWorkspaceSchema, transferOwnershipSchema, updateWorkspaceSchema, workspaceIdSchema } from './workspaces.schema.js';
import membersRouter from '../members/members.router.js';
import rolesRouter from '../roles/roles.router.js';
import activityRouter from '../activity/activity.router.js';
import { workspaceProjectsRouter } from '../projects/projects.router.js';
import { myTasksRouter } from '../tasks/tasks.router.js';

const router = Router();
const scope = { workspace: 'workspaceId' };

router.get('/', asyncHandler(async (req, res) => ok(res, await ws.listMine(), 'Workspaces loaded')));

// Only holders of the global `workspace.create` permission (Org Admin by default) can create workspaces.
router.post(
    '/',
    authorize('workspace.create'),
    imageUpload('logos', 'logo'),
    validate(createWorkspaceSchema),
    asyncHandler(async (req, res) => created(res, await ws.createWorkspace(req.body, req.file), 'Workspace created')),
);

router.get('/:workspaceId', validate(workspaceIdSchema), authorize('workspace.view', scope),
    asyncHandler(async (req, res) => ok(res, await ws.getOne(req.params.workspaceId), 'Workspace loaded')));

router.get('/:workspaceId/overview', validate(workspaceIdSchema), authorize('workspace.view', scope),
    asyncHandler(async (req, res) => ok(res, await ws.getOverview(req.params.workspaceId), 'Workspace overview loaded')));

router.patch('/:workspaceId', validate(updateWorkspaceSchema), authorize('workspace.update', scope),
    asyncHandler(async (req, res) => ok(res, await ws.updateWorkspace(req.params.workspaceId, req.body), 'Workspace updated')));

router.post('/:workspaceId/logo', validate(workspaceIdSchema), authorize('workspace.update', scope), imageUpload('logos', 'logo'),
    asyncHandler(async (req, res) => ok(res, await ws.setLogo(req.params.workspaceId, req.file), 'Logo updated')));

router.delete('/:workspaceId/logo', validate(workspaceIdSchema), authorize('workspace.update', scope),
    asyncHandler(async (req, res) => ok(res, await ws.removeLogo(req.params.workspaceId), 'Logo removed')));

router.post('/:workspaceId/transfer-ownership', validate(transferOwnershipSchema), authorize('workspace.update', scope),
    asyncHandler(async (req, res) => ok(res, await ws.transferOwnership(req.params.workspaceId, req.body), 'Ownership transferred')));

router.delete('/:workspaceId', validate(workspaceIdSchema), authorize('workspace.delete', scope),
    asyncHandler(async (req, res) => { await ws.deleteWorkspace(req.params.workspaceId); return ok(res, null, 'Workspace deleted'); }));

// Nested resources
router.use('/:workspaceId/members', membersRouter);
router.use('/:workspaceId/roles', rolesRouter);
router.use('/:workspaceId/projects', workspaceProjectsRouter);
router.use('/:workspaceId/activity', activityRouter);
router.use('/:workspaceId/my-tasks', myTasksRouter);

export default router;
