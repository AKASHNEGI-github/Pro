import { z } from 'zod';
import { email, idParam, optionalText, uuid } from '../../utils/validators.js';

const slug = z
    .string()
    .trim()
    .toLowerCase()
    .min(2, 'Slug must be at least 2 characters')
    .max(60)
    .regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'Use lowercase letters, numbers and single hyphens only');
const wsName = z.string().trim().min(2, 'Name must be at least 2 characters').max(80);

// multipart/form-data sends every field as a string; empty strings mean "not provided".
const emptyToUndef = (v) => (v === '' ? undefined : v);

export const createWorkspaceSchema = {
    body: z.object({
        name: wsName,
        slug: z.preprocess(emptyToUndef, slug.optional()),
        description: optionalText(500),
        ownerEmail: z.preprocess(emptyToUndef, email.optional()),
    }),
};
export const workspaceIdSchema = { params: idParam('workspaceId') };
export const updateWorkspaceSchema = {
    params: idParam('workspaceId'),
    body: z
        .object({ name: wsName.optional(), slug: slug.optional(), description: optionalText(500) })
        .refine((b) => Object.keys(b).length > 0, 'Provide at least one field to update'),
};
export const transferOwnershipSchema = {
    params: idParam('workspaceId'),
    body: z.object({ userId: uuid }),
};
