import { db } from '../../db/pool.js';
import { currentUser } from '../../core/context.js';
import { BadRequestException, ConflictException, ForbiddenException, NotFoundException, ValidationException } from '../../core/exceptions.js';
import { loadPermissions } from '../../rbac/authz.js';
import { permissionsOf, scopeOf } from '../../rbac/authorize.js';
import { systemRoleId } from '../../rbac/sync.js';
import { USER_JSON, projectDto, roleRef, userFromJson } from '../../utils/mappers.js';
import { logActivity } from '../activity/activity.service.js';
import { resolveAssignableRole } from '../roles/roles.service.js';

/** SQL predicate: project visible to user $3 (or everything when $2 = true, i.e. workspace-wide project.view). */
const VISIBLE = `($2::boolean OR EXISTS (
    SELECT 1 FROM project_members pm
      JOIN role_permissions rp ON rp.role_id = pm.role_id
      JOIN permissions pr ON pr.id = rp.permission_id AND pr.key = 'project.view'
     WHERE pm.project_id = p.id AND pm.user_id = $3))`;

export async function listProjects(workspaceId) {
    const rows = await db.rows(
        `SELECT p.*,
                (SELECT count(*) FROM project_members pm WHERE pm.project_id = p.id) AS members_count,
                (SELECT count(*) FROM tasks t WHERE t.project_id = p.id) AS tasks_count,
                (SELECT count(*) FROM tasks t WHERE t.project_id = p.id AND t.status = 'DONE') AS done_count
           FROM projects p WHERE p.workspace_id = $1 AND ${VISIBLE} ORDER BY p.created_at`,
        [workspaceId, permissionsOf().has('project.view'), currentUser().id],
    );
    return rows.map((r) => ({ ...projectDto(r), membersCount: r.members_count, tasksCount: r.tasks_count, doneCount: r.done_count }));
}

export async function getProject(projectId, perms = permissionsOf()) {
    const p = await db.first(
        `SELECT p.*, (SELECT count(*) FROM tasks t WHERE t.project_id = p.id) AS tasks_count FROM projects p WHERE p.id = $1`,
        [projectId],
    );
    if (!p) throw new NotFoundException('Project not found', 'PROJECT_NOT_FOUND');
    const members = await listMembers(projectId);
    return { ...projectDto(p), tasksCount: p.tasks_count, members, permissions: [...perms] };
}

export async function listMembers(projectId) {
    const rows = await db.rows(
        `SELECT pm.project_id, pm.user_id, r.id AS role_id, r.name AS role_name, r.system_key, ${USER_JSON('u')} AS "user"
           FROM project_members pm JOIN users u ON u.id = pm.user_id JOIN roles r ON r.id = pm.role_id
          WHERE pm.project_id = $1 ORDER BY pm.added_at, lower(u.name)`,
        [projectId],
    );
    return rows.map((m) => ({ id: `${projectId}:${m.user_id}`, userId: m.user_id, projectId, role: roleRef(m.role_id, m.role_name, m.system_key), user: userFromJson(m.user) }));
}

/** Closed projects (completed / cancelled) are read-only for everyone except those who can edit the project itself. */
export async function assertProjectWritable(projectId, perms = permissionsOf()) {
    const p = await db.first('SELECT status FROM projects WHERE id = $1', [projectId]);
    if (p && ['COMPLETED', 'CANCELLED'].includes(p.status) && !perms.has('project.update')) {
        throw new ForbiddenException('This project is closed (completed or cancelled) and is read-only. A project manager can reopen it.', 'PROJECT_READ_ONLY');
    }
}

export async function createProject(workspaceId, body) {
    const me = currentUser();
    const id = await db.transaction(async () => {
        const memberIds = [...new Set([body.team_lead, ...body.member_ids])];

        // Workspace isolation: everyone on a project must already belong to this workspace.
        const valid = await db.rows(
            `SELECT wm.user_id FROM workspace_members wm JOIN users u ON u.id = wm.user_id
              WHERE wm.workspace_id = $1 AND wm.user_id = ANY($2::uuid[]) AND u.deactivated_at IS NULL`,
            [workspaceId, memberIds],
        );
        if (valid.length !== memberIds.length) {
            throw new BadRequestException('The team lead and every member must be active members of this workspace. Onboard them to the workspace first.', 'NOT_WORKSPACE_MEMBER');
        }

        const project = await db.first(
            `INSERT INTO projects (workspace_id, name, description, status, priority, start_date, end_date, team_lead_id, progress, created_by)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING id`,
            [workspaceId, body.name, body.description, body.status, body.priority, body.start_date ?? null, body.end_date ?? null, body.team_lead, body.progress, me.id],
        );
        await db.query(
            `INSERT INTO project_members (project_id, user_id, role_id, added_by)
             SELECT $1, u, CASE WHEN u = $3::uuid THEN $4::uuid ELSE $5::uuid END, $6 FROM unnest($2::uuid[]) AS u`,
            [project.id, memberIds, body.team_lead, await systemRoleId('PROJECT_MANAGER'), await systemRoleId('PROJECT_MEMBER'), me.id],
        );
        await logActivity({ workspaceId, projectId: project.id, action: 'project.created', entityType: 'project', entityId: project.id, metadata: { name: body.name } });
        return project.id;
    });
    return getProject(id, await loadPermissions({ workspaceId, projectId: id }));
}

const UPDATABLE = {
    name: 'name', description: 'description', status: 'status', priority: 'priority',
    start_date: 'start_date', end_date: 'end_date', progress: 'progress', team_lead: 'team_lead_id',
};

export async function updateProject(projectId, patch) {
    const perms = permissionsOf();
    const { workspaceId } = scopeOf();
    await db.transaction(async () => {
        const current = await db.first('SELECT * FROM projects WHERE id = $1 FOR UPDATE', [projectId]);

        const start = 'start_date' in patch ? patch.start_date : current.start_date;
        const end = 'end_date' in patch ? patch.end_date : current.end_date;
        if (start && end && end < start) {
            throw new ValidationException('Validation failed', [{ location: 'body', field: 'end_date', message: 'End date must be on or after the start date' }]);
        }

        if (patch.team_lead && patch.team_lead !== current.team_lead_id) {
            if (!perms.has('project.lead.change')) throw new ForbiddenException('You do not have permission to change the team lead', 'FORBIDDEN');
            const isMember = await db.first('SELECT 1 FROM project_members WHERE project_id = $1 AND user_id = $2', [projectId, patch.team_lead]);
            if (!isMember) throw new BadRequestException('The new team lead must already be a member of the project', 'LEAD_NOT_MEMBER');
            const [manager, member] = [await systemRoleId('PROJECT_MANAGER'), await systemRoleId('PROJECT_MEMBER')];
            await db.query('UPDATE project_members SET role_id = $3 WHERE project_id = $1 AND user_id = $2', [projectId, patch.team_lead, manager]);
            await db.query('UPDATE project_members SET role_id = $3 WHERE project_id = $1 AND user_id = $2 AND role_id = $4', [projectId, current.team_lead_id, member, manager]);
        } else {
            delete patch.team_lead;
        }

        const sets = [];
        const params = [projectId];
        for (const [key, column] of Object.entries(UPDATABLE)) {
            if (key in patch) {
                params.push(patch[key] ?? null);
                sets.push(`${column} = $${params.length}`); // column names come from the constant map above, never from input
            }
        }
        if (sets.length) await db.query(`UPDATE projects SET ${sets.join(', ')} WHERE id = $1`, params);

        await logActivity({ workspaceId, projectId, action: 'project.updated', entityType: 'project', entityId: projectId, metadata: { name: patch.name ?? current.name, fields: Object.keys(patch) } });
    });
    return getProject(projectId);
}

export async function deleteProject(projectId) {
    const { workspaceId } = scopeOf();
    await db.transaction(async () => {
        const p = await db.first('SELECT name FROM projects WHERE id = $1', [projectId]);
        await db.query('DELETE FROM projects WHERE id = $1', [projectId]);
        // projectId is null on purpose: the project (and its own log rows) no longer exist, but this entry should remain visible.
        await logActivity({ workspaceId, action: 'project.deleted', entityType: 'project', metadata: { name: p.name } });
    });
}

// ----------------------------------------------------------------------------- project members

/** Adds a user who is ALREADY in the workspace (look-up by email or id is limited to this workspace's members). */
export async function addMember(projectId, { userId, email, roleId }) {
    const { workspaceId } = scopeOf();
    const me = currentUser();
    const addedId = await db.transaction(async () => {
        const candidate = await db.first(
            `SELECT u.id, u.name, u.deactivated_at FROM workspace_members wm JOIN users u ON u.id = wm.user_id
              WHERE wm.workspace_id = $1 AND ($2::uuid IS NULL OR u.id = $2::uuid) AND ($3::citext IS NULL OR u.email = $3::citext)`,
            [workspaceId, userId ?? null, email ?? null],
        );
        if (!candidate) {
            throw new NotFoundException('No user with this email belongs to this workspace. Ask a workspace admin to onboard them to the workspace first.', 'NOT_IN_WORKSPACE');
        }
        if (candidate.deactivated_at) throw new ConflictException('This account is deactivated', 'USER_DEACTIVATED');
        if (await db.first('SELECT 1 FROM project_members WHERE project_id = $1 AND user_id = $2', [projectId, candidate.id])) {
            throw new ConflictException('This user is already a member of the project', 'ALREADY_MEMBER');
        }
        const role = await resolveAssignableRole({ roleId, scope: 'PROJECT', workspaceId, defaultKey: 'PROJECT_MEMBER' });
        await db.query('INSERT INTO project_members (project_id, user_id, role_id, added_by) VALUES ($1, $2, $3, $4)', [projectId, candidate.id, role.id, me.id]);
        await logActivity({ workspaceId, projectId, action: 'project.member_added', entityType: 'member', entityId: candidate.id, metadata: { name: candidate.name, role: role.name } });
        return candidate.id;
    });
    return (await listMembers(projectId)).find((m) => m.userId === addedId);
}

export async function updateMemberRole(projectId, userId, { roleId }) {
    const { workspaceId } = scopeOf();
    await db.transaction(async () => {
        const p = await db.first('SELECT team_lead_id FROM projects WHERE id = $1', [projectId]);
        if (userId === currentUser().id) throw new ForbiddenException('You cannot change your own role', 'SELF_ROLE_CHANGE');
        if (userId === p.team_lead_id) throw new ConflictException('The team lead is always the Project Manager. Change the team lead first.', 'LEAD_PROTECTED');
        if (!(await db.first('SELECT 1 FROM project_members WHERE project_id = $1 AND user_id = $2', [projectId, userId]))) {
            throw new NotFoundException('This user is not a member of the project', 'MEMBER_NOT_FOUND');
        }
        const role = await resolveAssignableRole({ roleId, scope: 'PROJECT', workspaceId });
        await db.query('UPDATE project_members SET role_id = $3 WHERE project_id = $1 AND user_id = $2', [projectId, userId, role.id]);
        await logActivity({ workspaceId, projectId, action: 'project.member_role_changed', entityType: 'member', entityId: userId, metadata: { role: role.name } });
    });
    return (await listMembers(projectId)).find((m) => m.userId === userId);
}

/** Tasks assigned to the removed member are un-assigned automatically (composite FK ON DELETE SET NULL). */
export async function removeMember(projectId, userId) {
    const { workspaceId } = scopeOf();
    return db.transaction(async () => {
        const p = await db.first('SELECT team_lead_id FROM projects WHERE id = $1', [projectId]);
        if (userId === p.team_lead_id) throw new ConflictException('The team lead cannot be removed. Assign a new team lead first.', 'IS_TEAM_LEAD');
        const member = await db.first('SELECT u.name FROM project_members pm JOIN users u ON u.id = pm.user_id WHERE pm.project_id = $1 AND pm.user_id = $2', [projectId, userId]);
        if (!member) throw new NotFoundException('This user is not a member of the project', 'MEMBER_NOT_FOUND');
        const { count } = await db.first('SELECT count(*) AS count FROM tasks WHERE project_id = $1 AND assignee_id = $2', [projectId, userId]);
        await db.query('DELETE FROM project_members WHERE project_id = $1 AND user_id = $2', [projectId, userId]);
        await logActivity({ workspaceId, projectId, action: 'project.member_removed', entityType: 'member', metadata: { name: member.name, unassignedTasks: count } });
        return { unassignedTasks: count };
    });
}
