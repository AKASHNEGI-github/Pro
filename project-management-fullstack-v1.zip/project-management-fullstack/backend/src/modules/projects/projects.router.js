import { Router } from 'express';
import { asyncHandler } from '../../core/asyncHandler.js';
import { created, ok } from '../../core/response.js';
import { validate } from '../../middleware/validate.js';
import { authorize } from '../../rbac/authorize.js';
import * as projects from './projects.service.js';
import {
    addProjectMemberSchema, createProjectSchema, listProjectsSchema, projectIdSchema,
    projectMemberParamsSchema, updateProjectMemberSchema, updateProjectSchema,
} from './projects.schema.js';
import { projectTasksRouter } from '../tasks/tasks.router.js';

/** Mounted at /workspaces/:workspaceId/projects */
export const workspaceProjectsRouter = Router({ mergeParams: true });

workspaceProjectsRouter.get('/', validate(listProjectsSchema), authorize('workspace.view', { workspace: 'workspaceId' }),
    asyncHandler(async (req, res) => ok(res, await projects.listProjects(req.params.workspaceId), 'Projects loaded')));

workspaceProjectsRouter.post('/', validate(createProjectSchema), authorize('project.create', { workspace: 'workspaceId' }),
    asyncHandler(async (req, res) => created(res, await projects.createProject(req.params.workspaceId, req.body), 'Project created')));

/** Mounted at /projects */
const router = Router();
const pr = { project: 'projectId' };

router.get('/:projectId', validate(projectIdSchema), authorize('project.view', pr),
    asyncHandler(async (req, res) => ok(res, await projects.getProject(req.params.projectId), 'Project loaded')));

router.patch('/:projectId', validate(updateProjectSchema), authorize('project.update', pr),
    asyncHandler(async (req, res) => ok(res, await projects.updateProject(req.params.projectId, req.body), 'Project updated')));

router.delete('/:projectId', validate(projectIdSchema), authorize('project.delete', pr),
    asyncHandler(async (req, res) => { await projects.deleteProject(req.params.projectId); return ok(res, null, 'Project deleted'); }));

router.get('/:projectId/members', validate(projectIdSchema), authorize('project.view', pr),
    asyncHandler(async (req, res) => ok(res, await projects.listMembers(req.params.projectId), 'Members loaded')));

router.post('/:projectId/members', validate(addProjectMemberSchema), authorize('project.member.add', pr),
    asyncHandler(async (req, res) => created(res, await projects.addMember(req.params.projectId, req.body), 'Member added to the project')));

router.patch('/:projectId/members/:userId', validate(updateProjectMemberSchema), authorize('project.member.update_role', pr),
    asyncHandler(async (req, res) => ok(res, await projects.updateMemberRole(req.params.projectId, req.params.userId, req.body), 'Member role updated')));

router.delete('/:projectId/members/:userId', validate(projectMemberParamsSchema), authorize('project.member.remove', pr),
    asyncHandler(async (req, res) => ok(res, await projects.removeMember(req.params.projectId, req.params.userId), 'Member removed from the project')));

router.use('/:projectId/tasks', projectTasksRouter);

export default router;
