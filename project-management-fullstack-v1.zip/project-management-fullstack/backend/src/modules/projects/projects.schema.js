import { z } from 'zod';
import { dateOnly, email, idParam, optionalText, uuid } from '../../utils/validators.js';

const status = z.enum(['PLANNING', 'ACTIVE', 'ON_HOLD', 'COMPLETED', 'CANCELLED']);
const priority = z.enum(['LOW', 'MEDIUM', 'HIGH']);
const projectName = z.string().trim().min(2, 'Project name must be at least 2 characters').max(120);
const optionalDate = z.preprocess((v) => (v === '' ? null : v), dateOnly.nullish());
const progress = z.coerce.number().int().min(0).max(100);

const endAfterStart = (b) => !b.start_date || !b.end_date || b.end_date >= b.start_date;
const dateRule = [endAfterStart, { path: ['end_date'], message: 'End date must be on or after the start date' }];

export const listProjectsSchema = { params: idParam('workspaceId') };
export const projectIdSchema = { params: idParam('projectId') };

export const createProjectSchema = {
    params: idParam('workspaceId'),
    body: z
        .object({
            name: projectName,
            description: optionalText(2000),
            status: status.default('PLANNING'),
            priority: priority.default('MEDIUM'),
            start_date: optionalDate,
            end_date: optionalDate,
            team_lead: uuid,
            member_ids: z.array(uuid).max(200).default([]),
            progress: progress.default(0),
        })
        .refine(...dateRule),
};

export const updateProjectSchema = {
    params: idParam('projectId'),
    body: z
        .object({
            name: projectName.optional(),
            description: optionalText(2000),
            status: status.optional(),
            priority: priority.optional(),
            start_date: optionalDate,
            end_date: optionalDate,
            team_lead: uuid.optional(),
            progress: progress.optional(),
        })
        .refine((b) => Object.keys(b).length > 0, 'Provide at least one field to update')
        .refine(...dateRule),
};

export const addProjectMemberSchema = {
    params: idParam('projectId'),
    body: z
        .object({ userId: uuid.optional(), email: email.optional(), roleId: uuid.optional() })
        .refine((b) => b.userId || b.email, 'Provide the member\'s email or user id'),
};
export const updateProjectMemberSchema = { params: idParam('projectId', 'userId'), body: z.object({ roleId: uuid }) };
export const projectMemberParamsSchema = { params: idParam('projectId', 'userId') };
