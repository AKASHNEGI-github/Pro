-- =============================================================================
-- Project Management App :: initial schema (PostgreSQL 15+)
-- Organization -> Workspaces -> Projects -> Tasks -> Comments, with full RBAC.
--   * global role      : users.global_role_id
--   * workspace role   : workspace_members.role_id
--   * project role     : project_members.role_id
--   * project manager  : projects.team_lead_id (always holds the Project Manager role)
-- Passwords live in user_credentials (separate from users).
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS citext;

CREATE TYPE role_scope     AS ENUM ('GLOBAL', 'WORKSPACE', 'PROJECT');
CREATE TYPE project_status AS ENUM ('PLANNING', 'ACTIVE', 'ON_HOLD', 'COMPLETED', 'CANCELLED');
CREATE TYPE priority_level AS ENUM ('LOW', 'MEDIUM', 'HIGH');
CREATE TYPE task_status    AS ENUM ('TODO', 'IN_PROGRESS', 'DONE');
CREATE TYPE task_type      AS ENUM ('TASK', 'BUG', 'FEATURE', 'IMPROVEMENT', 'OTHER');

CREATE FUNCTION set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

-- -----------------------------------------------------------------------------
-- RBAC: permissions, roles, role_permissions
-- -----------------------------------------------------------------------------
CREATE TABLE permissions (
    id          uuid       PRIMARY KEY DEFAULT gen_random_uuid(),
    key         text       NOT NULL UNIQUE,
    scope       role_scope NOT NULL,      -- lowest level at which the permission is meaningful
    category    text       NOT NULL,
    description text       NOT NULL
);

CREATE TABLE roles (
    id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    system_key   text        UNIQUE,                 -- set for built-in roles, NULL for custom roles
    name         text        NOT NULL CHECK (length(btrim(name)) > 0),
    description  text        NOT NULL DEFAULT '',
    scope        role_scope  NOT NULL,
    workspace_id uuid,                               -- custom roles belong to one workspace (FK added below)
    created_by   uuid,
    created_at   timestamptz NOT NULL DEFAULT now(),
    updated_at   timestamptz NOT NULL DEFAULT now(),
    CHECK ((system_key IS NULL) = (workspace_id IS NOT NULL)),   -- system => no workspace, custom => workspace
    CHECK (workspace_id IS NULL OR scope <> 'GLOBAL')
);
CREATE UNIQUE INDEX roles_workspace_name_uq ON roles (workspace_id, scope, lower(name)) WHERE workspace_id IS NOT NULL;
CREATE TRIGGER roles_set_updated_at BEFORE UPDATE ON roles FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE role_permissions (
    role_id       uuid NOT NULL REFERENCES roles (id)       ON DELETE CASCADE,
    permission_id uuid NOT NULL REFERENCES permissions (id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);
CREATE INDEX role_permissions_permission_idx ON role_permissions (permission_id);

-- -----------------------------------------------------------------------------
-- USERS, CREDENTIALS, REFRESH TOKENS
-- -----------------------------------------------------------------------------
CREATE TABLE users (
    id                   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    name                 text        NOT NULL CHECK (length(btrim(name)) > 0),
    email                citext      NOT NULL UNIQUE,
    image_url            text        NOT NULL DEFAULT '',
    global_role_id       uuid        NOT NULL REFERENCES roles (id),
    must_change_password boolean     NOT NULL DEFAULT false,
    token_version        integer     NOT NULL DEFAULT 0,   -- bump to invalidate every access token
    deactivated_at       timestamptz,
    last_login_at        timestamptz,
    created_by           uuid        REFERENCES users (id) ON DELETE SET NULL,
    created_at           timestamptz NOT NULL DEFAULT now(),
    updated_at           timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX users_global_role_idx ON users (global_role_id);
CREATE TRIGGER users_set_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION set_updated_at();

ALTER TABLE roles ADD CONSTRAINT roles_created_by_fk FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL;

CREATE TABLE user_credentials (
    user_id             uuid        PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
    password_hash       text        NOT NULL,
    password_changed_at timestamptz NOT NULL DEFAULT now(),
    failed_attempts     integer     NOT NULL DEFAULT 0,
    locked_until        timestamptz,
    updated_at          timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER user_credentials_set_updated_at BEFORE UPDATE ON user_credentials FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE refresh_tokens (
    id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        uuid        NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    family_id      uuid        NOT NULL,                 -- one family per login session (rotation chain)
    token_hash     text        NOT NULL UNIQUE,          -- SHA-256 of the opaque token; raw token is never stored
    expires_at     timestamptz NOT NULL,
    revoked_at     timestamptz,
    replaced_by_id uuid,
    user_agent     text,
    ip             text,
    created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX refresh_tokens_user_idx   ON refresh_tokens (user_id);
CREATE INDEX refresh_tokens_family_idx ON refresh_tokens (family_id);

-- Invariant: the system always keeps at least one active Org Admin.
CREATE FUNCTION guard_last_org_admin() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    admin_role uuid;
    others     integer;
BEGIN
    SELECT id INTO admin_role FROM roles WHERE system_key = 'ORG_ADMIN';
    IF admin_role IS NULL OR OLD.global_role_id <> admin_role OR OLD.deactivated_at IS NOT NULL THEN
        RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
    END IF;
    IF TG_OP = 'DELETE' OR NEW.global_role_id <> admin_role OR NEW.deactivated_at IS NOT NULL THEN
        PERFORM pg_advisory_xact_lock(hashtext('last_org_admin'));
        SELECT count(*) INTO others FROM users
         WHERE global_role_id = admin_role AND deactivated_at IS NULL AND id <> OLD.id;
        IF others = 0 THEN
            RAISE EXCEPTION 'The organization must keep at least one active Org Admin' USING ERRCODE = 'check_violation';
        END IF;
    END IF;
    RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$;
CREATE TRIGGER users_guard_last_admin BEFORE UPDATE OF global_role_id, deactivated_at OR DELETE ON users
    FOR EACH ROW EXECUTE FUNCTION guard_last_org_admin();

-- -----------------------------------------------------------------------------
-- WORKSPACES + MEMBERS
-- -----------------------------------------------------------------------------
CREATE TABLE workspaces (
    id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    name        text        NOT NULL CHECK (length(btrim(name)) > 0),
    slug        citext      NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
    description text,
    image_url   text        NOT NULL DEFAULT '',
    settings    jsonb       NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(settings) = 'object'),
    owner_id    uuid        NOT NULL,                    -- must be a member (FK below)
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX workspaces_owner_idx ON workspaces (owner_id);
CREATE TRIGGER workspaces_set_updated_at BEFORE UPDATE ON workspaces FOR EACH ROW EXECUTE FUNCTION set_updated_at();

ALTER TABLE roles ADD CONSTRAINT roles_workspace_fk FOREIGN KEY (workspace_id) REFERENCES workspaces (id) ON DELETE CASCADE;

CREATE TABLE workspace_members (
    workspace_id uuid        NOT NULL REFERENCES workspaces (id) ON DELETE CASCADE,
    user_id      uuid        NOT NULL REFERENCES users (id)      ON DELETE CASCADE,
    role_id      uuid        NOT NULL REFERENCES roles (id) DEFERRABLE INITIALLY DEFERRED,  -- deferred: workspace deletion cascades roles + members together
    message      text        NOT NULL DEFAULT '',
    added_by     uuid        REFERENCES users (id) ON DELETE SET NULL,
    joined_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (workspace_id, user_id)
);
CREATE INDEX workspace_members_user_idx ON workspace_members (user_id);
CREATE INDEX workspace_members_role_idx ON workspace_members (role_id);

-- Owner must be a member of their workspace (checked at COMMIT, so both rows can be created in one transaction).
ALTER TABLE workspaces ADD CONSTRAINT workspaces_owner_is_member_fk
    FOREIGN KEY (id, owner_id) REFERENCES workspace_members (workspace_id, user_id) DEFERRABLE INITIALLY DEFERRED;

-- A role can only be used at its own level, and a custom role only inside its own workspace.
CREATE FUNCTION check_role_scope() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    expected role_scope := TG_ARGV[0]::role_scope;
    col      text       := TG_ARGV[1];
    j        jsonb      := to_jsonb(NEW);
    r        roles%ROWTYPE;
BEGIN
    SELECT * INTO r FROM roles WHERE id = (j ->> col)::uuid;
    IF NOT FOUND OR r.scope <> expected THEN
        RAISE EXCEPTION 'Role is not valid at the % level', lower(expected::text) USING ERRCODE = 'check_violation';
    END IF;
    IF expected <> 'GLOBAL' AND r.workspace_id IS NOT NULL AND r.workspace_id <> (j ->> 'workspace_id')::uuid THEN
        RAISE EXCEPTION 'Custom roles can only be used inside their own workspace' USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER users_check_role BEFORE INSERT OR UPDATE OF global_role_id ON users
    FOR EACH ROW EXECUTE FUNCTION check_role_scope('GLOBAL', 'global_role_id');
CREATE TRIGGER workspace_members_check_role BEFORE INSERT OR UPDATE OF role_id ON workspace_members
    FOR EACH ROW EXECUTE FUNCTION check_role_scope('WORKSPACE', 'role_id');

-- Invariant: the workspace owner always keeps the Workspace Admin role.
CREATE FUNCTION guard_owner_role() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE admin_role uuid;
BEGIN
    SELECT id INTO admin_role FROM roles WHERE system_key = 'WORKSPACE_ADMIN';
    IF NEW.role_id <> admin_role AND EXISTS (SELECT 1 FROM workspaces w WHERE w.id = NEW.workspace_id AND w.owner_id = NEW.user_id) THEN
        RAISE EXCEPTION 'The workspace owner must remain a Workspace Admin' USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER workspace_members_guard_owner BEFORE UPDATE OF role_id ON workspace_members
    FOR EACH ROW EXECUTE FUNCTION guard_owner_role();

-- -----------------------------------------------------------------------------
-- PROJECTS + MEMBERS
-- -----------------------------------------------------------------------------
CREATE TABLE projects (
    id           uuid           PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id uuid           NOT NULL REFERENCES workspaces (id) ON DELETE CASCADE,
    name         text           NOT NULL CHECK (length(btrim(name)) > 0),
    description  text,
    priority     priority_level NOT NULL DEFAULT 'MEDIUM',
    status       project_status NOT NULL DEFAULT 'PLANNING',
    start_date   date,
    end_date     date,
    team_lead_id uuid           NOT NULL,                  -- the project manager (FK below)
    progress     smallint       NOT NULL DEFAULT 0 CHECK (progress BETWEEN 0 AND 100),
    created_by   uuid           REFERENCES users (id) ON DELETE SET NULL,
    created_at   timestamptz    NOT NULL DEFAULT now(),
    updated_at   timestamptz    NOT NULL DEFAULT now(),
    CHECK (start_date IS NULL OR end_date IS NULL OR end_date >= start_date),
    UNIQUE (id, workspace_id)
);
CREATE INDEX projects_workspace_status_idx ON projects (workspace_id, status);
CREATE INDEX projects_team_lead_idx        ON projects (team_lead_id);
CREATE TRIGGER projects_set_updated_at BEFORE UPDATE ON projects FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- A project member must belong to the project's workspace (composite FK) -> workspaces stay isolated.
CREATE TABLE project_members (
    project_id   uuid        NOT NULL,
    user_id      uuid        NOT NULL,
    workspace_id uuid        NOT NULL,                     -- filled from the project by trigger
    role_id      uuid        NOT NULL REFERENCES roles (id) DEFERRABLE INITIALLY DEFERRED,
    added_by     uuid        REFERENCES users (id) ON DELETE SET NULL,
    added_at     timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (project_id, user_id),
    FOREIGN KEY (project_id, workspace_id) REFERENCES projects (id, workspace_id) ON DELETE CASCADE,
    FOREIGN KEY (workspace_id, user_id)    REFERENCES workspace_members (workspace_id, user_id) ON DELETE CASCADE
);
CREATE INDEX project_members_user_idx      ON project_members (user_id);
CREATE INDEX project_members_workspace_idx ON project_members (workspace_id, user_id);
CREATE INDEX project_members_role_idx      ON project_members (role_id);

CREATE FUNCTION project_members_fill_workspace() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.workspace_id IS NULL THEN
        SELECT workspace_id INTO NEW.workspace_id FROM projects WHERE id = NEW.project_id;
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER project_members_fill_workspace_trg BEFORE INSERT ON project_members
    FOR EACH ROW EXECUTE FUNCTION project_members_fill_workspace();
CREATE TRIGGER project_members_check_role BEFORE INSERT OR UPDATE OF role_id ON project_members
    FOR EACH ROW EXECUTE FUNCTION check_role_scope('PROJECT', 'role_id');

-- The team lead must be a member of the project (checked at COMMIT). Removing the lead needs a replacement first.
ALTER TABLE projects ADD CONSTRAINT projects_team_lead_is_member_fk
    FOREIGN KEY (id, team_lead_id) REFERENCES project_members (project_id, user_id) DEFERRABLE INITIALLY DEFERRED;

-- -----------------------------------------------------------------------------
-- TASKS (assignee must be a member of the task's project; removal just unassigns)
-- -----------------------------------------------------------------------------
CREATE TABLE tasks (
    id           uuid           PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id   uuid           NOT NULL REFERENCES projects (id) ON DELETE CASCADE,
    title        text           NOT NULL CHECK (length(btrim(title)) > 0),
    description  text,
    status       task_status    NOT NULL DEFAULT 'TODO',
    type         task_type      NOT NULL DEFAULT 'TASK',
    priority     priority_level NOT NULL DEFAULT 'MEDIUM',
    assignee_id  uuid,
    created_by   uuid           REFERENCES users (id) ON DELETE SET NULL,
    due_date     date           NOT NULL,
    completed_at timestamptz,
    created_at   timestamptz    NOT NULL DEFAULT now(),
    updated_at   timestamptz    NOT NULL DEFAULT now(),
    FOREIGN KEY (project_id, assignee_id) REFERENCES project_members (project_id, user_id) ON DELETE SET NULL (assignee_id)
);
CREATE INDEX tasks_project_status_idx   ON tasks (project_id, status);
CREATE INDEX tasks_project_due_idx      ON tasks (project_id, due_date);
CREATE INDEX tasks_project_assignee_idx ON tasks (project_id, assignee_id);
CREATE INDEX tasks_my_open_idx          ON tasks (assignee_id, due_date) WHERE status <> 'DONE';
CREATE TRIGGER tasks_set_updated_at BEFORE UPDATE ON tasks FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE FUNCTION tasks_set_completed_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.status = 'DONE' THEN
        IF TG_OP = 'INSERT' OR OLD.status <> 'DONE' THEN NEW.completed_at := now(); END IF;
    ELSE
        NEW.completed_at := NULL;
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER tasks_completed_at_trg BEFORE INSERT OR UPDATE OF status ON tasks
    FOR EACH ROW EXECUTE FUNCTION tasks_set_completed_at();

-- -----------------------------------------------------------------------------
-- COMMENTS
-- -----------------------------------------------------------------------------
CREATE TABLE comments (
    id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id    uuid        NOT NULL REFERENCES tasks (id) ON DELETE CASCADE,
    user_id    uuid        REFERENCES users (id) ON DELETE SET NULL,
    content    text        NOT NULL CHECK (length(btrim(content)) > 0),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX comments_task_created_idx ON comments (task_id, created_at);
CREATE INDEX comments_user_idx         ON comments (user_id);
CREATE TRIGGER comments_set_updated_at BEFORE UPDATE ON comments FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- ACTIVITY LOG (append-only; powers "Recent Activity")
-- -----------------------------------------------------------------------------
CREATE TABLE activity_logs (
    id           bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    workspace_id uuid        NOT NULL REFERENCES workspaces (id) ON DELETE CASCADE,
    project_id   uuid        REFERENCES projects (id) ON DELETE CASCADE,
    actor_id     uuid        REFERENCES users (id) ON DELETE SET NULL,
    action       text        NOT NULL,
    entity_type  text        NOT NULL CHECK (entity_type IN ('workspace', 'project', 'task', 'comment', 'member', 'role')),
    entity_id    uuid,
    metadata     jsonb       NOT NULL DEFAULT '{}'::jsonb,
    created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX activity_logs_workspace_idx ON activity_logs (workspace_id, created_at DESC);
CREATE INDEX activity_logs_project_idx   ON activity_logs (project_id, created_at DESC) WHERE project_id IS NOT NULL;
