# Project Management API

Express + PostgreSQL backend for the Project Management app. Raw, parameterized SQL (no ORM), full RBAC, refresh-token sessions.

```
Organization ─┬─ Workspace ─┬─ Project ─── Task ─── Comment
              │             └─ members (chosen from the workspace)
              └─ Workspace …
```

## Quick start

```bash
cd backend
npm install
cp .env.example .env          # then edit DATABASE_URL (and the JWT secret)
npm run db:setup              # creates the database, runs migrations, creates the first Org Admin
npm run db:seed:demo          # optional: demo workspace, users, projects, tasks
npm run dev                   # http://localhost:5000
```

Requires **Node 18.17+** and **PostgreSQL 15+** (it uses `ON DELETE SET NULL (column)`).

First login: the Org Admin from `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` (default `admin@example.com` / `Admin@12345`). That password is temporary: the API refuses everything except "change password" until you pick your own.

### Environment

| Variable | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | `postgresql://postgres:postgres@localhost:5432/project_management` | Connection string. If empty, `DB_HOST/DB_PORT/DB_USER/DB_PASSWORD/DB_NAME` are used instead |
| `DB_SSL` | `false` | `true` for hosted databases that need TLS (Neon, Supabase, RDS) |
| `PORT` / `API_PUBLIC_URL` | `5000` / `http://localhost:5000` | Public URL is used to build absolute image URLs |
| `CLIENT_URL` | `http://localhost:5173` | Allowed frontend origin(s), comma separated (CORS) |
| `JWT_ACCESS_SECRET` | dev placeholder | **Set a long random value in production** (the server refuses to start otherwise) |
| `ACCESS_TOKEN_TTL_MINUTES` / `REFRESH_TOKEN_TTL_DAYS` | `15` / `7` | Session lifetimes |
| `BCRYPT_ROUNDS` | `12` | Password hashing cost |
| `COOKIE_SAMESITE` / `COOKIE_SECURE` / `COOKIE_DOMAIN` | `lax` / `false` (true in production) / – | Refresh-token cookie. Frontend and API on different sites: `none` + `true` |
| `MAX_FAILED_LOGINS` / `LOCKOUT_MINUTES` | `5` / `15` | Account lockout |
| `UPLOAD_DIR` / `MAX_UPLOAD_MB` | `uploads` / `10` | Local image storage |
| `SEED_ADMIN_*` | see `.env.example` | First Org Admin created by `npm run db:seed` |
| `TRUST_PROXY` | – | Set to the number of proxies when behind nginx / a load balancer |

### Scripts

| Script | What it does |
|---|---|
| `npm run db:create` | Creates the database named in `DATABASE_URL` if it does not exist |
| `npm run db:migrate` | Applies `migrations/*.sql` in order and syncs permissions + built-in roles |
| `npm run db:seed` | Creates the first Org Admin (idempotent) |
| `npm run db:seed:demo` | Demo data (idempotent). Users `alice/bob/cara/dan@acme.test`, password `Demo@12345` |
| `npm run db:setup` | `db:create` + `db:migrate` + `db:seed` |
| `npm run dev` / `npm start` | Run with auto-reload / plain |
| `npm run test:smoke` | End-to-end API test (needs the API running + a seeded DB) |

## Architecture

```
src/
  server.js  app.js  routes.js
  config/env.js                     typed environment
  core/        exceptions.js        AppException + BadRequest/Unauthorized/Forbidden/NotFound/Conflict/Validation/TooManyRequests/...
               response.js          standard success / error envelope
               context.js           request context store (AsyncLocalStorage)
               logger.js  asyncHandler.js
  db/pool.js                        pg Pool, query helpers, transaction()
  middleware/  authenticate  validate (zod)  errorHandler  rateLimit  upload  requestContext
  rbac/        permissions.js       permission catalog + built-in roles (single source of truth)
               sync.js              keeps the DB in line with the catalog
               authz.js             effective-permission resolution, 404/403 rules, escalation guard
               authorize.js         route guard:  authorize('task.delete', { project: 'projectId' })
  modules/<name>/  <name>.router.js  <name>.schema.js  <name>.service.js
      auth  users  admin  workspaces  members  roles  projects  tasks  comments  activity
migrations/001_init.sql             schema, triggers, invariants
scripts/                            create-db, migrate, seed, seed-demo
tests/smoke.test.js
```

* **Router** = HTTP only (validation → authorization → call service → respond). **Schema** = zod validation. **Service** = business rules and every SQL statement.
* **Injection safety**: every statement uses `$1, $2 …` placeholders. The few dynamic `UPDATE … SET` lists take their column names from a constant whitelist, never from input.
* **Request context store**: `AsyncLocalStorage` carries the request id, current user, resolved permissions and the active DB transaction, so services never receive `req`. `db.transaction(fn)` makes every query inside `fn` (including nested service calls) join one transaction.
* **Exceptions → status codes**: services `throw new ConflictException(...)` etc.; the error handler maps them (and translates PostgreSQL errors such as unique/foreign-key/trigger violations) to the right HTTP status.

### Standard response

```jsonc
// success
{ "success": true,  "status": 200, "message": "Projects loaded", "data": [...], "meta": { "page": 1, "limit": 20, "total": 3, "totalPages": 1 }, "requestId": "…" }
// error
{ "success": false, "status": 403, "message": "You do not have permission to do this …", "error": { "code": "FORBIDDEN", "details": [...] }, "requestId": "…" }
```

Validation errors are `422` with `error.details = [{ location, field, message }]`. Every response carries an `X-Request-Id` header (also in logs).

## Authentication

* **Login**: email + password (bcrypt, in the separate `user_credentials` table). There is no public sign-up and no email service: admins create accounts and hand over a temporary password. `must_change_password` forces the user to choose their own before anything else works.
* **Access token**: short-lived JWT (15 min), sent as `Authorization: Bearer …`. The frontend keeps it in memory only.
* **Refresh token**: opaque random string in an `httpOnly` cookie scoped to `/api/v1/auth`. Only its SHA-256 hash is stored. It is **rotated on every refresh**; replaying an already-used token revokes the whole session family (theft detection), with a 10 s grace window for two tabs refreshing at once.
* The user row is loaded from the database on **every request**, so deactivation, password changes and role changes apply immediately (`token_version` invalidates old access tokens).
* **Brute force**: 5 failed logins lock the account for 15 minutes; failed attempts are also rate limited per IP; unknown emails get the same error and timing as wrong passwords.
* **Password resets** (no email): users change their own; Org Admins can reset anyone; a workspace admin can only set the initial password of accounts they created that have never signed in.

## Authorization (RBAC)

Roles live in tables (`roles`, `permissions`, `role_permissions`) and are assigned at three levels:

| Level | Stored on | Built-in roles |
|---|---|---|
| Organization | `users.global_role_id` | Org Admin, User |
| Workspace | `workspace_members.role_id` | Workspace Admin, Workspace Member |
| Project | `project_members.role_id` | Project Manager (= the team lead), Project Member |

A user's effective permissions inside a project = **global role ∪ workspace role ∪ project role**, read from the database on each request. Workspace admins can also create **custom roles** (any combination of permissions) from Settings → Roles.

Rules worth knowing:

* **Isolation**: workspaces never see each other. A user must be *onboarded into the workspace* (by a workspace admin) before they can be added to any of its projects; this is enforced by a composite foreign key in the database, not just in code.
* **404 vs 403**: if you cannot even *see* a workspace/project you get `404` (its existence is not leaked); if you can see it but lack the permission you get `403`.
* **No privilege escalation**: you can only grant a role/permission set that you hold yourself; nobody can change their own role; only the owner (or an Org Admin) can change or remove another Workspace Admin.
* **Invariants enforced by PostgreSQL**: the workspace owner is always a member and stays Workspace Admin; a project's team lead is always a member (and Project Manager); a task's assignee is always a member of that project (removing a member un-assigns their tasks instead of deleting them); there is always at least one active Org Admin.
* **Closed projects** (completed / cancelled) are read-only for everyone who cannot edit the project.

### Permission matrix

| Permission | Level | Org Admin | User | Workspace Admin | Workspace Member | Project Manager | Project Member |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|
| `workspace.create` | global | ✔ |  |  |  |  |  |
| `user.manage` | global | ✔ |  |  |  |  |  |
| `workspace.view` | workspace | ✔ |  | ✔ | ✔ |  |  |
| `workspace.update` | workspace | ✔ |  | ✔ |  |  |  |
| `workspace.delete` | workspace | ✔ |  | ✔ |  |  |  |
| `workspace.member.view` | workspace | ✔ |  | ✔ | ✔ |  |  |
| `workspace.member.add` | workspace | ✔ |  | ✔ |  |  |  |
| `workspace.member.update_role` | workspace | ✔ |  | ✔ |  |  |  |
| `workspace.member.remove` | workspace | ✔ |  | ✔ |  |  |  |
| `workspace.member.reset_password` | workspace | ✔ |  | ✔ |  |  |  |
| `role.view` | workspace | ✔ |  | ✔ | ✔ |  |  |
| `role.manage` | workspace | ✔ |  | ✔ |  |  |  |
| `project.create` | workspace | ✔ |  | ✔ |  |  |  |
| `project.view` | project | ✔ |  | ✔ |  | ✔ | ✔ |
| `project.update` | project | ✔ |  | ✔ |  | ✔ |  |
| `project.delete` | project | ✔ |  | ✔ |  |  |  |
| `project.lead.change` | project | ✔ |  | ✔ |  |  |  |
| `project.member.add` | project | ✔ |  | ✔ |  | ✔ |  |
| `project.member.update_role` | project | ✔ |  | ✔ |  | ✔ |  |
| `project.member.remove` | project | ✔ |  | ✔ |  | ✔ |  |
| `task.view` | project | ✔ |  | ✔ |  | ✔ | ✔ |
| `task.create` | project | ✔ |  | ✔ |  | ✔ | ✔ |
| `task.update` | project | ✔ |  | ✔ |  | ✔ |  |
| `task.update_own` | project | ✔ |  | ✔ |  | ✔ | ✔ |
| `task.assign` | project | ✔ |  | ✔ |  | ✔ |  |
| `task.delete` | project | ✔ |  | ✔ |  | ✔ |  |
| `comment.create` | project | ✔ |  | ✔ |  | ✔ | ✔ |
| `comment.delete` | project | ✔ |  | ✔ |  | ✔ |  |

Custom roles must include the base `workspace.view` / `project.view`. Project-level permissions held through a *workspace* or *global* role apply to every project in scope.

## API reference

Base URL `/api/v1`. Everything except `/auth/login`, `/auth/refresh`, `/auth/logout` needs a Bearer token. Field names mirror the frontend (`start_date`, `due_date`, `team_lead`, `assigneeId`, `image_url` …).

| Area | Endpoints |
|---|---|
| **Auth** | `POST /auth/login` · `POST /auth/refresh` · `POST /auth/logout` · `POST /auth/logout-all` · `GET /auth/me` · `POST /auth/change-password` |
| **Profile** | `GET/PATCH /users/me` · `POST/DELETE /users/me/avatar` (multipart `avatar`) |
| **Org admin** (`user.manage`) | `GET/POST /admin/users` · `PATCH /admin/users/:userId` · `POST /admin/users/:userId/reset-password` · `GET /admin/roles` · `GET /admin/workspaces` |
| **Workspaces** | `GET/POST /workspaces` (create needs `workspace.create`; multipart with optional `logo`) · `GET/PATCH/DELETE /workspaces/:id` · `GET /workspaces/:id/overview` (members + visible projects + tasks + permissions in one call) · `POST/DELETE /workspaces/:id/logo` · `POST /workspaces/:id/transfer-ownership` |
| **Members** | `GET/POST /workspaces/:id/members` · `GET …/members/lookup?email=` · `PATCH/DELETE …/members/:userId` · `POST …/members/:userId/reset-password` |
| **Roles** | `GET /permissions` · `GET/POST /workspaces/:id/roles` · `PATCH/DELETE /workspaces/:id/roles/:roleId` |
| **Projects** | `GET/POST /workspaces/:id/projects` · `GET/PATCH/DELETE /projects/:id` · `GET/POST /projects/:id/members` · `PATCH/DELETE /projects/:id/members/:userId` |
| **Tasks** | `GET/POST /projects/:id/tasks` (filters: `status,type,priority,assigneeId,search,page,limit`) · `POST /projects/:id/tasks/bulk-delete` · `GET/PATCH/DELETE /tasks/:id` · `GET /workspaces/:id/my-tasks` |
| **Comments** | `GET/POST /tasks/:id/comments` · `PATCH/DELETE /comments/:id` |
| **Activity** | `GET /workspaces/:id/activity?limit=&projectId=` (only shows projects the caller can see) |
| **Misc** | `GET /health` · `GET /avatar/:name.svg` (generated initials) · `GET /uploads/...` |

## Production checklist

* Set `NODE_ENV=production`, a strong `JWT_ACCESS_SECRET`, and `COOKIE_SECURE=true`; serve over HTTPS.
* If the frontend is on a different *site* than the API, set `COOKIE_SAMESITE=none` (requires HTTPS).
* Put the API behind a reverse proxy and set `TRUST_PROXY`.
* Uploaded images are stored on local disk (`UPLOAD_DIR`). Mount a persistent volume or move them to object storage when you scale out.
* Back up the database; migrations are plain SQL files in `migrations/` (add `002_*.sql` for changes, never edit applied ones).
