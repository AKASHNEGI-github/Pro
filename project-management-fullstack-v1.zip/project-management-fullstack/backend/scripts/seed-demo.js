// Optional demo data: one workspace, 4 users, 2 projects, tasks and comments (idempotent).
// Shows workspace isolation + per-project membership: Cara is on "Website Redesign" but NOT on "Mobile App".
import { db, closePool } from '../src/db/pool.js';
import { hashPassword } from '../src/utils/password.js';
import { syncRbac, systemRoleId } from '../src/rbac/sync.js';

const PASSWORD = 'Demo@12345';
const day = (offset) => new Date(Date.now() + offset * 86400000).toISOString().slice(0, 10);

try {
    await syncRbac();
    if (await db.first(`SELECT 1 FROM workspaces WHERE slug = 'acme-corp'`)) {
        console.log('✔ Demo data already present');
    } else {
        const [userRole, wsAdmin, wsMember, pmRole, pMember] = await Promise.all(
            ['USER', 'WORKSPACE_ADMIN', 'WORKSPACE_MEMBER', 'PROJECT_MANAGER', 'PROJECT_MEMBER'].map(systemRoleId),
        );
        const hash = await hashPassword(PASSWORD);

        await db.transaction(async () => {
            const ids = {};
            for (const [key, name, email] of [
                ['alice', 'Alice Johnson', 'alice@acme.test'], ['bob', 'Bob Martin', 'bob@acme.test'],
                ['cara', 'Cara Singh', 'cara@acme.test'], ['dan', 'Dan Lee', 'dan@acme.test'],
            ]) {
                const u = await db.first(`INSERT INTO users (name, email, global_role_id) VALUES ($1, $2, $3) RETURNING id`, [name, email, userRole]);
                await db.query('INSERT INTO user_credentials (user_id, password_hash) VALUES ($1, $2)', [u.id, hash]);
                ids[key] = u.id;
            }

            const ws = await db.first(
                `INSERT INTO workspaces (name, slug, description, owner_id) VALUES ('Acme Corp', 'acme-corp', 'Demo workspace', $1) RETURNING id`, [ids.alice]);
            for (const [key, role] of [['alice', wsAdmin], ['bob', wsMember], ['cara', wsMember], ['dan', wsMember]]) {
                await db.query('INSERT INTO workspace_members (workspace_id, user_id, role_id) VALUES ($1, $2, $3)', [ws.id, ids[key], role]);
            }

            const mkProject = async (name, description, status, priority, lead, members, progress) => {
                const p = await db.first(
                    `INSERT INTO projects (workspace_id, name, description, status, priority, start_date, end_date, team_lead_id, progress, created_by)
                     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
                    [ws.id, name, description, status, priority, day(-10), day(60), lead, progress, ids.alice]);
                for (const m of members) {
                    await db.query('INSERT INTO project_members (project_id, user_id, role_id) VALUES ($1, $2, $3)', [p.id, m, m === lead ? pmRole : pMember]);
                }
                return p.id;
            };
            const web = await mkProject('Website Redesign', 'Refresh the marketing website.', 'ACTIVE', 'HIGH', ids.bob, [ids.bob, ids.cara], 40);
            const mobile = await mkProject('Mobile App', 'Customer app for iOS and Android.', 'PLANNING', 'MEDIUM', ids.alice, [ids.alice, ids.dan], 10);

            const mkTask = async (project, title, description, status, type, priority, assignee, due, createdBy) =>
                (await db.first(
                    `INSERT INTO tasks (project_id, title, description, status, type, priority, assignee_id, due_date, created_by)
                     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
                    [project, title, description, status, type, priority, assignee, due, createdBy])).id;

            const t1 = await mkTask(web, 'Design new landing page', 'Hero, pricing and testimonials.', 'IN_PROGRESS', 'FEATURE', 'HIGH', ids.cara, day(5), ids.bob);
            await mkTask(web, 'Fix broken contact form', 'Form fails on Safari.', 'TODO', 'BUG', 'HIGH', ids.bob, day(-2), ids.bob);
            await mkTask(web, 'Migrate blog content', 'Move posts to the new CMS.', 'DONE', 'TASK', 'MEDIUM', ids.cara, day(-7), ids.bob);
            await mkTask(mobile, 'Set up React Native project', 'Repo, CI and linting.', 'IN_PROGRESS', 'TASK', 'MEDIUM', ids.dan, day(10), ids.alice);
            await mkTask(mobile, 'Define onboarding flow', 'Wireframes for first-run experience.', 'TODO', 'IMPROVEMENT', 'LOW', ids.alice, day(20), ids.alice);

            await db.query('INSERT INTO comments (task_id, user_id, content) VALUES ($1,$2,$3), ($1,$4,$5)',
                [t1, ids.bob, 'Please follow the new brand colors.', ids.cara, 'On it. First draft by Friday.']);
            await db.query(
                `INSERT INTO activity_logs (workspace_id, actor_id, action, entity_type, entity_id, metadata)
                 VALUES ($1, $2, 'workspace.created', 'workspace', $1, '{"name":"Acme Corp"}')`, [ws.id, ids.alice]);
        });
        console.log(`✔ Demo data created. Log in with any of:
    alice@acme.test  (Workspace Admin / owner)
    bob@acme.test    (Workspace Member, Project Manager of Website Redesign)
    cara@acme.test   (Workspace Member, on Website Redesign only)
    dan@acme.test    (Workspace Member, on Mobile App only)
  password: ${PASSWORD}`);
    }
} catch (err) {
    console.error(`✖ Demo seed failed: ${err.message}`);
    process.exitCode = 1;
} finally {
    await closePool();
}
