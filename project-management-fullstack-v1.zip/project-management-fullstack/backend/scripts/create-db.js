// Creates the target database from DATABASE_URL if it does not exist yet.
import pg from 'pg';
import { env } from '../src/config/env.js';

const url = new URL(env.databaseUrl);
const dbName = decodeURIComponent(url.pathname.replace(/^\//, ''));
if (!/^[A-Za-z0-9_]+$/.test(dbName)) {
    console.error(`Refusing to create database with unusual name "${dbName}". Create it manually.`);
    process.exit(1);
}

// Connect to the maintenance database to create the target one.
url.pathname = '/postgres';
const client = new pg.Client({ connectionString: url.toString(), ssl: env.dbSsl ? { rejectUnauthorized: false } : undefined });

try {
    await client.connect();
    const exists = await client.query('SELECT 1 FROM pg_database WHERE datname = $1', [dbName]);
    if (exists.rowCount) {
        console.log(`✔ Database "${dbName}" already exists`);
    } else {
        await client.query(`CREATE DATABASE "${dbName}"`); // identifier validated above
        console.log(`✔ Created database "${dbName}"`);
    }
} catch (err) {
    console.error(`✖ Could not create database: ${err.message}`);
    console.error('  Check DATABASE_URL (user/password/host) or create the database manually.');
    process.exitCode = 1;
} finally {
    await client.end().catch(() => {});
}
