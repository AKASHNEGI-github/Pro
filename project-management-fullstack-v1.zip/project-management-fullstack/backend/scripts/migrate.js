// Applies migrations/*.sql in order (each in its own transaction) and syncs permissions + built-in roles.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool, closePool } from '../src/db/pool.js';
import { syncRbac } from '../src/rbac/sync.js';

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'migrations');

export async function runMigrations() {
    await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);
    const applied = new Set((await pool.query('SELECT name FROM schema_migrations')).rows.map((r) => r.name));
    const files = (await fs.readdir(dir)).filter((f) => f.endsWith('.sql')).sort();

    for (const file of files) {
        if (applied.has(file)) continue;
        const sql = await fs.readFile(path.join(dir, file), 'utf8');
        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            await client.query(sql);
            await client.query('INSERT INTO schema_migrations (name) VALUES ($1)', [file]);
            await client.query('COMMIT');
            console.log(`✔ applied ${file}`);
        } catch (err) {
            await client.query('ROLLBACK').catch(() => {});
            throw new Error(`Migration ${file} failed: ${err.message}`);
        } finally {
            client.release();
        }
    }
    await syncRbac();
    console.log('✔ permissions and built-in roles are in sync');
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
    try {
        await runMigrations();
    } catch (err) {
        console.error(`✖ ${err.message}`);
        process.exitCode = 1;
    } finally {
        await closePool();
    }
}
