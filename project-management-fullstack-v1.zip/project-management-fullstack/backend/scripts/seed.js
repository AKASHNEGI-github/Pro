// Creates the first Org Admin (idempotent). Credentials come from SEED_ADMIN_* in .env.
import { env } from '../src/config/env.js';
import { db, closePool } from '../src/db/pool.js';
import { hashPassword } from '../src/utils/password.js';
import { syncRbac, systemRoleId } from '../src/rbac/sync.js';

try {
    await syncRbac();
    const { name, email, password, mustChange } = env.seedAdmin;
    const existing = await db.first('SELECT id FROM users WHERE email = $1', [email]);
    if (existing) {
        console.log(`✔ Org Admin ${email} already exists`);
    } else {
        const roleId = await systemRoleId('ORG_ADMIN');
        await db.transaction(async () => {
            const user = await db.first(
                `INSERT INTO users (name, email, global_role_id, must_change_password) VALUES ($1, $2, $3, $4) RETURNING id`,
                [name, email, roleId, mustChange],
            );
            await db.query('INSERT INTO user_credentials (user_id, password_hash) VALUES ($1, $2)', [user.id, await hashPassword(password)]);
        });
        console.log(`✔ Created Org Admin  ${email}  /  ${password}${mustChange ? '  (must change password at first login)' : ''}`);
    }
} catch (err) {
    console.error(`✖ Seed failed: ${err.message}`);
    process.exitCode = 1;
} finally {
    await closePool();
}
