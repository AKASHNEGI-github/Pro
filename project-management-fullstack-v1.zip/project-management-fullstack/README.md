# Project Management App (React + Express + PostgreSQL)

A multi-workspace project management tool: **Organization → Workspaces → Projects → Tasks**, with full role-based access control.

```
├── frontend/   React 19 · Redux Toolkit · Tailwind 4 · Vite
├── backend/    Express · PostgreSQL (raw SQL) · JWT + rotating refresh tokens · RBAC
```

## Run it locally (5 minutes)

**Prerequisites:** Node.js 18.17+ and PostgreSQL 15+ running locally.

```bash
# 1) Backend
cd backend
npm install
cp .env.example .env            # edit DATABASE_URL (user/password of your local Postgres)
npm run db:setup                # creates DB + tables + first Org Admin
npm run db:seed:demo            # optional demo data
npm run dev                     # API on http://localhost:5000

# 2) Frontend (new terminal)
cd frontend
npm install
cp .env.example .env            # VITE_API_URL=http://localhost:5000/api/v1
npm run dev                     # app on http://localhost:5173
```

Open http://localhost:5173 and sign in:

| Account | Password | What it is |
|---|---|---|
| `admin@example.com` | `Admin@12345` | **Org Admin**. Asked to choose a new password on first login |
| `alice@acme.test` | `Demo@12345` | Workspace Admin + owner of "Acme Corp" *(demo data)* |
| `bob@acme.test` | `Demo@12345` | Project Manager of "Website Redesign" *(demo data)* |
| `cara@acme.test` | `Demo@12345` | Member of "Website Redesign" only *(demo data)* |
| `dan@acme.test` | `Demo@12345` | Member of "Mobile App" only *(demo data)* |

> Windows / `cp` not available? Copy the `.env.example` files to `.env` by hand.

## How it works (in plain words)

* **No public sign-up and no email.** Accounts are created by admins. The Org Admin creates users and workspaces (Settings → Organization). A workspace admin onboards people into their workspace from the **Team** page ("Add member"): an existing account is added directly; otherwise a new account is created with a temporary password that you hand over yourself. New users must change that password at first sign-in.
* **Workspaces are isolated.** You only see workspaces you belong to. To put someone on a project, they must first be a member of that project's workspace.
* **Per-project membership.** Being in a workspace does not show you its projects; you see only the projects you were added to (workspace admins and Org Admins see all). You can be Project Manager in one project and a plain member in another.
* **Roles are permission bundles** at three levels (organization / workspace / project). Built-in roles cover the common cases; workspace admins can build **custom roles** under *Settings → Roles & permissions*.

| Who | Can |
|---|---|
| **Org Admin** | everything; create workspaces and users, reset any password |
| **Workspace Admin** | manage the workspace, members, roles, all projects |
| **Workspace Member** | see the workspace and the projects they were added to |
| **Project Manager** (team lead) | edit the project, manage its members and all tasks |
| **Project Member** | create tasks, edit their own tasks, comment |

Full permission matrix, API reference and architecture notes: [`backend/README.md`](backend/README.md).

## Tests

```bash
cd backend && npm run test:smoke          # 140+ end-to-end checks of the API (auth, isolation, RBAC rules)
cd frontend && npm run test:integration   # the real Redux/API layer against the running backend (needs db:seed:demo)
cd frontend && npm run test:ui            # mounts the real app in jsdom and clicks through it (needs db:seed:demo;
                                          #   set ADMIN_PW=<org admin password> to include the Org Admin steps)
```
Start the backend first (`npm run dev` in `backend/`); the frontend tests talk to it on `http://localhost:5000`.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Cannot connect to PostgreSQL` | Postgres not running, or wrong `DATABASE_URL` in `backend/.env` |
| `permission denied to create extension "citext"` | Run once as a superuser: `CREATE EXTENSION citext;` in your database |
| Login works but you are logged out on refresh | Frontend and API must share a site (e.g. both on `localhost`), or set `COOKIE_SAMESITE=none` + HTTPS |
| `Origin not allowed` in the browser | Add the frontend URL to `CLIENT_URL` in `backend/.env` |
| Images do not load | `API_PUBLIC_URL` must be the URL the **browser** uses to reach the API |
| Locked out after failed logins | Wait 15 minutes, or have an Org Admin reset your password |

## Notes

* Passwords use **bcrypt** via the `bcryptjs` package (identical algorithm and hash format as native `bcrypt`, but no native build step, so `npm install` works everywhere).
* The frontend keeps the access token in memory only; the refresh token is an `httpOnly` cookie.
