// Exercises the REAL frontend data layer (api client + redux slices) against the running backend.
// Needs: backend running, `npm run db:seed:demo` done.  Run:  npm run test:integration
const mem = new Map()
globalThis.localStorage = { getItem: (k) => mem.get(k) ?? null, setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) }
const assert = (c, m) => { if (!c) { console.log('  ✖', m); process.exitCode = 1 } else console.log('  ✔', m) }

const { store } = await import('../src/app/store.js')
const { login, logout } = await import('../src/features/authSlice.js')
const { fetchWorkspaces, loadWorkspace, resetWorkspaces } = await import('../src/features/workspaceSlice.js')
const { workspacesApi, tasksApi, rolesApi } = await import('../src/api/index.js')
const { tokenStore, authEvents, API_URL } = await import('../src/api/http.js')
const axios = (await import('axios')).default

console.log('API:', API_URL)
const as = async (email, password) => {
    await store.dispatch(logout()); store.dispatch(resetWorkspaces())
    const r = await store.dispatch(login({ email, password }))
    if (login.rejected.match(r)) throw new Error(`login ${email}: ${r.payload?.message}`)
    await store.dispatch(fetchWorkspaces())
    return store.getState()
}

console.log('\nAlice (Workspace Admin / owner)')
let st = await as('alice@acme.test', 'Demo@12345')
let ws = st.workspace.currentWorkspace
assert(st.auth.status === 'authenticated', 'login stored the user in the auth slice')
assert(ws?.name === 'Acme Corp', 'fetchWorkspaces loaded the workspace overview')
assert(ws.projects.length === 2 && ws.members.length === 4, 'sees both projects and all 4 members')
assert(ws.permissions.includes('project.create') && ws.permissions.includes('role.manage'), 'workspace permissions include project.create + role.manage')
const p = ws.projects[0]
assert(p.permissions.includes('task.delete') && Array.isArray(p.tasks) && p.members[0].user.name, 'project carries permissions, tasks and members(user)')
const t = p.tasks[0]
assert(typeof t.due_date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(t.due_date) && 'assigneeId' in t, 'task shape matches the UI (due_date string, assigneeId)')
assert(t.assignee ? typeof t.assignee.image === 'string' && t.assignee.image.startsWith('http') : true, 'assignee has an absolute image URL')
assert(typeof ws.image_url === 'string' && ws.image_url.includes('/avatar/'), 'workspace without a logo gets a generated avatar URL')
assert(st.workspace.workspaces.length === 1 && st.workspace.workspaces[0].membersCount === 4, 'workspace list has membersCount')

console.log('\nCara (member of one project only)')
st = await as('cara@acme.test', 'Demo@12345')
ws = st.workspace.currentWorkspace
assert(ws.projects.length === 1 && ws.projects[0].name === 'Website Redesign', 'only the project she belongs to')
assert(!ws.permissions.includes('project.create'), 'no project.create (New Project button hidden)')
assert(ws.projects[0].permissions.includes('task.create') && !ws.projects[0].permissions.includes('task.delete'), 'project permissions: can create tasks, cannot delete')
assert(!(await workspacesApi.list()).some((w) => w.slug !== 'acme-corp'), 'workspace list only has her workspace')
try { await tasksApi.bulkDelete(ws.projects[0].id, [ws.projects[0].tasks[0].id]); assert(false, 'bulk delete should be refused') }
catch (e) { assert(e.status === 403 && e.name === 'ApiError', `API error is normalized (status ${e.status}, "${e.message.slice(0, 50)}...")`) }

console.log('\nOrg Admin')
if (!process.env.ADMIN_PW) console.log('  (skipped: set ADMIN_PW to the Org Admin password to include this section)')
else {
st = await as(process.env.ADMIN_EMAIL || 'admin@example.com', process.env.ADMIN_PW)
assert(st.auth.user.permissions.includes('workspace.create') && st.auth.user.permissions.includes('user.manage'), 'global permissions come from /auth')
assert(st.workspace.workspaces.some((w) => w.slug === 'acme-corp'), 'Org Admin sees every workspace')
ws = st.workspace.currentWorkspace
assert(ws.projects.length === 2, 'and every project inside them')
}

console.log('\nToken refresh (the axios interceptor)')
// Node has no cookie jar: capture the refresh cookie from a raw login and attach it to refresh calls.
const raw = await axios.post(`${API_URL}/auth/login`, { email: 'alice@acme.test', password: 'Demo@12345' })
const cookie = raw.headers['set-cookie'].find((c) => c.startsWith('refresh_token=')).split(';')[0]
axios.defaults.headers.common.Cookie = cookie
tokenStore.set('definitely.not.a.valid.jwt')
const list = await workspacesApi.list()          // 401 TOKEN_INVALID -> silent refresh -> retry
assert(Array.isArray(list) && list.length === 1, 'expired/invalid access token is refreshed silently and the request retried')
assert(tokenStore.get() && tokenStore.get() !== 'definitely.not.a.valid.jwt', 'new access token stored in memory')

// concurrent 401s must share ONE refresh (rotation would otherwise kill the session)
axios.defaults.headers.common.Cookie = (await axios.post(`${API_URL}/auth/login`, { email: 'alice@acme.test', password: 'Demo@12345' })).headers['set-cookie'].find((c) => c.startsWith('refresh_token=')).split(';')[0]
tokenStore.set('garbage')
let refreshCalls = 0
const origPost = axios.post.bind(axios)
axios.post = (url, ...rest) => { if (String(url).endsWith('/auth/refresh')) refreshCalls++; return origPost(url, ...rest) }
const results = await Promise.all([workspacesApi.list(), workspacesApi.list(), rolesApi.permissions()])
assert(results.every(Boolean) && refreshCalls === 1, `3 parallel 401s -> exactly 1 refresh call (got ${refreshCalls})`)
axios.post = origPost

let expired = false
authEvents.addEventListener('session-expired', () => { expired = true })
delete axios.defaults.headers.common.Cookie       // no valid cookie any more
tokenStore.set('garbage')
try { await workspacesApi.list(); assert(false, 'should fail') } catch (e) { assert(e.status === 401, 'unrecoverable 401 is surfaced as ApiError') }
assert(expired, 'session-expired event fired (app returns to the login screen)')
process.exit(process.exitCode || 0)
