// Mounts the REAL <App/> in jsdom against the live backend and drives it like a user.
// Needs: backend running + `npm run db:seed:demo`.  ADMIN_PW=<org admin password> npm run test:ui
// (Node has no cookie jar, so this test never reloads the app: a reload would need the refresh cookie.)
import { JSDOM } from 'jsdom'
const dom = new JSDOM('<!doctype html><html><body></body></html>', { url: 'http://localhost:5173/', pretendToBeVisual: true })
const { window } = dom
globalThis.window = window
globalThis.document = window.document
Object.defineProperty(globalThis, 'navigator', { value: window.navigator, configurable: true })
for (const k of ['HTMLElement', 'HTMLInputElement', 'HTMLSelectElement', 'HTMLTextAreaElement', 'HTMLButtonElement', 'HTMLFormElement', 'Node', 'Element', 'Event', 'KeyboardEvent', 'MouseEvent', 'MutationObserver', 'getComputedStyle', 'DocumentFragment', 'SVGElement', 'CustomEvent']) globalThis[k] = window[k]
globalThis.localStorage = window.localStorage
globalThis.requestAnimationFrame = window.requestAnimationFrame.bind(window)
globalThis.cancelAnimationFrame = window.cancelAnimationFrame.bind(window)
globalThis.IS_REACT_ACT_ENVIRONMENT = true
window.ResizeObserver = globalThis.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} }
window.matchMedia = window.matchMedia || (() => ({ matches: false, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} }))
globalThis.matchMedia = window.matchMedia
window.scrollTo = () => {}
window.confirm = () => true
URL.createObjectURL = () => 'blob:test'; URL.revokeObjectURL = () => {}

const React = (await import('react')).default
const { render, screen, waitFor, fireEvent, cleanup, within } = await import('@testing-library/react')
const { MemoryRouter } = await import('react-router-dom')
const { Provider } = await import('react-redux')
const { store } = await import('../src/app/store.js')
const { logout } = await import('../src/features/authSlice.js')
const { resetWorkspaces } = await import('../src/features/workspaceSlice.js')
const { tokenStore } = await import('../src/api/http.js')
const App = (await import('../src/App.jsx')).default

let failed = 0
const step = async (name, fn) => {
    try { await fn(); console.log('  ✔', name) } catch (e) { failed++; console.log('  ✖', name, '\n     ', String(e.message).split('\n')[0].slice(0, 260)) }
}
const T = { timeout: 9000 }
const mount = (path = '/') => render(React.createElement(MemoryRouter, { initialEntries: [path] }, React.createElement(Provider, { store }, React.createElement(App))))
const type = (el, value) => fireEvent.change(el, { target: { value } })
const click = (el) => fireEvent.click(el)
const reset = async () => { cleanup(); await store.dispatch(logout()); store.dispatch(resetWorkspaces()); tokenStore.clear(); window.localStorage.clear() }
const loginAs = async (email, password) => {
    mount('/')
    await screen.findByRole('heading', { name: /^sign in$/i }, T)
    type(screen.getByPlaceholderText('you@company.com'), email)
    type(screen.getByPlaceholderText('Your password'), password)
    click(screen.getByRole('button', { name: /sign in/i }))
}
const nav = async (name) => { click(screen.getAllByRole('link', { name })[0]) }

console.log('\nAlice (Workspace Admin)')
await step('unauthenticated visitor sees the login screen', async () => { mount('/projects'); await screen.findByRole('heading', { name: /^sign in$/i }, T) })
await step('wrong password shows an error and stays on login', async () => {
    cleanup(); mount('/'); await screen.findByRole('heading', { name: /^sign in$/i }, T)
    type(screen.getByPlaceholderText('you@company.com'), 'alice@acme.test'); type(screen.getByPlaceholderText('Your password'), 'WrongPass123')
    click(screen.getByRole('button', { name: /sign in/i }))
    await screen.findByText(/invalid email or password/i, {}, T)
})
await step('correct login lands on the dashboard with real data', async () => {
    cleanup(); await loginAs('alice@acme.test', 'Demo@12345')
    await screen.findByText(/Welcome back, Alice/, {}, T)
    await screen.findAllByText('Acme Corp', {}, T)
    await screen.findAllByText('Website Redesign', {}, T)
})
await step('dashboard shows New Project (she has project.create)', async () => { screen.getAllByText('New Project') })
await step('Recent Activity renders the real activity feed', async () => { await screen.findAllByText(/created the project|created the workspace/i, {}, T) })

await step('Projects page lists projects; create a project through the dialog', async () => {
    await nav('Projects')
    await screen.findByText('Manage and track your projects', {}, T)
    click(screen.getAllByText('New Project')[0])
    await screen.findByText('Create New Project', {}, T)
    type(screen.getByPlaceholderText('Enter project name'), 'UI Test Project')
    click(screen.getByRole('button', { name: /^Create Project$/ }))
    await waitFor(() => { if (screen.queryByText('Create New Project')) throw new Error('dialog still open') }, T)
    await screen.findAllByText('UI Test Project', {}, T)
})
await step('open the project, create a task, see it listed', async () => {
    click(screen.getAllByText('UI Test Project').map((n) => n.closest('a')).find(Boolean))
    await screen.findByText('New Task', {}, T)
    click(screen.getByText('New Task'))
    type(await screen.findByPlaceholderText('Task title'), 'Write UI tests')
    const due = document.querySelector('input[type="date"]'); type(due, '2030-01-15')
    click(screen.getByRole('button', { name: /create task/i }))
    await screen.findAllByText('Write UI tests', {}, T)
})
await step('Settings tab of the project shows member management + danger zone', async () => {
    click(screen.getByRole('button', { name: /Settings/ }))
    await screen.findByText('Project Details', {}, T)
    await screen.findByText(/Delete project/i, {}, T)
})
await step('Analytics + Calendar tabs render without crashing', async () => {
    click(screen.getByRole('button', { name: /Analytics/ })); await screen.findAllByText(/Task Status|Completion|Total/i, {}, T)
    click(screen.getByRole('button', { name: /Calendar/ })); await screen.findAllByText(/Upcoming|Overdue|Calendar|Sun/i, {}, T)
})
await step('Team page lists members and offers Add Member', async () => {
    await nav('Team')
    await screen.findByText('Total Members', {}, T)
    await screen.findAllByText('cara@acme.test', {}, T)
    click(screen.getByText('Add Member'))
    await screen.findByText('Add member to workspace', {}, T)
    fireEvent.keyDown(document, { key: 'Escape' })
    await waitFor(() => { if (screen.queryByText('Add member to workspace')) throw new Error('still open') }, T)
})
await step('Add Member dialog recognises an existing account by email', async () => {
    click(screen.getByText('Add Member'))
    type(await screen.findByPlaceholderText('name@company.com'), 'dan@acme.test')
    await screen.findByText(/already a member/i, {}, T)
    fireEvent.keyDown(document, { key: 'Escape' })
})
await step('Settings: workspace tab + Roles & permissions (built-in roles listed)', async () => {
    await nav('Settings')
    await screen.findByText('Workspace profile', {}, T)
    click(screen.getByRole('button', { name: /Roles & permissions/ }))
    await screen.findAllByText('Workspace Admin', {}, T)
    await screen.findAllByText('Project Manager', {}, T)
    click(screen.getByRole('button', { name: /New role/ }))
    await screen.findByText('Create custom role', {}, T)
    fireEvent.keyDown(document, { key: 'Escape' })
})
await step('Profile dialog (Account > Profile / Security)', async () => {
    click(screen.getByLabelText('Account menu')); click(await screen.findByText('Manage account'))
    await screen.findByText('Profile details', {}, T)
    await screen.findByText('alice@acme.test', {}, T)
    click(screen.getAllByRole('button', { name: /Security/ })[0])
    await screen.findByText('Change password', {}, T)
    fireEvent.keyDown(document, { key: 'Escape' })
})
await step('open a task from the list: details + discussion (create a comment)', async () => {
    await nav('Projects')
    click(screen.getAllByText('Website Redesign').map((n) => n.closest('a')).find(Boolean))
    click((await screen.findAllByText('Design new landing page', {}, T))[0])
    await screen.findByText(/Task Discussion/, {}, T)
    await screen.findByText(/Please follow the new brand colors/, {}, T)
    const note = `Looks great ${Date.now().toString(36)}`
    type(screen.getByPlaceholderText('Write a comment...'), note)
    click(screen.getByRole('button', { name: /^Post$/ }))
    await screen.findByText(note, {}, T)
})
await step('sign out returns to the login screen', async () => {
    click(screen.getByLabelText('Account menu')); click(await screen.findByText('Sign out'))
    await screen.findByRole('heading', { name: /^sign in$/i }, T)
})

console.log('\nCara (member of one project only)')
await reset()
await step('login; dashboard has NO New Project button', async () => {
    await loginAs('cara@acme.test', 'Demo@12345'); await screen.findByText(/Welcome back, Cara/, {}, T)
    if (screen.queryByText('New Project')) throw new Error('New Project is visible')
})
await step('only her project is listed; no Add Member on Team', async () => {
    await nav('Projects'); await screen.findByText('Manage and track your projects', {}, T)
    await screen.findAllByText('Website Redesign', {}, T)
    if (screen.queryByText('Mobile App')) throw new Error("sees a project she is not on")
    await nav('Team'); await screen.findByText('Total Members', {}, T)
    if (screen.queryByText('Add Member')) throw new Error('Add Member visible')
})
await step('Settings has no Organization tab and no danger zone', async () => {
    await nav('Settings'); await screen.findByText('Workspace profile', {}, T)
    if (screen.queryByRole('button', { name: /Organization/ })) throw new Error('Organization tab visible')
    if (screen.queryByText('Danger zone')) throw new Error('danger zone visible')
})

console.log('\nOrg Admin')
await reset()
await step('login; workspace switcher offers Create Workspace', async () => {
    await loginAs('admin@example.com', process.env.ADMIN_PW); await screen.findByText(/Welcome back, Org/, {}, T)
    click(screen.getByText('Acme Corp').closest('button') || screen.getAllByText('Acme Corp')[0])
    await screen.findByText('Create Workspace', {}, T)
    click(screen.getByText('Create Workspace'))
    await screen.findByRole('heading', { name: 'Create workspace' }, T)
    fireEvent.keyDown(document, { key: 'Escape' })
})
await step('Settings > Organization lists all users', async () => {
    await nav('Settings'); click(await screen.findByRole('button', { name: /Organization/ }))
    await screen.findByText('Create user', {}, T); await screen.findAllByText(/@/, {}, T); await screen.findAllByText('All workspaces', {}, T)
})

await reset()
await step('forced password change flow (new account with temporary password)', async () => {
    const { adminApi } = await import('../src/api/index.js'); const { authApi } = await import('../src/api/index.js')
    await authApi.login({ email: 'admin@example.com', password: process.env.ADMIN_PW })
    const email = `ui.${Date.now().toString(36)}@test.dev`
    await adminApi.createUser({ name: 'Temp User', email, password: 'Temp-pass-123' })
    tokenStore.clear()
    await loginAs(email, 'Temp-pass-123')
    await screen.findByText('Choose a new password', {}, T)
    const [cur, next, conf] = document.querySelectorAll('input[type="password"]')
    type(cur, 'Temp-pass-123'); type(next, 'My-new-pass-9'); type(conf, 'My-new-pass-9')
    click(screen.getByRole('button', { name: /update password/i }))
    await screen.findByText(/not in a workspace yet/i, {}, T)
})

console.log(failed ? `\n${failed} UI step(s) failed` : '\nAll UI steps passed')
process.exit(failed ? 1 : 0)
