# Project Management: Frontend

React 19 + Redux Toolkit + Tailwind CSS 4 + Vite. It talks to the Express API in `../backend`.

```bash
npm install
cp .env.example .env     # VITE_API_URL=http://localhost:5000/api/v1
npm run dev              # http://localhost:5173
npm run build            # production build in dist/
```

* `src/api/`: axios client (in-memory access token, silent refresh via the httpOnly cookie, request de-duplication) and one function per endpoint.
* `src/features/`: Redux slices. `authSlice` (session), `workspaceSlice` (current workspace overview: members, projects, tasks, permissions).
* `src/hooks/useCan.js`: permission checks that decide which buttons/tabs are shown. The backend enforces the same rules.
* `src/pages/`: Login, ChangePassword (forced for temporary passwords), Dashboard, Projects, ProjectDetails, TaskDetails, Team, Settings.
* `src/components/settings/`: workspace settings, roles & permissions manager, organization admin.

See the root `README.md` for the full setup and the backend `README.md` for the API.
