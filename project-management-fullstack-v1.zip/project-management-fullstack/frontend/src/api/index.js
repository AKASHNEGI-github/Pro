import { http, tokenStore } from './http'

// Every backend response is { success, message, data, meta }. These helpers return `data` (or `{ data, meta }`).
const data = (p) => p.then((r) => r.data.data)
const withMeta = (p) => p.then((r) => ({ items: r.data.data, meta: r.data.meta }))

export const authApi = {
    login: (body) => data(http.post('/auth/login', body)).then((d) => { tokenStore.set(d.accessToken); return d }),
    logout: () => http.post('/auth/logout').catch(() => {}).finally(() => tokenStore.clear()),
    logoutAll: () => data(http.post('/auth/logout-all')).finally(() => tokenStore.clear()),
    me: () => data(http.get('/auth/me')),
    changePassword: (body) => data(http.post('/auth/change-password', body)).then((d) => { tokenStore.set(d.accessToken); return d }),
}

export const usersApi = {
    updateProfile: (body) => data(http.patch('/users/me', body)),
    uploadAvatar: (file) => { const f = new FormData(); f.append('avatar', file); return data(http.post('/users/me/avatar', f)) },
    removeAvatar: () => data(http.delete('/users/me/avatar')),
}

export const adminApi = {
    listUsers: (params) => withMeta(http.get('/admin/users', { params })),
    createUser: (body) => data(http.post('/admin/users', body)),
    updateUser: (id, body) => data(http.patch(`/admin/users/${id}`, body)),
    resetPassword: (id, body) => data(http.post(`/admin/users/${id}/reset-password`, body)),
    globalRoles: () => data(http.get('/admin/roles')),
    workspaces: () => data(http.get('/admin/workspaces')),
}

export const workspacesApi = {
    list: () => data(http.get('/workspaces')),
    overview: (id) => data(http.get(`/workspaces/${id}/overview`)),
    create: ({ name, slug, ownerEmail, logo }) => {
        const f = new FormData()
        f.append('name', name)
        if (slug) f.append('slug', slug)
        if (ownerEmail) f.append('ownerEmail', ownerEmail)
        if (logo) f.append('logo', logo)
        return data(http.post('/workspaces', f))
    },
    update: (id, body) => data(http.patch(`/workspaces/${id}`, body)),
    uploadLogo: (id, file) => { const f = new FormData(); f.append('logo', file); return data(http.post(`/workspaces/${id}/logo`, f)) },
    removeLogo: (id) => data(http.delete(`/workspaces/${id}/logo`)),
    transferOwnership: (id, userId) => data(http.post(`/workspaces/${id}/transfer-ownership`, { userId })),
    remove: (id) => data(http.delete(`/workspaces/${id}`)),
}

export const membersApi = {
    lookup: (wid, email) => data(http.get(`/workspaces/${wid}/members/lookup`, { params: { email } })),
    add: (wid, body) => data(http.post(`/workspaces/${wid}/members`, body)),
    updateRole: (wid, userId, roleId) => data(http.patch(`/workspaces/${wid}/members/${userId}`, { roleId })),
    remove: (wid, userId) => data(http.delete(`/workspaces/${wid}/members/${userId}`)),
    resetPassword: (wid, userId, newPassword) => data(http.post(`/workspaces/${wid}/members/${userId}/reset-password`, { newPassword })),
}

export const rolesApi = {
    permissions: () => data(http.get('/permissions')),
    list: (wid, scope) => data(http.get(`/workspaces/${wid}/roles`, { params: scope ? { scope } : undefined })),
    create: (wid, body) => data(http.post(`/workspaces/${wid}/roles`, body)),
    update: (wid, roleId, body) => data(http.patch(`/workspaces/${wid}/roles/${roleId}`, body)),
    remove: (wid, roleId) => data(http.delete(`/workspaces/${wid}/roles/${roleId}`)),
}

export const projectsApi = {
    create: (wid, body) => data(http.post(`/workspaces/${wid}/projects`, body)),
    update: (id, body) => data(http.patch(`/projects/${id}`, body)),
    remove: (id) => data(http.delete(`/projects/${id}`)),
    addMember: (id, body) => data(http.post(`/projects/${id}/members`, body)),
    updateMemberRole: (id, userId, roleId) => data(http.patch(`/projects/${id}/members/${userId}`, { roleId })),
    removeMember: (id, userId) => data(http.delete(`/projects/${id}/members/${userId}`)),
}

export const tasksApi = {
    create: (projectId, body) => data(http.post(`/projects/${projectId}/tasks`, body)),
    update: (id, body) => data(http.patch(`/tasks/${id}`, body)),
    remove: (id) => data(http.delete(`/tasks/${id}`)),
    bulkDelete: (projectId, taskIds) => data(http.post(`/projects/${projectId}/tasks/bulk-delete`, { taskIds })),
}

export const commentsApi = {
    list: (taskId) => data(http.get(`/tasks/${taskId}/comments`)),
    create: (taskId, content) => data(http.post(`/tasks/${taskId}/comments`, { content })),
    update: (id, content) => data(http.patch(`/comments/${id}`, { content })),
    remove: (id) => data(http.delete(`/comments/${id}`)),
}

export const activityApi = {
    list: (wid, params) => data(http.get(`/workspaces/${wid}/activity`, { params })),
}
