import axios from 'axios'

export const API_URL = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api/v1').replace(/\/$/, '')

/** Access token lives in memory only (never localStorage). The refresh token is an httpOnly cookie the browser manages. */
let accessToken = null
export const tokenStore = {
    get: () => accessToken,
    set: (token) => { accessToken = token },
    clear: () => { accessToken = null },
}

/** Fired when the session cannot be recovered any more (refresh failed) -> the app signs the user out. */
export const authEvents = new EventTarget()

export class ApiError extends Error {
    constructor({ message, status = 0, code = 'UNKNOWN', details }) {
        super(message)
        this.name = 'ApiError'
        this.status = status
        this.code = code
        this.details = details
    }
}

const toApiError = (error) => {
    if (error instanceof ApiError) return error
    const res = error.response
    if (!res) {
        return new ApiError({ message: 'Cannot reach the server. Check that the backend is running.', code: 'NETWORK_ERROR' })
    }
    const body = res.data ?? {}
    // 422 validation: surface the first field message, e.g. "Password must contain at least one number"
    const first = body.error?.code === 'VALIDATION_ERROR' ? body.error.details?.[0]?.message : null
    return new ApiError({ message: first || body.message || 'Request failed', status: res.status, code: body.error?.code, details: body.error?.details })
}

export const http = axios.create({ baseURL: API_URL, withCredentials: true, timeout: 30000 })

http.interceptors.request.use((config) => {
    const token = tokenStore.get()
    if (token) config.headers.Authorization = `Bearer ${token}`
    return config
})

// One refresh at a time: concurrent 401s all wait for the same refresh request.
let refreshing = null
export const refreshSession = () => {
    refreshing ??= axios
        .post(`${API_URL}/auth/refresh`, null, { withCredentials: true })
        .then((res) => {
            const data = res.data.data
            tokenStore.set(data.accessToken)
            return data
        })
        .finally(() => { refreshing = null })
    return refreshing
}

const NO_REFRESH = ['/auth/login', '/auth/refresh', '/auth/logout']

http.interceptors.response.use(
    (response) => response,
    async (error) => {
        const { config, response } = error
        const isAuthCall = NO_REFRESH.some((p) => config?.url?.startsWith(p))
        if (response?.status === 401 && config && !config._retried && !isAuthCall) {
            config._retried = true
            try {
                const session = await refreshSession()
                config.headers.Authorization = `Bearer ${session.accessToken}`
                return await http(config)
            } catch (refreshError) {
                const refreshStatus = refreshError?.response?.status
                if (refreshStatus === 401 || refreshStatus === 403) {
                    tokenStore.clear()
                    authEvents.dispatchEvent(new Event('session-expired'))
                }
                throw toApiError(error)
            }
        }
        throw toApiError(error)
    },
)
