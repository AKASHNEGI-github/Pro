import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { authApi, usersApi } from '../api'
import { refreshSession, tokenStore } from '../api/http'

/** status: 'checking' (restoring session on page load) | 'authenticated' | 'anonymous' */
const initialState = { user: null, status: 'checking' }

/** On page load: use the httpOnly refresh cookie to get a fresh access token + the user. */
export const bootstrapSession = createAsyncThunk('auth/bootstrap', async (_, { rejectWithValue }) => {
    try {
        const session = await refreshSession()
        return session.user
    } catch {
        tokenStore.clear()
        return rejectWithValue(null)
    }
})

export const login = createAsyncThunk('auth/login', async (credentials, { rejectWithValue }) => {
    try {
        return (await authApi.login(credentials)).user
    } catch (e) {
        return rejectWithValue({ message: e.message, code: e.code })
    }
})

export const logout = createAsyncThunk('auth/logout', async () => { await authApi.logout() })

export const changePassword = createAsyncThunk('auth/changePassword', async (body, { rejectWithValue }) => {
    try {
        return (await authApi.changePassword(body)).user
    } catch (e) {
        return rejectWithValue({ message: e.message, code: e.code })
    }
})

export const reloadMe = createAsyncThunk('auth/me', async () => authApi.me())
export const updateProfile = createAsyncThunk('auth/updateProfile', async (body) => usersApi.updateProfile(body))
export const uploadAvatar = createAsyncThunk('auth/uploadAvatar', async (file) => usersApi.uploadAvatar(file))
export const removeAvatar = createAsyncThunk('auth/removeAvatar', async () => usersApi.removeAvatar())

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        sessionExpired: (state) => { state.user = null; state.status = 'anonymous' },
    },
    extraReducers: (builder) => {
        const setUser = (state, { payload }) => { state.user = payload; state.status = 'authenticated' }
        builder
            .addCase(bootstrapSession.fulfilled, setUser)
            .addCase(bootstrapSession.rejected, (state) => { state.user = null; state.status = 'anonymous' })
            .addCase(login.fulfilled, setUser)
            .addCase(changePassword.fulfilled, setUser)
            .addCase(reloadMe.fulfilled, setUser)
            .addCase(updateProfile.fulfilled, setUser)
            .addCase(uploadAvatar.fulfilled, setUser)
            .addCase(removeAvatar.fulfilled, setUser)
            .addCase(logout.fulfilled, (state) => { state.user = null; state.status = 'anonymous' })
            .addCase(logout.rejected, (state) => { state.user = null; state.status = 'anonymous' })
    },
})

export const { sessionExpired } = authSlice.actions
export default authSlice.reducer
