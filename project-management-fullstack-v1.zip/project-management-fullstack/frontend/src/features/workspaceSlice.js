import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { workspacesApi } from '../api'

const STORAGE_KEY = 'currentWorkspaceId'

const initialState = {
    workspaces: [],          // lightweight list for the switcher
    currentWorkspace: null,  // full overview: members, projects (+members, tasks), permissions
    loading: true,
    error: null,
    latestRequest: null,
}

/** Loads the workspace list, then the overview of the last-used (or first) workspace. */
export const fetchWorkspaces = createAsyncThunk('workspace/fetchAll', async (_, { rejectWithValue }) => {
    try {
        const list = await workspacesApi.list()
        const target = list.find((w) => w.id === localStorage.getItem(STORAGE_KEY)) ?? list[0]
        const overview = target ? await workspacesApi.overview(target.id) : null
        return { list, overview }
    } catch (e) {
        return rejectWithValue(e.message)
    }
})

/** Loads one workspace's overview. `silent: true` refreshes in the background without a full-screen spinner. */
export const loadWorkspace = createAsyncThunk('workspace/load', async ({ id }, { dispatch, rejectWithValue }) => {
    try {
        return await workspacesApi.overview(id)
    } catch (e) {
        if (e.status === 404 || e.status === 403) dispatch(fetchWorkspaces()) // lost access (removed / deleted)
        return rejectWithValue(e.message)
    }
})

/** Re-fetch the current workspace after any mutation so the UI always mirrors server truth. */
export const refreshWorkspace = () => (dispatch, getState) => {
    const id = getState().workspace.currentWorkspace?.id
    return id ? dispatch(loadWorkspace({ id, silent: true })) : Promise.resolve()
}

export const createWorkspace = createAsyncThunk('workspace/create', async (payload, { dispatch }) => {
    const ws = await workspacesApi.create(payload)
    await dispatch(fetchWorkspaces()).unwrap().catch(() => {})
    await dispatch(loadWorkspace({ id: ws.id }))
    return ws
})

export const deleteWorkspace = createAsyncThunk('workspace/delete', async (id, { dispatch }) => {
    await workspacesApi.remove(id)
    localStorage.removeItem(STORAGE_KEY)
    await dispatch(fetchWorkspaces())
})

const workspaceSlice = createSlice({
    name: 'workspace',
    initialState,
    reducers: {
        resetWorkspaces: () => ({ ...initialState }),
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchWorkspaces.pending, (state) => { state.loading = true; state.error = null })
            .addCase(fetchWorkspaces.fulfilled, (state, { payload }) => {
                state.workspaces = payload.list
                state.currentWorkspace = payload.overview
                state.loading = false
                if (payload.overview) localStorage.setItem(STORAGE_KEY, payload.overview.id)
            })
            .addCase(fetchWorkspaces.rejected, (state, { payload }) => { state.loading = false; state.error = payload ?? 'Could not load workspaces' })

            .addCase(loadWorkspace.pending, (state, { meta }) => {
                state.latestRequest = meta.requestId
                if (!meta.arg.silent) state.loading = true
            })
            .addCase(loadWorkspace.fulfilled, (state, { payload, meta }) => {
                if (state.latestRequest !== meta.requestId) return // a newer request superseded this one
                state.currentWorkspace = payload
                state.loading = false
                localStorage.setItem(STORAGE_KEY, payload.id)
                const i = state.workspaces.findIndex((w) => w.id === payload.id)
                if (i >= 0) {
                    state.workspaces[i] = { ...state.workspaces[i], name: payload.name, slug: payload.slug, image_url: payload.image_url, membersCount: payload.membersCount, myRole: payload.myRole }
                }
            })
            .addCase(loadWorkspace.rejected, (state, { meta }) => { if (!meta.arg.silent) state.loading = false })
    },
})

export const { resetWorkspaces } = workspaceSlice.actions
export default workspaceSlice.reducer
