import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { BrowserRouter } from 'react-router-dom'
import { store } from './app/store.js'
import { Provider } from 'react-redux'
import { authEvents } from './api/http.js'
import { sessionExpired } from './features/authSlice.js'

// If a token refresh fails (expired / revoked session), drop back to the login screen.
authEvents.addEventListener('session-expired', () => store.dispatch(sessionExpired()))

createRoot(document.getElementById('root')).render(
    <BrowserRouter>
        <Provider store={store}>
            <App />
        </Provider>
    </BrowserRouter>,
)
