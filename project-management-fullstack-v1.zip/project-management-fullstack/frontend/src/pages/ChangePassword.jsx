import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { ShieldCheckIcon } from 'lucide-react'
import toast from 'react-hot-toast'
import { changePassword, logout } from '../features/authSlice'
import { Field, inputClass, primaryBtn, Spinner } from '../components/ui/ui'

/** Shown right after sign-in when the account still has a temporary password (set by an administrator). */
const ChangePassword = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const user = useSelector((s) => s.auth.user)
    const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirm: '' })
    const [error, setError] = useState('')
    const [submitting, setSubmitting] = useState(false)

    const submit = async (e) => {
        e.preventDefault()
        setError('')
        if (form.newPassword !== form.confirm) return setError('The new passwords do not match')
        setSubmitting(true)
        const result = await dispatch(changePassword({ currentPassword: form.currentPassword, newPassword: form.newPassword }))
        setSubmitting(false)
        if (changePassword.rejected.match(result)) return setError(result.payload?.message || 'Could not change the password')
        toast.success('Password updated')
        navigate('/', { replace: true })
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-zinc-50 dark:bg-zinc-950 px-4">
            <div className="w-full max-w-sm">
                <div className="flex flex-col items-center mb-6 text-center">
                    <div className="size-11 rounded-xl bg-amber-500/15 flex items-center justify-center"><ShieldCheckIcon className="size-6 text-amber-500" /></div>
                    <h1 className="mt-4 text-2xl font-semibold text-zinc-900 dark:text-white">Choose a new password</h1>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">Hi {user?.name?.split(' ')[0]}, you are using a temporary password. Set your own to continue.</p>
                </div>

                <form onSubmit={submit} className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm space-y-4">
                    {error && <div role="alert" className="text-sm rounded border border-red-200 dark:border-red-500/30 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 px-3 py-2">{error}</div>}
                    <Field label="Temporary password"><input type="password" autoComplete="current-password" required value={form.currentPassword} onChange={(e) => setForm({ ...form, currentPassword: e.target.value })} className={inputClass} /></Field>
                    <Field label="New password" hint="At least 8 characters with a letter and a number."><input type="password" autoComplete="new-password" required minLength={8} value={form.newPassword} onChange={(e) => setForm({ ...form, newPassword: e.target.value })} className={inputClass} /></Field>
                    <Field label="Confirm new password"><input type="password" autoComplete="new-password" required value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} className={inputClass} /></Field>
                    <button type="submit" disabled={submitting} className={`${primaryBtn} w-full py-2.5`}>{submitting && <Spinner />} Update password</button>
                </form>
                <button onClick={() => dispatch(logout())} className="block mx-auto mt-4 text-xs text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300">Sign out</button>
            </div>
        </div>
    )
}

export default ChangePassword
