import { useEffect, useState } from "react";
import { CheckIcon, CopyIcon, KeyRoundIcon, RefreshCwIcon, XIcon } from "lucide-react";
import { UsersIcon, Search, UserPlus, Shield, Activity } from "lucide-react";
import AddMemberDialog from "../components/AddMemberDialog";
import { useDispatch, useSelector } from "react-redux";
import { membersApi, rolesApi } from "../api";
import { refreshWorkspace } from "../features/workspaceSlice";
import useCan from "../hooks/useCan";
import { Modal, Field, inputClass, primaryBtn, secondaryBtn, Spinner } from "../components/ui/ui";
import { generatePassword } from "../utils/text";
import { run } from "../utils/notify";

/** Admin sets a new temporary password (no email service: the admin shares it). */
function ResetPasswordDialog({ member, workspaceId, onClose }) {
    const [password, setPassword] = useState(() => generatePassword());
    const [saving, setSaving] = useState(false);
    const [done, setDone] = useState(false);
    const [copied, setCopied] = useState(false);

    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        if (await run(() => membersApi.resetPassword(workspaceId, member.userId, password))) setDone(true);
        setSaving(false);
    };
    const copy = async () => {
        await navigator.clipboard?.writeText(`Email: ${member.user.email}\nTemporary password: ${password}`);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <Modal title={`Set password for ${member.user.name}`} onClose={onClose} maxWidth="max-w-md">
            {done ? (
                <>
                    <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-3">Share this temporary password with them. They must change it at their next sign in.</p>
                    <div className="rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 p-4 text-sm font-mono">{password}</div>
                    <div className="flex justify-end gap-2 mt-5">
                        <button onClick={copy} className={secondaryBtn}>{copied ? <CheckIcon className="size-4" /> : <CopyIcon className="size-4" />} {copied ? "Copied" : "Copy"}</button>
                        <button onClick={onClose} className={primaryBtn}>Done</button>
                    </div>
                </>
            ) : (
                <form onSubmit={submit} className="space-y-4">
                    <p className="text-sm text-zinc-600 dark:text-zinc-400">Only possible for accounts you created that have not signed in yet. For anyone else, ask an Org Admin.</p>
                    <Field label="Temporary password">
                        <div className="flex gap-2">
                            <input value={password} onChange={(e) => setPassword(e.target.value)} minLength={8} required className={`${inputClass} font-mono`} />
                            <button type="button" onClick={() => setPassword(generatePassword())} className={secondaryBtn}><RefreshCwIcon className="size-4" /></button>
                        </div>
                    </Field>
                    <div className="flex justify-end gap-3"><button type="button" onClick={onClose} className={secondaryBtn}>Cancel</button><button disabled={saving} className={primaryBtn}>{saving && <Spinner />} Set password</button></div>
                </form>
            )}
        </Modal>
    );
}

/** Role dropdown + remove / reset-password buttons for one member row (only what the viewer is allowed to do). */
function MemberActions({ member, roles }) {
    const dispatch = useDispatch();
    const can = useCan();
    const me = useSelector((state) => state.auth.user);
    const workspace = useSelector((state) => state.workspace.currentWorkspace);
    const [resetting, setResetting] = useState(false);

    const isOwner = member.userId === workspace.ownerId;
    const isMe = member.userId === me.id;
    const canRole = can("workspace.member.update_role") && !isOwner && !isMe && roles.length > 0;
    const canRemove = can("workspace.member.remove") && !isOwner;
    const canReset = can("workspace.member.reset_password") && !isMe;

    const changeRole = async (roleId) => {
        if (await run(() => membersApi.updateRole(workspace.id, member.userId, roleId), "Role updated")) await dispatch(refreshWorkspace());
    };
    const remove = async () => {
        if (!window.confirm(`Remove ${member.user.name} from ${workspace.name}? They will also be removed from all its projects and their tasks become unassigned.`)) return;
        if (await run(() => membersApi.remove(workspace.id, member.userId), "Member removed")) await dispatch(refreshWorkspace());
    };

    return (
        <div className="flex items-center gap-2 justify-end">
            {canRole && (
                <select value={member.role?.id} onChange={(e) => changeRole(e.target.value)} className="text-xs rounded border border-gray-300 dark:border-zinc-700 dark:bg-zinc-900 px-1.5 py-1">
                    {roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
            )}
            {canReset && <button type="button" title="Set a new temporary password" onClick={() => setResetting(true)} className="p-1.5 rounded hover:bg-gray-100 dark:hover:bg-zinc-800"><KeyRoundIcon className="size-4" /></button>}
            {canRemove && <button type="button" title="Remove from workspace" onClick={remove} className="p-1.5 rounded hover:bg-red-100 dark:hover:bg-red-500/20 text-red-500"><XIcon className="size-4" /></button>}
            {resetting && <ResetPasswordDialog member={member} workspaceId={workspace.id} onClose={() => setResetting(false)} />}
        </div>
    );
}

const Team = () => {

    const [tasks, setTasks] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [users, setUsers] = useState([]);
    const [roles, setRoles] = useState([]);
    const can = useCan();
    const currentWorkspace = useSelector((state) => state?.workspace?.currentWorkspace || null);
    const projects = currentWorkspace?.projects || [];

    const filteredUsers = users.filter(
        (user) =>
            user?.user?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user?.user?.email?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Workspace roles for the per-member role dropdown
    useEffect(() => {
        if (currentWorkspace && can("workspace.member.update_role")) rolesApi.list(currentWorkspace.id, "WORKSPACE").then(setRoles).catch(() => setRoles([]));
    }, [currentWorkspace?.id]); // eslint-disable-line react-hooks/exhaustive-deps

    useEffect(() => {
        setUsers(currentWorkspace?.members || []);
        setTasks(currentWorkspace?.projects?.reduce((acc, project) => [...acc, ...project.tasks], []) || []);
    }, [currentWorkspace]);

    return (
        <div className="space-y-6 max-w-6xl mx-auto">
            {/* Header */}
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
                <div>
                    <h1 className="text-xl sm:text-2xl font-semibold text-gray-900 dark:text-white mb-1">Team</h1>
                    <p className="text-gray-500 dark:text-zinc-400 text-sm">
                        Manage team members and their contributions
                    </p>
                </div>
                {can("workspace.member.add") && (
                    <button onClick={() => setIsDialogOpen(true)} className="flex items-center px-5 py-2 rounded text-sm bg-gradient-to-br from-blue-500 to-blue-600 hover:opacity-90 text-white transition" >
                        <UserPlus className="w-4 h-4 mr-2" /> Add Member
                    </button>
                )}
                {isDialogOpen && <AddMemberDialog onClose={() => setIsDialogOpen(false)} />}
            </div>

            {/* Stats Cards */}
            <div className="flex flex-wrap gap-4">
                {/* Total Members */}
                <div className="max-sm:w-full dark:bg-gradient-to-br dark:from-zinc-800/70 dark:to-zinc-900/50 border border-gray-300 dark:border-zinc-800 rounded-lg p-6">
                    <div className="flex items-center justify-between gap-8 md:gap-22">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-zinc-400">Total Members</p>
                            <p className="text-xl font-bold text-gray-900 dark:text-white">{users.length}</p>
                        </div>
                        <div className="p-3 rounded-xl bg-blue-100 dark:bg-blue-500/10">
                            <UsersIcon className="size-4 text-blue-500 dark:text-blue-200" />
                        </div>
                    </div>
                </div>

                {/* Active Projects */}
                <div className="max-sm:w-full dark:bg-gradient-to-br dark:from-zinc-800/70 dark:to-zinc-900/50 border border-gray-300 dark:border-zinc-800 rounded-lg p-6">
                    <div className="flex items-center justify-between gap-8 md:gap-22">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-zinc-400">Active Projects</p>
                            <p className="text-xl font-bold text-gray-900 dark:text-white">
                                {projects.filter((p) => p.status !== "CANCELLED" && p.status !== "COMPLETED").length}
                            </p>
                        </div>
                        <div className="p-3 rounded-xl bg-emerald-100 dark:bg-emerald-500/10">
                            <Activity className="size-4 text-emerald-500 dark:text-emerald-200" />
                        </div>
                    </div>
                </div>

                {/* Total Tasks */}
                <div className="max-sm:w-full dark:bg-gradient-to-br dark:from-zinc-800/70 dark:to-zinc-900/50 border border-gray-300 dark:border-zinc-800 rounded-lg p-6">
                    <div className="flex items-center justify-between gap-8 md:gap-22">
                        <div>
                            <p className="text-sm text-gray-500 dark:text-zinc-400">Total Tasks</p>
                            <p className="text-xl font-bold text-gray-900 dark:text-white">{tasks.length}</p>
                        </div>
                        <div className="p-3 rounded-xl bg-purple-100 dark:bg-purple-500/10">
                            <Shield className="size-4 text-purple-500 dark:text-purple-200" />
                        </div>
                    </div>
                </div>
            </div>

            {/* Search */}
            <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-zinc-400 size-3" />
                <input placeholder="Search team members..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-8 w-full text-sm rounded-md border border-gray-300 dark:border-zinc-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-zinc-400 py-2 focus:outline-none focus:border-blue-500" />
            </div>

            {/* Team Members */}
            <div className="w-full">
                {filteredUsers.length === 0 ? (
                    <div className="col-span-full text-center py-16">
                        <div className="w-24 h-24 mx-auto mb-6 bg-gray-200 dark:bg-zinc-800 rounded-full flex items-center justify-center">
                            <UsersIcon className="w-12 h-12 text-gray-400 dark:text-zinc-500" />
                        </div>
                        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                            {users.length === 0
                                ? "No team members yet"
                                : "No members match your search"}
                        </h3>
                        <p className="text-gray-500 dark:text-zinc-400 mb-6">
                            {users.length === 0
                                ? "Add team members to start collaborating"
                                : "Try adjusting your search term"}
                        </p>
                    </div>
                ) : (
                    <div className="max-w-4xl w-full">
                        {/* Desktop Table */}
                        <div className="hidden sm:block overflow-x-auto rounded-md border border-gray-200 dark:border-zinc-800">
                            <table className="min-w-full divide-y divide-gray-200 dark:divide-zinc-800">
                                <thead className="bg-gray-50 dark:bg-zinc-900/50">
                                    <tr>
                                        <th className="px-6 py-2.5 text-left font-medium text-sm">
                                            Name
                                        </th>
                                        <th className="px-6 py-2.5 text-left font-medium text-sm">
                                            Email
                                        </th>
                                        <th className="px-6 py-2.5 text-left font-medium text-sm">
                                            Role
                                        </th>
                                    <th className="px-6 py-2.5 text-right font-medium text-sm">
                                            Actions
                                        </th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200 dark:divide-zinc-800">
                                    {filteredUsers.map((user) => (
                                        <tr
                                            key={user.id}
                                            className="hover:bg-gray-50 dark:hover:bg-zinc-800/50 transition-colors"
                                        >
                                            <td className="px-6 py-2.5 whitespace-nowrap flex items-center gap-3">
                                                <img
                                                    src={user.user.image}
                                                    alt={user.user.name}
                                                    className="size-7 rounded-full bg-gray-200 dark:bg-zinc-800"
                                                />
                                                <span className="text-sm text-zinc-800 dark:text-white truncate">
                                                    {user.user?.name || "Unknown User"}
                                                </span>
                                            </td>
                                            <td className="px-6 py-2.5 whitespace-nowrap text-sm text-gray-500 dark:text-zinc-400">
                                                {user.user.email}
                                            </td>
                                            <td className="px-6 py-2.5 whitespace-nowrap">
                                                <span
                                                    className={`px-2 py-1 text-xs rounded-md ${user.role?.name === "Workspace Admin"
                                                            ? "bg-purple-100 dark:bg-purple-500/20 text-purple-500 dark:text-purple-400"
                                                            : "bg-gray-200 dark:bg-zinc-700 text-gray-700 dark:text-zinc-300"
                                                        }`}
                                                >
                                                    {user.role?.name || "Member"}{user.userId === currentWorkspace.ownerId ? " · Owner" : ""}
                                                </span>
                                            </td>
                                            <td className="px-6 py-2.5 whitespace-nowrap"><MemberActions member={user} roles={roles} /></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        {/* Mobile Cards */}
                        <div className="sm:hidden space-y-3">
                            {filteredUsers.map((user) => (
                                <div
                                    key={user.id}
                                    className="p-4 border border-gray-200 dark:border-zinc-800 rounded-md bg-white dark:bg-zinc-900"
                                >
                                    <div className="flex items-center gap-3 mb-2">
                                        <img
                                            src={user.user.image}
                                            alt={user.user.name}
                                            className="size-9 rounded-full bg-gray-200 dark:bg-zinc-800"
                                        />
                                        <div>
                                            <p className="font-medium text-gray-900 dark:text-white">
                                                {user.user?.name || "Unknown User"}
                                            </p>
                                            <p className="text-sm text-gray-500 dark:text-zinc-400">
                                                {user.user.email}
                                            </p>
                                        </div>
                                    </div>
                                    <div>
                                        <span
                                            className={`px-2 py-1 text-xs rounded-md ${user.role?.name === "Workspace Admin"
                                                    ? "bg-purple-100 dark:bg-purple-500/20 text-purple-500 dark:text-purple-400"
                                                    : "bg-gray-200 dark:bg-zinc-700 text-gray-700 dark:text-zinc-300"
                                                }`}
                                        >
                                            {user.role?.name || "Member"}{user.userId === currentWorkspace.ownerId ? " · Owner" : ""}
                                        </span>
                                        <div className="mt-3"><MemberActions member={user} roles={roles} /></div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>


        </div>
    );
};

export default Team;
