import { useSearchParams } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { BuildingIcon, SettingsIcon, ShieldIcon } from 'lucide-react'
import useCan from '../hooks/useCan'
import GeneralSettings from '../components/settings/GeneralSettings'
import RolesManager from '../components/settings/RolesManager'
import OrganizationAdmin from '../components/settings/OrganizationAdmin'

const Settings = () => {
    const can = useCan()
    const workspace = useSelector((s) => s.workspace.currentWorkspace)
    const [params, setParams] = useSearchParams()

    const tabs = [
        { id: 'general', label: 'Workspace', icon: SettingsIcon, show: Boolean(workspace) },
        { id: 'roles', label: 'Roles & permissions', icon: ShieldIcon, show: Boolean(workspace) && can('role.view') },
        { id: 'organization', label: 'Organization', icon: BuildingIcon, show: can('user.manage') },
    ].filter((t) => t.show)

    const active = tabs.find((t) => t.id === params.get('tab')) ?? tabs[0]

    if (!active) return <p className="text-zinc-500 dark:text-zinc-400">Nothing to configure here yet.</p>

    return (
        <div className="max-w-5xl mx-auto">
            <div className="mb-6">
                <h1 className="text-2xl font-semibold text-zinc-900 dark:text-white">Settings</h1>
                <p className="text-sm text-gray-500 dark:text-zinc-400 mt-1">{workspace ? `Manage ${workspace.name} and your organization.` : 'Manage your organization.'}</p>
            </div>

            <div className="flex gap-1 border-b border-gray-200 dark:border-zinc-800 mb-6 overflow-x-auto no-scrollbar">
                {tabs.map(({ id, label, icon: Icon }) => (
                    <button key={id} onClick={() => setParams({ tab: id })} className={`flex items-center gap-2 px-4 py-2.5 text-sm whitespace-nowrap border-b-2 -mb-px transition ${active.id === id ? 'border-blue-500 text-blue-600 dark:text-blue-400 font-medium' : 'border-transparent text-gray-500 dark:text-zinc-400 hover:text-gray-800 dark:hover:text-zinc-200'}`}>
                        <Icon className="size-4" /> {label}
                    </button>
                ))}
            </div>

            {active.id === 'general' && <GeneralSettings />}
            {active.id === 'roles' && <RolesManager />}
            {active.id === 'organization' && <OrganizationAdmin />}
        </div>
    )
}

export default Settings
