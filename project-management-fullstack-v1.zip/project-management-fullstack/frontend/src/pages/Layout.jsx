import { useState, useEffect } from 'react'
import Navbar from '../components/Navbar'
import Sidebar from '../components/Sidebar'
import { Outlet, useLocation } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { Loader2Icon, FolderPlusIcon, AlertTriangleIcon } from 'lucide-react'
import { fetchWorkspaces } from '../features/workspaceSlice'
import CreateWorkspaceDialog from '../components/CreateWorkspaceDialog'
import useCan from '../hooks/useCan'
import { primaryBtn, secondaryBtn } from '../components/ui/ui'

const Layout = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false)
    const [showCreateWorkspace, setShowCreateWorkspace] = useState(false)
    const { loading, currentWorkspace, error } = useSelector((state) => state.workspace)
    const dispatch = useDispatch()
    const can = useCan()
    const { pathname } = useLocation()

    // Load the user's workspaces (and the active workspace's projects/tasks) from the API.
    useEffect(() => {
        dispatch(fetchWorkspaces())
    }, [dispatch])

    if (loading) return (
        <div className='flex items-center justify-center h-screen bg-white dark:bg-zinc-950'>
            <Loader2Icon className="size-7 text-blue-500 animate-spin" />
        </div>
    )

    // Org-level settings stay reachable even if the user has no workspace.
    const showContent = currentWorkspace || pathname.startsWith('/settings')

    return (
        <div className="flex bg-white dark:bg-zinc-950 text-gray-900 dark:text-slate-100">
            <Sidebar isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} />
            <div className="flex-1 flex flex-col h-screen min-w-0">
                <Navbar isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} />
                <div className="flex-1 h-full p-6 xl:p-10 xl:px-16 overflow-y-scroll">
                    {showContent ? <Outlet /> : (
                        <div className="max-w-md mx-auto mt-24 text-center">
                            <div className="mx-auto size-14 rounded-2xl bg-blue-500/10 flex items-center justify-center mb-5">
                                {error ? <AlertTriangleIcon className="size-7 text-amber-500" /> : <FolderPlusIcon className="size-7 text-blue-500" />}
                            </div>
                            {error ? (
                                <>
                                    <h2 className="text-xl font-semibold">Could not load your workspaces</h2>
                                    <p className="text-sm text-gray-500 dark:text-zinc-400 mt-2">{error}</p>
                                    <button onClick={() => dispatch(fetchWorkspaces())} className={`${secondaryBtn} mt-5`}>Try again</button>
                                </>
                            ) : (
                                <>
                                    <h2 className="text-xl font-semibold">You are not in a workspace yet</h2>
                                    <p className="text-sm text-gray-500 dark:text-zinc-400 mt-2">
                                        {can('workspace.create')
                                            ? 'Create the first workspace to start organizing projects and tasks.'
                                            : 'Ask a workspace admin to add you. Once you are added, your workspace will show up here.'}
                                    </p>
                                    {can('workspace.create') && <button onClick={() => setShowCreateWorkspace(true)} className={`${primaryBtn} mt-5`}>Create workspace</button>}
                                </>
                            )}
                        </div>
                    )}
                </div>
            </div>
            {showCreateWorkspace && <CreateWorkspaceDialog onClose={() => setShowCreateWorkspace(false)} />}
        </div>
    )
}

export default Layout
