import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { useLocation, useNavigate } from 'react-router-dom'
import { EyeIcon, EyeOffIcon, LockIcon, MailIcon, FolderKanbanIcon } from 'lucide-react'
import { login } from '../features/authSlice'
import { Field, inputClass, primaryBtn, Spinner } from '../components/ui/ui'

const Login = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const location = useLocation()
    const [form, setForm] = useState({ email: '', password: '' })
    const [showPassword, setShowPassword] = useState(false)
    const [error, setError] = useState('')
    const [submitting, setSubmitting] = useState(false)

    const submit = async (e) => {
        e.preventDefault()
        setError('')
        setSubmitting(true)
        const result = await dispatch(login({ email: form.email.trim(), password: form.password }))
        setSubmitting(false)
        if (login.rejected.match(result)) return setError(result.payload?.message || 'Could not sign in')
        navigate(result.payload.mustChangePassword ? '/change-password' : location.state?.from || '/', { replace: true })
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-zinc-50 dark:bg-zinc-950 px-4">
            <div className="w-full max-w-sm">
                <div className="flex flex-col items-center mb-6">
                    <div className="size-11 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow">
                        <FolderKanbanIcon className="size-6 text-white" />
                    </div>
                    <h1 className="mt-4 text-2xl font-semibold text-zinc-900 dark:text-white">Sign in</h1>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">to continue to Project Management</p>
                </div>

                <form onSubmit={submit} className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm space-y-4">
                    {error && <div role="alert" className="text-sm rounded border border-red-200 dark:border-red-500/30 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 px-3 py-2">{error}</div>}

                    <Field label="Email address">
                        <div className="relative">
                            <MailIcon className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-zinc-400" />
                            <input type="email" autoFocus autoComplete="username" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@company.com" className={`${inputClass} pl-9`} />
                        </div>
                    </Field>

                    <Field label="Password">
                        <div className="relative">
                            <LockIcon className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-zinc-400" />
                            <input type={showPassword ? 'text' : 'password'} autoComplete="current-password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="Your password" className={`${inputClass} pl-9 pr-10`} />
                            <button type="button" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword((v) => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200">
                                {showPassword ? <EyeOffIcon className="size-4" /> : <EyeIcon className="size-4" />}
                            </button>
                        </div>
                    </Field>

                    <button type="submit" disabled={submitting} className={`${primaryBtn} w-full py-2.5`}>
                        {submitting && <Spinner />} {submitting ? 'Signing in...' : 'Sign in'}
                    </button>
                </form>
                <p className="text-xs text-center text-zinc-500 dark:text-zinc-500 mt-4">Accounts are created by your administrator. Forgot your password? Ask them to reset it.</p>
            </div>
        </div>
    )
}

export default Login
