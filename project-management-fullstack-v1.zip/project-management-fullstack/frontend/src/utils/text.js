export const slugify = (input = '') =>
    input.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60)

/** Readable temporary password (no ambiguous characters) that satisfies the backend policy (letters + digits, 8+). */
export const generatePassword = (length = 12) => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'
    const bytes = crypto.getRandomValues(new Uint32Array(length))
    const pwd = Array.from(bytes, (b) => chars[b % chars.length]).join('')
    return /[A-Za-z]/.test(pwd) && /\d/.test(pwd) ? pwd : generatePassword(length)
}

export const MAX_IMAGE_BYTES = 10 * 1024 * 1024
export const validateImage = (file) => {
    if (!file) return null
    if (!['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(file.type)) return 'Use a PNG, JPEG, WEBP or GIF image'
    if (file.size > MAX_IMAGE_BYTES) return 'Image must be 10MB or smaller'
    return null
}
