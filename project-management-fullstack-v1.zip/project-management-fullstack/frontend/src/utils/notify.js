import toast from 'react-hot-toast'

/** Shows the server's message (already human readable) or a fallback. */
export const toastError = (error, fallback = 'Something went wrong') => toast.error(error?.message || fallback)

/** Runs an async action with success/error toasts. Returns the result, or undefined on failure. */
export async function run(action, successMessage) {
    try {
        const result = await action()
        if (successMessage) toast.success(successMessage)
        return result
    } catch (error) {
        toastError(error)
        return undefined
    }
}

export const initials = (name = '') => name.trim().split(/\s+/).slice(0, 2).map((p) => p[0]?.toUpperCase()).join('') || '?'
