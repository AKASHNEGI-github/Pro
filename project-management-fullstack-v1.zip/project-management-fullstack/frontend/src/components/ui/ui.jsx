import { useEffect, useState } from 'react'
import { XIcon, Loader2Icon } from 'lucide-react'

export const inputClass =
    'w-full px-3 py-2 rounded dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-200 text-sm focus:outline-none focus:border-blue-500 disabled:opacity-60'
export const primaryBtn =
    'px-4 py-2 rounded text-sm bg-gradient-to-br from-blue-500 to-blue-600 text-white dark:text-zinc-200 hover:opacity-90 disabled:opacity-60 disabled:cursor-not-allowed transition inline-flex items-center justify-center gap-2'
export const darkBtn =
    'px-4 py-2 rounded-md text-sm bg-zinc-900 text-white hover:bg-zinc-700 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-white disabled:opacity-60 disabled:cursor-not-allowed transition inline-flex items-center justify-center gap-2'
export const secondaryBtn =
    'px-4 py-2 rounded text-sm border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition disabled:opacity-60 disabled:cursor-not-allowed inline-flex items-center justify-center gap-2'
export const dangerBtn =
    'px-4 py-2 rounded text-sm bg-red-600 text-white hover:bg-red-700 disabled:opacity-60 disabled:cursor-not-allowed transition inline-flex items-center justify-center gap-2'

export const Spinner = ({ className = 'size-4' }) => <Loader2Icon className={`${className} animate-spin`} />

export function Field({ label, hint, error, children, className = '' }) {
    return (
        <div className={className}>
            {label && <label className="block text-sm mb-1 text-zinc-800 dark:text-zinc-200">{label}</label>}
            {children}
            {error ? <p className="text-xs text-red-500 mt-1">{error}</p> : hint ? <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">{hint}</p> : null}
        </div>
    )
}

/** Same look as the app's existing dialogs. Closes on Escape or backdrop click. */
export function Modal({ title, subtitle, onClose, children, maxWidth = 'max-w-lg' }) {
    useEffect(() => {
        const onKey = (e) => e.key === 'Escape' && onClose?.()
        document.addEventListener('keydown', onKey)
        return () => document.removeEventListener('keydown', onKey)
    }, [onClose])

    return (
        <div className="fixed inset-0 bg-black/20 dark:bg-black/60 backdrop-blur flex items-center justify-center text-left z-50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose?.()}>
            <div role="dialog" aria-modal="true" className={`bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-6 w-full ${maxWidth} max-h-[92vh] overflow-y-auto text-zinc-900 dark:text-zinc-200 relative`}>
                <button type="button" aria-label="Close" className="absolute top-3 right-3 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200" onClick={onClose}>
                    <XIcon className="size-5" />
                </button>
                {title && <h2 className="text-xl font-medium mb-1 pr-6">{title}</h2>}
                {subtitle && <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">{subtitle}</p>}
                {!subtitle && title && <div className="mb-4" />}
                {children}
            </div>
        </div>
    )
}

/** <img> that falls back to initials if the URL is empty or fails to load. */
export function Avatar({ src, name = '?', className = 'size-8', rounded = 'rounded-full' }) {
    const [failed, setFailed] = useState(false)
    useEffect(() => setFailed(false), [src])
    if (!src || failed) {
        const initials = name.trim().split(/\s+/).slice(0, 2).map((p) => p[0]?.toUpperCase()).join('') || '?'
        return <div className={`${className} ${rounded} bg-blue-600 text-white text-xs font-medium flex items-center justify-center shrink-0`}>{initials}</div>
    }
    return <img src={src} alt={name} onError={() => setFailed(true)} className={`${className} ${rounded} object-cover shrink-0`} />
}

export const Badge = ({ children, tone = 'zinc' }) => {
    const tones = {
        zinc: 'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300',
        blue: 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-400',
        green: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-400',
        amber: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-400',
        red: 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-400',
    }
    return <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${tones[tone]}`}>{children}</span>
}
