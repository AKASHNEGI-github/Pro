import { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { LogOutIcon, SettingsIcon, UserCircleIcon } from 'lucide-react'
import { logout } from '../features/authSlice'
import ProfileDialog from './ProfileDialog'
import { Avatar, Badge } from './ui/ui'

/** Avatar button in the navbar: profile & security dialog, settings, sign out. */
export default function UserMenu() {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const user = useSelector((s) => s.auth.user)
    const [open, setOpen] = useState(false)
    const [profileTab, setProfileTab] = useState(null)
    const ref = useRef(null)

    useEffect(() => {
        const onDown = (e) => ref.current && !ref.current.contains(e.target) && setOpen(false)
        document.addEventListener('mousedown', onDown)
        return () => document.removeEventListener('mousedown', onDown)
    }, [])

    if (!user) return null

    const item = 'w-full flex items-center gap-2.5 px-3 py-2 text-sm text-left rounded hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-800 dark:text-zinc-100'

    return (
        <div className="relative" ref={ref}>
            <button onClick={() => setOpen((v) => !v)} aria-label="Account menu" className="block rounded-full ring-offset-2 ring-blue-500 dark:ring-offset-zinc-900 hover:ring-2 transition">
                <Avatar src={user.image} name={user.name} className="size-8" />
            </button>
            {open && (
                <div className="absolute right-0 mt-2 w-64 z-50 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-700 rounded-lg shadow-lg p-2">
                    <div className="flex items-center gap-3 p-2">
                        <Avatar src={user.image} name={user.name} className="size-10" />
                        <div className="min-w-0">
                            <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{user.name}</p>
                            <p className="text-xs text-gray-500 dark:text-zinc-400 truncate">{user.email}</p>
                        </div>
                    </div>
                    {user.globalRole?.key === 'ORG_ADMIN' && <div className="px-2 pb-2"><Badge tone="blue">{user.globalRole.name}</Badge></div>}
                    <hr className="border-gray-200 dark:border-zinc-800 my-1" />
                    <button className={item} onClick={() => { setProfileTab('profile'); setOpen(false) }}><UserCircleIcon className="size-4" /> Manage account</button>
                    <button className={item} onClick={() => { navigate('/settings'); setOpen(false) }}><SettingsIcon className="size-4" /> Settings</button>
                    <button className={item} onClick={() => dispatch(logout())}><LogOutIcon className="size-4" /> Sign out</button>
                </div>
            )}
            {profileTab && <ProfileDialog initialTab={profileTab} onClose={() => setProfileTab(null)} />}
        </div>
    )
}
