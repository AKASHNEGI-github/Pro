import { useEffect, useState } from "react";
import { Clock, FolderPlus, ListChecks, MessageSquare, UserPlus, Shield, Trash2, Pencil, CheckCircle2, Building2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useSelector } from "react-redux";
import { activityApi } from "../api";
import { Avatar } from "./ui/ui";

// Turns an activity-log row into a sentence + icon.
const ICONS = {
    "workspace": { icon: Building2, color: "text-purple-500 dark:text-purple-400" },
    "member": { icon: UserPlus, color: "text-blue-500 dark:text-blue-400" },
    "project": { icon: FolderPlus, color: "text-emerald-500 dark:text-emerald-400" },
    "task": { icon: ListChecks, color: "text-amber-500 dark:text-amber-400" },
    "comment": { icon: MessageSquare, color: "text-sky-500 dark:text-sky-400" },
    "role": { icon: Shield, color: "text-rose-500 dark:text-rose-400" },
};

const pretty = (s = "") => s.replace("_", " ").toLowerCase();

const describe = (a) => {
    const m = a.metadata || {};
    switch (a.action) {
        case "workspace.created": return `created the workspace “${m.name ?? ""}”`;
        case "workspace.updated": return "updated the workspace settings";
        case "workspace.ownership_transferred": return `transferred ownership to ${m.to}`;
        case "member.added": return `added ${m.name} to the workspace as ${m.role}`;
        case "member.removed": return `removed ${m.name} from the workspace`;
        case "member.role_changed": return `changed ${m.name}'s role: ${m.from} → ${m.to}`;
        case "project.created": return `created the project “${m.name}”`;
        case "project.updated": return `updated the project “${m.name}”`;
        case "project.deleted": return `deleted the project “${m.name}”`;
        case "project.member_added": return `added ${m.name} to the project as ${m.role}`;
        case "project.member_removed": return `removed ${m.name} from the project`;
        case "project.member_role_changed": return `changed a project member's role to ${m.role}`;
        case "task.created": return `created the task “${m.title}”`;
        case "task.updated": return `updated the task “${m.title}”`;
        case "task.status_changed": return `moved “${m.title}” from ${pretty(m.from)} to ${pretty(m.to)}`;
        case "task.assigned": return `changed the assignee of “${m.title}”`;
        case "task.deleted": return m.count ? `deleted ${m.count} tasks` : `deleted the task “${m.title}”`;
        case "comment.created": return `commented on “${m.taskTitle}”`;
        case "role.created": return `created the role “${m.name}”`;
        case "role.updated": return `updated the role “${m.name}”`;
        case "role.deleted": return `deleted the role “${m.name}”`;
        default: return a.action;
    }
};

const RecentActivity = () => {
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const { currentWorkspace } = useSelector((state) => state.workspace);

    // The workspace object is replaced after every change, so the feed refreshes automatically.
    useEffect(() => {
        if (!currentWorkspace) return;
        activityApi.list(currentWorkspace.id, { limit: 15 })
            .then(setItems)
            .catch(() => setItems([]))
            .finally(() => setLoading(false));
    }, [currentWorkspace]);

    return (
        <div className="bg-white dark:bg-zinc-950 dark:bg-gradient-to-br dark:from-zinc-800/70 dark:to-zinc-900/50 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 rounded-lg transition-all overflow-hidden">
            <div className="border-b border-zinc-200 dark:border-zinc-800 p-4">
                <h2 className="text-lg text-zinc-800 dark:text-zinc-200">Recent Activity</h2>
            </div>

            <div className="p-0">
                {!loading && items.length === 0 ? (
                    <div className="p-12 text-center">
                        <div className="w-16 h-16 mx-auto mb-4 bg-zinc-200 dark:bg-zinc-800 rounded-full flex items-center justify-center">
                            <Clock className="w-8 h-8 text-zinc-600 dark:text-zinc-500" />
                        </div>
                        <p className="text-zinc-600 dark:text-zinc-400">No recent activity</p>
                    </div>
                ) : (
                    <div className="divide-y divide-zinc-200 dark:divide-zinc-800">
                        {items.map((a) => {
                            const { icon: Icon, color } = ICONS[a.entityType] || { icon: Pencil, color: "text-gray-500" };
                            return (
                                <div key={a.id} className="p-5 hover:bg-zinc-50 dark:hover:bg-zinc-900/50 transition-colors">
                                    <div className="flex items-start gap-4">
                                        <div className="p-2 bg-zinc-200 dark:bg-zinc-800 rounded-lg">
                                            <Icon className={`w-4 h-4 ${color}`} />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm text-zinc-800 dark:text-zinc-200">
                                                <span className="font-medium">{a.actor?.name}</span> {describe(a)}
                                            </p>
                                            <div className="flex items-center gap-3 mt-1 text-xs text-zinc-500 dark:text-zinc-400">
                                                {a.projectName && <span className="px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800">{a.projectName}</span>}
                                                <span>{formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}</span>
                                            </div>
                                        </div>
                                        <Avatar src={a.actor?.image} name={a.actor?.name} className="size-6 hidden sm:flex" />
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};

export default RecentActivity;
