import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { CheckIcon, CopyIcon, UserPlusIcon, RefreshCwIcon } from 'lucide-react'
import toast from 'react-hot-toast'
import { membersApi, rolesApi } from '../api'
import { refreshWorkspace } from '../features/workspaceSlice'
import { Field, Modal, inputClass, primaryBtn, secondaryBtn, Spinner } from './ui/ui'
import { generatePassword } from '../utils/text'
import { toastError } from '../utils/notify'

/**
 * Onboard a user INTO the workspace (there is no email service, so the admin hands over the credentials).
 * Existing account -> added directly.  No account yet -> creates one with a temporary password.
 * Users must be onboarded here before they can be added to any project of this workspace.
 */
export default function AddMemberDialog({ onClose }) {
    const dispatch = useDispatch()
    const workspace = useSelector((s) => s.workspace.currentWorkspace)
    const [roles, setRoles] = useState([])
    const [roleId, setRoleId] = useState('')
    const [email, setEmail] = useState('')
    const [lookup, setLookup] = useState(null) // null | { exists, alreadyMember, user }
    const [looking, setLooking] = useState(false)
    const [name, setName] = useState('')
    const [password, setPassword] = useState(() => generatePassword())
    const [submitting, setSubmitting] = useState(false)
    const [created, setCreated] = useState(null) // credentials to hand over
    const [copied, setCopied] = useState(false)

    useEffect(() => {
        rolesApi.list(workspace.id, 'WORKSPACE').then((list) => {
            setRoles(list)
            setRoleId(list.find((r) => r.systemKey === 'WORKSPACE_MEMBER')?.id ?? list[0]?.id ?? '')
        }).catch(toastError)
    }, [workspace.id])

    // Look the email up (debounced) so the form only asks for name + password when no account exists.
    useEffect(() => {
        setLookup(null)
        if (!/^\S+@\S+\.\S+$/.test(email)) return undefined
        const timer = setTimeout(async () => {
            setLooking(true)
            try { setLookup(await membersApi.lookup(workspace.id, email.trim().toLowerCase())) } catch { setLookup(null) } finally { setLooking(false) }
        }, 400)
        return () => clearTimeout(timer)
    }, [email, workspace.id])

    const needsAccount = lookup && !lookup.exists
    const blocked = lookup?.alreadyMember || (lookup?.exists && lookup.isActive === false)

    const submit = async (e) => {
        e.preventDefault()
        if (!lookup) return toast.error('Enter a valid email address')
        if (needsAccount && !name.trim()) return toast.error('Enter the new member\'s name')
        setSubmitting(true)
        try {
            const body = { email: email.trim().toLowerCase(), roleId: roleId || undefined }
            if (needsAccount) { body.name = name.trim(); body.password = password }
            await membersApi.add(workspace.id, body)
            await dispatch(refreshWorkspace())
            if (needsAccount) setCreated({ email: body.email, name: body.name, password })
            else { toast.success(`${lookup.user.name} was added to the workspace`); onClose() }
        } catch (err) { toastError(err) } finally { setSubmitting(false) }
    }

    const copy = async () => {
        await navigator.clipboard?.writeText(`Sign-in for ${workspace.name}\nEmail: ${created.email}\nTemporary password: ${created.password}\n(You will be asked to choose a new password at first sign in.)`)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
    }

    if (created) {
        return (
            <Modal title="Member added" onClose={onClose} maxWidth="max-w-md">
                <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">An account was created for <b>{created.name}</b>. There is no email service, so share these sign-in details with them yourself.</p>
                <div className="rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 p-4 text-sm space-y-2 font-mono">
                    <div className="flex justify-between gap-4"><span className="text-zinc-500">Email</span><span className="truncate">{created.email}</span></div>
                    <div className="flex justify-between gap-4"><span className="text-zinc-500">Temporary password</span><span>{created.password}</span></div>
                </div>
                <p className="text-xs text-zinc-500 mt-2">They will be asked to choose their own password at first sign in. This password is not shown again.</p>
                <div className="flex justify-end gap-2 mt-5">
                    <button onClick={copy} className={secondaryBtn}>{copied ? <CheckIcon className="size-4" /> : <CopyIcon className="size-4" />} {copied ? 'Copied' : 'Copy details'}</button>
                    <button onClick={onClose} className={primaryBtn}>Done</button>
                </div>
            </Modal>
        )
    }

    return (
        <Modal title="Add member to workspace" subtitle={`They will be able to join projects in ${workspace.name} once added.`} onClose={onClose} maxWidth="max-w-md">
            <form onSubmit={submit} className="space-y-4">
                <Field label="Email address" hint={looking ? 'Checking...' : undefined}>
                    <input type="email" autoFocus value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@company.com" className={inputClass} />
                </Field>

                {lookup?.alreadyMember && <p className="text-sm text-amber-600 dark:text-amber-400">{lookup.user.name} is already a member of this workspace.</p>}
                {lookup?.exists && !lookup.alreadyMember && lookup.isActive === false && <p className="text-sm text-amber-600 dark:text-amber-400">This account is deactivated.</p>}
                {lookup?.exists && !blocked && <p className="text-sm text-emerald-600 dark:text-emerald-400">Existing account found: <b>{lookup.user.name}</b>. They will be added directly.</p>}

                {needsAccount && (
                    <>
                        <p className="text-sm text-zinc-600 dark:text-zinc-400">No account exists for this email yet. Create one:</p>
                        <Field label="Full name"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className={inputClass} maxLength={100} /></Field>
                        <Field label="Temporary password" hint="They must change it at first sign in.">
                            <div className="flex gap-2">
                                <input value={password} onChange={(e) => setPassword(e.target.value)} className={`${inputClass} font-mono`} minLength={8} />
                                <button type="button" title="Generate a new password" onClick={() => setPassword(generatePassword())} className={secondaryBtn}><RefreshCwIcon className="size-4" /></button>
                            </div>
                        </Field>
                    </>
                )}

                <Field label="Workspace role">
                    <select value={roleId} onChange={(e) => setRoleId(e.target.value)} className={inputClass}>
                        {roles.map((r) => <option key={r.id} value={r.id}>{r.name}{r.isSystem ? '' : ' (custom)'}</option>)}
                    </select>
                </Field>

                <div className="flex justify-end gap-3 pt-2">
                    <button type="button" onClick={onClose} className={secondaryBtn}>Cancel</button>
                    <button type="submit" disabled={submitting || !lookup || blocked} className={primaryBtn}>{submitting ? <Spinner /> : <UserPlusIcon className="size-4" />} {needsAccount ? 'Create & add' : 'Add member'}</button>
                </div>
            </form>
        </Modal>
    )
}
