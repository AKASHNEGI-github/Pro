import { useEffect, useMemo, useRef, useState } from 'react'
import { useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { createWorkspace } from '../features/workspaceSlice'
import { Field, Modal, inputClass, darkBtn, Spinner, Avatar } from './ui/ui'
import { slugify, validateImage } from '../utils/text'
import { toastError } from '../utils/notify'

/** "Create workspace" dialog (logo, name, slug), following the Create-organization design. */
export default function CreateWorkspaceDialog({ onClose }) {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const fileRef = useRef(null)
    const [name, setName] = useState('')
    const [slug, setSlug] = useState('')
    const [slugTouched, setSlugTouched] = useState(false)
    const [ownerEmail, setOwnerEmail] = useState('')
    const [logo, setLogo] = useState(null)
    const [imageError, setImageError] = useState('')
    const [submitting, setSubmitting] = useState(false)
    const [errors, setErrors] = useState({})

    const preview = useMemo(() => (logo ? URL.createObjectURL(logo) : ''), [logo])
    useEffect(() => () => preview && URL.revokeObjectURL(preview), [preview])

    const onName = (value) => {
        setName(value)
        if (!slugTouched) setSlug(slugify(value))
    }

    const onFile = (e) => {
        const file = e.target.files?.[0]
        const problem = validateImage(file)
        setImageError(problem || '')
        setLogo(problem ? null : file ?? null)
        e.target.value = ''
    }

    const submit = async (e) => {
        e.preventDefault()
        const next = {}
        if (name.trim().length < 2) next.name = 'Enter at least 2 characters'
        if (slug && !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug)) next.slug = 'Use lowercase letters, numbers and single hyphens'
        setErrors(next)
        if (Object.keys(next).length) return

        setSubmitting(true)
        try {
            await dispatch(createWorkspace({ name: name.trim(), slug, ownerEmail: ownerEmail.trim(), logo })).unwrap()
            toast.success('Workspace created')
            onClose()
            navigate('/')
        } catch (err) {
            toastError(err, 'Could not create the workspace')
        } finally {
            setSubmitting(false)
        }
    }

    return (
        <Modal title="Create workspace" onClose={onClose} maxWidth="max-w-md">
            <form onSubmit={submit} className="space-y-5">
                <div>
                    <p className="text-sm font-medium mb-2">Logo</p>
                    <div className="flex items-center gap-4">
                        <Avatar src={preview} name={name || 'W'} className="size-16" rounded="rounded-lg" />
                        <div>
                            <button type="button" onClick={() => fileRef.current?.click()} className="px-3 py-1.5 text-sm rounded-md border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800">Upload</button>
                            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1.5">Recommended size 1:1, up to 10MB.</p>
                            {imageError && <p className="text-xs text-red-500 mt-1">{imageError}</p>}
                        </div>
                        <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="hidden" onChange={onFile} />
                    </div>
                </div>

                <Field label="Name" error={errors.name}>
                    <input autoFocus value={name} onChange={(e) => onName(e.target.value)} placeholder="Acme Inc" className={inputClass} />
                </Field>

                <Field label="Slug" error={errors.slug} hint="Used in links. Letters, numbers and hyphens.">
                    <input value={slug} onChange={(e) => { setSlugTouched(true); setSlug(e.target.value.toLowerCase()) }} placeholder="acme-inc" className={inputClass} />
                </Field>

                <Field label="Owner email (optional)" hint="Leave empty to own the workspace yourself. The owner must already have an account.">
                    <input type="email" value={ownerEmail} onChange={(e) => setOwnerEmail(e.target.value)} placeholder="owner@company.com" className={inputClass} />
                </Field>

                <div className="flex justify-end">
                    <button type="submit" disabled={submitting} className={darkBtn}>{submitting && <Spinner />} Create workspace</button>
                </div>
            </form>
        </Modal>
    )
}
