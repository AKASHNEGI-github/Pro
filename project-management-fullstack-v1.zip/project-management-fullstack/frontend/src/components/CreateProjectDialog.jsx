import { useEffect, useState } from "react";
import { XIcon } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import toast from "react-hot-toast";
import { projectsApi } from "../api";
import { refreshWorkspace } from "../features/workspaceSlice";
import { Avatar } from "./ui/ui";
import { toastError } from "../utils/notify";

const field = "w-full px-3 py-2 rounded dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 mt-1 text-zinc-900 dark:text-zinc-200 text-sm focus:outline-none focus:border-blue-500";

const emptyForm = (leadId = "") => ({
    name: "",
    description: "",
    status: "PLANNING",
    priority: "MEDIUM",
    start_date: "",
    end_date: "",
    team_members: [],   // user ids (besides the lead)
    team_lead: leadId,
});

const CreateProjectDialog = ({ isDialogOpen, setIsDialogOpen }) => {

    const dispatch = useDispatch();
    const { currentWorkspace } = useSelector((state) => state.workspace);
    const me = useSelector((state) => state.auth.user);
    // Only people already onboarded into this workspace can be on a project.
    const members = (currentWorkspace?.members || []).filter((m) => m.user?.id);

    const [formData, setFormData] = useState(emptyForm());
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Each time the dialog opens: blank form, lead defaults to the current user if they belong to the workspace.
    useEffect(() => {
        if (isDialogOpen) setFormData(emptyForm(members.some((m) => m.userId === me?.id) ? me.id : ""));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isDialogOpen]);

    const byId = (id) => members.find((m) => m.userId === id)?.user;

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!formData.team_lead) return toast.error("Choose a project lead");
        if (formData.start_date && formData.end_date && formData.end_date < formData.start_date) return toast.error("End date must be on or after the start date");

        setIsSubmitting(true);
        try {
            await projectsApi.create(currentWorkspace.id, {
                name: formData.name.trim(),
                description: formData.description,
                status: formData.status,
                priority: formData.priority,
                start_date: formData.start_date || null,
                end_date: formData.end_date || null,
                team_lead: formData.team_lead,
                member_ids: formData.team_members,
            });
            await dispatch(refreshWorkspace());
            toast.success("Project created");
            setIsDialogOpen(false);
        } catch (err) {
            toastError(err);
        } finally {
            setIsSubmitting(false);
        }
    };

    const removeTeamMember = (id) => {
        setFormData((prev) => ({ ...prev, team_members: prev.team_members.filter((m) => m !== id) }));
    };

    if (!isDialogOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/20 dark:bg-black/60 backdrop-blur flex items-center justify-center text-left z-50 p-4">
            <div className="bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl p-6 w-full max-w-lg max-h-[92vh] overflow-y-auto text-zinc-900 dark:text-zinc-200 relative">
                <button className="absolute top-3 right-3 text-zinc-500 dark:text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200" onClick={() => setIsDialogOpen(false)} >
                    <XIcon className="size-5" />
                </button>

                <h2 className="text-xl font-medium mb-1">Create New Project</h2>
                {currentWorkspace && (
                    <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">
                        In workspace: <span className="text-blue-600 dark:text-blue-400">{currentWorkspace.name}</span>
                    </p>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                    {/* Project Name */}
                    <div>
                        <label className="block text-sm mb-1">Project Name</label>
                        <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} placeholder="Enter project name" className={field} minLength={2} maxLength={120} required />
                    </div>

                    {/* Description */}
                    <div>
                        <label className="block text-sm mb-1">Description</label>
                        <textarea value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} placeholder="Describe your project" className={`${field} h-20`} maxLength={2000} />
                    </div>

                    {/* Status & Priority */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm mb-1">Status</label>
                            <select value={formData.status} onChange={(e) => setFormData({ ...formData, status: e.target.value })} className={field} >
                                <option value="PLANNING">Planning</option>
                                <option value="ACTIVE">Active</option>
                                <option value="COMPLETED">Completed</option>
                                <option value="ON_HOLD">On Hold</option>
                                <option value="CANCELLED">Cancelled</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm mb-1">Priority</label>
                            <select value={formData.priority} onChange={(e) => setFormData({ ...formData, priority: e.target.value })} className={field} >
                                <option value="LOW">Low</option>
                                <option value="MEDIUM">Medium</option>
                                <option value="HIGH">High</option>
                            </select>
                        </div>
                    </div>

                    {/* Dates */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm mb-1">Start Date</label>
                            <input type="date" value={formData.start_date} onChange={(e) => setFormData({ ...formData, start_date: e.target.value })} className={field} />
                        </div>
                        <div>
                            <label className="block text-sm mb-1">End Date</label>
                            <input type="date" value={formData.end_date} onChange={(e) => setFormData({ ...formData, end_date: e.target.value })} min={formData.start_date || undefined} className={field} />
                        </div>
                    </div>

                    {/* Lead */}
                    <div>
                        <label className="block text-sm mb-1">Project Lead <span className="text-zinc-500">(becomes Project Manager)</span></label>
                        <select value={formData.team_lead} required onChange={(e) => setFormData({ ...formData, team_lead: e.target.value, team_members: formData.team_members.filter((id) => id !== e.target.value) })} className={field} >
                            <option value="">Select a lead</option>
                            {members.map((member) => (
                                <option key={member.userId} value={member.userId}>
                                    {member.user.name} ({member.user.email})
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Team Members */}
                    <div>
                        <label className="block text-sm mb-1">Team Members</label>
                        <select className={field} value=""
                            onChange={(e) => {
                                if (e.target.value && !formData.team_members.includes(e.target.value)) {
                                    setFormData((prev) => ({ ...prev, team_members: [...prev.team_members, e.target.value] }));
                                }
                            }}
                        >
                            <option value="">Add team members</option>
                            {members
                                .filter((m) => m.userId !== formData.team_lead && !formData.team_members.includes(m.userId))
                                .map((member) => (
                                    <option key={member.userId} value={member.userId}>
                                        {member.user.name} ({member.user.email})
                                    </option>
                                ))}
                        </select>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Only people already added to this workspace can join a project.</p>

                        {formData.team_members.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-2">
                                {formData.team_members.map((id) => (
                                    <div key={id} className="flex items-center gap-1.5 bg-blue-200/50 dark:bg-blue-500/20 text-blue-700 dark:text-blue-400 pl-1.5 pr-2 py-1 rounded-md text-sm" >
                                        <Avatar src={byId(id)?.image} name={byId(id)?.name} className="size-4" />
                                        {byId(id)?.name}
                                        <button type="button" onClick={() => removeTeamMember(id)} className="ml-0.5 hover:bg-blue-300/30 dark:hover:bg-blue-500/30 rounded" >
                                            <XIcon className="w-3 h-3" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Footer */}
                    <div className="flex justify-end gap-3 pt-2 text-sm">
                        <button type="button" onClick={() => setIsDialogOpen(false)} className="px-4 py-2 rounded border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-200 dark:hover:bg-zinc-800" >
                            Cancel
                        </button>
                        <button disabled={isSubmitting || !currentWorkspace} className="px-4 py-2 rounded bg-gradient-to-br from-blue-500 to-blue-600 text-white dark:text-zinc-200 disabled:opacity-60" >
                            {isSubmitting ? "Creating..." : "Create Project"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CreateProjectDialog;
