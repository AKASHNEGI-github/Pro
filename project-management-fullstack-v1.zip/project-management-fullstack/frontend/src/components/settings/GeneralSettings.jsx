import { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { workspacesApi } from '../../api'
import { deleteWorkspace, refreshWorkspace } from '../../features/workspaceSlice'
import useCan from '../../hooks/useCan'
import { Avatar, Badge, Field, inputClass, primaryBtn, secondaryBtn, dangerBtn, Spinner } from '../ui/ui'
import { run, toastError } from '../../utils/notify'
import { slugify, validateImage } from '../../utils/text'

const Section = ({ title, description, children }) => (
    <section className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg p-5 sm:p-6">
        <h3 className="font-medium text-zinc-900 dark:text-white">{title}</h3>
        {description && <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-0.5 mb-4">{description}</p>}
        {!description && <div className="mb-4" />}
        {children}
    </section>
)

export default function GeneralSettings() {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const can = useCan()
    const fileRef = useRef(null)
    const workspace = useSelector((s) => s.workspace.currentWorkspace)
    const me = useSelector((s) => s.auth.user)
    const canEdit = can('workspace.update')
    const isOwner = workspace.ownerId === me.id
    const [form, setForm] = useState({ name: workspace.name, slug: workspace.slug, description: workspace.description || '' })
    const [saving, setSaving] = useState(false)
    const [confirmName, setConfirmName] = useState('')
    const [newOwner, setNewOwner] = useState('')
    const [busy, setBusy] = useState(false)

    useEffect(() => { setForm({ name: workspace.name, slug: workspace.slug, description: workspace.description || '' }) }, [workspace.id, workspace.name, workspace.slug, workspace.description])

    const dirty = form.name !== workspace.name || form.slug !== workspace.slug || form.description !== (workspace.description || '')

    const save = async (e) => {
        e.preventDefault()
        setSaving(true)
        const ok = await run(() => workspacesApi.update(workspace.id, { name: form.name.trim(), slug: form.slug.trim(), description: form.description }), 'Workspace updated')
        if (ok) await dispatch(refreshWorkspace())
        setSaving(false)
    }

    const onLogo = async (e) => {
        const file = e.target.files?.[0]
        e.target.value = ''
        const problem = validateImage(file)
        if (problem) return toast.error(problem)
        if (!file) return
        setBusy(true)
        if (await run(() => workspacesApi.uploadLogo(workspace.id, file), 'Logo updated')) await dispatch(refreshWorkspace())
        setBusy(false)
    }
    const removeLogo = async () => {
        setBusy(true)
        if (await run(() => workspacesApi.removeLogo(workspace.id), 'Logo removed')) await dispatch(refreshWorkspace())
        setBusy(false)
    }

    const transfer = async () => {
        const target = workspace.members.find((m) => m.userId === newOwner)
        if (!target || !window.confirm(`Make ${target.user.name} the owner of ${workspace.name}? They will become a Workspace Admin and you will keep your current role.`)) return
        setBusy(true)
        if (await run(() => workspacesApi.transferOwnership(workspace.id, newOwner), 'Ownership transferred')) { setNewOwner(''); await dispatch(refreshWorkspace()) }
        setBusy(false)
    }

    const remove = async () => {
        setBusy(true)
        try {
            await dispatch(deleteWorkspace(workspace.id)).unwrap()
            toast.success('Workspace deleted')
            navigate('/')
        } catch (err) { toastError(err) } finally { setBusy(false) }
    }

    const canTransfer = canEdit && (isOwner || can('user.manage'))
    const canDelete = can('workspace.delete') && (isOwner || can('user.manage'))
    const ownerMember = workspace.members.find((m) => m.userId === workspace.ownerId)

    return (
        <div className="space-y-6">
            <Section title="Workspace profile" description={canEdit ? 'How this workspace appears to your team.' : 'You have read-only access to these settings.'}>
                <div className="flex items-center gap-4 mb-5">
                    <Avatar src={workspace.image_url} name={workspace.name} className="size-16" rounded="rounded-lg" />
                    {canEdit && (
                        <div className="flex gap-2">
                            <button type="button" disabled={busy} onClick={() => fileRef.current?.click()} className={secondaryBtn}>Upload logo</button>
                            <button type="button" disabled={busy} onClick={removeLogo} className={secondaryBtn}>Remove</button>
                            <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="hidden" onChange={onLogo} />
                        </div>
                    )}
                </div>
                <form onSubmit={save} className="space-y-4 max-w-xl">
                    <Field label="Name"><input disabled={!canEdit} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputClass} minLength={2} required /></Field>
                    <Field label="Slug" hint="Lowercase letters, numbers and hyphens.">
                        <input disabled={!canEdit} value={form.slug} onChange={(e) => setForm({ ...form, slug: slugify(e.target.value) })} className={inputClass} required />
                    </Field>
                    <Field label="Description"><textarea disabled={!canEdit} rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className={`${inputClass} resize-none`} maxLength={500} /></Field>
                    {canEdit && <button type="submit" disabled={!dirty || saving} className={primaryBtn}>{saving && <Spinner />} Save changes</button>}
                </form>
            </Section>

            <Section title="Details">
                <dl className="grid sm:grid-cols-3 gap-4 text-sm">
                    <div><dt className="text-zinc-500 dark:text-zinc-400">Owner</dt><dd className="mt-0.5 text-zinc-900 dark:text-zinc-100">{ownerMember?.user.name ?? workspace.owner?.name}</dd></div>
                    <div><dt className="text-zinc-500 dark:text-zinc-400">Members</dt><dd className="mt-0.5 text-zinc-900 dark:text-zinc-100">{workspace.membersCount}</dd></div>
                    <div><dt className="text-zinc-500 dark:text-zinc-400">Your role</dt><dd className="mt-0.5"><Badge tone="blue">{workspace.myRole?.name ?? 'Org Admin (not a member)'}</Badge></dd></div>
                </dl>
            </Section>

            {(canTransfer || canDelete) && (
                <Section title="Danger zone" description="These actions affect everyone in the workspace.">
                    <div className="space-y-6 max-w-xl">
                        {canTransfer && (
                            <div>
                                <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">Transfer ownership</p>
                                <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-2">The new owner must already be a member. They become a Workspace Admin.</p>
                                <div className="flex gap-2">
                                    <select value={newOwner} onChange={(e) => setNewOwner(e.target.value)} className={inputClass}>
                                        <option value="">Select a member</option>
                                        {workspace.members.filter((m) => m.userId !== workspace.ownerId && m.user.id).map((m) => <option key={m.userId} value={m.userId}>{m.user.name} ({m.user.email})</option>)}
                                    </select>
                                    <button disabled={!newOwner || busy} onClick={transfer} className={secondaryBtn}>Transfer</button>
                                </div>
                            </div>
                        )}
                        {canDelete && (
                            <div>
                                <p className="text-sm font-medium text-red-600 dark:text-red-400">Delete workspace</p>
                                <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-2">Permanently deletes all projects, tasks and comments in this workspace. Type <b>{workspace.name}</b> to confirm.</p>
                                <div className="flex gap-2">
                                    <input value={confirmName} onChange={(e) => setConfirmName(e.target.value)} placeholder={workspace.name} className={inputClass} />
                                    <button disabled={confirmName !== workspace.name || busy} onClick={remove} className={dangerBtn}>Delete</button>
                                </div>
                            </div>
                        )}
                    </div>
                </Section>
            )}
        </div>
    )
}
