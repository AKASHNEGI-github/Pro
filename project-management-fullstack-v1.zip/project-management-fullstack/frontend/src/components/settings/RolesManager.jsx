import { useCallback, useEffect, useMemo, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { LockIcon, PencilIcon, PlusIcon, Trash2Icon } from 'lucide-react'
import { rolesApi } from '../../api'
import { refreshWorkspace } from '../../features/workspaceSlice'
import useCan from '../../hooks/useCan'
import { Badge, Field, Modal, inputClass, primaryBtn, secondaryBtn, Spinner } from '../ui/ui'
import { run, toastError } from '../../utils/notify'

const BASE = { WORKSPACE: 'workspace.view', PROJECT: 'project.view' }

function RoleEditor({ workspaceId, role, catalog, onClose, onSaved }) {
    const can = useCan()
    const editing = Boolean(role)
    const [name, setName] = useState(role?.name ?? '')
    const [description, setDescription] = useState(role?.description ?? '')
    const [scope, setScope] = useState(role?.scope ?? 'PROJECT')
    const [selected, setSelected] = useState(() => new Set(role?.permissions ?? []))
    const [saving, setSaving] = useState(false)

    // Workspace roles may include workspace-level AND project-level permissions (the latter apply to every project); project roles only project-level.
    const allowed = useMemo(() => catalog.filter((p) => (scope === 'WORKSPACE' ? ['WORKSPACE', 'PROJECT'].includes(p.scope) : p.scope === 'PROJECT')), [catalog, scope])
    const groups = useMemo(() => allowed.reduce((acc, p) => ({ ...acc, [p.category]: [...(acc[p.category] ?? []), p] }), {}), [allowed])

    useEffect(() => { setSelected((prev) => new Set([...prev].filter((k) => allowed.some((p) => p.key === k)).concat(BASE[scope]))) }, [scope, allowed])

    const toggle = (key) => setSelected((prev) => { const next = new Set(prev); next.has(key) ? next.delete(key) : next.add(key); return next })

    const save = async (e) => {
        e.preventDefault()
        setSaving(true)
        const permissionKeys = [...selected]
        const result = await run(() => (editing ? rolesApi.update(workspaceId, role.id, { name: name.trim(), description, permissionKeys }) : rolesApi.create(workspaceId, { name: name.trim(), description, scope, permissionKeys })), editing ? 'Role updated' : 'Role created')
        setSaving(false)
        if (result) onSaved()
    }

    return (
        <Modal title={editing ? `Edit role: ${role.name}` : 'Create custom role'} subtitle="Choose exactly what members with this role can do." onClose={onClose} maxWidth="max-w-2xl">
            <form onSubmit={save} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="Role name"><input autoFocus value={name} onChange={(e) => setName(e.target.value)} minLength={2} maxLength={50} required className={inputClass} placeholder="e.g. Reviewer" /></Field>
                    <Field label="Applies to">
                        <select disabled={editing} value={scope} onChange={(e) => setScope(e.target.value)} className={inputClass}>
                            <option value="PROJECT">Projects (assigned per project)</option>
                            <option value="WORKSPACE">Workspace (assigned per member)</option>
                        </select>
                    </Field>
                </div>
                <Field label="Description"><input value={description} onChange={(e) => setDescription(e.target.value)} maxLength={300} className={inputClass} placeholder="What is this role for?" /></Field>

                <div className="space-y-4 max-h-[42vh] overflow-y-auto pr-1">
                    {Object.entries(groups).map(([category, perms]) => (
                        <div key={category}>
                            <p className="text-xs uppercase tracking-wider text-zinc-500 dark:text-zinc-400 mb-1.5">{category}</p>
                            <div className="space-y-1">
                                {perms.map((p) => {
                                    const locked = p.key === BASE[scope]
                                    const held = can(p.key)
                                    const disabled = locked || (!held && !selected.has(p.key))
                                    return (
                                        <label key={p.key} title={!held ? 'You cannot grant a permission you do not have yourself' : undefined} className={`flex items-start gap-3 p-2 rounded text-sm ${disabled ? 'opacity-60' : 'hover:bg-zinc-100 dark:hover:bg-zinc-900 cursor-pointer'}`}>
                                            <input type="checkbox" className="mt-0.5 !size-4 shrink-0" checked={selected.has(p.key)} disabled={disabled} onChange={() => toggle(p.key)} />
                                            <span>
                                                <span className="text-zinc-900 dark:text-zinc-100">{p.description}</span>
                                                <span className="block text-xs text-zinc-500 font-mono">{p.key}{locked ? ' · always included' : ''}</span>
                                            </span>
                                        </label>
                                    )
                                })}
                            </div>
                        </div>
                    ))}
                </div>

                <div className="flex justify-end gap-3 pt-2">
                    <button type="button" onClick={onClose} className={secondaryBtn}>Cancel</button>
                    <button type="submit" disabled={saving} className={primaryBtn}>{saving && <Spinner />} {editing ? 'Save role' : 'Create role'}</button>
                </div>
            </form>
        </Modal>
    )
}

function RoleCard({ role, canManage, onEdit, onDelete }) {
    const [open, setOpen] = useState(false)
    const shown = open ? role.permissions : role.permissions.slice(0, 5)
    return (
        <div className="border border-zinc-200 dark:border-zinc-800 rounded-lg p-4 bg-white dark:bg-zinc-900">
            <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-medium text-zinc-900 dark:text-white">{role.name}</h4>
                        {role.isSystem ? <Badge tone="zinc"><LockIcon className="inline size-3 -mt-0.5 mr-1" />Built-in</Badge> : <Badge tone="blue">Custom</Badge>}
                        <span className="text-xs text-zinc-500">{role.usageCount} assigned</span>
                    </div>
                    {role.description && <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">{role.description}</p>}
                </div>
                {canManage && !role.isSystem && (
                    <div className="flex gap-1 shrink-0">
                        <button onClick={onEdit} aria-label="Edit role" className="p-1.5 rounded hover:bg-zinc-100 dark:hover:bg-zinc-800"><PencilIcon className="size-4" /></button>
                        <button onClick={onDelete} aria-label="Delete role" className="p-1.5 rounded hover:bg-red-50 dark:hover:bg-red-500/10 text-red-500"><Trash2Icon className="size-4" /></button>
                    </div>
                )}
            </div>
            <div className="flex flex-wrap gap-1.5 mt-3">
                {shown.map((k) => <span key={k} className="text-xs font-mono px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300">{k}</span>)}
                {role.permissions.length > 5 && <button onClick={() => setOpen((v) => !v)} className="text-xs text-blue-600 dark:text-blue-400 hover:underline">{open ? 'Show less' : `+${role.permissions.length - 5} more`}</button>}
            </div>
        </div>
    )
}

export default function RolesManager() {
    const dispatch = useDispatch()
    const can = useCan()
    const workspace = useSelector((s) => s.workspace.currentWorkspace)
    const canManage = can('role.manage')
    const [roles, setRoles] = useState([])
    const [catalog, setCatalog] = useState([])
    const [loading, setLoading] = useState(true)
    const [editor, setEditor] = useState(null) // null | { role? }

    const load = useCallback(async () => {
        try {
            const [r, c] = await Promise.all([rolesApi.list(workspace.id), rolesApi.permissions()])
            setRoles(r); setCatalog(c)
        } catch (e) { toastError(e) } finally { setLoading(false) }
    }, [workspace.id])
    useEffect(() => { load() }, [load])

    const remove = async (role) => {
        if (!window.confirm(`Delete the role "${role.name}"?`)) return
        if (await run(() => rolesApi.remove(workspace.id, role.id), 'Role deleted')) load()
    }
    const saved = async () => { setEditor(null); await load(); dispatch(refreshWorkspace()) }

    if (loading) return <div className="flex justify-center py-16"><Spinner className="size-6 text-blue-500" /></div>

    const groups = [['Workspace roles', 'Assigned to people in the workspace (Team page).', roles.filter((r) => r.scope === 'WORKSPACE')], ['Project roles', 'Assigned to people inside a single project.', roles.filter((r) => r.scope === 'PROJECT')]]

    return (
        <div className="space-y-8">
            <div className="flex items-start justify-between gap-4">
                <p className="text-sm text-zinc-500 dark:text-zinc-400 max-w-2xl">Roles are bundles of permissions. A person's access is the combination of their workspace role and, inside a project, their project role. Built-in roles are fixed; create custom roles for anything in between.</p>
                {canManage && <button onClick={() => setEditor({})} className={`${primaryBtn} shrink-0`}><PlusIcon className="size-4" /> New role</button>}
            </div>
            {groups.map(([title, hint, list]) => (
                <section key={title}>
                    <h3 className="font-medium text-zinc-900 dark:text-white">{title}</h3>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-3">{hint}</p>
                    <div className="grid lg:grid-cols-2 gap-3">
                        {list.map((r) => <RoleCard key={r.id} role={r} canManage={canManage} onEdit={() => setEditor({ role: r })} onDelete={() => remove(r)} />)}
                    </div>
                </section>
            ))}
            {editor && <RoleEditor workspaceId={workspace.id} role={editor.role} catalog={catalog} onClose={() => setEditor(null)} onSaved={saved} />}
        </div>
    )
}
