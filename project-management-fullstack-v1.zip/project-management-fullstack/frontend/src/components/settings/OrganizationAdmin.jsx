import { useCallback, useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { CheckIcon, CopyIcon, KeyRoundIcon, PlusIcon, RefreshCwIcon, SearchIcon } from 'lucide-react'
import { format } from 'date-fns'
import { adminApi } from '../../api'
import { Avatar, Badge, Field, Modal, inputClass, primaryBtn, secondaryBtn, Spinner } from '../ui/ui'
import { run, toastError } from '../../utils/notify'
import { generatePassword } from '../../utils/text'

function Credentials({ email, password, onDone }) {
    const [copied, setCopied] = useState(false)
    const copy = async () => {
        await navigator.clipboard?.writeText(`Email: ${email}\nTemporary password: ${password}`)
        setCopied(true); setTimeout(() => setCopied(false), 2000)
    }
    return (
        <>
            <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-3">Share these details with the user. They must choose a new password at their next sign in. This password is not shown again.</p>
            <div className="rounded-lg border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 p-4 text-sm space-y-2 font-mono">
                <div className="flex justify-between gap-4"><span className="text-zinc-500">Email</span><span className="truncate">{email}</span></div>
                <div className="flex justify-between gap-4"><span className="text-zinc-500">Temporary password</span><span>{password}</span></div>
            </div>
            <div className="flex justify-end gap-2 mt-5">
                <button onClick={copy} className={secondaryBtn}>{copied ? <CheckIcon className="size-4" /> : <CopyIcon className="size-4" />} {copied ? 'Copied' : 'Copy'}</button>
                <button onClick={onDone} className={primaryBtn}>Done</button>
            </div>
        </>
    )
}

const PasswordInput = ({ value, onChange }) => (
    <div className="flex gap-2">
        <input value={value} onChange={(e) => onChange(e.target.value)} minLength={8} required className={`${inputClass} font-mono`} />
        <button type="button" title="Generate" onClick={() => onChange(generatePassword())} className={secondaryBtn}><RefreshCwIcon className="size-4" /></button>
    </div>
)

function CreateUserModal({ roles, onClose, onCreated }) {
    const [form, setForm] = useState({ name: '', email: '', password: generatePassword(), globalRoleId: roles.find((r) => r.key === 'USER')?.id ?? '' })
    const [saving, setSaving] = useState(false)
    const [done, setDone] = useState(null)
    const submit = async (e) => {
        e.preventDefault(); setSaving(true)
        const res = await run(() => adminApi.createUser({ ...form, email: form.email.trim().toLowerCase(), name: form.name.trim() }))
        setSaving(false)
        if (res) { setDone({ email: res.email, password: form.password }); onCreated() }
    }
    return (
        <Modal title={done ? 'User created' : 'Create user'} onClose={onClose} maxWidth="max-w-md">
            {done ? <Credentials {...done} onDone={onClose} /> : (
                <form onSubmit={submit} className="space-y-4">
                    <Field label="Full name"><input autoFocus required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputClass} maxLength={100} /></Field>
                    <Field label="Email"><input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputClass} /></Field>
                    <Field label="Temporary password" hint="At least 8 characters with a letter and a number."><PasswordInput value={form.password} onChange={(v) => setForm({ ...form, password: v })} /></Field>
                    <Field label="Organization role">
                        <select value={form.globalRoleId} onChange={(e) => setForm({ ...form, globalRoleId: e.target.value })} className={inputClass}>{roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select>
                    </Field>
                    <div className="flex justify-end gap-3"><button type="button" onClick={onClose} className={secondaryBtn}>Cancel</button><button disabled={saving} className={primaryBtn}>{saving && <Spinner />} Create user</button></div>
                </form>
            )}
        </Modal>
    )
}

function ResetPasswordModal({ user, onClose }) {
    const [password, setPassword] = useState(generatePassword())
    const [saving, setSaving] = useState(false)
    const [done, setDone] = useState(false)
    const submit = async (e) => {
        e.preventDefault(); setSaving(true)
        if (await run(() => adminApi.resetPassword(user.id, { newPassword: password }))) setDone(true)
        setSaving(false)
    }
    return (
        <Modal title={`Reset password for ${user.name}`} onClose={onClose} maxWidth="max-w-md">
            {done ? <Credentials email={user.email} password={password} onDone={onClose} /> : (
                <form onSubmit={submit} className="space-y-4">
                    <p className="text-sm text-zinc-600 dark:text-zinc-400">This signs the user out everywhere and requires them to set a new password at next sign in.</p>
                    <Field label="New temporary password"><PasswordInput value={password} onChange={setPassword} /></Field>
                    <div className="flex justify-end gap-3"><button type="button" onClick={onClose} className={secondaryBtn}>Cancel</button><button disabled={saving} className={primaryBtn}>{saving && <Spinner />} Reset password</button></div>
                </form>
            )}
        </Modal>
    )
}

export default function OrganizationAdmin() {
    const me = useSelector((s) => s.auth.user)
    const [users, setUsers] = useState([])
    const [meta, setMeta] = useState({ page: 1, totalPages: 1, total: 0 })
    const [roles, setRoles] = useState([])
    const [workspaces, setWorkspaces] = useState([])
    const [search, setSearch] = useState('')
    const [status, setStatus] = useState('all')
    const [page, setPage] = useState(1)
    const [loading, setLoading] = useState(true)
    const [modal, setModal] = useState(null)

    const load = useCallback(async () => {
        try {
            const { items, meta: m } = await adminApi.listUsers({ page, limit: 10, status, search: search || undefined })
            setUsers(items); setMeta(m)
        } catch (e) { toastError(e) } finally { setLoading(false) }
    }, [page, status, search])

    useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [load])
    useEffect(() => { adminApi.globalRoles().then(setRoles).catch(toastError); adminApi.workspaces().then(setWorkspaces).catch(toastError) }, [])

    const changeRole = async (u, globalRoleId) => { if (await run(() => adminApi.updateUser(u.id, { globalRoleId }), 'Role updated')) load() }
    const toggleActive = async (u) => {
        if (u.isActive && !window.confirm(`Deactivate ${u.name}? They will be signed out and cannot sign in until reactivated.`)) return
        if (await run(() => adminApi.updateUser(u.id, { isActive: !u.isActive }), u.isActive ? 'User deactivated' : 'User reactivated')) load()
    }

    return (
        <div className="space-y-10">
            <section>
                <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                    <div>
                        <h3 className="font-medium text-zinc-900 dark:text-white">Users</h3>
                        <p className="text-sm text-zinc-500 dark:text-zinc-400">Every account in the organization. Workspace admins add people to their own workspaces from the Team page.</p>
                    </div>
                    <button onClick={() => setModal({ type: 'create' })} className={primaryBtn}><PlusIcon className="size-4" /> Create user</button>
                </div>
                <div className="flex flex-wrap gap-3 mb-3">
                    <div className="relative flex-1 min-w-48 max-w-sm">
                        <SearchIcon className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-zinc-400" />
                        <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1) }} placeholder="Search name or email" className={`${inputClass} pl-8`} />
                    </div>
                    <select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1) }} className={`${inputClass} !w-auto`}>
                        <option value="all">All users</option><option value="active">Active</option><option value="deactivated">Deactivated</option>
                    </select>
                </div>
                <div className="border border-zinc-200 dark:border-zinc-800 rounded-lg overflow-x-auto bg-white dark:bg-zinc-900">
                    <table className="w-full text-sm min-w-[760px]">
                        <thead className="text-left text-xs uppercase tracking-wider text-zinc-500 border-b border-zinc-200 dark:border-zinc-800">
                            <tr><th className="p-3">User</th><th className="p-3">Organization role</th><th className="p-3">Workspaces</th><th className="p-3">Last sign in</th><th className="p-3">Status</th><th className="p-3 text-right">Actions</th></tr>
                        </thead>
                        <tbody>
                            {loading ? <tr><td colSpan={6} className="p-8 text-center"><Spinner className="size-5 inline text-blue-500" /></td></tr> : users.length === 0 ? <tr><td colSpan={6} className="p-8 text-center text-zinc-500">No users found</td></tr> : users.map((u) => (
                                <tr key={u.id} className="border-b last:border-0 border-zinc-100 dark:border-zinc-800/70">
                                    <td className="p-3"><div className="flex items-center gap-3 min-w-0"><Avatar src={u.image} name={u.name} className="size-8" /><div className="min-w-0"><p className="font-medium text-zinc-900 dark:text-zinc-100 truncate">{u.name}{u.id === me.id && <span className="text-xs text-zinc-500"> (you)</span>}</p><p className="text-xs text-zinc-500 truncate">{u.email}</p></div></div></td>
                                    <td className="p-3">
                                        <select disabled={u.id === me.id} value={u.globalRole.id} onChange={(e) => changeRole(u, e.target.value)} className={`${inputClass} !w-auto !py-1`}>{roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select>
                                    </td>
                                    <td className="p-3 text-zinc-600 dark:text-zinc-300">{u.workspacesCount}</td>
                                    <td className="p-3 text-zinc-600 dark:text-zinc-300">{u.lastLoginAt ? format(new Date(u.lastLoginAt), 'MMM d, yyyy') : 'Never'}</td>
                                    <td className="p-3">{u.isActive ? (u.mustChangePassword ? <Badge tone="amber">Temp password</Badge> : <Badge tone="green">Active</Badge>) : <Badge tone="red">Deactivated</Badge>}</td>
                                    <td className="p-3"><div className="flex justify-end gap-2">
                                        <button onClick={() => setModal({ type: 'reset', user: u })} title="Reset password" className="p-1.5 rounded hover:bg-zinc-100 dark:hover:bg-zinc-800"><KeyRoundIcon className="size-4" /></button>
                                        {u.id !== me.id && <button onClick={() => toggleActive(u)} className="text-xs px-2 py-1 rounded border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800">{u.isActive ? 'Deactivate' : 'Reactivate'}</button>}
                                    </div></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <div className="flex items-center justify-between mt-3 text-sm text-zinc-500">
                    <span>{meta.total} user{meta.total === 1 ? '' : 's'}</span>
                    <div className="flex items-center gap-2">
                        <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className={`${secondaryBtn} !py-1`}>Previous</button>
                        <span>Page {meta.page} of {meta.totalPages}</span>
                        <button disabled={page >= meta.totalPages} onClick={() => setPage((p) => p + 1)} className={`${secondaryBtn} !py-1`}>Next</button>
                    </div>
                </div>
            </section>

            <section>
                <h3 className="font-medium text-zinc-900 dark:text-white mb-3">All workspaces</h3>
                <div className="border border-zinc-200 dark:border-zinc-800 rounded-lg overflow-x-auto bg-white dark:bg-zinc-900">
                    <table className="w-full text-sm min-w-[560px]">
                        <thead className="text-left text-xs uppercase tracking-wider text-zinc-500 border-b border-zinc-200 dark:border-zinc-800"><tr><th className="p-3">Workspace</th><th className="p-3">Owner</th><th className="p-3">Members</th><th className="p-3">Projects</th></tr></thead>
                        <tbody>
                            {workspaces.length === 0 && <tr><td colSpan={4} className="p-6 text-center text-zinc-500">No workspaces yet</td></tr>}
                            {workspaces.map((w) => (
                                <tr key={w.id} className="border-b last:border-0 border-zinc-100 dark:border-zinc-800/70">
                                    <td className="p-3"><div className="flex items-center gap-3"><Avatar src={w.image_url} name={w.name} className="size-7" rounded="rounded" /><div><p className="font-medium text-zinc-900 dark:text-zinc-100">{w.name}</p><p className="text-xs text-zinc-500">/{w.slug}</p></div></div></td>
                                    <td className="p-3 text-zinc-600 dark:text-zinc-300">{w.owner.name}</td><td className="p-3">{w.membersCount}</td><td className="p-3">{w.projectsCount}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </section>

            {modal?.type === 'create' && <CreateUserModal roles={roles} onClose={() => setModal(null)} onCreated={load} />}
            {modal?.type === 'reset' && <ResetPasswordModal user={modal.user} onClose={() => setModal(null)} />}
        </div>
    )
}
