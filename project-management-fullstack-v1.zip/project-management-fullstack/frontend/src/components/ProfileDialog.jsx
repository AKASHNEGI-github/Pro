import { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { ShieldIcon, UserCircleIcon, XIcon } from 'lucide-react'
import toast from 'react-hot-toast'
import { changePassword, logout, removeAvatar, updateProfile, uploadAvatar } from '../features/authSlice'
import { resetWorkspaces } from '../features/workspaceSlice'
import { authApi } from '../api'
import { Avatar, Badge, Field, inputClass, primaryBtn, secondaryBtn, Spinner } from './ui/ui'
import { run, toastError } from '../utils/notify'
import { validateImage } from '../utils/text'

const Row = ({ label, children, action }) => (
    <div className="flex items-start gap-6 py-5 border-b border-zinc-200 dark:border-zinc-800 last:border-0">
        <div className="w-40 shrink-0 text-sm font-medium text-zinc-800 dark:text-zinc-200 pt-1">{label}</div>
        <div className="flex-1 min-w-0">{children}</div>
        {action}
    </div>
)

function ProfileTab() {
    const dispatch = useDispatch()
    const user = useSelector((s) => s.auth.user)
    const fileRef = useRef(null)
    const [editing, setEditing] = useState(false)
    const [name, setName] = useState(user.name)
    const [busy, setBusy] = useState(false)

    const saveName = async (e) => {
        e.preventDefault()
        if (name.trim().length < 1) return toast.error('Name is required')
        setBusy(true)
        try {
            await dispatch(updateProfile({ name: name.trim() })).unwrap()
            toast.success('Profile updated')
            setEditing(false)
        } catch (err) { toastError(err) } finally { setBusy(false) }
    }

    const onFile = async (e) => {
        const file = e.target.files?.[0]
        e.target.value = ''
        const problem = validateImage(file)
        if (problem) return toast.error(problem)
        if (!file) return
        setBusy(true)
        try { await dispatch(uploadAvatar(file)).unwrap(); toast.success('Profile photo updated') } catch (err) { toastError(err) } finally { setBusy(false) }
    }

    const removePhoto = async () => {
        setBusy(true)
        try { await dispatch(removeAvatar()).unwrap(); toast.success('Profile photo removed') } catch (err) { toastError(err) } finally { setBusy(false) }
    }

    return (
        <>
            <h3 className="text-lg font-semibold text-zinc-900 dark:text-white pb-4 border-b border-zinc-200 dark:border-zinc-800">Profile details</h3>
            <Row
                label="Profile"
                action={!editing && <button onClick={() => { setName(user.name); setEditing(true) }} className="text-sm text-blue-600 dark:text-blue-400 hover:underline shrink-0 pt-1">Update profile</button>}
            >
                {!editing ? (
                    <div className="flex items-center gap-3">
                        <Avatar src={user.image} name={user.name} className="size-10" />
                        <span className="text-sm font-medium text-zinc-900 dark:text-white truncate">{user.name}</span>
                    </div>
                ) : (
                    <form onSubmit={saveName} className="space-y-4">
                        <div className="flex items-center gap-4">
                            <Avatar src={user.image} name={user.name} className="size-14" />
                            <div className="flex flex-wrap gap-2">
                                <button type="button" disabled={busy} onClick={() => fileRef.current?.click()} className={secondaryBtn}>Upload photo</button>
                                {user.hasCustomImage && <button type="button" disabled={busy} onClick={removePhoto} className={secondaryBtn}>Remove</button>}
                            </div>
                            <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="hidden" onChange={onFile} />
                        </div>
                        <Field label="Full name"><input value={name} onChange={(e) => setName(e.target.value)} className={inputClass} maxLength={100} /></Field>
                        <div className="flex gap-2">
                            <button type="submit" disabled={busy} className={primaryBtn}>{busy && <Spinner />} Save</button>
                            <button type="button" onClick={() => setEditing(false)} className={secondaryBtn}>Cancel</button>
                        </div>
                    </form>
                )}
            </Row>
            <Row label="Email address">
                <div className="flex items-center gap-2 text-sm text-zinc-900 dark:text-zinc-100 truncate">
                    {user.email} <Badge tone="zinc">Primary</Badge>
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">Your email is your sign-in ID. Ask an administrator if it needs to change.</p>
            </Row>
            <Row label="Account type">
                <Badge tone={user.globalRole?.key === 'ORG_ADMIN' ? 'blue' : 'zinc'}>{user.globalRole?.name}</Badge>
            </Row>
        </>
    )
}

function SecurityTab({ onClose }) {
    const dispatch = useDispatch()
    const [open, setOpen] = useState(false)
    const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirm: '' })
    const [error, setError] = useState('')
    const [busy, setBusy] = useState(false)

    const submit = async (e) => {
        e.preventDefault()
        setError('')
        if (form.newPassword !== form.confirm) return setError('The new passwords do not match')
        setBusy(true)
        const result = await dispatch(changePassword({ currentPassword: form.currentPassword, newPassword: form.newPassword }))
        setBusy(false)
        if (changePassword.rejected.match(result)) return setError(result.payload?.message || 'Could not change the password')
        toast.success('Password changed. Other devices were signed out.')
        setForm({ currentPassword: '', newPassword: '', confirm: '' })
        setOpen(false)
    }

    const signOutEverywhere = async () => {
        if (!window.confirm('Sign out of every device, including this one?')) return
        await run(() => authApi.logoutAll())
        dispatch(resetWorkspaces())
        await dispatch(logout())
        onClose()
    }

    return (
        <>
            <h3 className="text-lg font-semibold text-zinc-900 dark:text-white pb-4 border-b border-zinc-200 dark:border-zinc-800">Security</h3>
            <Row label="Password" action={!open && <button onClick={() => setOpen(true)} className="text-sm text-blue-600 dark:text-blue-400 hover:underline shrink-0 pt-1">Change password</button>}>
                {!open ? (
                    <p className="text-sm text-zinc-600 dark:text-zinc-400 pt-1">••••••••••</p>
                ) : (
                    <form onSubmit={submit} className="space-y-3 max-w-sm">
                        {error && <div role="alert" className="text-sm rounded border border-red-200 dark:border-red-500/30 bg-red-50 dark:bg-red-500/10 text-red-600 dark:text-red-400 px-3 py-2">{error}</div>}
                        <Field label="Current password"><input type="password" autoComplete="current-password" required value={form.currentPassword} onChange={(e) => setForm({ ...form, currentPassword: e.target.value })} className={inputClass} /></Field>
                        <Field label="New password" hint="At least 8 characters with a letter and a number."><input type="password" autoComplete="new-password" required minLength={8} value={form.newPassword} onChange={(e) => setForm({ ...form, newPassword: e.target.value })} className={inputClass} /></Field>
                        <Field label="Confirm new password"><input type="password" autoComplete="new-password" required value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value })} className={inputClass} /></Field>
                        <div className="flex gap-2">
                            <button type="submit" disabled={busy} className={primaryBtn}>{busy && <Spinner />} Update password</button>
                            <button type="button" onClick={() => setOpen(false)} className={secondaryBtn}>Cancel</button>
                        </div>
                    </form>
                )}
            </Row>
            <Row label="Devices">
                <p className="text-sm text-zinc-600 dark:text-zinc-400 pt-1">Sign out of every browser and device where you are signed in.</p>
                <button onClick={signOutEverywhere} className={`${secondaryBtn} mt-3`}>Sign out of all devices</button>
            </Row>
        </>
    )
}

/** Account dialog: Profile + Security tabs. */
export default function ProfileDialog({ onClose, initialTab = 'profile' }) {
    const [tab, setTab] = useState(initialTab)
    useEffect(() => {
        const onKey = (e) => e.key === 'Escape' && onClose()
        document.addEventListener('keydown', onKey)
        return () => document.removeEventListener('keydown', onKey)
    }, [onClose])

    const tabs = [{ id: 'profile', label: 'Profile', icon: UserCircleIcon }, { id: 'security', label: 'Security', icon: ShieldIcon }]

    return (
        <div className="fixed inset-0 bg-black/20 dark:bg-black/60 backdrop-blur flex items-center justify-center z-50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
            <div role="dialog" aria-modal="true" className="relative w-full max-w-3xl h-[min(640px,92vh)] bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden flex text-zinc-900 dark:text-zinc-200 shadow-xl">
                <aside className="hidden sm:flex w-56 shrink-0 flex-col bg-gradient-to-b from-zinc-50 to-orange-50/40 dark:from-zinc-900 dark:to-zinc-900 border-r border-zinc-200 dark:border-zinc-800 p-5">
                    <h2 className="text-xl font-semibold text-zinc-900 dark:text-white">Account</h2>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 mb-5">Manage your account info.</p>
                    <nav className="space-y-1">
                        {tabs.map(({ id, label, icon: Icon }) => (
                            <button key={id} onClick={() => setTab(id)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-sm transition ${tab === id ? 'bg-zinc-200/70 dark:bg-zinc-800 font-medium text-zinc-900 dark:text-white' : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/60'}`}>
                                <Icon className="size-4" /> {label}
                            </button>
                        ))}
                    </nav>
                </aside>
                <section className="flex-1 min-w-0 overflow-y-auto p-6">
                    <div className="sm:hidden flex gap-2 mb-4">
                        {tabs.map(({ id, label }) => (
                            <button key={id} onClick={() => setTab(id)} className={`px-3 py-1.5 rounded-md text-sm ${tab === id ? 'bg-zinc-200 dark:bg-zinc-800 font-medium' : 'text-zinc-500'}`}>{label}</button>
                        ))}
                    </div>
                    {tab === 'profile' ? <ProfileTab /> : <SecurityTab onClose={onClose} />}
                </section>
                <button aria-label="Close" onClick={onClose} className="absolute top-4 right-4 text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200"><XIcon className="size-5" /></button>
            </div>
        </div>
    )
}
