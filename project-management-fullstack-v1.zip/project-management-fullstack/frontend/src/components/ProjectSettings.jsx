import { Plus, Save, Trash2Icon, XIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import AddProjectMember from "./AddProjectMember";
import { projectsApi, rolesApi } from "../api";
import { refreshWorkspace } from "../features/workspaceSlice";
import useCan from "../hooks/useCan";
import { Avatar, Badge } from "./ui/ui";
import { run } from "../utils/notify";

const toForm = (p) => ({
    name: p.name,
    description: p.description ?? "",
    status: p.status,
    priority: p.priority,
    start_date: p.start_date ?? "",
    end_date: p.end_date ?? "",
    progress: p.progress ?? 0,
});

export default function ProjectSettings({ project }) {

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const can = useCan();
    const me = useSelector((state) => state.auth.user);
    const workspace = useSelector((state) => state.workspace.currentWorkspace);

    const canEdit = can("project.update", project);
    const canAddMember = can("project.member.add", project);
    const canRemoveMember = can("project.member.remove", project);
    const canChangeRole = can("project.member.update_role", project);
    const canChangeLead = can("project.lead.change", project);
    const canDelete = can("project.delete", project);

    const [formData, setFormData] = useState(toForm(project));
    const [roles, setRoles] = useState([]);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => { setFormData(toForm(project)); }, [project]);

    // Project roles for the per-member role dropdown (listing roles needs the `role.view` permission).
    useEffect(() => {
        if (canChangeRole) rolesApi.list(workspace.id, "PROJECT").then(setRoles).catch(() => setRoles([]));
    }, [canChangeRole, workspace.id]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (formData.start_date && formData.end_date && formData.end_date < formData.start_date) return toast.error("End date must be on or after the start date");
        setIsSubmitting(true);
        const ok = await run(() => projectsApi.update(project.id, {
            name: formData.name.trim(),
            description: formData.description,
            status: formData.status,
            priority: formData.priority,
            start_date: formData.start_date || null,
            end_date: formData.end_date || null,
            progress: formData.progress,
        }), "Project updated");
        if (ok) await dispatch(refreshWorkspace());
        setIsSubmitting(false);
    };

    const changeLead = async (userId) => {
        if (!userId || userId === project.team_lead) return;
        if (await run(() => projectsApi.update(project.id, { team_lead: userId }), "Team lead changed")) await dispatch(refreshWorkspace());
    };

    const changeRole = async (userId, roleId) => {
        if (await run(() => projectsApi.updateMemberRole(project.id, userId, roleId), "Role updated")) await dispatch(refreshWorkspace());
    };

    const removeMember = async (member) => {
        if (!window.confirm(`Remove ${member.user.name} from this project? Tasks assigned to them become unassigned.`)) return;
        const res = await run(() => projectsApi.removeMember(project.id, member.userId));
        if (res) {
            toast.success(res.unassignedTasks ? `Removed. ${res.unassignedTasks} task(s) are now unassigned.` : "Member removed");
            await dispatch(refreshWorkspace());
        }
    };

    const deleteProject = async () => {
        if (!window.confirm(`Delete "${project.name}" permanently? All of its tasks and comments will be lost.`)) return;
        if (await run(() => projectsApi.remove(project.id), "Project deleted")) {
            await dispatch(refreshWorkspace());
            navigate("/projects");
        }
    };

    const inputClasses = "w-full px-3 py-2 rounded mt-2 border text-sm dark:bg-zinc-900 border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-300 disabled:opacity-70";

    const cardClasses = "rounded-lg border p-6 not-dark:bg-white dark:bg-gradient-to-br dark:from-zinc-800/70 dark:to-zinc-900/50 border-zinc-300 dark:border-zinc-800";

    const labelClasses = "text-sm text-zinc-600 dark:text-zinc-400";

    return (
        <div className="grid lg:grid-cols-2 gap-8">
            {/* Project Details */}
            <div className={cardClasses}>
                <h2 className="text-lg font-medium text-zinc-900 dark:text-zinc-300 mb-4">Project Details</h2>
                {!canEdit && <p className="text-sm text-zinc-500 dark:text-zinc-400 mb-4">Only project managers and workspace admins can edit these details.</p>}
                <form onSubmit={handleSubmit} className="space-y-4">
                    {/* Name */}
                    <div className="space-y-2">
                        <label className={labelClasses}>Project Name</label>
                        <input disabled={!canEdit} value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className={inputClasses} minLength={2} required />
                    </div>

                    {/* Description */}
                    <div className="space-y-2">
                        <label className={labelClasses}>Description</label>
                        <textarea disabled={!canEdit} value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} className={inputClasses + " h-24"} />
                    </div>

                    {/* Status & Priority */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <label className={labelClasses}>Status</label>
                            <select disabled={!canEdit} value={formData.status} onChange={(e) => setFormData({ ...formData, status: e.target.value })} className={inputClasses} >
                                <option value="PLANNING">Planning</option>
                                <option value="ACTIVE">Active</option>
                                <option value="ON_HOLD">On Hold</option>
                                <option value="COMPLETED">Completed</option>
                                <option value="CANCELLED">Cancelled</option>
                            </select>
                        </div>

                        <div className="space-y-2">
                            <label className={labelClasses}>Priority</label>
                            <select disabled={!canEdit} value={formData.priority} onChange={(e) => setFormData({ ...formData, priority: e.target.value })} className={inputClasses} >
                                <option value="LOW">Low</option>
                                <option value="MEDIUM">Medium</option>
                                <option value="HIGH">High</option>
                            </select>
                        </div>
                    </div>

                    {/* Timeline */}
                    <div className="space-y-4 grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <label className={labelClasses}>Start Date</label>
                            <input disabled={!canEdit} type="date" value={formData.start_date} onChange={(e) => setFormData({ ...formData, start_date: e.target.value })} className={inputClasses} />
                        </div>
                        <div className="space-y-2">
                            <label className={labelClasses}>End Date</label>
                            <input disabled={!canEdit} type="date" min={formData.start_date || undefined} value={formData.end_date} onChange={(e) => setFormData({ ...formData, end_date: e.target.value })} className={inputClasses} />
                        </div>
                    </div>

                    {/* Progress */}
                    <div className="space-y-2">
                        <label className={labelClasses}>Progress: {formData.progress}%</label>
                        <input disabled={!canEdit} type="range" min="0" max="100" step="5" value={formData.progress} onChange={(e) => setFormData({ ...formData, progress: Number(e.target.value) })} className="w-full accent-blue-500 dark:bg-zinc-800" />
                    </div>

                    {/* Save Button */}
                    {canEdit && (
                        <button type="submit" disabled={isSubmitting} className="ml-auto flex items-center text-sm justify-center gap-2 bg-gradient-to-br from-blue-500 to-blue-600 text-white px-4 py-2 rounded disabled:opacity-60" >
                            <Save className="size-4" /> {isSubmitting ? "Saving..." : "Save Changes"}
                        </button>
                    )}
                </form>
            </div>

            {/* Team Members */}
            <div className="space-y-6">
                <div className={cardClasses}>
                    <div className="flex items-center justify-between gap-4">
                        <h2 className="text-lg font-medium text-zinc-900 dark:text-zinc-300 mb-4">
                            Team Members <span className="text-sm text-zinc-600 dark:text-zinc-400">({project.members.length})</span>
                        </h2>
                        {canAddMember && (
                            <button type="button" onClick={() => setIsDialogOpen(true)} title="Add a workspace member to this project" className="p-2 rounded-lg border border-zinc-300 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800" >
                                <Plus className="size-4 text-zinc-900 dark:text-zinc-300" />
                            </button>
                        )}
                        <AddProjectMember isDialogOpen={isDialogOpen} setIsDialogOpen={setIsDialogOpen} />
                    </div>

                    {canChangeLead && project.members.length > 1 && (
                        <div className="mb-3">
                            <label className={labelClasses}>Team lead</label>
                            <select value={project.team_lead} onChange={(e) => changeLead(e.target.value)} className={inputClasses}>
                                {project.members.map((m) => <option key={m.userId} value={m.userId}>{m.user.name}</option>)}
                            </select>
                        </div>
                    )}

                    {/* Member List */}
                    {project.members.length > 0 && (
                        <div className="space-y-2 mt-2 max-h-72 overflow-y-auto">
                            {project.members.map((member) => {
                                const isLead = project.team_lead === member.userId;
                                const isMe = member.userId === me?.id;
                                return (
                                    <div key={member.id} className="flex items-center justify-between gap-3 px-3 py-2 rounded dark:bg-zinc-800 bg-zinc-100/70 text-sm text-zinc-900 dark:text-zinc-300" >
                                        <div className="flex items-center gap-2.5 min-w-0">
                                            <Avatar src={member.user.image} name={member.user.name} className="size-7" />
                                            <div className="min-w-0">
                                                <p className="truncate">{member.user.name}{isMe && <span className="text-xs text-zinc-500"> (you)</span>}</p>
                                                <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate">{member.user.email}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2 shrink-0">
                                            {isLead ? <Badge tone="blue">Team Lead</Badge>
                                                : canChangeRole && !isMe && roles.length > 0 ? (
                                                    <select value={member.role?.id} onChange={(e) => changeRole(member.userId, e.target.value)} className="text-xs rounded border border-zinc-300 dark:border-zinc-700 dark:bg-zinc-900 px-1.5 py-1">
                                                        {roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                                                    </select>
                                                ) : <Badge>{member.role?.name}</Badge>}
                                            {canRemoveMember && !isLead && (
                                                <button type="button" aria-label={`Remove ${member.user.name}`} onClick={() => removeMember(member)} className="p-1 rounded hover:bg-red-100 dark:hover:bg-red-500/20 text-red-500"><XIcon className="size-4" /></button>
                                            )}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>

                {canDelete && (
                    <div className={`${cardClasses} !border-red-200 dark:!border-red-500/30`}>
                        <h2 className="text-lg font-medium text-red-600 dark:text-red-400 mb-1">Danger zone</h2>
                        <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">Deleting a project permanently removes its tasks and comments.</p>
                        <button type="button" onClick={deleteProject} className="flex items-center gap-2 text-sm px-4 py-2 rounded bg-red-600 hover:bg-red-700 text-white"><Trash2Icon className="size-4" /> Delete project</button>
                    </div>
                )}
            </div>
        </div>
    );
}
