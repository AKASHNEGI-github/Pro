import { useEffect } from 'react'
import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { useDispatch, useSelector } from 'react-redux'
import { Loader2Icon } from 'lucide-react'
import Layout from './pages/Layout'
import Dashboard from './pages/Dashboard'
import Projects from './pages/Projects'
import Team from './pages/Team'
import ProjectDetails from './pages/ProjectDetails'
import TaskDetails from './pages/TaskDetails'
import Settings from './pages/Settings'
import Login from './pages/Login'
import ChangePassword from './pages/ChangePassword'
import { bootstrapSession } from './features/authSlice'
import { resetWorkspaces } from './features/workspaceSlice'
import { loadTheme } from './features/themeSlice'

const FullScreenSpinner = () => (
    <div className="flex items-center justify-center h-screen bg-white dark:bg-zinc-950">
        <Loader2Icon className="size-7 text-blue-500 animate-spin" />
    </div>
)

/** Signed-in users only. Users with a temporary password are sent to /change-password first. */
function RequireAuth({ children, passwordChangePage = false }) {
    const { status, user } = useSelector((s) => s.auth)
    const location = useLocation()
    if (status === 'checking') return <FullScreenSpinner />
    if (status !== 'authenticated') return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />
    if (user.mustChangePassword && !passwordChangePage) return <Navigate to="/change-password" replace />
    if (!user.mustChangePassword && passwordChangePage) return <Navigate to="/" replace />
    return children
}

function PublicOnly({ children }) {
    const { status, user } = useSelector((s) => s.auth)
    if (status === 'checking') return <FullScreenSpinner />
    if (status === 'authenticated') return <Navigate to={user.mustChangePassword ? '/change-password' : '/'} replace />
    return children
}

const App = () => {
    const dispatch = useDispatch()
    const status = useSelector((s) => s.auth.status)

    useEffect(() => {
        dispatch(loadTheme())
        dispatch(bootstrapSession()) // restore the session from the httpOnly refresh cookie
    }, [dispatch])

    // Clear workspace data whenever the user signs out, so the next user never sees it.
    useEffect(() => {
        if (status === 'anonymous') dispatch(resetWorkspaces())
    }, [status, dispatch])

    return (
        <>
            <Toaster />
            <Routes>
                <Route path="/login" element={<PublicOnly><Login /></PublicOnly>} />
                <Route path="/change-password" element={<RequireAuth passwordChangePage><ChangePassword /></RequireAuth>} />
                <Route path="/" element={<RequireAuth><Layout /></RequireAuth>}>
                    <Route index element={<Dashboard />} />
                    <Route path="team" element={<Team />} />
                    <Route path="projects" element={<Projects />} />
                    <Route path="projectsDetail" element={<ProjectDetails />} />
                    <Route path="taskDetails" element={<TaskDetails />} />
                    <Route path="settings" element={<Settings />} />
                </Route>
                <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
        </>
    )
}

export default App
