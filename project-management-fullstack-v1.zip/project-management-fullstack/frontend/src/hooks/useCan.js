import { useCallback } from 'react'
import { useSelector } from 'react-redux'

/**
 * Permission check for the UI (the backend enforces the same rules; this only decides what to show).
 *   can('project.create')            -> workspace-level (includes global + workspace role permissions)
 *   can('task.delete', project)      -> permissions the user has inside that specific project
 *   can('user.manage')               -> global permissions (Org Admin)
 */
export default function useCan() {
    const user = useSelector((s) => s.auth.user)
    const workspace = useSelector((s) => s.workspace.currentWorkspace)
    return useCallback(
        (key, project) => {
            if (user?.permissions?.includes(key)) return true
            if (project) return project.permissions?.includes(key) ?? false
            return workspace?.permissions?.includes(key) ?? false
        },
        [user, workspace],
    )
}
