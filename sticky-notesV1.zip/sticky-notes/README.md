# 📝 Sticky Notes

A small full-stack learning project: **FastAPI** + **MySQL** (raw SQL) + **React** (Vite, plain JavaScript).

* **Admin** (exactly one, defined in the backend `.env`): manages members, plus has own private notes.
* **Member**: registers, manages own profile, has own private notes.
* Notes are written in **Markdown** with [`react-markdown-studio`](https://www.npmjs.com/package/react-markdown-studio).
* Notes are **private to their owner**, even the admin cannot read another user's notes.
* **Soft delete everywhere** (`is_deleted`, `deleted_at`); there is no `DELETE` statement in the code.

```
sticky-notes/
├── backend/    FastAPI + PyMySQL        (see backend/README.md for the full API reference)
│   └── database/schema.sql              run this in MySQL Workbench
└── frontend/   React + Vite + react-markdown-studio
```

## Quick start (3 terminals / steps)

You need: **MySQL** (5.7.6+; 8.x recommended), **Python 3.10+**, **Node.js 18+**.

### 1. Database
Open `backend/database/schema.sql` in MySQL Workbench and run the whole file. It is safe to run twice.

### 2. Backend  →  http://127.0.0.1:8000  (Swagger UI at `/docs`)
```bash
cd backend
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                 # Windows: copy .env.example .env
#   edit .env: DB_USER, DB_PASSWORD, JWT_SECRET_KEY and the ADMIN_* credentials
uvicorn app.main:app --reload
```
On first start the backend creates the admin from `.env`. To change the admin password later, edit `.env` and restart.

### 3. Frontend  →  http://localhost:5173
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173. Log in with the `ADMIN_EMAIL` / `ADMIN_PASSWORD` from your backend `.env`, or click **Create an account** to register as a member.

> If the backend is not at `http://127.0.0.1:8000`, copy `frontend/.env.example` to `frontend/.env` and set `VITE_PROXY_TARGET`.

## What you can do in the app

| Page | Who | What |
|---|---|---|
| `/login`, `/register` | logged-out visitors | log in with email + password; sign up with username, email, password |
| `/` My notes | admin, member | grid of your sticky notes (Markdown preview), new note, delete one, delete all |
| `/notes/new`, `/notes/:id` | admin, member | Markdown editor (live preview), title, colour; save, delete. `Ctrl+S` saves |
| `/profile` | member | edit username/email, **change password** (logs you out), delete account |
| `/profile` | admin | read-only info (the admin is managed from `.env`) |
| `/admin/users` | admin | list members, add, edit, reset a member's password, delete one, delete all |

## How login works (the part worth understanding)

1. `POST /api/auth/login` returns a short-lived **access token** (JSON) and sets a **refresh token** as an **httpOnly cookie**. MySQL stores only the refresh token's **SHA-256 hash**.
2. The frontend keeps the access token **in memory only** (a variable in `src/api/client.js`): nothing in `localStorage`, `sessionStorage` or any cookie JavaScript can read.
3. Page reload → memory is empty → the app calls `/auth/refresh` (the browser attaches the cookie) → new access token + rotated refresh cookie.
4. Access token expires (15 min) → a `401` makes the Axios interceptor refresh once and retry the request.
5. Changing your password revokes every session on the server, and the app returns to the login page.

## Frontend layout (`frontend/src`)

```
api/client.js        axios instance, in-memory token, refresh + retry logic
api/services.js      one function per backend endpoint
context/             AuthContext (session), ToastContext, ConfirmContext (confirm dialogs)
components/          Layout (top bar), RouteGuards, Modal, Field, NoteCard
pages/               Login, Register, Notes, NoteEditor, Profile, AdminUsers, NotFound
utils/format.js      error messages, dates, note colours
styles.css           all styling (plain CSS)
```

Production build: `npm run build` (output in `frontend/dist`).

## Known limits (by design, it is a learning project)

* No rate limiting, pagination, search or "forgot password" (the admin resets passwords).
* An access token stays valid until it expires (15 min) after logout or a password change, except for deleted users, who are locked out immediately.
* Plain light theme only.
