"""Shared schema pieces."""
from datetime import datetime, timezone
from typing import Annotated

from pydantic import AfterValidator, BaseModel, Field

from app.security import MAX_PASSWORD_BYTES


def _as_utc(value: datetime) -> datetime:
    """MySQL DATETIME comes back naive. We store UTC, so tag it as UTC ("...Z" in JSON)."""
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value


UTCDateTime = Annotated[datetime, AfterValidator(_as_utc)]

# Letters, digits, underscore, dot, hyphen.
USERNAME_PATTERN = r"^[A-Za-z0-9_.-]+$"
Username = Annotated[str, Field(min_length=3, max_length=50, pattern=USERNAME_PATTERN)]


def validate_password_value(value: str) -> str:
    if len(value) < 8:
        raise ValueError("Password must be at least 8 characters long")
    if len(value.encode("utf-8")) > MAX_PASSWORD_BYTES:
        raise ValueError("Password is too long (maximum 72 bytes)")
    return value


class MessageResponse(BaseModel):
    message: str


class BulkDeleteResponse(BaseModel):
    message: str
    deleted_count: int
