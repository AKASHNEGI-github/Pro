from typing import Optional

from pydantic import BaseModel, EmailStr, field_validator, model_validator

from app.schemas.common import UTCDateTime, Username, validate_password_value


class UserResponse(BaseModel):
    id: int
    username: str
    email: EmailStr
    role: str
    created_at: UTCDateTime
    updated_at: UTCDateTime


class RegisterRequest(BaseModel):
    username: Username
    email: EmailStr
    password: str

    @field_validator("password")
    @classmethod
    def check_password(cls, v: str) -> str:
        return validate_password_value(v)


# Admin creating a member uses exactly the same fields as registering.
AdminCreateUserRequest = RegisterRequest


class UserUpdateRequest(BaseModel):
    """Send only the fields you want to change. Roles and passwords cannot be changed here."""

    username: Optional[Username] = None
    email: Optional[EmailStr] = None

    @model_validator(mode="after")
    def at_least_one_field(self):
        if self.username is None and self.email is None:
            raise ValueError("Provide at least one of: username, email")
        return self


class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str

    @field_validator("new_password")
    @classmethod
    def check_new_password(cls, v: str) -> str:
        return validate_password_value(v)


class AdminResetPasswordRequest(BaseModel):
    new_password: str

    @field_validator("new_password")
    @classmethod
    def check_new_password(cls, v: str) -> str:
        return validate_password_value(v)
