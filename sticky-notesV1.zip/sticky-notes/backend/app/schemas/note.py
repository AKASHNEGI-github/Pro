from typing import Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from app.schemas.common import UTCDateTime

DEFAULT_NOTE_COLOR = "#FFF59D"
COLOR_PATTERN = r"^#[0-9A-Fa-f]{6}$"
MAX_CONTENT_CHARS = 100_000


class NoteCreate(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    content: str = Field(default="", max_length=MAX_CONTENT_CHARS)  # markdown
    color: str = Field(default=DEFAULT_NOTE_COLOR, pattern=COLOR_PATTERN)

    @field_validator("title")
    @classmethod
    def strip_title(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Title cannot be blank")
        return v


class NoteUpdate(BaseModel):
    """Send only the fields you want to change."""

    title: Optional[str] = Field(default=None, min_length=1, max_length=255)
    content: Optional[str] = Field(default=None, max_length=MAX_CONTENT_CHARS)
    color: Optional[str] = Field(default=None, pattern=COLOR_PATTERN)

    @field_validator("title")
    @classmethod
    def strip_title(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        v = v.strip()
        if not v:
            raise ValueError("Title cannot be blank")
        return v

    @model_validator(mode="after")
    def at_least_one_field(self):
        if self.title is None and self.content is None and self.color is None:
            raise ValueError("Provide at least one of: title, content, color")
        return self


class NoteResponse(BaseModel):
    id: int
    title: str
    content: str
    color: str
    created_at: UTCDateTime
    updated_at: UTCDateTime
