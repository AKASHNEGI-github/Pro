from pydantic import BaseModel, EmailStr

from app.schemas.user import UserResponse


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """The refresh token is NOT here - it travels only in the httpOnly cookie."""

    access_token: str
    token_type: str = "bearer"
    user: UserResponse
