"""
User management - raw SQL.

Naming: "member" = a user whose role is MEMBER. Every admin-facing function works on
members only, so the ADMIN row can never be read-for-edit, changed or deleted through
the API (it simply "does not exist" from these functions' point of view).

Soft delete: nothing is ever DELETEd. We set is_deleted = 1 and deleted_at = now (UTC).
"""
from typing import Optional

import pymysql
from pymysql.connections import Connection

from app.database import transaction
from app.exceptions import ConflictError, NotFoundError
from app.security import hash_password

ROLE_ADMIN = "ADMIN"
ROLE_MEMBER = "MEMBER"

# Base SELECT used everywhere. Only ACTIVE users with an ACTIVE role mapping.
_USER_SELECT = """
    SELECT u.id, u.username, u.email, r.name AS role, u.created_at, u.updated_at
    FROM users u
    JOIN user_roles ur ON ur.user_id = u.id AND ur.is_deleted = 0
    JOIN roles r       ON r.id = ur.role_id AND r.is_deleted = 0
    WHERE u.is_deleted = 0
"""

# user ids that belong to MEMBERs (no is_deleted filter on purpose, see delete_all_members)
_MEMBER_IDS_SUBQUERY = """
    SELECT ur.user_id
    FROM user_roles ur
    JOIN roles r ON r.id = ur.role_id
    WHERE r.name = 'MEMBER'
"""


def normalize_email(email: str) -> str:
    return email.strip().lower()


# ----------------------------------------------------------------------------
# reads
# ----------------------------------------------------------------------------
def get_user_by_id(conn: Connection, user_id: int) -> Optional[dict]:
    """Any active user (admin or member). Used by authentication."""
    with conn.cursor() as cur:
        cur.execute(_USER_SELECT + " AND u.id = %s", (user_id,))
        return cur.fetchone()


def get_member_by_id(conn: Connection, member_id: int) -> Optional[dict]:
    with conn.cursor() as cur:
        cur.execute(_USER_SELECT + " AND u.id = %s AND r.name = %s", (member_id, ROLE_MEMBER))
        return cur.fetchone()


def get_member_or_404(conn: Connection, member_id: int) -> dict:
    member = get_member_by_id(conn, member_id)
    if member is None:
        raise NotFoundError("User not found")
    return member


def list_members(conn: Connection) -> list[dict]:
    with conn.cursor() as cur:
        cur.execute(_USER_SELECT + " AND r.name = %s ORDER BY u.id", (ROLE_MEMBER,))
        return list(cur.fetchall())


# ----------------------------------------------------------------------------
# uniqueness (friendly messages; the DB unique indexes are the final safety net)
# ----------------------------------------------------------------------------
def _assert_unique(cur, username: Optional[str], email: Optional[str], exclude_user_id: Optional[int] = None):
    exclude = exclude_user_id if exclude_user_id is not None else 0
    if username is not None:
        cur.execute(
            "SELECT 1 FROM users WHERE username = %s AND is_deleted = 0 AND id <> %s LIMIT 1",
            (username, exclude),
        )
        if cur.fetchone():
            raise ConflictError("Username is already taken")
    if email is not None:
        cur.execute(
            "SELECT 1 FROM users WHERE email = %s AND is_deleted = 0 AND id <> %s LIMIT 1",
            (email, exclude),
        )
        if cur.fetchone():
            raise ConflictError("Email is already registered")


def _conflict_from_integrity_error(exc: pymysql.err.IntegrityError) -> ConflictError:
    """Two requests racing past _assert_unique end up here."""
    message = str(exc)
    if "uq_users_active_email" in message:
        return ConflictError("Email is already registered")
    if "uq_users_active_username" in message:
        return ConflictError("Username is already taken")
    return ConflictError("Duplicate value")


# ----------------------------------------------------------------------------
# create
# ----------------------------------------------------------------------------
def insert_user_with_role(cur, username: str, email: str, password_hash: str, role_name: str) -> int:
    """Inserts users + user_passwords + user_roles using an existing cursor (caller owns the transaction)."""
    cur.execute("SELECT id FROM roles WHERE name = %s AND is_deleted = 0", (role_name,))
    role = cur.fetchone()
    if role is None:
        raise RuntimeError(f"Role {role_name} is missing. Did you run database/schema.sql?")

    cur.execute("INSERT INTO users (username, email) VALUES (%s, %s)", (username, email))
    user_id = cur.lastrowid
    cur.execute(
        "INSERT INTO user_passwords (user_id, password_hash) VALUES (%s, %s)",
        (user_id, password_hash),
    )
    cur.execute("INSERT INTO user_roles (user_id, role_id) VALUES (%s, %s)", (user_id, role["id"]))
    return user_id


def create_member(conn: Connection, username: str, email: str, password: str) -> dict:
    """Used by both POST /auth/register and POST /admin/users. Always creates a MEMBER."""
    email = normalize_email(email)
    password_hash = hash_password(password)  # slow on purpose; do it before opening the transaction
    try:
        with transaction(conn):
            with conn.cursor() as cur:
                _assert_unique(cur, username, email)
                user_id = insert_user_with_role(cur, username, email, password_hash, ROLE_MEMBER)
    except pymysql.err.IntegrityError as exc:
        raise _conflict_from_integrity_error(exc) from exc
    return get_user_by_id(conn, user_id)


# ----------------------------------------------------------------------------
# update  (username / email only. Role and password are never changed here.)
# ----------------------------------------------------------------------------
def update_member(conn: Connection, member_id: int, username: Optional[str], email: Optional[str]) -> dict:
    if email is not None:
        email = normalize_email(email)
    try:
        with transaction(conn):
            with conn.cursor() as cur:
                # make sure it is an active MEMBER (this is what protects the admin)
                get_member_or_404(conn, member_id)
                _assert_unique(cur, username, email, exclude_user_id=member_id)

                assignments, params = [], []
                if username is not None:
                    assignments.append("username = %s")
                    params.append(username)
                if email is not None:
                    assignments.append("email = %s")
                    params.append(email)
                params.append(member_id)
                cur.execute(
                    f"UPDATE users SET {', '.join(assignments)} WHERE id = %s AND is_deleted = 0",
                    params,
                )
    except pymysql.err.IntegrityError as exc:
        raise _conflict_from_integrity_error(exc) from exc
    return get_member_or_404(conn, member_id)


# ----------------------------------------------------------------------------
# soft delete
# ----------------------------------------------------------------------------
def delete_member(conn: Connection, member_id: int) -> None:
    """Soft-deletes the member AND everything they own, in one transaction."""
    with transaction(conn):
        get_member_or_404(conn, member_id)
        with conn.cursor() as cur:
            for table in ("notes", "refresh_tokens", "user_passwords", "user_roles"):
                cur.execute(
                    f"UPDATE {table} SET is_deleted = 1, deleted_at = UTC_TIMESTAMP() "
                    "WHERE user_id = %s AND is_deleted = 0",
                    (member_id,),
                )
            cur.execute(
                "UPDATE users SET is_deleted = 1, deleted_at = UTC_TIMESTAMP() "
                "WHERE id = %s AND is_deleted = 0",
                (member_id,),
            )


def delete_all_members(conn: Connection) -> int:
    """
    Soft-deletes every MEMBER (never the admin) plus their notes, tokens, passwords, roles.
    Returns how many users were deleted.

    The member list is resolved through user_roles, so user_roles must be updated LAST
    (and its subquery must not filter on is_deleted).
    """
    with transaction(conn):
        with conn.cursor() as cur:
            for table in ("notes", "refresh_tokens", "user_passwords"):
                cur.execute(
                    f"UPDATE {table} SET is_deleted = 1, deleted_at = UTC_TIMESTAMP() "
                    f"WHERE is_deleted = 0 AND user_id IN ({_MEMBER_IDS_SUBQUERY})"
                )
            cur.execute(
                """
                UPDATE users u
                JOIN user_roles ur ON ur.user_id = u.id
                JOIN roles r       ON r.id = ur.role_id
                SET u.is_deleted = 1, u.deleted_at = UTC_TIMESTAMP()
                WHERE r.name = 'MEMBER' AND u.is_deleted = 0
                """
            )
            deleted_count = cur.rowcount
            # MySQL forbids "UPDATE user_roles ... WHERE x IN (SELECT FROM user_roles)", so use a JOIN here.
            cur.execute(
                """
                UPDATE user_roles ur
                JOIN roles r ON r.id = ur.role_id
                SET ur.is_deleted = 1, ur.deleted_at = UTC_TIMESTAMP()
                WHERE r.name = 'MEMBER' AND ur.is_deleted = 0
                """
            )
    return deleted_count
