"""
Authentication - raw SQL.

Refresh tokens
--------------
* The browser holds the raw token ONLY in an httpOnly cookie (set by the router).
* The database holds only its SHA-256 hash.
* Rotation: every successful /refresh revokes the used token and issues a new one.
* "Revoked" = is_deleted = 1 (we never hard-delete). Revoked rows stay so that a
  replayed token can be recognised:
    - replayed within REFRESH_REUSE_GRACE_SECONDS  -> harmless duplicate request, just 401
    - replayed later                               -> assume theft, revoke ALL tokens of that user
"""
from typing import Optional

from pymysql.connections import Connection

from app.config import settings
from app.database import transaction
from app.exceptions import BadRequestError, NotFoundError, UnauthorizedError
from app.security import (
    DUMMY_PASSWORD_HASH,
    create_access_token,
    generate_refresh_token,
    hash_password,
    hash_refresh_token,
    verify_password,
)
from app.services import user_service


# ----------------------------------------------------------------------------
# refresh-token helpers (take an open cursor; caller owns the transaction)
# ----------------------------------------------------------------------------
def _insert_refresh_token(cur, user_id: int) -> str:
    raw_token = generate_refresh_token()
    cur.execute(
        "INSERT INTO refresh_tokens (user_id, token_hash, expires_at) "
        "VALUES (%s, %s, DATE_ADD(UTC_TIMESTAMP(), INTERVAL %s DAY))",
        (user_id, hash_refresh_token(raw_token), settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )
    return raw_token


def revoke_all_refresh_tokens(cur, user_id: int) -> None:
    cur.execute(
        "UPDATE refresh_tokens SET is_deleted = 1, deleted_at = UTC_TIMESTAMP() "
        "WHERE user_id = %s AND is_deleted = 0",
        (user_id,),
    )


# ----------------------------------------------------------------------------
# login
# ----------------------------------------------------------------------------
def login(conn: Connection, email: str, password: str) -> tuple[dict, str, str]:
    """Returns (user, access_token, raw_refresh_token)."""
    email = user_service.normalize_email(email)

    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT u.id, up.password_hash
            FROM users u
            JOIN user_passwords up ON up.user_id = u.id AND up.is_deleted = 0
            WHERE u.email = %s AND u.is_deleted = 0
            """,
            (email,),
        )
        row = cur.fetchone()

    # Always run one bcrypt check, so response time does not reveal whether the email exists.
    password_ok = verify_password(password, row["password_hash"] if row else DUMMY_PASSWORD_HASH)
    if row is None or not password_ok:
        raise UnauthorizedError("Invalid email or password")

    user = user_service.get_user_by_id(conn, row["id"])
    if user is None:  # e.g. role mapping missing
        raise UnauthorizedError("Invalid email or password")

    with transaction(conn):
        with conn.cursor() as cur:
            raw_refresh = _insert_refresh_token(cur, user["id"])
    return user, create_access_token(user["id"]), raw_refresh


# ----------------------------------------------------------------------------
# refresh (with rotation + replay detection)
# ----------------------------------------------------------------------------
def refresh(conn: Connection, raw_refresh_token: Optional[str]) -> tuple[dict, str, str]:
    """Returns (user, new_access_token, new_raw_refresh_token)."""
    if not raw_refresh_token:
        raise UnauthorizedError("Missing refresh token")

    token_hash = hash_refresh_token(raw_refresh_token)
    result: Optional[tuple[dict, str, str]] = None

    # Everything that must be SAVED (revocations) happens inside this block.
    # We raise only AFTER it, because raising inside would roll those revocations back.
    with transaction(conn):
        with conn.cursor() as cur:
            # FOR UPDATE: two simultaneous refreshes with the same token are serialised.
            cur.execute(
                """
                SELECT id, user_id, is_deleted,
                       (expires_at <= UTC_TIMESTAMP()) AS is_expired,
                       TIMESTAMPDIFF(SECOND, deleted_at, UTC_TIMESTAMP()) AS revoked_seconds_ago
                FROM refresh_tokens
                WHERE token_hash = %s
                FOR UPDATE
                """,
                (token_hash,),
            )
            token = cur.fetchone()

            if token is None:
                pass  # unknown token -> 401 below

            elif token["is_deleted"]:
                seconds = token["revoked_seconds_ago"]
                if seconds is not None and seconds > settings.REFRESH_REUSE_GRACE_SECONDS:
                    # An old, already-used token came back -> possible theft: kill every session.
                    revoke_all_refresh_tokens(cur, token["user_id"])
                # else: a duplicate request inside the grace window -> just 401, no mass revoke

            elif token["is_expired"]:
                cur.execute(
                    "UPDATE refresh_tokens SET is_deleted = 1, deleted_at = UTC_TIMESTAMP() WHERE id = %s",
                    (token["id"],),
                )

            else:
                user = user_service.get_user_by_id(conn, token["user_id"])
                if user is None:  # user was deleted meanwhile
                    revoke_all_refresh_tokens(cur, token["user_id"])
                else:
                    # rotate: revoke the used token, issue a brand-new one
                    cur.execute(
                        "UPDATE refresh_tokens SET is_deleted = 1, deleted_at = UTC_TIMESTAMP() WHERE id = %s",
                        (token["id"],),
                    )
                    new_raw_token = _insert_refresh_token(cur, user["id"])
                    result = (user, create_access_token(user["id"]), new_raw_token)

    if result is None:
        raise UnauthorizedError("Invalid refresh token")
    return result


# ----------------------------------------------------------------------------
# logout
# ----------------------------------------------------------------------------
def logout(conn: Connection, raw_refresh_token: Optional[str]) -> None:
    """Revokes the presented refresh token. Silent if there is none / it is unknown."""
    if not raw_refresh_token:
        return
    with transaction(conn):
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE refresh_tokens SET is_deleted = 1, deleted_at = UTC_TIMESTAMP() "
                "WHERE token_hash = %s AND is_deleted = 0",
                (hash_refresh_token(raw_refresh_token),),
            )


# ----------------------------------------------------------------------------
# passwords
# ----------------------------------------------------------------------------
def change_own_password(conn: Connection, user_id: int, old_password: str, new_password: str) -> None:
    """Verifies the old password, saves the new one, revokes ALL refresh tokens (forces re-login)."""
    with conn.cursor() as cur:
        cur.execute(
            "SELECT password_hash FROM user_passwords WHERE user_id = %s AND is_deleted = 0",
            (user_id,),
        )
        row = cur.fetchone()
    if row is None or not verify_password(old_password, row["password_hash"]):
        raise BadRequestError("Old password is incorrect")
    if verify_password(new_password, row["password_hash"]):
        raise BadRequestError("New password must be different from the old password")

    new_hash = hash_password(new_password)
    with transaction(conn):
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE user_passwords SET password_hash = %s WHERE user_id = %s AND is_deleted = 0",
                (new_hash, user_id),
            )
            revoke_all_refresh_tokens(cur, user_id)


def admin_reset_member_password(conn: Connection, member_id: int, new_password: str) -> None:
    """Admin sets a member's password. Revokes that member's refresh tokens."""
    new_hash = hash_password(new_password)
    with transaction(conn):
        if user_service.get_member_by_id(conn, member_id) is None:
            raise NotFoundError("User not found")
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE user_passwords SET password_hash = %s WHERE user_id = %s AND is_deleted = 0",
                (new_hash, member_id),
            )
            revoke_all_refresh_tokens(cur, member_id)
