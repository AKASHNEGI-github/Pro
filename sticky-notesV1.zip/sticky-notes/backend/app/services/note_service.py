"""
Notes - raw SQL.

PRIVACY RULE: every query filters on user_id, and user_id ALWAYS comes from the
authenticated token (never from the request). A note that belongs to somebody else
is reported as 404, exactly like a note that does not exist, so its existence is not leaked.
"""
from pymysql.connections import Connection

from app.database import transaction
from app.exceptions import NotFoundError

_NOTE_COLUMNS = "id, title, content, color, created_at, updated_at"


def create_note(conn: Connection, user_id: int, title: str, content: str, color: str) -> dict:
    with transaction(conn):
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO notes (user_id, title, content, color) VALUES (%s, %s, %s, %s)",
                (user_id, title, content, color),
            )
            note_id = cur.lastrowid
    return get_note(conn, user_id, note_id)


def list_notes(conn: Connection, user_id: int) -> list[dict]:
    with conn.cursor() as cur:
        cur.execute(
            f"SELECT {_NOTE_COLUMNS} FROM notes "
            "WHERE user_id = %s AND is_deleted = 0 ORDER BY updated_at DESC, id DESC",
            (user_id,),
        )
        return list(cur.fetchall())


def get_note(conn: Connection, user_id: int, note_id: int) -> dict:
    with conn.cursor() as cur:
        cur.execute(
            f"SELECT {_NOTE_COLUMNS} FROM notes WHERE id = %s AND user_id = %s AND is_deleted = 0",
            (note_id, user_id),
        )
        note = cur.fetchone()
    if note is None:
        raise NotFoundError("Note not found")
    return note


def update_note(conn: Connection, user_id: int, note_id: int, changes: dict) -> dict:
    """`changes` holds only the fields to update (title / content / color)."""
    allowed = ("title", "content", "color")  # whitelist: column names are never taken from user input
    columns = [name for name in allowed if name in changes]
    params = [changes[name] for name in columns]

    with transaction(conn):
        with conn.cursor() as cur:
            cur.execute(
                f"UPDATE notes SET {', '.join(f'{c} = %s' for c in columns)}, updated_at = UTC_TIMESTAMP() "
                "WHERE id = %s AND user_id = %s AND is_deleted = 0",
                (*params, note_id, user_id),
            )
            if cur.rowcount == 0:  # FOUND_ROWS: 0 means "no such active note of yours"
                raise NotFoundError("Note not found")
    return get_note(conn, user_id, note_id)


def delete_note(conn: Connection, user_id: int, note_id: int) -> None:
    with transaction(conn):
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE notes SET is_deleted = 1, deleted_at = UTC_TIMESTAMP() "
                "WHERE id = %s AND user_id = %s AND is_deleted = 0",
                (note_id, user_id),
            )
            if cur.rowcount == 0:
                raise NotFoundError("Note not found")


def delete_all_notes(conn: Connection, user_id: int) -> int:
    with transaction(conn):
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE notes SET is_deleted = 1, deleted_at = UTC_TIMESTAMP() "
                "WHERE user_id = %s AND is_deleted = 0",
                (user_id,),
            )
            return cur.rowcount
