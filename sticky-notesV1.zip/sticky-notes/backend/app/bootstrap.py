"""
Admin bootstrap - runs once on every backend startup.

* No admin yet           -> create it from .env (the admin is the first user of the app).
* Admin already exists   -> re-sync username / email / password from .env.
                            If the password in .env no longer matches the stored hash,
                            the hash is replaced and all admin refresh tokens are revoked.
"""
import logging

import pymysql

from app.config import settings
from app.database import get_connection, transaction
from app.security import hash_password, verify_password
from app.services import auth_service, user_service

logger = logging.getLogger("sticky_notes.bootstrap")


def _find_admin(cur):
    cur.execute(
        """
        SELECT u.id, u.username, u.email, up.password_hash
        FROM users u
        JOIN user_roles ur     ON ur.user_id = u.id AND ur.is_deleted = 0
        JOIN roles r           ON r.id = ur.role_id AND r.name = 'ADMIN'
        JOIN user_passwords up ON up.user_id = u.id AND up.is_deleted = 0
        WHERE u.is_deleted = 0
        ORDER BY u.id
        LIMIT 1
        """
    )
    return cur.fetchone()


def ensure_admin() -> None:
    """Wraps _ensure_admin() so the most common first-run mistakes get a readable message."""
    try:
        _ensure_admin()
    except pymysql.err.OperationalError as exc:
        code = exc.args[0] if exc.args else None
        hints = {
            1045: "Wrong DB_USER / DB_PASSWORD in .env.",
            1044: f"This MySQL user has no access to database '{settings.DB_NAME}' (or it does not exist). Run database/schema.sql first.",
            1049: f"Database '{settings.DB_NAME}' does not exist. Run database/schema.sql in MySQL Workbench first.",
            2003: f"Cannot reach MySQL at {settings.DB_HOST}:{settings.DB_PORT}. Is the MySQL server running?",
        }
        raise RuntimeError(f"Cannot connect to MySQL: {hints.get(code, exc)}") from exc
    except pymysql.err.ProgrammingError as exc:
        if exc.args and exc.args[0] == 1146:  # table doesn't exist
            raise RuntimeError("Tables not found. Run database/schema.sql in MySQL Workbench first.") from exc
        raise


def _ensure_admin() -> None:
    username = settings.ADMIN_USERNAME
    email = user_service.normalize_email(str(settings.ADMIN_EMAIL))

    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS n FROM roles WHERE name IN ('ADMIN', 'MEMBER') AND is_deleted = 0")
            if cur.fetchone()["n"] != 2:
                raise RuntimeError("Roles ADMIN/MEMBER not found. Run database/schema.sql in MySQL Workbench first.")

            admin = _find_admin(cur)

        # ---------------- first start: create the admin ----------------
        if admin is None:
            password_hash = hash_password(settings.ADMIN_PASSWORD)
            with transaction(conn):
                with conn.cursor() as cur:
                    _assert_no_clash(cur, username, email, exclude_id=None)
                    user_service.insert_user_with_role(cur, username, email, password_hash, user_service.ROLE_ADMIN)
            logger.info("Admin user created (%s).", email)
            return

        # ---------------- later starts: sync from .env ----------------
        with transaction(conn):
            with conn.cursor() as cur:
                if admin["username"] != username or admin["email"] != email:
                    _assert_no_clash(cur, username, email, exclude_id=admin["id"])
                    cur.execute(
                        "UPDATE users SET username = %s, email = %s WHERE id = %s",
                        (username, email, admin["id"]),
                    )
                    logger.info("Admin username/email synced from .env.")

                if not verify_password(settings.ADMIN_PASSWORD, admin["password_hash"]):
                    cur.execute(
                        "UPDATE user_passwords SET password_hash = %s WHERE user_id = %s AND is_deleted = 0",
                        (hash_password(settings.ADMIN_PASSWORD), admin["id"]),
                    )
                    auth_service.revoke_all_refresh_tokens(cur, admin["id"])
                    logger.info("Admin password re-synced from .env; admin sessions revoked.")
    finally:
        conn.close()


def _assert_no_clash(cur, username: str, email: str, exclude_id) -> None:
    """The admin's username/email must not be used by another active user."""
    exclude = exclude_id if exclude_id is not None else 0
    cur.execute(
        "SELECT username, email FROM users WHERE is_deleted = 0 AND id <> %s AND (username = %s OR email = %s) LIMIT 1",
        (exclude, username, email),
    )
    clash = cur.fetchone()
    if clash:
        raise RuntimeError(
            "ADMIN_USERNAME / ADMIN_EMAIL from .env is already used by another active user "
            f"({clash['username']} / {clash['email']}). Pick different values in .env."
        )
