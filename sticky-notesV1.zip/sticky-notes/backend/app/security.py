"""Password hashing, JWT access tokens and refresh-token helpers."""
import hashlib
import secrets
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from app.config import settings

# bcrypt only looks at the first 72 BYTES of a password.
MAX_PASSWORD_BYTES = 72


# ---------------- passwords ----------------
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except ValueError:
        return False


# A real bcrypt hash of a random string. Used so that "unknown email" logins take
# about as long as "wrong password" logins (avoids leaking which emails exist).
DUMMY_PASSWORD_HASH = hash_password(secrets.token_urlsafe(16))


# ---------------- access token (JWT) ----------------
def create_access_token(user_id: int) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user_id),
        "type": "access",
        "iat": now,
        "exp": now + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
    }
    return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def decode_access_token(token: str) -> int:
    """Returns the user id, or raises jwt.PyJWTError / ValueError if invalid."""
    payload = jwt.decode(
        token,
        settings.JWT_SECRET_KEY,
        algorithms=[settings.JWT_ALGORITHM],
        options={"require": ["exp", "sub"]},
    )
    if payload.get("type") != "access":
        raise ValueError("Not an access token")
    return int(payload["sub"])


# ---------------- refresh token (opaque random string) ----------------
def generate_refresh_token() -> str:
    return secrets.token_urlsafe(48)


def hash_refresh_token(token: str) -> str:
    """SHA-256 hex digest. Only this hash is stored in the database."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()
