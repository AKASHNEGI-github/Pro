"""
MySQL access (PyMySQL, raw SQL, no ORM).

* One connection per request, handed out by the `get_db` dependency.
* autocommit is OFF. Services wrap every write in `with transaction(conn):`
  so the commit/rollback happens deterministically BEFORE the response is sent.
* Every connection runs in UTC, so NOW()/CURRENT_TIMESTAMP columns are UTC.
* CLIENT.FOUND_ROWS makes cursor.rowcount = rows MATCHED by an UPDATE
  (not just rows whose values changed), which is what we want for 404 checks.
"""
from contextlib import contextmanager
from typing import Iterator

import pymysql
from pymysql.connections import Connection
from pymysql.constants import CLIENT
from pymysql.cursors import DictCursor

from app.config import settings


def get_connection() -> Connection:
    return pymysql.connect(
        host=settings.DB_HOST,
        port=settings.DB_PORT,
        user=settings.DB_USER,
        password=settings.DB_PASSWORD,
        database=settings.DB_NAME,
        charset="utf8mb4",
        cursorclass=DictCursor,
        autocommit=False,
        client_flag=CLIENT.FOUND_ROWS,
        init_command="SET time_zone = '+00:00'",
    )


def get_db() -> Iterator[Connection]:
    """FastAPI dependency: yields a connection and always closes it."""
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()  # closing an open transaction rolls it back


@contextmanager
def transaction(conn: Connection):
    """Commit if the block succeeds, roll back if it raises."""
    try:
        yield
        conn.commit()
    except Exception:
        conn.rollback()
        raise
