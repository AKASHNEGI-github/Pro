"""Authentication / authorisation dependencies used by the routers."""
import jwt
from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pymysql.connections import Connection

from app.database import get_db
from app.exceptions import ForbiddenError, UnauthorizedError
from app.security import decode_access_token
from app.services import user_service

# auto_error=False so we can return our own 401 (HTTPBearer would send 403 for a missing header).
bearer_scheme = HTTPBearer(auto_error=False)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    conn: Connection = Depends(get_db),
) -> dict:
    """
    Validates the access token, then loads the user from the DB on EVERY request.
    Because of the DB lookup, a deleted user is locked out immediately, even though
    their (stateless) access token has not expired yet. The role is read from the DB too.
    """
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise UnauthorizedError("Not authenticated")
    try:
        user_id = decode_access_token(credentials.credentials)
    except (jwt.PyJWTError, ValueError):
        raise UnauthorizedError("Invalid or expired token")

    user = user_service.get_user_by_id(conn, user_id)
    if user is None:
        raise UnauthorizedError("User no longer exists")
    return user


def require_admin(user: dict = Depends(get_current_user)) -> dict:
    if user["role"] != user_service.ROLE_ADMIN:
        raise ForbiddenError("Admin access required")
    return user


def require_member(user: dict = Depends(get_current_user)) -> dict:
    """Self-service profile endpoints. The admin's own account is managed only through .env."""
    if user["role"] != user_service.ROLE_MEMBER:
        raise ForbiddenError("The admin account cannot be changed through the API (edit the .env file)")
    return user
