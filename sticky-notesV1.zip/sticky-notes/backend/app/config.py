"""Application settings, loaded from the .env file (or real environment variables)."""
from functools import lru_cache
from typing import Annotated

from pydantic import EmailStr, Field, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Database
    DB_HOST: str = "127.0.0.1"
    DB_PORT: int = 3306
    DB_USER: str = "root"
    DB_PASSWORD: str = ""
    DB_NAME: str = "sticky_notes"

    # JWT / tokens
    JWT_SECRET_KEY: str = Field(min_length=16)
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    REFRESH_REUSE_GRACE_SECONDS: int = 10

    # The single admin (source of truth is this file)
    ADMIN_USERNAME: str = Field(min_length=3, max_length=50)
    ADMIN_EMAIL: EmailStr
    ADMIN_PASSWORD: str = Field(min_length=8)

    # CORS / cookies
    CORS_ORIGINS: Annotated[list[str], NoDecode] = ["http://localhost:5173"]
    COOKIE_SECURE: bool = False
    COOKIE_SAMESITE: str = "lax"  # "lax" | "strict" | "none"

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def split_origins(cls, value):
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        return value


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
