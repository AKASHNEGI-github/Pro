"""Admin-only user management. Works on MEMBERS only - the admin account is untouchable here."""
from fastapi import APIRouter, Depends, Response, status
from pymysql.connections import Connection

from app.database import get_db
from app.dependencies import require_admin
from app.schemas.common import BulkDeleteResponse, MessageResponse
from app.schemas.user import (
    AdminCreateUserRequest,
    AdminResetPasswordRequest,
    UserResponse,
    UserUpdateRequest,
)
from app.services import auth_service, user_service

router = APIRouter(prefix="/admin/users", tags=["Admin - User management"], dependencies=[Depends(require_admin)])


@router.post("", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def create_user(body: AdminCreateUserRequest, conn: Connection = Depends(get_db)):
    return user_service.create_member(conn, body.username, str(body.email), body.password)


@router.get("", response_model=list[UserResponse])
def view_all_users(conn: Connection = Depends(get_db)):
    return user_service.list_members(conn)


@router.delete("", response_model=BulkDeleteResponse)
def delete_all_users(conn: Connection = Depends(get_db)):
    """Soft-deletes every member (and their notes). The admin is never affected."""
    count = user_service.delete_all_members(conn)
    return BulkDeleteResponse(message=f"{count} user(s) deleted", deleted_count=count)


@router.get("/{user_id}", response_model=UserResponse)
def view_user(user_id: int, conn: Connection = Depends(get_db)):
    return user_service.get_member_or_404(conn, user_id)


@router.put("/{user_id}", response_model=UserResponse)
def update_user(user_id: int, body: UserUpdateRequest, conn: Connection = Depends(get_db)):
    return user_service.update_member(conn, user_id, body.username, str(body.email) if body.email else None)


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int, conn: Connection = Depends(get_db)):
    user_service.delete_member(conn, user_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put("/{user_id}/password", response_model=MessageResponse)
def reset_user_password(user_id: int, body: AdminResetPasswordRequest, conn: Connection = Depends(get_db)):
    """Replaces a member's password (no old password needed) and logs that member out everywhere."""
    auth_service.admin_reset_member_password(conn, user_id, body.new_password)
    return MessageResponse(message="Password reset. The user has been logged out everywhere.")
