"""Notes. Available to admin AND member, but each person only ever sees their OWN notes."""
from fastapi import APIRouter, Depends, Response, status
from pymysql.connections import Connection

from app.database import get_db
from app.dependencies import get_current_user
from app.schemas.common import BulkDeleteResponse
from app.schemas.note import NoteCreate, NoteResponse, NoteUpdate
from app.services import note_service

router = APIRouter(prefix="/notes", tags=["Notes"])


@router.post("", response_model=NoteResponse, status_code=status.HTTP_201_CREATED)
def create_note(body: NoteCreate, user: dict = Depends(get_current_user), conn: Connection = Depends(get_db)):
    return note_service.create_note(conn, user["id"], body.title, body.content, body.color)


@router.get("", response_model=list[NoteResponse])
def view_all_notes(user: dict = Depends(get_current_user), conn: Connection = Depends(get_db)):
    return note_service.list_notes(conn, user["id"])


@router.delete("", response_model=BulkDeleteResponse)
def delete_all_notes(user: dict = Depends(get_current_user), conn: Connection = Depends(get_db)):
    count = note_service.delete_all_notes(conn, user["id"])
    return BulkDeleteResponse(message=f"{count} note(s) deleted", deleted_count=count)


@router.get("/{note_id}", response_model=NoteResponse)
def view_note(note_id: int, user: dict = Depends(get_current_user), conn: Connection = Depends(get_db)):
    return note_service.get_note(conn, user["id"], note_id)


@router.put("/{note_id}", response_model=NoteResponse)
def update_note(
    note_id: int,
    body: NoteUpdate,
    user: dict = Depends(get_current_user),
    conn: Connection = Depends(get_db),
):
    return note_service.update_note(conn, user["id"], note_id, body.model_dump(exclude_none=True))


@router.delete("/{note_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_note(note_id: int, user: dict = Depends(get_current_user), conn: Connection = Depends(get_db)):
    note_service.delete_note(conn, user["id"], note_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
