from typing import Optional

from fastapi import APIRouter, Cookie, Depends, HTTPException, Response, status
from fastapi.responses import JSONResponse
from pymysql.connections import Connection

from app.cookies import REFRESH_COOKIE_NAME, clear_refresh_cookie, set_refresh_cookie
from app.database import get_db
from app.schemas.auth import LoginRequest, TokenResponse
from app.schemas.user import RegisterRequest, UserResponse
from app.services import auth_service, user_service

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(body: RegisterRequest, conn: Connection = Depends(get_db)):
    """Public. Creates a MEMBER (there is no way to register as admin)."""
    return user_service.create_member(conn, body.username, str(body.email), body.password)


@router.post("/login", response_model=TokenResponse)
def login(body: LoginRequest, response: Response, conn: Connection = Depends(get_db)):
    """Returns the access token in JSON and sets the refresh token as an httpOnly cookie."""
    user, access_token, raw_refresh = auth_service.login(conn, str(body.email), body.password)
    set_refresh_cookie(response, raw_refresh)
    return TokenResponse(access_token=access_token, user=user)


@router.post("/refresh", response_model=TokenResponse)
def refresh(
    response: Response,
    refresh_token: Optional[str] = Cookie(default=None, alias=REFRESH_COOKIE_NAME),
    conn: Connection = Depends(get_db),
):
    """Reads the refresh cookie, rotates it, returns a new access token (+ the user, handy after a page reload)."""
    try:
        user, access_token, new_raw_refresh = auth_service.refresh(conn, refresh_token)
    except HTTPException as exc:
        # Headers set on the injected `response` are dropped when an exception is raised,
        # so build the error response ourselves and let it clear the dead cookie.
        error_response = JSONResponse(status_code=exc.status_code, content={"detail": exc.detail}, headers=exc.headers)
        clear_refresh_cookie(error_response)
        return error_response
    set_refresh_cookie(response, new_raw_refresh)
    return TokenResponse(access_token=access_token, user=user)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    response: Response,
    refresh_token: Optional[str] = Cookie(default=None, alias=REFRESH_COOKIE_NAME),
    conn: Connection = Depends(get_db),
):
    """Revokes the refresh token and clears the cookie. Needs no access token (it may have expired)."""
    auth_service.logout(conn, refresh_token)
    clear_refresh_cookie(response)
    response.status_code = status.HTTP_204_NO_CONTENT
    return response
