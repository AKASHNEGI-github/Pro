"""Self-service: the logged-in user managing THEIR OWN account."""
from fastapi import APIRouter, Depends, Response, status
from pymysql.connections import Connection

from app.cookies import clear_refresh_cookie
from app.database import get_db
from app.dependencies import get_current_user, require_member
from app.schemas.common import MessageResponse
from app.schemas.user import ChangePasswordRequest, UserResponse, UserUpdateRequest
from app.services import auth_service, user_service

router = APIRouter(prefix="/users/me", tags=["Users (self)"])


@router.get("", response_model=UserResponse)
def view_me(user: dict = Depends(get_current_user)):
    """Admin and member can both view themselves."""
    return user


@router.put("", response_model=UserResponse)
def update_me(body: UserUpdateRequest, user: dict = Depends(require_member), conn: Connection = Depends(get_db)):
    """Member only. Change own username and/or email."""
    return user_service.update_member(conn, user["id"], body.username, str(body.email) if body.email else None)


@router.delete("", status_code=status.HTTP_204_NO_CONTENT)
def delete_me(response: Response, user: dict = Depends(require_member), conn: Connection = Depends(get_db)):
    """Member only. Soft-deletes own account, notes and sessions."""
    user_service.delete_member(conn, user["id"])
    clear_refresh_cookie(response)
    response.status_code = status.HTTP_204_NO_CONTENT
    return response


@router.post("/change-password", response_model=MessageResponse)
def change_my_password(
    body: ChangePasswordRequest,
    response: Response,
    user: dict = Depends(require_member),
    conn: Connection = Depends(get_db),
):
    """
    Member only. Verifies the old password, saves the new one and revokes every refresh token.
    The frontend must then drop its access token and send the user to the login page.
    """
    auth_service.change_own_password(conn, user["id"], body.old_password, body.new_password)
    clear_refresh_cookie(response)
    return MessageResponse(message="Password changed. Please log in again with your new password.")
