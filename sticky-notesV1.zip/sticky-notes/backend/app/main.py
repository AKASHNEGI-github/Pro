import logging
from contextlib import asynccontextmanager

import pymysql
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.bootstrap import ensure_admin
from app.config import settings
from app.routers import admin_users, auth, notes, users

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")
logger = logging.getLogger("sticky_notes")


@asynccontextmanager
async def lifespan(app: FastAPI):
    ensure_admin()  # create / sync the single admin from .env
    yield


app = FastAPI(title="Sticky Notes API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,  # required so the browser sends/accepts the refresh cookie
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(pymysql.MySQLError)
async def database_error_handler(request: Request, exc: pymysql.MySQLError):
    logger.exception("Database error on %s %s", request.method, request.url.path)
    return JSONResponse(status_code=500, content={"detail": "Database error"})


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}


app.include_router(auth.router, prefix="/api")
app.include_router(users.router, prefix="/api")
app.include_router(admin_users.router, prefix="/api")
app.include_router(notes.router, prefix="/api")
