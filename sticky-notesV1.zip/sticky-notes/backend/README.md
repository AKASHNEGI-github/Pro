# Sticky Notes – Backend

FastAPI + MySQL (raw SQL with PyMySQL, no ORM). Two roles: **ADMIN** (exactly one, defined in `.env`) and **MEMBER**.

## 1. Setup

**1. Create the database** – open `database/schema.sql` in MySQL Workbench and run the whole file (⚡ / `Ctrl+Shift+Enter`).
It creates the `sticky_notes` database, the 6 tables and seeds the `ADMIN` and `MEMBER` roles. It is safe to run twice.

**2. Python environment** (Python 3.10+):

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

**3. Configure** – copy `.env.example` to `.env` and edit it:

```bash
cp .env.example .env             # Windows: copy .env.example .env
```

Must-change values: `DB_USER`, `DB_PASSWORD`, `JWT_SECRET_KEY`, and the `ADMIN_*` credentials.
Generate a secret with `python -c "import secrets; print(secrets.token_urlsafe(64))"`.

**4. Run**

```bash
uvicorn app.main:app --reload
```

* Swagger UI: http://127.0.0.1:8000/docs (log in via `POST /api/auth/login`, copy the `access_token`, click **Authorize**, paste it)
* On startup the backend creates the admin from `.env` if there is none yet. On every later startup it re-syncs the admin's username, email and password from `.env`. **To change the admin password, edit `.env` and restart.**

## 2. Project layout

```
database/schema.sql        complete MySQL schema (run in Workbench)
app/
  main.py                  app, CORS, routers, startup (admin bootstrap)
  config.py                .env settings
  database.py              PyMySQL connection per request + transaction() helper
  security.py              bcrypt, JWT access token, refresh token + SHA-256 hashing
  cookies.py               the httpOnly refresh-token cookie
  dependencies.py          get_current_user / require_admin / require_member
  bootstrap.py             create + sync the single admin from .env
  routers/                 thin HTTP layer
  services/                ALL raw SQL lives here
  schemas/                 Pydantic request / response models
```

## 3. Database (6 tables)

| Table | Purpose |
|---|---|
| `roles` | `ADMIN`, `MEMBER` (seeded) |
| `users` | `username`, `email` only. Unique **among active rows** (generated columns), so a deleted user's email/username can register again |
| `user_roles` | one row per user → role. Never updated (roles can't change) |
| `user_passwords` | current bcrypt hash only (one row per user, no history) |
| `refresh_tokens` | SHA-256 **hash** of each refresh token. Revoked = `is_deleted = 1` |
| `notes` | `title`, `content` (markdown), `color`, owned by exactly one user |

Every table has `is_deleted` + `deleted_at`. **There is no `DELETE` statement anywhere in the code.**

## 4. API

All paths are prefixed with `/api`. “Bearer” = `Authorization: Bearer <access_token>`.

### Auth
| Method | Path | Who | Notes |
|---|---|---|---|
| POST | `/auth/register` | public | body: `username`, `email`, `password` → creates a MEMBER |
| POST | `/auth/login` | public | body: `email`, `password` → `{access_token, user}` + sets refresh cookie |
| POST | `/auth/refresh` | cookie | rotates the refresh token → `{access_token, user}` |
| POST | `/auth/logout` | cookie | revokes the refresh token, clears the cookie |

### Own account (`/users/me`)
| Method | Path | Who | Notes |
|---|---|---|---|
| GET | `/users/me` | admin, member | view self |
| PUT | `/users/me` | member | body: `username` and/or `email` |
| DELETE | `/users/me` | member | soft-deletes the account, its notes and its sessions |
| POST | `/users/me/change-password` | member | body: `old_password`, `new_password`. Verifies old, saves new, **revokes all sessions** → frontend must log out |

### Admin → members (`/admin/users`) – ADMIN only, members only
| Method | Path | Notes |
|---|---|---|
| POST | `/admin/users` | create a member |
| GET | `/admin/users` | view all members |
| GET | `/admin/users/{id}` | view one member |
| PUT | `/admin/users/{id}` | update username/email |
| PUT | `/admin/users/{id}/password` | body: `new_password` (replaces the password, logs that member out everywhere) |
| DELETE | `/admin/users/{id}` | soft-delete a member + their notes |
| DELETE | `/admin/users` | soft-delete **all** members + their notes (never the admin) |

### Notes (`/notes`) – admin and member, **own notes only**
| Method | Path | Notes |
|---|---|---|
| POST | `/notes` | body: `title`, `content` (markdown), `color` (`#RRGGBB`, optional) |
| GET | `/notes` | all my notes, newest-updated first |
| GET | `/notes/{id}` | one of my notes |
| PUT | `/notes/{id}` | send only the fields to change |
| DELETE | `/notes/{id}` | soft delete → 204 |
| DELETE | `/notes` | soft-delete all **my** notes → `{deleted_count}` |

### Status codes you will see
`401` not logged in / bad credentials · `403` wrong role (or admin trying to edit itself) · `404` not found **or not yours** · `409` username/email already in use · `422` validation error · `400` wrong old password.

## 5. How the rules are enforced

* **Notes are private** – every notes query filters on `user_id` taken from the token, never from the request. Someone else's note returns `404`, same as a missing one. The admin has no special access to notes.
* **Admin can't be changed or deleted** – `/users/me` write endpoints reject the admin (`403`), and every `/admin/users/*` query only matches rows whose role is `MEMBER`, so the admin id returns `404` there. Only `.env` changes the admin.
* **No role changes** – no endpoint accepts a role; `register` and `POST /admin/users` always create `MEMBER`.
* **Deleted users are locked out at once** – `get_current_user` reads the user from MySQL on every request, so a still-valid access token stops working the moment the user is deleted.
* **Refresh tokens** – the browser only ever holds the **access token** (in memory). The refresh token is a random string sent as an **httpOnly cookie** (path `/api/auth`, invisible to JavaScript); MySQL stores only its SHA-256 hash. Each `/refresh` **rotates** it. If an *old, already-used* token shows up again later, all of that user's sessions are revoked (possible theft). A duplicate within `REFRESH_REUSE_GRACE_SECONDS` (default 10 s) is just rejected without punishment.
* **Transactions** – multi-table operations (register, delete user, delete all users, change password…) run inside one `with transaction(conn):` block, so they either fully happen or don't happen at all.

## 6. The frontend

The React app lives in `../frontend` (see the project README). How it talks to this API:

* Axios uses `withCredentials: true`; the Vite dev server proxies `/api` to this backend, so the refresh cookie is an ordinary same-origin cookie and CORS is not even involved in development.
* The access token is kept in memory only. On page load the app calls `POST /api/auth/refresh` once (a shared in-flight promise makes React 18 StrictMode's double effect harmless). `200` = logged in, `401` = show the login page.
* On any `401` from a normal endpoint the Axios interceptor refreshes once and retries the request; if the refresh fails, the user is sent to the login page.
* After `change-password` or deleting the own account, the frontend drops its token and goes to the login page.
