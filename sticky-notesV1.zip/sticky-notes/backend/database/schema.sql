-- =====================================================================
--  STICKY NOTES  -  MySQL schema
--  Run this whole file once in MySQL Workbench (Ctrl+Shift+Enter).
--  Requires MySQL 5.7.6+ (8.0 recommended) because of generated columns.
--
--  Design rules
--  ------------
--  * No hard deletes anywhere. Every table has is_deleted + deleted_at.
--  * Every table uses an auto-increment primary key.
--  * "Unique among ACTIVE rows" is done with a generated column that is
--    NULL once a row is soft-deleted. MySQL allows many NULLs inside a
--    UNIQUE index, so a deleted user no longer blocks the same email /
--    username from registering again.
--  * All timestamps are stored in UTC (the backend sets the session
--    time zone to +00:00 for every connection it opens).
-- =====================================================================

CREATE DATABASE IF NOT EXISTS sticky_notes
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE sticky_notes;

-- ---------------------------------------------------------------------
-- Uncomment ONLY if you want to wipe everything and start over.
-- ---------------------------------------------------------------------
-- SET FOREIGN_KEY_CHECKS = 0;
-- DROP TABLE IF EXISTS notes, refresh_tokens, user_passwords, user_roles, users, roles;
-- SET FOREIGN_KEY_CHECKS = 1;


-- ---------------------------------------------------------------------
-- 1. roles  (static lookup: ADMIN, MEMBER)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS roles (
    id          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    name        VARCHAR(20)   NOT NULL,
    description VARCHAR(255)  NULL,
    is_deleted  TINYINT(1)    NOT NULL DEFAULT 0,
    deleted_at  DATETIME      NULL,
    created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_roles_name (name)
) ENGINE=InnoDB;


-- ---------------------------------------------------------------------
-- 2. users  (identity only - no password, no role here)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    username   VARCHAR(50)     NOT NULL,
    email      VARCHAR(255)    NOT NULL,
    is_deleted TINYINT(1)      NOT NULL DEFAULT 0,
    deleted_at DATETIME        NULL,
    created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Generated helpers: equal to the value while the user is active,
    -- NULL after soft delete -> lets the UNIQUE indexes ignore deleted rows.
    active_username VARCHAR(50)  GENERATED ALWAYS AS (IF(is_deleted = 0, username, NULL)) STORED,
    active_email    VARCHAR(255) GENERATED ALWAYS AS (IF(is_deleted = 0, email,    NULL)) STORED,

    PRIMARY KEY (id),
    UNIQUE KEY uq_users_active_username (active_username),
    UNIQUE KEY uq_users_active_email    (active_email)
) ENGINE=InnoDB;


-- ---------------------------------------------------------------------
-- 3. user_roles  (mapping users <-> roles; exactly one row per user)
--    Roles never change, so there is no "update role" anywhere.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_roles (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id    BIGINT UNSIGNED NOT NULL,
    role_id    INT UNSIGNED    NOT NULL,
    is_deleted TINYINT(1)      NOT NULL DEFAULT 0,
    deleted_at DATETIME        NULL,
    created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_user_roles_user (user_id),
    KEY idx_user_roles_role (role_id),
    CONSTRAINT fk_user_roles_user FOREIGN KEY (user_id) REFERENCES users (id),
    CONSTRAINT fk_user_roles_role FOREIGN KEY (role_id) REFERENCES roles (id)
) ENGINE=InnoDB;


-- ---------------------------------------------------------------------
-- 4. user_passwords  (current bcrypt hash only - no history)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_passwords (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id       BIGINT UNSIGNED NOT NULL,
    password_hash VARCHAR(255)    NOT NULL,
    is_deleted    TINYINT(1)      NOT NULL DEFAULT 0,
    deleted_at    DATETIME        NULL,
    created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_user_passwords_user (user_id),
    CONSTRAINT fk_user_passwords_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB;


-- ---------------------------------------------------------------------
-- 5. refresh_tokens  (only the SHA-256 hash of the token is stored)
--    "Revoked" == is_deleted = 1. Revoked rows are kept on purpose so a
--    replayed (already-used) token can be detected.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id    BIGINT UNSIGNED NOT NULL,
    token_hash CHAR(64)        NOT NULL,
    expires_at DATETIME        NOT NULL,
    is_deleted TINYINT(1)      NOT NULL DEFAULT 0,
    deleted_at DATETIME        NULL,
    created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY uq_refresh_tokens_hash (token_hash),
    KEY idx_refresh_tokens_user (user_id, is_deleted),
    CONSTRAINT fk_refresh_tokens_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB;


-- ---------------------------------------------------------------------
-- 6. notes  (private to the owner - admin included)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notes (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id    BIGINT UNSIGNED NOT NULL,
    title      VARCHAR(255)    NOT NULL,
    content    LONGTEXT        NOT NULL,                 -- markdown
    color      VARCHAR(7)      NOT NULL DEFAULT '#FFF59D',
    is_deleted TINYINT(1)      NOT NULL DEFAULT 0,
    deleted_at DATETIME        NULL,
    created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    KEY idx_notes_user_active (user_id, is_deleted, updated_at),
    CONSTRAINT fk_notes_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB;


-- ---------------------------------------------------------------------
-- Seed data: the two fixed roles.
-- (The ADMIN user itself is created by the backend on startup from .env,
--  because its password must be hashed with bcrypt.)
-- ---------------------------------------------------------------------
INSERT INTO roles (name, description)
VALUES ('ADMIN',  'The single administrator. Manages members and own notes.'),
       ('MEMBER', 'Regular user. Manages own profile and own notes.')
ON DUPLICATE KEY UPDATE description = VALUES(description);
