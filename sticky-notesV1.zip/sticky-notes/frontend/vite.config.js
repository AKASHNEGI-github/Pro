import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The browser talks to the Vite server (same origin), and Vite forwards /api/* to FastAPI.
// Benefits: no CORS problems, and the httpOnly refresh cookie is a plain same-origin cookie.
const proxy = {
  "/api": {
    target: process.env.VITE_PROXY_TARGET || "http://127.0.0.1:8000",
    changeOrigin: true,
  },
};

export default defineConfig({
  plugins: [react()],
  server: { port: 5173, proxy },
  preview: { port: 5173, proxy },
});
