import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { authApi } from "../api/services";
import { refreshSession, setAccessToken, setAuthLostHandler } from "../api/client";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // true until we know whether a session exists

  // On first load: the access token is gone from memory, so try the refresh cookie once.
  useEffect(() => {
    let ignore = false;
    setAuthLostHandler(() => setUser(null)); // called by the axios interceptor if the session dies

    refreshSession() // shared in-flight promise -> safe under React StrictMode
      .then((data) => !ignore && setUser(data.user))
      .catch(() => {}) // 401 = simply not logged in
      .finally(() => !ignore && setLoading(false));

    return () => {
      ignore = true;
    };
  }, []);

  const login = useCallback(async (email, password) => {
    const data = await authApi.login(email, password);
    setAccessToken(data.access_token);
    setUser(data.user);
    return data.user;
  }, []);

  // Normal logout: tell the server (revokes the refresh token), then forget everything locally.
  const logout = useCallback(async () => {
    try {
      await authApi.logout();
    } catch {
      /* even if the call fails we still log out locally */
    }
    setAccessToken(null);
    setUser(null);
  }, []);

  // Used after change-password / delete-account: the server already revoked and cleared everything.
  const clearSession = useCallback(() => {
    setAccessToken(null);
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({ user, loading, login, logout, clearSession, setUser }),
    [user, loading, login, logout, clearSession]
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
