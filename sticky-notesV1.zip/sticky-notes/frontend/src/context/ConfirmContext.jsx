import { createContext, useCallback, useContext, useState } from "react";
import Modal from "../components/Modal";

const ConfirmContext = createContext(null);

/**
 * Usage:   const confirm = useConfirm();
 *          if (await confirm({ title, message, confirmText, danger: true })) { ... }
 */
export function ConfirmProvider({ children }) {
  const [request, setRequest] = useState(null);

  const confirm = useCallback((options) => new Promise((resolve) => setRequest({ ...options, resolve })), []);

  const answer = (result) => {
    request.resolve(result);
    setRequest(null);
  };

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      {request && (
        <Modal
          title={request.title || "Are you sure?"}
          onClose={() => answer(false)}
          footer={
            <>
              <button className="btn" onClick={() => answer(false)}>
                Cancel
              </button>
              <button className={`btn ${request.danger ? "btn--danger" : "btn--primary"}`} onClick={() => answer(true)} autoFocus>
                {request.confirmText || "Confirm"}
              </button>
            </>
          }
        >
          <p>{request.message}</p>
        </Modal>
      )}
    </ConfirmContext.Provider>
  );
}

export const useConfirm = () => useContext(ConfirmContext);
