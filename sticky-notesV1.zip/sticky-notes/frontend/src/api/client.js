/**
 * The ONE axios instance of the app.
 *
 * Token handling (as designed):
 *  - The ACCESS token lives only in this module's memory (a plain variable).
 *    Never localStorage / sessionStorage / cookies written by JavaScript.
 *  - The REFRESH token is an httpOnly cookie managed by the browser + backend.
 *    JavaScript cannot see it. We only trigger POST /auth/refresh and the browser attaches it.
 *  - After a page reload the memory is empty, so the app calls refreshSession() once to get a new
 *    access token (this is how "stay logged in" works).
 */
import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "/api",
  withCredentials: true, // lets the browser send / accept the refresh cookie
});

let accessToken = null;
let onAuthLost = () => {};

export const setAccessToken = (token) => {
  accessToken = token;
};
export const setAuthLostHandler = (handler) => {
  onAuthLost = handler;
};

// Attach the access token to every request.
api.interceptors.request.use((config) => {
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`;
  return config;
});

/**
 * Gets a fresh access token using the refresh cookie.
 * If several callers ask at the same moment (React StrictMode double effects, or several
 * requests failing with 401 together) they all share ONE network call. This matters because
 * the backend rotates the refresh token: a second simultaneous call would present an
 * already-used token.
 */
let refreshPromise = null;
export function refreshSession() {
  if (!refreshPromise) {
    refreshPromise = api
      .post("/auth/refresh")
      .then((response) => {
        accessToken = response.data.access_token;
        return response.data; // { access_token, token_type, user }
      })
      .finally(() => {
        refreshPromise = null;
      });
  }
  return refreshPromise;
}

// If a request fails with 401 (access token expired), refresh once and retry it.
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    const isAuthEndpoint = original?.url?.startsWith("/auth/");

    if (error.response?.status === 401 && original && !original._retried && !isAuthEndpoint && accessToken) {
      original._retried = true;
      try {
        await refreshSession();
        return api(original); // the request interceptor adds the new token
      } catch {
        accessToken = null;
        onAuthLost(); // session is really gone -> app goes to the login page
      }
    }
    return Promise.reject(error);
  }
);

export default api;
