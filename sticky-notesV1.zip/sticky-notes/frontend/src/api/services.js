/** One small function per backend endpoint. Every function returns the response body. */
import api from "./client";

const data = (response) => response.data;

export const authApi = {
  register: (body) => api.post("/auth/register", body).then(data), // {username, email, password}
  login: (email, password) => api.post("/auth/login", { email, password }).then(data),
  logout: () => api.post("/auth/logout"),
};

// The logged-in user's own account
export const meApi = {
  update: (body) => api.put("/users/me", body).then(data), // {username?, email?}
  remove: () => api.delete("/users/me"),
  changePassword: (old_password, new_password) =>
    api.post("/users/me/change-password", { old_password, new_password }).then(data),
};

// Admin only
export const adminApi = {
  list: () => api.get("/admin/users").then(data),
  get: (id) => api.get(`/admin/users/${id}`).then(data),
  create: (body) => api.post("/admin/users", body).then(data),
  update: (id, body) => api.put(`/admin/users/${id}`, body).then(data),
  remove: (id) => api.delete(`/admin/users/${id}`),
  removeAll: () => api.delete("/admin/users").then(data),
  resetPassword: (id, new_password) => api.put(`/admin/users/${id}/password`, { new_password }).then(data),
};

// Notes (own notes only - the backend guarantees it)
export const notesApi = {
  list: () => api.get("/notes").then(data),
  get: (id) => api.get(`/notes/${id}`).then(data),
  create: (body) => api.post("/notes", body).then(data), // {title, content, color}
  update: (id, body) => api.put(`/notes/${id}`, body).then(data),
  remove: (id) => api.delete(`/notes/${id}`),
  removeAll: () => api.delete("/notes").then(data),
};
