import { Link, useNavigate } from "react-router-dom";
import { MarkdownViewer } from "react-markdown-studio";
import { formatDate } from "../utils/format";

/** One coloured sticky note. Click anywhere (or the title) to open it in the editor. */
export default function NoteCard({ note, onDelete }) {
  const navigate = useNavigate();
  const open = () => navigate(`/notes/${note.id}`);

  return (
    <article
      className="note-card"
      style={{ background: note.color, "--tilt": `${((note.id % 5) - 2) * 0.5}deg` }}
      onClick={open}
    >
      <h3 className="note-card__title">
        <Link to={`/notes/${note.id}`} onClick={(e) => e.stopPropagation()}>
          {note.title}
        </Link>
      </h3>

      <div className="note-card__body">
        <MarkdownViewer
          value={note.content || "*Empty note*"}
          theme="light"
          className="note-md"
          interactiveChecklists={false}
          headingOffset={2}
        />
      </div>

      <footer className="note-card__footer">
        <time dateTime={note.updated_at}>{formatDate(note.updated_at)}</time>
        <button
          className="icon-btn"
          aria-label={`Delete note ${note.title}`}
          title="Delete note"
          onClick={(e) => {
            e.stopPropagation();
            onDelete(note);
          }}
        >
          🗑
        </button>
      </footer>
    </article>
  );
}
