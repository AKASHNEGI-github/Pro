import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

/** Top bar + page area for every logged-in page. */
export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/login", { replace: true });
  };

  const linkClass = ({ isActive }) => `nav__link${isActive ? " nav__link--active" : ""}`;

  return (
    <>
      <header className="topbar">
        <div className="topbar__inner">
          <NavLink to="/" className="brand">
            <span aria-hidden="true">📝</span> Sticky Notes
          </NavLink>

          <nav className="nav" aria-label="Main">
            <NavLink to="/" end className={linkClass}>
              My notes
            </NavLink>
            {user.role === "ADMIN" && (
              <NavLink to="/admin/users" className={linkClass}>
                Users
              </NavLink>
            )}
            <NavLink to="/profile" className={linkClass}>
              Profile
            </NavLink>
          </nav>

          <div className="topbar__user">
            <span className="topbar__name">{user.username}</span>
            <span className={`badge badge--${user.role.toLowerCase()}`}>{user.role}</span>
            <button className="btn btn--small" onClick={handleLogout}>
              Log out
            </button>
          </div>
        </div>
      </header>

      <main className="page">
        <Outlet />
      </main>
    </>
  );
}
