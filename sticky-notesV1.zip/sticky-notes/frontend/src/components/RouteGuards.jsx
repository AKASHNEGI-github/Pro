import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export function Splash() {
  return (
    <div className="splash" role="status">
      <span className="spinner" /> Loading…
    </div>
  );
}

/** Only for logged-in users. With `role="ADMIN"` it also requires that role. */
export function RequireAuth({ role }) {
  const { user, loading } = useAuth();

  if (loading) return <Splash />;
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to="/" replace />;
  return <Outlet />;
}

/** Login / register pages: logged-in users are sent to the notes page instead. */
export function PublicOnly() {
  const { user, loading } = useAuth();
  if (loading) return <Splash />;
  if (user) return <Navigate to="/" replace />;
  return <Outlet />;
}
