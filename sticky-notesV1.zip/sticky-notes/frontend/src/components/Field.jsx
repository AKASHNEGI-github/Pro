import { useId } from "react";

/** A label + input pair (the label is connected to the input, which helps accessibility). */
export default function Field({ label, hint, ...inputProps }) {
  const id = useId();
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <input id={id} {...inputProps} />
      {hint && <small>{hint}</small>}
    </div>
  );
}
