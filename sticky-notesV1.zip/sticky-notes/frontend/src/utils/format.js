/** Turns an axios error into one readable sentence (FastAPI sends `detail` as text or a list). */
export function getErrorMessage(error, fallback = "Something went wrong. Please try again.") {
  if (!error?.response) return "Cannot reach the server. Is the backend running?";
  const detail = error.response.data?.detail;
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    return detail
      .map((item) => {
        const field = Array.isArray(item.loc) ? item.loc.filter((p) => p !== "body").join(".") : "";
        const message = String(item.msg || "").replace(/^Value error, /, "");
        return field ? `${field}: ${message}` : message;
      })
      .join(" · ");
  }
  return fallback;
}

export function formatDate(iso) {
  return new Date(iso).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

export const NOTE_COLORS = [
  { name: "Yellow", value: "#FFF59D" },
  { name: "Pink", value: "#F8BBD0" },
  { name: "Green", value: "#C5E1A5" },
  { name: "Blue", value: "#B3E5FC" },
  { name: "Purple", value: "#D1C4E9" },
  { name: "Orange", value: "#FFCCBC" },
];
export const DEFAULT_NOTE_COLOR = NOTE_COLORS[0].value;

// Same rule as the backend: letters, digits, underscore, dot, hyphen (3-50 chars).
export const USERNAME_PATTERN = "[\\w.\\-]+";
export const USERNAME_HINT = "3-50 characters: letters, numbers, _ . -";
