import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="auth-page">
      <div className="auth-card" style={{ textAlign: "center" }}>
        <h1>404</h1>
        <p className="muted">This page does not exist.</p>
        <Link to="/" className="btn btn--primary">Back to my notes</Link>
      </div>
    </div>
  );
}
