import { useState } from "react";
import { Link } from "react-router-dom";
import Field from "../components/Field";
import { authApi } from "../api/services";
import { useAuth } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { USERNAME_HINT, USERNAME_PATTERN, getErrorMessage } from "../utils/format";

export default function Register() {
  const { login } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ username: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (name) => (e) => setForm((f) => ({ ...f, [name]: e.target.value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    if (form.password !== form.confirm) return setError("Passwords do not match.");

    setBusy(true);
    try {
      const email = form.email.trim();
      await authApi.register({ username: form.username.trim(), email, password: form.password });
      toast.success("Account created. Welcome!");
      await login(email, form.password); // log in right away; PublicOnly then redirects to "/"
    } catch (err) {
      setError(getErrorMessage(err));
      setBusy(false);
    }
  };

  return (
    <div className="auth-page">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h1 className="auth-card__brand">📝 Sticky Notes</h1>
        <p className="muted">Create your account</p>

        {error && <div className="alert alert--error" role="alert">{error}</div>}

        <Field label="Username" value={form.username} onChange={set("username")} required minLength={3} maxLength={50} pattern={USERNAME_PATTERN} title={USERNAME_HINT} hint={USERNAME_HINT} autoFocus autoComplete="username" />
        <Field label="Email" type="email" value={form.email} onChange={set("email")} required autoComplete="email" />
        <Field label="Password" type="password" value={form.password} onChange={set("password")} required minLength={8} maxLength={72} hint="At least 8 characters" autoComplete="new-password" />
        <Field label="Confirm password" type="password" value={form.confirm} onChange={set("confirm")} required autoComplete="new-password" />

        <button className="btn btn--primary btn--block" disabled={busy}>
          {busy ? "Creating…" : "Sign up"}
        </button>
        <p className="auth-card__switch">
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </form>
    </div>
  );
}
