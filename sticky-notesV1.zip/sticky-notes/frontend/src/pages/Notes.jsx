import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import NoteCard from "../components/NoteCard";
import { notesApi } from "../api/services";
import { useConfirm } from "../context/ConfirmContext";
import { useToast } from "../context/ToastContext";
import { getErrorMessage } from "../utils/format";

export default function Notes() {
  const [notes, setNotes] = useState(null); // null = still loading
  const [error, setError] = useState("");
  const confirm = useConfirm();
  const toast = useToast();

  useEffect(() => {
    let ignore = false;
    notesApi
      .list()
      .then((list) => !ignore && setNotes(list))
      .catch((err) => !ignore && setError(getErrorMessage(err)));
    return () => {
      ignore = true;
    };
  }, []);

  const handleDelete = async (note) => {
    const ok = await confirm({
      title: "Delete note?",
      message: `"${note.title}" will be deleted.`,
      confirmText: "Delete",
      danger: true,
    });
    if (!ok) return;
    try {
      await notesApi.remove(note.id);
      setNotes((list) => list.filter((n) => n.id !== note.id));
      toast.success("Note deleted");
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleDeleteAll = async () => {
    const ok = await confirm({
      title: "Delete ALL your notes?",
      message: `All ${notes.length} of your notes will be deleted.`,
      confirmText: "Delete all",
      danger: true,
    });
    if (!ok) return;
    try {
      const result = await notesApi.removeAll();
      setNotes([]);
      toast.success(result.message);
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  if (error) return <div className="alert alert--error">{error}</div>;
  if (notes === null) return <div className="splash"><span className="spinner" /> Loading notes…</div>;

  return (
    <>
      <div className="page-head">
        <div>
          <h1>My notes</h1>
          <p className="muted">{notes.length === 1 ? "1 note" : `${notes.length} notes`}</p>
        </div>
        <div className="page-head__actions">
          <button className="btn btn--danger-outline" onClick={handleDeleteAll} disabled={notes.length === 0}>
            Delete all
          </button>
          <Link to="/notes/new" className="btn btn--primary">
            + New note
          </Link>
        </div>
      </div>

      {notes.length === 0 ? (
        <div className="empty">
          <div className="empty__icon" aria-hidden="true">🗒️</div>
          <h2>No notes yet</h2>
          <p className="muted">Write your first sticky note. Markdown is supported.</p>
          <Link to="/notes/new" className="btn btn--primary">
            Create a note
          </Link>
        </div>
      ) : (
        <div className="notes-grid">
          {notes.map((note) => (
            <NoteCard key={note.id} note={note} onDelete={handleDelete} />
          ))}
        </div>
      )}
    </>
  );
}
