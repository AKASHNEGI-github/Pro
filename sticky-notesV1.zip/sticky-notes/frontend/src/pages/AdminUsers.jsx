import { useCallback, useEffect, useState } from "react";
import Field from "../components/Field";
import Modal from "../components/Modal";
import { adminApi } from "../api/services";
import { useConfirm } from "../context/ConfirmContext";
import { useToast } from "../context/ToastContext";
import { USERNAME_HINT, USERNAME_PATTERN, formatDate, getErrorMessage } from "../utils/format";

/** Admin: manage MEMBERS. (The backend never lets the admin account be touched here.) */
export default function AdminUsers() {
  const [users, setUsers] = useState(null); // null = loading
  const [error, setError] = useState("");
  const [modal, setModal] = useState(null); // { type: "create" } | { type: "edit"|"password", user }
  const confirm = useConfirm();
  const toast = useToast();

  useEffect(() => {
    let ignore = false;
    adminApi
      .list()
      .then((list) => !ignore && setUsers(list))
      .catch((err) => !ignore && setError(getErrorMessage(err)));
    return () => {
      ignore = true;
    };
  }, []);

  const closeModal = useCallback(() => setModal(null), []);

  const handleCreated = (user) => {
    setUsers((list) => [...list, user]);
    closeModal();
    toast.success(`User "${user.username}" created`);
  };

  const handleUpdated = (user) => {
    setUsers((list) => list.map((u) => (u.id === user.id ? user : u)));
    closeModal();
    toast.success("User updated");
  };

  const handleDelete = async (user) => {
    const ok = await confirm({
      title: "Delete user?",
      message: `"${user.username}" and all of their notes will be deleted.`,
      confirmText: "Delete user",
      danger: true,
    });
    if (!ok) return;
    try {
      await adminApi.remove(user.id);
      setUsers((list) => list.filter((u) => u.id !== user.id));
      toast.success("User deleted");
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleDeleteAll = async () => {
    const ok = await confirm({
      title: "Delete ALL users?",
      message: `All ${users.length} users and all of their notes will be deleted. Your admin account is not affected.`,
      confirmText: "Delete all users",
      danger: true,
    });
    if (!ok) return;
    try {
      const result = await adminApi.removeAll();
      setUsers([]);
      toast.success(result.message);
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  // "View user": load the freshest copy from the server before editing.
  const openEdit = async (user) => {
    try {
      setModal({ type: "edit", user: await adminApi.get(user.id) });
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  if (error) return <div className="alert alert--error">{error}</div>;
  if (users === null) return <div className="splash"><span className="spinner" /> Loading users…</div>;

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Users</h1>
          <p className="muted">{users.length === 1 ? "1 member" : `${users.length} members`}</p>
        </div>
        <div className="page-head__actions">
          <button className="btn btn--danger-outline" onClick={handleDeleteAll} disabled={users.length === 0}>
            Delete all users
          </button>
          <button className="btn btn--primary" onClick={() => setModal({ type: "create" })}>
            + Add user
          </button>
        </div>
      </div>

      {users.length === 0 ? (
        <div className="empty">
          <div className="empty__icon" aria-hidden="true">👥</div>
          <h2>No members yet</h2>
          <p className="muted">Members can register themselves, or you can add one here.</p>
        </div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Joined</th>
                <th className="table__actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td><strong>{user.username}</strong></td>
                  <td>{user.email}</td>
                  <td>{formatDate(user.created_at)}</td>
                  <td className="table__actions">
                    <button className="btn btn--small" onClick={() => openEdit(user)} aria-label={`Edit ${user.username}`}>Edit</button>
                    <button className="btn btn--small" onClick={() => setModal({ type: "password", user })} aria-label={`Reset password for ${user.username}`}>Reset password</button>
                    <button className="btn btn--small btn--danger-outline" onClick={() => handleDelete(user)} aria-label={`Delete ${user.username}`}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modal?.type === "create" && <UserFormModal onClose={closeModal} onSaved={handleCreated} />}
      {modal?.type === "edit" && <UserFormModal user={modal.user} onClose={closeModal} onSaved={handleUpdated} />}
      {modal?.type === "password" && <PasswordModal user={modal.user} onClose={closeModal} />}
    </>
  );
}

/** Create (no `user` prop) or edit (with `user`) a member. */
function UserFormModal({ user, onClose, onSaved }) {
  const isEdit = Boolean(user);
  const [form, setForm] = useState({ username: user?.username ?? "", email: user?.email ?? "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (name) => (e) => setForm((f) => ({ ...f, [name]: e.target.value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const body = { username: form.username.trim(), email: form.email.trim() };
      const saved = isEdit ? await adminApi.update(user.id, body) : await adminApi.create({ ...body, password: form.password });
      onSaved(saved);
    } catch (err) {
      setError(getErrorMessage(err));
      setBusy(false);
    }
  };

  return (
    <Modal
      title={isEdit ? `Edit ${user.username}` : "Add user"}
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button type="submit" form="user-form" className="btn btn--primary" disabled={busy}>
            {busy ? "Saving…" : isEdit ? "Save changes" : "Create user"}
          </button>
        </>
      }
    >
      <form id="user-form" onSubmit={handleSubmit}>
        {error && <div className="alert alert--error" role="alert">{error}</div>}
        <Field label="Username" value={form.username} onChange={set("username")} required minLength={3} maxLength={50} pattern={USERNAME_PATTERN} title={USERNAME_HINT} autoFocus />
        <Field label="Email" type="email" value={form.email} onChange={set("email")} required />
        {!isEdit && <Field label="Password" type="password" value={form.password} onChange={set("password")} required minLength={8} maxLength={72} hint="At least 8 characters" autoComplete="new-password" />}
      </form>
    </Modal>
  );
}

function PasswordModal({ user, onClose }) {
  const toast = useToast();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      await adminApi.resetPassword(user.id, password);
      toast.success(`Password reset for "${user.username}". They were logged out everywhere.`);
      onClose();
    } catch (err) {
      setError(getErrorMessage(err));
      setBusy(false);
    }
  };

  return (
    <Modal
      title={`Reset password for ${user.username}`}
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
          <button type="submit" form="password-form" className="btn btn--primary" disabled={busy}>
            {busy ? "Resetting…" : "Reset password"}
          </button>
        </>
      }
    >
      <form id="password-form" onSubmit={handleSubmit}>
        {error && <div className="alert alert--error" role="alert">{error}</div>}
        <p className="muted">The user will be logged out everywhere and must sign in with this new password.</p>
        <Field label="New password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} maxLength={72} hint="At least 8 characters" autoFocus autoComplete="new-password" />
      </form>
    </Modal>
  );
}
