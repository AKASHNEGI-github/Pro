import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { MarkdownEditor } from "react-markdown-studio";
import { notesApi } from "../api/services";
import { useConfirm } from "../context/ConfirmContext";
import { useToast } from "../context/ToastContext";
import { DEFAULT_NOTE_COLOR, NOTE_COLORS, getErrorMessage } from "../utils/format";

/** Create (/notes/new) and edit (/notes/:id) share this page. */
export default function NoteEditor() {
  const { id } = useParams();
  const isNew = id === undefined;
  const navigate = useNavigate();
  const confirm = useConfirm();
  const toast = useToast();

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [color, setColor] = useState(DEFAULT_NOTE_COLOR);
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const saved = useRef({ title: "", content: "", color: DEFAULT_NOTE_COLOR }); // last saved/loaded values

  // Editing: load the note first.
  useEffect(() => {
    if (isNew) return;
    let ignore = false;
    notesApi
      .get(id)
      .then((note) => {
        if (ignore) return;
        saved.current = { title: note.title, content: note.content, color: note.color };
        setTitle(note.title);
        setContent(note.content);
        setColor(note.color);
        setLoading(false);
      })
      .catch((err) => {
        if (ignore) return;
        toast.error(getErrorMessage(err, "Note not found"));
        navigate("/", { replace: true });
      });
    return () => {
      ignore = true;
    };
  }, [id, isNew, navigate, toast]);

  const dirty = title !== saved.current.title || content !== saved.current.content || color !== saved.current.color;
  const canSave = title.trim().length > 0 && !saving;

  const save = useCallback(async () => {
    if (!title.trim() || saving) return;
    setSaving(true);
    try {
      const body = { title: title.trim(), content, color };
      if (isNew) await notesApi.create(body);
      else await notesApi.update(id, body);
      toast.success(isNew ? "Note created" : "Note saved");
      saved.current = { title: body.title, content, color }; // not "dirty" any more
      navigate("/");
    } catch (err) {
      toast.error(getErrorMessage(err));
      setSaving(false);
    }
  }, [title, content, color, saving, isNew, id, navigate, toast]);

  // Ctrl+S / Cmd+S saves.
  useEffect(() => {
    const onKey = (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
        event.preventDefault();
        save();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [save]);

  const handleCancel = async () => {
    if (dirty) {
      const discard = await confirm({
        title: "Discard changes?",
        message: "You have unsaved changes that will be lost.",
        confirmText: "Discard",
        danger: true,
      });
      if (!discard) return;
    }
    navigate("/");
  };

  const handleDelete = async () => {
    const ok = await confirm({ title: "Delete note?", message: `"${title}" will be deleted.`, confirmText: "Delete", danger: true });
    if (!ok) return;
    try {
      await notesApi.remove(id);
      toast.success("Note deleted");
      navigate("/");
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  if (loading) return <div className="splash"><span className="spinner" /> Loading note…</div>;

  return (
    <>
      <div className="page-head">
        <h1>{isNew ? "New note" : "Edit note"}</h1>
        <div className="page-head__actions">
          {!isNew && (
            <button className="btn btn--danger-outline" onClick={handleDelete}>
              Delete
            </button>
          )}
          <button className="btn" onClick={handleCancel}>
            Cancel
          </button>
          <button className="btn btn--primary" onClick={save} disabled={!canSave}>
            {saving ? "Saving…" : "Save"}
          </button>
        </div>
      </div>

      <div className="editor-sheet">
        <div className="editor-sheet__top" style={{ background: color }}>
          <input
            className="editor-sheet__title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Note title"
            maxLength={255}
            aria-label="Note title"
            autoFocus={isNew}
          />
          <div className="swatches" role="radiogroup" aria-label="Note color">
            {NOTE_COLORS.map((c) => (
              <button
                key={c.value}
                type="button"
                role="radio"
                aria-checked={color.toLowerCase() === c.value.toLowerCase()}
                aria-label={c.name}
                title={c.name}
                className={`swatch${color.toLowerCase() === c.value.toLowerCase() ? " swatch--active" : ""}`}
                style={{ background: c.value }}
                onClick={() => setColor(c.value)}
              />
            ))}
          </div>
        </div>

        <MarkdownEditor
          value={content}
          onChange={setContent}
          theme="light"
          height="62vh"
          minHeight="380px"
          placeholder="Write your note in Markdown…"
          className="note-editor-md"
        />
      </div>
    </>
  );
}
