import { useState } from "react";
import Field from "../components/Field";
import { meApi } from "../api/services";
import { useAuth } from "../context/AuthContext";
import { useConfirm } from "../context/ConfirmContext";
import { useToast } from "../context/ToastContext";
import { USERNAME_HINT, USERNAME_PATTERN, formatDate, getErrorMessage } from "../utils/format";

export default function Profile() {
  const { user } = useAuth();
  const isAdmin = user.role === "ADMIN";

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Profile</h1>
          <p className="muted">Member since {formatDate(user.created_at)}</p>
        </div>
      </div>

      {isAdmin ? (
        <section className="card">
          <h2>Account</h2>
          <dl className="details">
            <dt>Username</dt><dd>{user.username}</dd>
            <dt>Email</dt><dd>{user.email}</dd>
            <dt>Role</dt><dd><span className="badge badge--admin">ADMIN</span></dd>
          </dl>
          <div className="alert alert--info">
            The admin account is managed from the backend <code>.env</code> file, so it cannot be edited, deleted, or have its
            password changed here.
          </div>
        </section>
      ) : (
        <div className="stack">
          <AccountCard />
          <PasswordCard />
          <DangerCard />
        </div>
      )}
    </>
  );
}

function AccountCard() {
  const { user, setUser } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ username: user.username, email: user.email });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const changed = form.username.trim() !== user.username || form.email.trim().toLowerCase() !== user.email;

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const updated = await meApi.update({ username: form.username.trim(), email: form.email.trim() });
      setUser(updated);
      setForm({ username: updated.username, email: updated.email });
      toast.success("Profile updated");
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="card" onSubmit={handleSubmit}>
      <h2>Account details</h2>
      {error && <div className="alert alert--error" role="alert">{error}</div>}
      <Field label="Username" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} required minLength={3} maxLength={50} pattern={USERNAME_PATTERN} title={USERNAME_HINT} />
      <Field label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
      <button className="btn btn--primary" disabled={!changed || busy}>
        {busy ? "Saving…" : "Save changes"}
      </button>
    </form>
  );
}

function PasswordCard() {
  const { clearSession } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ old: "", next: "", confirm: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (name) => (e) => setForm((f) => ({ ...f, [name]: e.target.value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    if (form.next !== form.confirm) return setError("New passwords do not match.");
    setBusy(true);
    try {
      await meApi.changePassword(form.old, form.next);
      toast.success("Password changed. Please log in with your new password.");
      clearSession(); // the server revoked every session -> we go back to the login page
    } catch (err) {
      setError(getErrorMessage(err));
      setBusy(false);
    }
  };

  return (
    <form className="card" onSubmit={handleSubmit}>
      <h2>Change password</h2>
      <p className="muted">You will be logged out after changing it.</p>
      {error && <div className="alert alert--error" role="alert">{error}</div>}
      <Field label="Current password" type="password" value={form.old} onChange={set("old")} required autoComplete="current-password" />
      <Field label="New password" type="password" value={form.next} onChange={set("next")} required minLength={8} maxLength={72} hint="At least 8 characters" autoComplete="new-password" />
      <Field label="Confirm new password" type="password" value={form.confirm} onChange={set("confirm")} required autoComplete="new-password" />
      <button className="btn btn--primary" disabled={busy}>
        {busy ? "Changing…" : "Change password"}
      </button>
    </form>
  );
}

function DangerCard() {
  const { clearSession } = useAuth();
  const confirm = useConfirm();
  const toast = useToast();

  const handleDelete = async () => {
    const ok = await confirm({
      title: "Delete your account?",
      message: "Your account and all of your notes will be deleted. You will be logged out immediately.",
      confirmText: "Delete my account",
      danger: true,
    });
    if (!ok) return;
    try {
      await meApi.remove();
      toast.success("Your account was deleted.");
      clearSession();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  return (
    <section className="card card--danger">
      <h2>Delete account</h2>
      <p className="muted">This removes your account and all your notes.</p>
      <button className="btn btn--danger" onClick={handleDelete}>
        Delete my account
      </button>
    </section>
  );
}
