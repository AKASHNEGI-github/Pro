import { Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import { PublicOnly, RequireAuth } from "./components/RouteGuards";
import AdminUsers from "./pages/AdminUsers";
import Login from "./pages/Login";
import NoteEditor from "./pages/NoteEditor";
import NotFound from "./pages/NotFound";
import Notes from "./pages/Notes";
import Profile from "./pages/Profile";
import Register from "./pages/Register";

export default function App() {
  return (
    <Routes>
      {/* only for logged-out visitors */}
      <Route element={<PublicOnly />}>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Route>

      {/* only for logged-in users (admin AND member) */}
      <Route element={<RequireAuth />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Notes />} />
          <Route path="/notes/new" element={<NoteEditor />} />
          <Route path="/notes/:id" element={<NoteEditor />} />
          <Route path="/profile" element={<Profile />} />

          {/* admin only */}
          <Route element={<RequireAuth role="ADMIN" />}>
            <Route path="/admin/users" element={<AdminUsers />} />
          </Route>
        </Route>
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
