import { useEffect, useLayoutEffect, useState, type RefObject } from "react";

const useIsomorphicLayoutEffect = typeof window !== "undefined" ? useLayoutEffect : useEffect;

/** Above this many lines we skip measuring (it is O(lines) per edit) and the gutter falls back to one row per line. */
const MAX_MEASURED_LINES = 50_000;

/**
 * Builds a hidden copy of the textarea's text, one block per logical line, with the same width, font and wrapping
 * rules, and reads back how tall each block is. A line that wraps onto three rows measures three rows tall.
 * Returns null when the browser cannot lay anything out (for example jsdom or a hidden element), so callers can
 * fall back instead of collapsing every row to zero height.
 */
function measureLineHeights(textarea: HTMLTextAreaElement, lines: string[]): number[] | null {
  const style = getComputedStyle(textarea);
  const mirror = document.createElement("div");
  mirror.setAttribute("aria-hidden", "true");
  Object.assign(mirror.style, {
    position: "absolute",
    visibility: "hidden",
    pointerEvents: "none",
    top: "0",
    left: "-99999px",
    boxSizing: "border-box",
    border: "0",
    // clientWidth excludes borders and the scrollbar, exactly the space the text wraps in.
    width: `${textarea.clientWidth}px`,
    padding: `0 ${style.paddingRight} 0 ${style.paddingLeft}`,
    whiteSpace: "pre-wrap",
    overflowWrap: "break-word",
    wordBreak: style.wordBreak,
    fontFamily: style.fontFamily,
    fontSize: style.fontSize,
    fontWeight: style.fontWeight,
    fontStyle: style.fontStyle,
    letterSpacing: style.letterSpacing,
    lineHeight: style.lineHeight,
    tabSize: style.tabSize,
  });

  const fragment = document.createDocumentFragment();
  for (const line of lines) {
    const row = document.createElement("div");
    // A zero-width space gives empty lines their natural one-row height.
    row.textContent = line === "" ? "\u200b" : line;
    fragment.appendChild(row);
  }
  mirror.appendChild(fragment);
  document.body.appendChild(mirror);
  const heights = Array.from(mirror.children, (row) => row.getBoundingClientRect().height);
  mirror.remove();

  return heights.every((h) => h > 0) ? heights : null;
}

const sameHeights = (a: number[] | null, b: number[] | null): boolean =>
  a === b || (a !== null && b !== null && a.length === b.length && a.every((h, i) => h === b[i]));

/**
 * Pixel height of every logical line of a soft-wrapping textarea, so a line-number gutter can keep each number
 * beside the FIRST row of its line even when the line wraps onto several rows.
 *
 * Measured before the browser paints, so numbers never flash out of place. Re-measured when the text changes,
 * when the textarea is resized (including fullscreen), and when web fonts finish loading. Returns null while
 * disabled, on the server, when too many lines to measure cheaply, or when layout is unavailable.
 */
export function useWrappedLineHeights(
  textareaRef: RefObject<HTMLTextAreaElement>,
  value: string,
  enabled: boolean,
): number[] | null {
  const [heights, setHeights] = useState<number[] | null>(null);

  useIsomorphicLayoutEffect(() => {
    const textarea = textareaRef.current;
    if (!enabled || !textarea) {
      setHeights((prev) => (prev === null ? prev : null));
      return;
    }
    const lines = value.split("\n");
    if (lines.length > MAX_MEASURED_LINES) {
      setHeights((prev) => (prev === null ? prev : null));
      return;
    }

    let frame = 0;
    let measuredWidth = -1;
    const measure = () => {
      measuredWidth = textarea.clientWidth;
      const next = measureLineHeights(textarea, lines);
      setHeights((prev) => (sameHeights(prev, next) ? prev : next));
      // A vertical scrollbar appearing (or going away) changes the width the text wraps in, which this pass could
      // not know about. If the width moved, measure once more. It cannot oscillate: a narrower width never
      // produces fewer lines, so the scrollbar state settles after one extra pass.
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        if (textarea.clientWidth !== measuredWidth) measure();
      });
    };

    measure();
    const observer = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    observer?.observe(textarea);
    // Web fonts change glyph widths, so wrap points move when they finish loading.
    void document.fonts?.ready.then(measure);

    return () => {
      cancelAnimationFrame(frame);
      observer?.disconnect();
    };
  }, [textareaRef, value, enabled]);

  return heights;
}
