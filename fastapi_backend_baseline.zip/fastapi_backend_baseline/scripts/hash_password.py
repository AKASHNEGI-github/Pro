"""Generate the bcrypt hash for SUPER_ADMIN_PASSWORD_HASH.

    python scripts/hash_password.py              # asks for the password (input is hidden)
    python scripts/hash_password.py --rounds 13  # slower = harder to brute-force (default 12)

Nothing is stored or sent anywhere: the hash is only printed.

To rotate the super admin password:
  1. run this script and copy the printed line
  2. put it in your .env (or in your secret manager / deployment environment)
  3. restart the application
Every existing super admin session is then invalidated automatically.
"""

import argparse
import getpass
import sys
from pathlib import Path

# Make `app` importable when this file is run directly (python scripts/hash_password.py).
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import bcrypt  # noqa: E402

from app.utils.passwords import password_problems  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a bcrypt hash for the super admin password.")
    parser.add_argument("--rounds", type=int, default=12, choices=range(10, 16), metavar="10-15")
    rounds = parser.parse_args().rounds

    password = getpass.getpass("New super admin password: ")
    problems = password_problems(password)
    if problems:
        print("\nThat password is too weak. It " + "; ".join(problems) + ".", file=sys.stderr)
        return 1
    if getpass.getpass("Repeat the password:        ") != password:
        print("\nThe two entries do not match.", file=sys.stderr)
        return 1

    hashed = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=rounds)).decode("ascii")
    print("\nPut this line in your .env file (the single quotes are important: the hash contains '$'):\n")
    print(f"SUPER_ADMIN_PASSWORD_HASH='{hashed}'")
    print("\nIn a secret manager or an `environment:` entry, use the bare value (without the quotes).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
