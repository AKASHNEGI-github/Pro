"""Delete expired refresh and password-reset tokens once, then exit.

    python scripts/cleanup_tokens.py

The application already does this every hour on its own. This script is for running it
on demand or from an external scheduler (cron, a Kubernetes CronJob, ...), for example
when you prefer to switch the in-app task off in your deployment.
"""

import asyncio
import sys
from pathlib import Path

# Make `app` importable when this file is run directly.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.database import db  # noqa: E402
from app.core.logger import configure_logging  # noqa: E402
from app.modules.system.service import cleanup_expired_tokens  # noqa: E402


async def main() -> None:
    configure_logging()
    await db.connect()
    try:
        deleted = await cleanup_expired_tokens()
        print(f"Deleted: {deleted}")
    finally:
        await db.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
