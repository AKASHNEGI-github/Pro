"""Password policy and temporary-password generation.

Policy (enforced when a user CHOOSES a password: sign-up, change, reset):

  * 8 to 64 characters (and at most 72 bytes in UTF-8: bcrypt's own limit)
  * at least one uppercase letter, one lowercase letter, one digit and one
    special character (any character that is not a letter or a digit)

Login forms do NOT apply the policy; they only check the credentials.
"""

import secrets

from app.core.constants import (
    BCRYPT_MAX_BYTES,
    PASSWORD_MAX_LENGTH,
    PASSWORD_MIN_LENGTH,
    TEMPORARY_PASSWORD_LENGTH,
)

# Temporary passwords avoid look-alike characters (0/O, 1/l/I) because an admin
# may have to read them out to the user.
_LOWER = "abcdefghijkmnopqrstuvwxyz"
_UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ"
_DIGITS = "23456789"
_SPECIAL = "!@#$%^&*-_=+?"


def password_problems(password: str) -> list[str]:
    """Return what is wrong with `password` (an empty list means it is fine)."""
    problems: list[str] = []
    if not PASSWORD_MIN_LENGTH <= len(password) <= PASSWORD_MAX_LENGTH:
        problems.append(f"must be {PASSWORD_MIN_LENGTH} to {PASSWORD_MAX_LENGTH} characters long")
    elif len(password.encode("utf-8")) > BCRYPT_MAX_BYTES:
        problems.append(f"must not be longer than {BCRYPT_MAX_BYTES} bytes")
    if not any(char.isupper() for char in password):
        problems.append("must contain an uppercase letter")
    if not any(char.islower() for char in password):
        problems.append("must contain a lowercase letter")
    if not any(char.isdigit() for char in password):
        problems.append("must contain a digit")
    if all(char.isalnum() for char in password):
        problems.append("must contain a special character")
    return problems


def validate_password_policy(password: str) -> str:
    """Pydantic-friendly validator: returns the password or raises ValueError."""
    problems = password_problems(password)
    if problems:
        raise ValueError("Password " + "; ".join(problems))
    return password


def generate_temporary_password(length: int = TEMPORARY_PASSWORD_LENGTH) -> str:
    """Random password that satisfies the policy (shown once to an admin)."""
    required = [
        secrets.choice(_LOWER),
        secrets.choice(_UPPER),
        secrets.choice(_DIGITS),
        secrets.choice(_SPECIAL),
    ]
    alphabet = _LOWER + _UPPER + _DIGITS + _SPECIAL
    rest = [secrets.choice(alphabet) for _ in range(length - len(required))]
    characters = required + rest
    secrets.SystemRandom().shuffle(characters)
    return "".join(characters)

