"""Building blocks shared by every module's `schemas.py`.

  * `RequestModel`   base class for request bodies
  * `ResponseModel`  base class for response data
  * reusable field types (`NormalizedEmail`, `FullName`, `Password`, ...)
  * the envelope models (`SuccessResponse`, `FailureResponse`) which exist so
    Swagger shows the real response shape; the actual bodies are produced by
    `utils/response.py` and `errors/handlers.py`.

JSON uses camelCase (`fullName`), Python uses snake_case (`full_name`). The
conversion is automatic through `alias_generator`.
"""

from datetime import datetime
from typing import Annotated, Any, Generic, TypeVar

from pydantic import (
    AfterValidator,
    BaseModel,
    BeforeValidator,
    ConfigDict,
    EmailStr,
    StringConstraints,
)
from pydantic.alias_generators import to_camel

from app.utils.clock import as_utc
from app.utils.passwords import validate_password_policy

T = TypeVar("T")


class RequestModel(BaseModel):
    """Request bodies: camelCase keys only, and unknown fields are rejected (422)."""

    model_config = ConfigDict(alias_generator=to_camel, extra="forbid")


class ResponseModel(BaseModel):
    """Response data: camelCase output. Can be built from a database row (snake_case keys)."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,
        validate_by_alias=True,
        serialize_by_alias=True,
    )


# ---------------------------------------------------------------------------
# Reusable field types
# ---------------------------------------------------------------------------
def _normalize_email(value: Any) -> Any:
    """E-mails are compared case-insensitively, so always store them trimmed + lower-case."""
    return value.strip().lower() if isinstance(value, str) else value


def _check_email_length(value: str) -> str:
    if len(value) > 150:  # users.email is VARCHAR(150)
        raise ValueError("E-mail address is too long (maximum 150 characters)")
    return value


NormalizedEmail = Annotated[
    EmailStr,
    BeforeValidator(_normalize_email),
    AfterValidator(_check_email_length),
]

FullName = Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=100)]

# A password a user CHOOSES (sign-up / change / reset): the policy is enforced.
Password = Annotated[str, AfterValidator(validate_password_policy)]

# A password a user TYPES to prove who they are: only a sanity length limit.
ExistingPassword = Annotated[str, StringConstraints(min_length=1, max_length=128)]

# Datetimes coming from MySQL are naive UTC; this prints them as `...Z`.
UtcDatetime = Annotated[datetime, AfterValidator(as_utc)]


# ---------------------------------------------------------------------------
# Response envelope (documentation models)
# ---------------------------------------------------------------------------
class PageMeta(ResponseModel):
    page: int
    limit: int
    total: int
    total_pages: int


class SuccessResponse(ResponseModel, Generic[T]):
    success: bool = True
    message: str
    data: T | None = None
    meta: PageMeta | None = None
    request_id: str


class ErrorBody(ResponseModel):
    code: str
    details: list[dict[str, Any]] | None = None


class FailureResponse(ResponseModel):
    success: bool = False
    message: str
    error: ErrorBody
    request_id: str
