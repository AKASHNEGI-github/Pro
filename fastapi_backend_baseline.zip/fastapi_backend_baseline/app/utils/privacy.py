"""Small helpers that keep personal data out of the logs."""


def mask_email(email: str) -> str:
    """`jane.doe@example.com` -> `j***@example.com`."""
    local, separator, domain = email.partition("@")
    if not separator:
        return "***"
    return f"{local[:1]}***@{domain}"
