"""Standard success response.

There are exactly two response shapes in the whole API. This file produces the
success one; the failure one is produced only by `errors/handlers.py`.

    {
      "success": true,
      "message": "Users fetched successfully",
      "data": ...,                  # null when there is nothing to return
      "meta": {"page": 1, ...},     # only on paginated lists
      "requestId": "b1c2d3e4-..."
    }

Convention for `data`:
  * a single resource  -> the object itself
  * a list             -> an array (together with `meta` when paginated)
  * several things     -> a named object, e.g. {"user": ..., "temporaryPassword": ...}

Usage in a router:

    return send_success(user, "Profile fetched successfully")
    return send_created(user, "Account created successfully")
"""

import math
from typing import Any

from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse

from app.core.constants import REQUEST_ID_HEADER
from app.core.context import get_request_id
from app.utils.schemas import PageMeta


def build_page_meta(*, page: int, limit: int, total: int) -> PageMeta:
    return PageMeta(page=page, limit=limit, total=total, total_pages=math.ceil(total / limit))


def send_success(
    data: Any = None,
    message: str = "Success",
    *,
    meta: PageMeta | None = None,
    status_code: int = 200,
) -> JSONResponse:
    request_id = get_request_id()
    body: dict[str, Any] = {"success": True, "message": message, "data": data}
    if meta is not None:
        body["meta"] = meta
    body["requestId"] = request_id
    return JSONResponse(
        status_code=status_code,
        content=jsonable_encoder(body),
        headers={REQUEST_ID_HEADER: request_id} if request_id else None,
    )


def send_created(
    data: Any = None,
    message: str = "Created successfully",
    *,
    meta: PageMeta | None = None,
) -> JSONResponse:
    return send_success(data, message, meta=meta, status_code=201)
