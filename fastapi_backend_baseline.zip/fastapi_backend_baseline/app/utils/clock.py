"""Time helpers.

Everything is UTC. The application clock is the single source of time: every
timestamp that is written to the database, compared with another timestamp, or
compared with a JWT `iat` claim is produced here (not by MySQL), so they can
never disagree because of clock drift between the app and the database server.

MySQL DATETIME columns have no timezone, so values going in and coming out are
"naive" datetimes that always mean UTC.
"""

from datetime import UTC, datetime


def utcnow() -> datetime:
    """Current UTC time as a naive datetime (the form MySQL DATETIME(6) uses)."""
    return datetime.now(UTC).replace(tzinfo=None)


def to_epoch_seconds(value: datetime) -> float:
    """Unix timestamp of a naive-UTC datetime read from MySQL."""
    return value.replace(tzinfo=UTC).timestamp()


def as_utc(value: datetime) -> datetime:
    """Attach the UTC timezone (used for API output, which prints a trailing `Z`)."""
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)
