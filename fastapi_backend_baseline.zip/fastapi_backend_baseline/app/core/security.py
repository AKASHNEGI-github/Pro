"""Everything cryptographic lives here, so it can be reviewed in one place.

  * Passwords          bcrypt (slow on purpose, salted, cost from BCRYPT_ROUNDS)
  * Security answers   normalise -> HMAC with a secret pepper -> bcrypt
  * Refresh / reset tokens   random opaque strings, stored only as SHA-256
  * Access tokens      short-lived signed JWTs (they carry NO role, see below)
  * Super admin        a fingerprint of its password hash is placed in its JWT, so
                       rotating the password in ENV instantly invalidates old tokens

bcrypt is CPU heavy (~250 ms). Every call runs in a worker thread, so the event
loop keeps serving other requests meanwhile.
"""

import asyncio
import hashlib
import hmac
import secrets
import unicodedata
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any

import bcrypt
import jwt

from app.core.config import settings
from app.core.constants import JWT_CLOCK_LEEWAY_SECONDS, SUPER_ADMIN_USER_ID
from app.errors.exceptions import UnauthorizedError
from app.utils.clock import to_epoch_seconds, utcnow

# ---------------------------------------------------------------------------
# bcrypt
# ---------------------------------------------------------------------------


def _hash_sync(secret: bytes) -> str:
    return bcrypt.hashpw(secret, bcrypt.gensalt(rounds=settings.BCRYPT_ROUNDS)).decode("ascii")


def _verify_sync(secret: bytes, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(secret, hashed.encode("ascii"))
    except ValueError:  # malformed hash, or a secret longer than bcrypt's 72 bytes
        return False


async def hash_password(password: str) -> str:
    return await asyncio.to_thread(_hash_sync, password.encode("utf-8"))


async def verify_password(password: str, hashed: str) -> bool:
    return await asyncio.to_thread(_verify_sync, password.encode("utf-8"), hashed)


# Used to make "unknown account" take as long as "wrong password" (see below).
_dummy_hash: str | None = None


async def prepare_security() -> None:
    """Called once at start-up: pre-compute a throw-away hash with the configured cost."""
    global _dummy_hash
    _dummy_hash = await hash_password("timing-equalisation-password")


async def burn_verification_time(count: int = 1) -> None:
    """Spend the time of `count` real password checks.

    When an e-mail does not exist we still do the same amount of bcrypt work as
    for a real account, so response time does not reveal which e-mails exist.
    """
    if _dummy_hash is None:
        return
    await asyncio.gather(*(verify_password("not-the-password", _dummy_hash) for _ in range(count)))


# ---------------------------------------------------------------------------
# Security answers (password recovery)
# ---------------------------------------------------------------------------


def normalize_answer(answer: str) -> str:
    """Make equivalent answers identical: `' Lahore  '`, `'LAHORE'`, `'lahore'` -> `'lahore'`."""
    folded = unicodedata.normalize("NFKC", answer).casefold()
    return " ".join(folded.split())


def _peppered(field: str, normalized_answer: str) -> bytes:
    """HMAC-SHA256(pepper, "<field>:<answer>") as 64 hex bytes (fits bcrypt's 72-byte limit).

    The field name is part of the message, so a hash made for one question can
    never be copied into another question's column and still verify.
    """
    digest = hmac.new(
        settings.SECURITY_ANSWER_PEPPER.encode("utf-8"),
        f"{field}:{normalized_answer}".encode(),
        hashlib.sha256,
    ).hexdigest()
    return digest.encode("ascii")


async def hash_security_answer(field: str, answer: str) -> str:
    return await asyncio.to_thread(_hash_sync, _peppered(field, normalize_answer(answer)))


async def verify_security_answer(field: str, answer: str, stored_hash: str) -> bool:
    return await asyncio.to_thread(_verify_sync, _peppered(field, normalize_answer(answer)), stored_hash)


# ---------------------------------------------------------------------------
# Opaque tokens (refresh tokens, password-reset tokens)
# ---------------------------------------------------------------------------


def hash_token(raw_token: str) -> str:
    """SHA-256 hex digest. Enough for random 384-bit tokens (no salt or slow hash needed)."""
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()


def generate_opaque_token() -> tuple[str, str]:
    """Return `(raw_token, token_hash)`. Give the raw token to the client, store only the hash."""
    raw_token = secrets.token_urlsafe(48)
    return raw_token, hash_token(raw_token)


# ---------------------------------------------------------------------------
# Access tokens (JWT)
# ---------------------------------------------------------------------------
# The token deliberately contains NO role. `authenticate` re-reads the user from
# the database on every request, so a role change, deactivation or deletion
# takes effect on the very next request instead of when the token expires.


@dataclass(frozen=True)
class AccessToken:
    token: str
    expires_in: int  # seconds


def super_admin_fingerprint() -> str:
    """Short, non-reversible fingerprint of the super admin's CURRENT password hash.

    It is stored in the super admin's JWT (claim `pwf`). Change the password in
    ENV and the fingerprint changes, so every older super admin token stops working.
    """
    return hmac.new(
        settings.JWT_SECRET.encode("utf-8"),
        settings.SUPER_ADMIN_PASSWORD_HASH.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()[:16]


def create_access_token(user_id: int, *, issued_at: datetime | None = None) -> AccessToken:
    """Sign a JWT for `user_id`.

    `issued_at` should be the same instant that was written to the database in
    the same operation (e.g. a password change), see `authenticate` for why.
    """
    issued = int(to_epoch_seconds(issued_at or utcnow()))
    lifetime = settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    claims: dict[str, Any] = {
        "sub": str(user_id),
        "iat": issued,
        "exp": issued + lifetime,
        "iss": settings.JWT_ISSUER,
        "jti": uuid.uuid4().hex,
    }
    if user_id == SUPER_ADMIN_USER_ID:
        claims["pwf"] = super_admin_fingerprint()
    token = jwt.encode(claims, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)
    return AccessToken(token=token, expires_in=lifetime)


def decode_access_token(token: str) -> dict[str, Any]:
    """Verify signature, issuer and expiry. Raises 401 TOKEN_EXPIRED / TOKEN_INVALID."""
    try:
        claims = jwt.decode(
            token,
            settings.JWT_SECRET,
            algorithms=[settings.JWT_ALGORITHM],
            issuer=settings.JWT_ISSUER,
            leeway=JWT_CLOCK_LEEWAY_SECONDS,
            options={"require": ["exp", "iat", "sub", "iss"]},
        )
    except jwt.ExpiredSignatureError as exc:
        raise UnauthorizedError("The access token has expired.", code="TOKEN_EXPIRED", cause=exc) from exc
    except jwt.PyJWTError as exc:
        raise UnauthorizedError("The access token is invalid.", code="TOKEN_INVALID", cause=exc) from exc

    if not str(claims["sub"]).isdigit() or not isinstance(claims["iat"], int):
        raise UnauthorizedError("The access token is invalid.", code="TOKEN_INVALID")
    return claims
