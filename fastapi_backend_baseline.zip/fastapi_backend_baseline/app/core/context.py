"""Request context store.

Every HTTP request gets one `RequestContext` object (request id, client IP,
user agent, ... and later the authenticated user). It is kept in a
`ContextVar`, which means:

  * any code that runs while the request is being handled (routers, services,
    the logger, the error handler) can read it WITHOUT it being passed around
    as a function argument;
  * concurrent requests never see each other's data (each asyncio task has its
    own copy of the context).

The context is created by `RequestContextMiddleware` at the very start of the
request and cleared at the very end. Outside of a request (start-up code,
scripts) there is no context and the getters return `None`.
"""

from contextvars import ContextVar, Token
from dataclasses import dataclass


@dataclass
class RequestContext:
    request_id: str
    method: str
    path: str
    client_ip: str | None = None
    user_agent: str | None = None
    # Filled in later, by `authenticate`, once the caller is known:
    user_id: int | None = None
    role: str | None = None
    # Filled in by the error handler so the access log can show it:
    error_code: str | None = None


_request_context: ContextVar[RequestContext | None] = ContextVar("request_context", default=None)


def start_request_context(context: RequestContext) -> Token:
    """Store `context` for the current request. Keep the token for `end_request_context`."""
    return _request_context.set(context)


def end_request_context(token: Token) -> None:
    _request_context.reset(token)


def get_request_context() -> RequestContext | None:
    return _request_context.get()


def get_request_id() -> str | None:
    context = _request_context.get()
    return context.request_id if context else None


def get_client_ip() -> str | None:
    context = _request_context.get()
    return context.client_ip if context else None


def get_user_agent() -> str | None:
    context = _request_context.get()
    return context.user_agent if context else None


def get_user_id() -> int | None:
    context = _request_context.get()
    return context.user_id if context else None


def set_current_user(user_id: int, role: str) -> None:
    """Remember who is calling, so every later log line carries the user id."""
    context = _request_context.get()
    if context is not None:
        context.user_id = user_id
        context.role = role


def set_error_code(code: str) -> None:
    context = _request_context.get()
    if context is not None:
        context.error_code = code
