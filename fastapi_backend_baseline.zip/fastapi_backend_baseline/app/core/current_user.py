"""The authenticated caller, as seen by routers and services."""

from dataclasses import dataclass

from app.core.constants import SUPER_ADMIN_USER_ID


@dataclass(frozen=True, slots=True)
class CurrentUser:
    user_id: int
    full_name: str
    email: str
    role: str  # "super_admin" | "admin" | "member"
    role_level: int  # 1000 | roles.role_level (admin 2, member 1)
    is_active: bool
    must_change_password: bool

    @property
    def is_super_admin(self) -> bool:
        return self.user_id == SUPER_ADMIN_USER_ID
