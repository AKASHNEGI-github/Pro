"""Structured logging.

Standard-library `logging` only, configured once at start-up. Every log line
automatically carries the `requestId` and `userId` of the request that produced
it (read from the request context store), so all the lines of one request can be
found with a single search.

How to log in a module:

    from app.core.logger import get_logger
    logger = get_logger(__name__)

    logger.info("User created", extra={"data": {"userId": 5}})
    logger.warning("Something odd")
    logger.error("Failed", exc_info=exc)

Extra structured fields always go inside `extra={"data": {...}}`.
NEVER log passwords, tokens, security answers or password hashes. As a safety
net, values stored under keys that look sensitive are replaced by "[REDACTED]".
"""

import json
import logging
import sys
from datetime import UTC, datetime
from typing import Any

from app.core.config import settings
from app.core.context import get_request_id, get_user_id

_SENSITIVE_KEY_PARTS = ("password", "token", "secret", "answer", "hash", "authorization", "cookie")
_REDACTED = "[REDACTED]"


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def _redact(value: Any) -> Any:
    """Return a copy of `value` with sensitive-looking dict entries masked.

    Only non-numeric values are masked: a count such as "revokedTokens": 3 is not a secret.
    """
    if isinstance(value, dict):
        return {
            key: _REDACTED
            if any(part in str(key).lower() for part in _SENSITIVE_KEY_PARTS)
            and not isinstance(item, (int, float, bool, type(None)))
            else _redact(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_redact(item) for item in value]
    return value


class RequestContextFilter(logging.Filter):
    """Copies request id / user id from the context store onto every record."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = get_request_id()
        record.user_id = get_user_id()
        return True


class JsonFormatter(logging.Formatter):
    """One JSON object per line (easy to ship to ELK, Loki, CloudWatch, ...)."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, UTC).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "requestId": getattr(record, "request_id", None),
            "userId": getattr(record, "user_id", None),
        }
        data = getattr(record, "data", None)
        if data:
            payload["data"] = _redact(data)
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str, ensure_ascii=False)


class TextFormatter(logging.Formatter):
    """Human friendly single-line format for local development."""

    def format(self, record: logging.LogRecord) -> str:
        request_id = getattr(record, "request_id", None) or "-"
        user_id = getattr(record, "user_id", None)
        who = f" user={user_id}" if user_id else ""
        line = (
            f"{datetime.fromtimestamp(record.created).strftime('%H:%M:%S.%f')[:-3]} "
            f"{record.levelname:<7} [{request_id[:8]}{who}] {record.name}: {record.getMessage()}"
        )
        data = getattr(record, "data", None)
        if data:
            line += " " + json.dumps(_redact(data), default=str, ensure_ascii=False)
        if record.exc_info:
            line += "\n" + self.formatException(record.exc_info)
        return line


def configure_logging() -> None:
    """Install the handler on the root logger. Safe to call more than once."""
    handler = logging.StreamHandler(sys.stdout)
    handler.addFilter(RequestContextFilter())
    handler.setFormatter(JsonFormatter() if settings.LOG_FORMAT == "json" else TextFormatter())

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(settings.LOG_LEVEL)

    # Uvicorn installs its own handlers; route its records through ours instead.
    for name in ("uvicorn", "uvicorn.error"):
        uvicorn_logger = logging.getLogger(name)
        uvicorn_logger.handlers.clear()
        uvicorn_logger.propagate = True
    # We write our own access log (with request id, user id and duration).
    access_logger = logging.getLogger("uvicorn.access")
    access_logger.handlers.clear()
    access_logger.propagate = False
    access_logger.disabled = True
