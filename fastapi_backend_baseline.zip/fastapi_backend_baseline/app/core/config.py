"""Application settings.

All configuration comes from environment variables (a local `.env` file is
read automatically). Settings are validated once at start-up, so a missing or
malformed value stops the application immediately with a clear message,
instead of failing later in the middle of a request.

Usage anywhere in the code:

    from app.core.config import settings
    settings.DB_HOST
"""

import re
from functools import lru_cache
from typing import Literal

import bcrypt
from pydantic import EmailStr, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# A bcrypt hash looks like  $2b$12$<22 chars salt><31 chars hash>  (60 chars).
_BCRYPT_HASH_PATTERN = re.compile(r"^\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}$")

# This password is printed in the README and in `.env.example`, so it is public.
# Production refuses to start with it (see `_check_production_safety`).
_PUBLIC_EXAMPLE_SUPER_ADMIN_PASSWORD = b"SuperAdmin@12345"
_PLACEHOLDER_PREFIX = "change-me"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ------------------------------------------------------------------
    # Application
    # ------------------------------------------------------------------
    APP_NAME: str = "FastAPI Backend Baseline"
    APP_ENV: Literal["development", "production", "test"] = "development"
    LOG_LEVEL: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    LOG_FORMAT: Literal["json", "text"] = "json"
    SELF_REGISTRATION_ENABLED: bool = True

    # Comma separated list of allowed browser origins,
    # e.g. "http://localhost:3000,https://app.example.com".
    CORS_ORIGINS: str = ""

    # How many reverse proxies sit in front of the app (0 = none).
    # Only when > 0 is the X-Forwarded-For header used to find the client IP.
    TRUSTED_PROXY_COUNT: int = Field(default=0, ge=0, le=10)

    RATE_LIMIT_ENABLED: bool = True

    # ------------------------------------------------------------------
    # Database (MySQL 8)
    # ------------------------------------------------------------------
    DB_HOST: str = "127.0.0.1"
    DB_PORT: int = Field(default=3306, ge=1, le=65535)
    DB_USER: str
    DB_PASSWORD: str
    DB_NAME: str = "fastapi_backend_baseline"
    DB_POOL_MIN_SIZE: int = Field(default=1, ge=0, le=50)
    DB_POOL_MAX_SIZE: int = Field(default=10, ge=1, le=200)
    DB_POOL_RECYCLE_SECONDS: int = Field(default=1800, ge=30)
    DB_CONNECT_TIMEOUT_SECONDS: int = Field(default=10, ge=1, le=120)
    DB_POOL_ACQUIRE_TIMEOUT_SECONDS: int = Field(default=10, ge=1, le=120)

    # ------------------------------------------------------------------
    # Tokens
    # ------------------------------------------------------------------
    JWT_SECRET: str = Field(min_length=32)
    JWT_ALGORITHM: Literal["HS256", "HS384", "HS512"] = "HS256"
    JWT_ISSUER: str = "fastapi-backend-baseline"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=15, ge=1, le=120)
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(default=7, ge=1, le=90)

    # Refresh token cookie
    REFRESH_COOKIE_NAME: str = "refresh_token"
    REFRESH_COOKIE_SECURE: bool = False  # must be true in production (HTTPS)
    REFRESH_COOKIE_SAMESITE: Literal["lax", "strict", "none"] = "lax"
    REFRESH_COOKIE_DOMAIN: str | None = None

    # ------------------------------------------------------------------
    # Hashing
    # ------------------------------------------------------------------
    BCRYPT_ROUNDS: int = Field(default=12, ge=10, le=15)
    # Secret mixed (HMAC) into security answers BEFORE bcrypt, so a leaked
    # database alone cannot be brute-forced offline.
    SECURITY_ANSWER_PEPPER: str = Field(min_length=32)

    # ------------------------------------------------------------------
    # Super admin (credentials live ONLY here, never in the database)
    # ------------------------------------------------------------------
    SUPER_ADMIN_NAME: str = Field(default="Super Admin", min_length=2, max_length=100)
    SUPER_ADMIN_EMAIL: EmailStr
    SUPER_ADMIN_PASSWORD_HASH: str

    # ------------------------------------------------------------------
    # Validators
    # ------------------------------------------------------------------
    @field_validator("LOG_LEVEL", mode="before")
    @classmethod
    def _uppercase(cls, value: object) -> object:
        """Accept `info` as well as `INFO`."""
        return value.strip().upper() if isinstance(value, str) else value

    @field_validator("LOG_FORMAT", "REFRESH_COOKIE_SAMESITE", mode="before")
    @classmethod
    def _lowercase(cls, value: object) -> object:
        """Accept `Lax` as well as `lax`."""
        return value.strip().lower() if isinstance(value, str) else value

    @field_validator("REFRESH_COOKIE_DOMAIN", mode="before")
    @classmethod
    def _empty_means_unset(cls, value: object) -> object:
        """`REFRESH_COOKIE_DOMAIN=` (empty, as in .env.example) means "not set"."""
        if isinstance(value, str) and not value.strip():
            return None
        return value

    @field_validator("SUPER_ADMIN_EMAIL", mode="before")
    @classmethod
    def _lowercase_email(cls, value: object) -> object:
        return value.strip().lower() if isinstance(value, str) else value

    @field_validator("SUPER_ADMIN_PASSWORD_HASH")
    @classmethod
    def _check_bcrypt_hash(cls, value: str) -> str:
        if not _BCRYPT_HASH_PATTERN.match(value):
            raise ValueError(
                "must be a bcrypt hash such as $2b$12$... "
                "(generate one with: python scripts/hash_password.py). "
                "Tip: wrap it in single quotes in .env because it contains '$'."
            )
        return value

    @model_validator(mode="after")
    def _check_cookie_settings(self) -> "Settings":
        if self.REFRESH_COOKIE_SAMESITE == "none" and not self.REFRESH_COOKIE_SECURE:
            raise ValueError("REFRESH_COOKIE_SAMESITE=none requires REFRESH_COOKIE_SECURE=true")
        if self.DB_POOL_MIN_SIZE > self.DB_POOL_MAX_SIZE:
            raise ValueError("DB_POOL_MIN_SIZE must not be greater than DB_POOL_MAX_SIZE")
        return self

    @model_validator(mode="after")
    def _check_production_safety(self) -> "Settings":
        """Refuse to start in production with insecure or example values."""
        if self.APP_ENV != "production":
            return self

        problems: list[str] = []
        if not self.REFRESH_COOKIE_SECURE:
            problems.append("REFRESH_COOKIE_SECURE must be true")
        for name in ("JWT_SECRET", "SECURITY_ANSWER_PEPPER"):
            if getattr(self, name).lower().startswith(_PLACEHOLDER_PREFIX):
                problems.append(f"{name} still has the placeholder value from .env.example")
        if bcrypt.checkpw(
            _PUBLIC_EXAMPLE_SUPER_ADMIN_PASSWORD, self.SUPER_ADMIN_PASSWORD_HASH.encode()
        ):
            problems.append(
                "SUPER_ADMIN_PASSWORD_HASH is the hash of the public example password; "
                "generate your own with: python scripts/hash_password.py"
            )
        if problems:
            raise ValueError("Unsafe production configuration: " + "; ".join(problems))
        return self

    # ------------------------------------------------------------------
    # Convenience properties
    # ------------------------------------------------------------------
    @property
    def is_production(self) -> bool:
        return self.APP_ENV == "production"

    @property
    def docs_enabled(self) -> bool:
        """Swagger UI / ReDoc / openapi.json are hidden in production."""
        return not self.is_production

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip().rstrip("/") for origin in self.CORS_ORIGINS.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]  # values come from the environment


settings = get_settings()
