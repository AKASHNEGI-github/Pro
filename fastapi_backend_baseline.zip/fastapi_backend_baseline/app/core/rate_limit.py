"""Rate limiting engine (independent of FastAPI).

Algorithm: SLIDING WINDOW LOG. For every key (for example "auth.login:ip|1.2.3.4")
we remember the times of its recent hits. A new hit is refused when the key
already has `limit` hits inside the last `window_seconds`. Refused hits are not
recorded, so a client that keeps hammering is not punished beyond the window.

Where the numbers live:     app/core/rate_limit_rules.py
How routes use them:        app/dependencies/rate_limit.py
The global per-IP limit:    app/middleware/rate_limit.py

REDIS LATER: the in-memory store below keeps counters inside one process, which
is right for a single instance (and for this baseline). With several instances or
workers each would count separately. To share counters, write a class with the
same `hit()` method on top of Redis (e.g. a sorted set per key, or INCR + EXPIRE)
and pass it to `RateLimiter(...)` at the bottom of this file. Nothing else changes.
"""

import math
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Protocol

from app.core.config import settings
from app.errors.exceptions import TooManyRequestsError


@dataclass(frozen=True)
class RateLimitRule:
    name: str  # unique, e.g. "auth.login:ip"
    limit: int  # hits allowed ...
    window_seconds: int  # ... inside this many seconds


@dataclass(frozen=True)
class RateLimitDecision:
    allowed: bool
    retry_after: int = 0  # seconds to wait; only meaningful when `allowed` is False


class RateLimitStore(Protocol):
    """Where counters live. Implement this for Redis (or anything else)."""

    async def hit(self, key: str, *, limit: int, window_seconds: int) -> RateLimitDecision: ...


@dataclass
class _Bucket:
    window_seconds: int
    hits: deque[float] = field(default_factory=deque)  # monotonic timestamps, oldest first


class InMemoryRateLimitStore:
    """Per-process store. No locks needed: asyncio runs this code without interruption."""

    PRUNE_EVERY_SECONDS = 60

    def __init__(self) -> None:
        self._buckets: dict[str, _Bucket] = {}
        self._last_prune = time.monotonic()

    async def hit(self, key: str, *, limit: int, window_seconds: int) -> RateLimitDecision:
        now = time.monotonic()
        self._prune_if_due(now)

        bucket = self._buckets.setdefault(key, _Bucket(window_seconds))
        window_start = now - window_seconds
        while bucket.hits and bucket.hits[0] <= window_start:
            bucket.hits.popleft()

        if len(bucket.hits) >= limit:
            wait = math.ceil(bucket.hits[0] + window_seconds - now)
            return RateLimitDecision(allowed=False, retry_after=max(1, wait))

        bucket.hits.append(now)
        return RateLimitDecision(allowed=True)

    def _prune_if_due(self, now: float) -> None:
        """Forget keys that have no recent hits, so memory does not grow forever."""
        if now - self._last_prune < self.PRUNE_EVERY_SECONDS:
            return
        self._last_prune = now
        stale = [
            key
            for key, bucket in self._buckets.items()
            if not bucket.hits or bucket.hits[-1] <= now - bucket.window_seconds
        ]
        for key in stale:
            del self._buckets[key]


class RateLimiter:
    def __init__(self, store: RateLimitStore, *, enabled: bool = True) -> None:
        self.store = store
        self.enabled = enabled

    async def check(self, rule: RateLimitRule, identifier: str) -> None:
        """Count one hit for `identifier` under `rule`; raise 429 when over the limit."""
        if not self.enabled:
            return
        decision = await self.store.hit(
            f"{rule.name}:{identifier}", limit=rule.limit, window_seconds=rule.window_seconds
        )
        if not decision.allowed:
            raise TooManyRequestsError(
                f"Too many requests. Please try again in {decision.retry_after} seconds.",
                meta={"retry_after": decision.retry_after},
            )


rate_limiter = RateLimiter(InMemoryRateLimitStore(), enabled=settings.RATE_LIMIT_ENABLED)
