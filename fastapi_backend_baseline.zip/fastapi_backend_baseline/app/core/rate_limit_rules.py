"""Every rate limit of the application, in one table.

"per IP"        counts all requests from one client IP to that route
"per IP + e-mail"  counts requests from one IP for one e-mail address
                   (stops one attacker from guessing a single account's password
                   or answers, without locking out everybody behind the same IP)

All of these are applied IN ADDITION to the global limit below. Routes that check
a password the caller already has (change password, security profile, delete
account) share the same strict "5 per 15 minutes" rule.
"""

from app.core.rate_limit import RateLimitRule

MINUTE = 60
QUARTER_HOUR = 15 * MINUTE
HOUR = 60 * MINUTE

# Applied to every request by `middleware/rate_limit.py` (health probes excluded).
GLOBAL_PER_IP = RateLimitRule("global:ip", limit=100, window_seconds=MINUTE)

# --- auth ------------------------------------------------------------------
LOGIN_PER_IP = RateLimitRule("auth.login:ip", limit=20, window_seconds=QUARTER_HOUR)
LOGIN_PER_IP_EMAIL = RateLimitRule("auth.login:ip-email", limit=5, window_seconds=QUARTER_HOUR)

REGISTER_PER_IP = RateLimitRule("auth.register:ip", limit=5, window_seconds=HOUR)

REFRESH_PER_IP = RateLimitRule("auth.refresh:ip", limit=30, window_seconds=MINUTE)

FORGOT_QUESTIONS_PER_IP = RateLimitRule("auth.forgot.questions:ip", limit=10, window_seconds=QUARTER_HOUR)
FORGOT_QUESTIONS_PER_IP_EMAIL = RateLimitRule("auth.forgot.questions:ip-email", limit=5, window_seconds=QUARTER_HOUR)

# Verification is also protected by the per-account lockout stored in the database.
FORGOT_VERIFY_PER_IP = RateLimitRule("auth.forgot.verify:ip", limit=10, window_seconds=QUARTER_HOUR)
FORGOT_VERIFY_PER_IP_EMAIL = RateLimitRule("auth.forgot.verify:ip-email", limit=5, window_seconds=QUARTER_HOUR)

FORGOT_RESET_PER_IP = RateLimitRule("auth.forgot.reset:ip", limit=5, window_seconds=QUARTER_HOUR)

# --- routes that re-check the caller's current password -----------------------
CHANGE_PASSWORD_PER_IP = RateLimitRule("auth.change-password:ip", limit=5, window_seconds=QUARTER_HOUR)
SECURITY_PROFILE_WRITE_PER_IP = RateLimitRule("auth.security-profile:ip", limit=5, window_seconds=QUARTER_HOUR)
DELETE_ACCOUNT_PER_IP = RateLimitRule("users.delete-me:ip", limit=5, window_seconds=QUARTER_HOUR)
