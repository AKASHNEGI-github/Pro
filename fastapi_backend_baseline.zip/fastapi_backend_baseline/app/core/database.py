"""MySQL access layer: one async connection pool and three tiny helpers.

There is NO ORM. Services write real SQL (in their own `service.py`) and run it
with these helpers:

    from app.core.database import db

    row  = await db.fetch_one("SELECT user_id FROM users WHERE user_id = %s", (5,))
    rows = await db.fetch_all("SELECT role_id, role_name FROM roles")
    done = await db.execute("UPDATE users SET full_name = %s WHERE user_id = %s", (name, 5))
    done.row_count, done.last_insert_id

    # several statements that must succeed or fail together:
    async with db.transaction() as tx:
        user = await tx.execute("INSERT INTO users (...) VALUES (%s, %s)", (a, b))
        await tx.execute("INSERT INTO user_roles (...) VALUES (%s, %s)", (user.last_insert_id, 1))

SQL INJECTION SAFETY: values are ALWAYS passed through `params` and written as
`%s` placeholders; the driver sends them escaped. Never build SQL text out of
request data with f-strings or `+`. (The few dynamic queries, such as the admin
user list, only ever add fixed SQL fragments chosen from a whitelist.)

Behaviour worth knowing:
  * Every connection runs in UTC (`SET time_zone = '+00:00'`).
  * Autocommit is ON; a transaction exists only inside `db.transaction()`.
  * `row_count` of an UPDATE is the number of rows MATCHED (the FOUND_ROWS
    client flag), so "UPDATE ... WHERE user_id = 5" reports 1 even when the new
    values equal the old ones.
  * Rows come back as plain dicts keyed by column name.
  * Connection problems (server down, pool exhausted, deadlock, lock timeout)
    become `ServiceUnavailableError` (503 + Retry-After). Constraint errors are
    left alone so services can translate them (see `is_duplicate_key_error`).
"""

import asyncio
from collections.abc import AsyncIterator, Awaitable, Sequence
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, Literal, Protocol

import asyncmy
from asyncmy.connection import Connection
from asyncmy.constants.CLIENT import FOUND_ROWS
from asyncmy.cursors import DictCursor
from asyncmy.errors import IntegrityError, InterfaceError, OperationalError

from app.core.config import settings
from app.core.constants import DB_RETRY_AFTER_SECONDS
from app.core.logger import get_logger
from app.errors.exceptions import ServiceUnavailableError

logger = get_logger(__name__)

__all__ = ["db", "Database", "Transaction", "SqlExecutor", "ExecuteResult", "IntegrityError", "is_duplicate_key_error"]

Params = Sequence[Any] | None
Row = dict[str, Any]

MYSQL_ERROR_DUPLICATE_ENTRY = 1062

# Errors that mean "the database could not serve this request right now".
_UNAVAILABLE_ERRORS = (OperationalError, InterfaceError, ConnectionError, TimeoutError)


def is_duplicate_key_error(exc: BaseException) -> bool:
    """True when `exc` is MySQL's "Duplicate entry ... for key ..." (UNIQUE violated)."""
    return isinstance(exc, IntegrityError) and bool(exc.args) and exc.args[0] == MYSQL_ERROR_DUPLICATE_ENTRY


@dataclass(frozen=True)
class ExecuteResult:
    row_count: int  # rows matched by the statement
    last_insert_id: int  # AUTO_INCREMENT id of the inserted row (0 if none)


class SqlExecutor(Protocol):
    """Anything that can run SQL: the `db` object or a `Transaction`.

    Service helper functions take an `SqlExecutor`, so the same function can be
    used on its own or inside a larger transaction.
    """

    async def fetch_one(self, sql: str, params: Params = None) -> Row | None: ...

    async def fetch_all(self, sql: str, params: Params = None) -> list[Row]: ...

    async def execute(self, sql: str, params: Params = None) -> ExecuteResult: ...


def _unavailable(exc: BaseException) -> ServiceUnavailableError:
    return ServiceUnavailableError(cause=exc, meta={"retry_after": DB_RETRY_AFTER_SECONDS})


async def _guard(operation: Awaitable[Any]) -> Any:
    """Await a connection-level operation (BEGIN / COMMIT), mapping outages to 503."""
    try:
        return await operation
    except _UNAVAILABLE_ERRORS as exc:
        raise _unavailable(exc) from exc


async def _run(
    conn: Connection,
    sql: str,
    params: Params,
    mode: Literal["one", "all", "execute"],
) -> Any:
    """Run one statement on `conn`; the single place where the driver is called."""
    try:
        cursor = conn.cursor(DictCursor)
        try:
            await cursor.execute(sql, params)
            if mode == "one":
                return await cursor.fetchone()
            if mode == "all":
                return list(await cursor.fetchall())
            return ExecuteResult(row_count=cursor.rowcount, last_insert_id=cursor.lastrowid or 0)
        finally:
            await cursor.close()
    except _UNAVAILABLE_ERRORS as exc:
        raise _unavailable(exc) from exc


class Transaction:
    """One connection reserved for a group of statements (see `Database.transaction`)."""

    def __init__(self, conn: Connection) -> None:
        self._conn = conn

    async def fetch_one(self, sql: str, params: Params = None) -> Row | None:
        return await _run(self._conn, sql, params, "one")

    async def fetch_all(self, sql: str, params: Params = None) -> list[Row]:
        return await _run(self._conn, sql, params, "all")

    async def execute(self, sql: str, params: Params = None) -> ExecuteResult:
        return await _run(self._conn, sql, params, "execute")


class Database:
    def __init__(self) -> None:
        self._pool: asyncmy.Pool | None = None

    # ------------------------------------------------------------------
    # Life cycle (called from the application lifespan)
    # ------------------------------------------------------------------
    async def connect(self) -> None:
        self._pool = await asyncmy.create_pool(
            host=settings.DB_HOST,
            port=settings.DB_PORT,
            user=settings.DB_USER,
            password=settings.DB_PASSWORD,
            database=settings.DB_NAME,
            charset="utf8mb4",
            autocommit=True,
            client_flag=FOUND_ROWS,
            init_command="SET time_zone = '+00:00'",
            connect_timeout=settings.DB_CONNECT_TIMEOUT_SECONDS,
            minsize=settings.DB_POOL_MIN_SIZE,
            maxsize=settings.DB_POOL_MAX_SIZE,
            pool_recycle=settings.DB_POOL_RECYCLE_SECONDS,
        )
        logger.info(
            "Database pool ready",
            extra={
                "data": {
                    "host": settings.DB_HOST,
                    "database": settings.DB_NAME,
                    "maxSize": settings.DB_POOL_MAX_SIZE,
                }
            },
        )

    async def disconnect(self) -> None:
        if self._pool is not None:
            self._pool.close()
            await self._pool.wait_closed()
            self._pool = None
            logger.info("Database pool closed")

    async def ping(self) -> None:
        """Raises ServiceUnavailableError when the database cannot answer."""
        await self.fetch_one("SELECT 1 AS ok")

    # ------------------------------------------------------------------
    # Single statements (each one borrows a connection from the pool)
    # ------------------------------------------------------------------
    async def fetch_one(self, sql: str, params: Params = None) -> Row | None:
        async with self._connection() as conn:
            return await _run(conn, sql, params, "one")

    async def fetch_all(self, sql: str, params: Params = None) -> list[Row]:
        async with self._connection() as conn:
            return await _run(conn, sql, params, "all")

    async def execute(self, sql: str, params: Params = None) -> ExecuteResult:
        async with self._connection() as conn:
            return await _run(conn, sql, params, "execute")

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------
    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[Transaction]:
        """Commit when the block ends normally, roll back when it raises."""
        async with self._connection() as conn:
            await _guard(conn.begin())
            try:
                yield Transaction(conn)
            except BaseException:
                await self._rollback_quietly(conn)
                raise
            else:
                await _guard(conn.commit())

    @staticmethod
    async def _rollback_quietly(conn: Connection) -> None:
        try:
            await conn.rollback()
        except Exception:  # the connection may already be broken; the pool discards it
            logger.warning("Rollback failed", exc_info=True)

    # ------------------------------------------------------------------
    # Pool plumbing
    # ------------------------------------------------------------------
    @asynccontextmanager
    async def _connection(self) -> AsyncIterator[Connection]:
        if self._pool is None:
            raise RuntimeError("Database.connect() has not been called")
        try:
            conn = await asyncio.wait_for(self._pool.acquire(), timeout=settings.DB_POOL_ACQUIRE_TIMEOUT_SECONDS)
        except _UNAVAILABLE_ERRORS as exc:  # includes the acquire timeout
            raise _unavailable(exc) from exc
        try:
            yield conn
        finally:
            self._pool.release(conn)


db = Database()
