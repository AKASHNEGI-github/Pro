"""Fixed values shared by the whole application.

Everything a developer might want to tune lives either here (same in every
environment) or in `config.py` (differs per environment). Keeping them in one
place means there are no "magic numbers" scattered through the code.
"""

from dataclasses import dataclass

# --------------------------------------------------------------------------
# Application
# --------------------------------------------------------------------------
APP_VERSION = "1.0.0"
API_PREFIX = "/api/v1"
REQUEST_ID_HEADER = "X-Request-Id"

# --------------------------------------------------------------------------
# Roles
# The super admin is NOT a row in the `roles` table. It is the reserved
# `users` row with user_id = 1 and its level exists only in code.
# `admin` and `member` levels come from `roles.role_level` (2 and 1).
# --------------------------------------------------------------------------
SUPER_ADMIN_USER_ID = 1
SUPER_ADMIN_LEVEL = 1000

ROLE_SUPER_ADMIN = "super_admin"
ROLE_ADMIN = "admin"
ROLE_MEMBER = "member"

# --------------------------------------------------------------------------
# Passwords
# --------------------------------------------------------------------------
PASSWORD_MIN_LENGTH = 8
PASSWORD_MAX_LENGTH = 64
# bcrypt only uses the first 72 BYTES of its input (and bcrypt 5 refuses
# longer input), so passwords are also limited in bytes, not just characters.
BCRYPT_MAX_BYTES = 72
# Longest password accepted by "login"-style forms (policy is NOT enforced
# there, only a sanity limit to avoid pointless hashing work).
LOGIN_PASSWORD_MAX_LENGTH = 128
TEMPORARY_PASSWORD_LENGTH = 16

# --------------------------------------------------------------------------
# Tokens and sessions
# --------------------------------------------------------------------------
TOKEN_TYPE = "Bearer"
JWT_CLOCK_LEEWAY_SECONDS = 10
REFRESH_COOKIE_PATH = f"{API_PREFIX}/auth"
PASSWORD_RESET_TOKEN_TTL_MINUTES = 10
USER_AGENT_MAX_LENGTH = 512

# --------------------------------------------------------------------------
# Password recovery (security questions)
# --------------------------------------------------------------------------
RECOVERY_MAX_FAILED_ATTEMPTS = 5
RECOVERY_LOCK_MINUTES = 15


@dataclass(frozen=True)
class SecurityQuestion:
    """One of the fixed recovery questions.

    `id` is also the name of the request field that carries the answer.
    """

    id: str
    text: str
    answer_type: str  # "date" or "text"


# Question 1-3 are the same for every user and live in code, so only the
# (hashed) answers are stored in the database. Questions 4-5 are written by
# the user and stored (as text) in `user_security_profiles`.
FIXED_SECURITY_QUESTIONS: tuple[SecurityQuestion, ...] = (
    SecurityQuestion("dateOfBirth", "What is your date of birth?", "date"),
    SecurityQuestion("answerQ2", "In which city were you born?", "text"),
    SecurityQuestion("answerQ3", "What was the name of your first pet?", "text"),
)

# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
MAX_BODY_BYTES = 100 * 1024  # 100 kb
DEFAULT_PAGE_SIZE = 20
MAX_PAGE_SIZE = 100
DB_RETRY_AFTER_SECONDS = 5

# --------------------------------------------------------------------------
# Background maintenance
# --------------------------------------------------------------------------
CLEANUP_INTERVAL_SECONDS = 60 * 60  # hourly
CLEANUP_BATCH_SIZE = 5000
