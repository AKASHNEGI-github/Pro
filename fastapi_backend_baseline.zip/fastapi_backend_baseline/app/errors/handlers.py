"""Error handling: the ONLY place that produces failure responses.

    {
      "success": false,
      "message": "Validation failed",
      "error": {"code": "VALIDATION_ERROR", "details": [{"field": "email", "message": "..."}]},
      "requestId": "b1c2d3e4-..."
    }

Three entry points use the same two functions (`to_app_error` -> `failure_response`):

  1. exception handlers registered on the app (errors raised by routers/services)
  2. `ErrorBoundaryMiddleware`   (unexpected crashes: becomes a generic 500)
  3. middleware that rejects a request early (CORS, rate limit, body size)

Unexpected errors NEVER leak details: the client gets a generic message, and
the stack trace goes to the log only.
"""

import uuid
from typing import Any

from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.constants import REQUEST_ID_HEADER
from app.core.context import get_request_id, set_error_code
from app.core.logger import get_logger
from app.errors.exceptions import (
    AppError,
    BadRequestError,
    ForbiddenError,
    InternalServerError,
    NotFoundError,
    PayloadTooLargeError,
    TooManyRequestsError,
    UnauthorizedError,
    ValidationError,
)

logger = get_logger(__name__)

_REQUEST_PARTS = {"body", "query", "path", "header", "cookie"}


# ---------------------------------------------------------------------------
# 1. Convert any exception into an AppError
# ---------------------------------------------------------------------------
def _validation_details(exc: RequestValidationError) -> list[dict[str, Any]]:
    """Pydantic errors -> [{"field": "securityProfile.dateOfBirth", "message": "..."}]."""
    details: list[dict[str, Any]] = []
    for error in exc.errors():
        location = [str(part) for part in error.get("loc", ())]
        if location and location[0] in _REQUEST_PARTS:
            location = location[1:] or [location[0]]
        message = str(error.get("msg", "Invalid value"))
        message = message.removeprefix("Value error, ")  # added by Pydantic for custom validators
        if error.get("type") == "model_attributes_type" and location == ["body"]:
            # The body was not parsed as JSON: almost always a missing Content-Type header.
            message = "The request body must be a JSON object, sent with the header 'Content-Type: application/json'."
        details.append({"field": ".".join(location), "message": message})
    return details


def _from_validation_error(exc: RequestValidationError) -> AppError:
    if any(error.get("type") == "json_invalid" for error in exc.errors()):
        return BadRequestError("The request body is not valid JSON.", code="BAD_REQUEST")
    return ValidationError("Validation failed", details=_validation_details(exc))


def _from_http_exception(exc: StarletteHTTPException) -> AppError:
    """Errors raised by Starlette/FastAPI themselves (unknown route, wrong method, ...)."""
    detail = exc.detail if isinstance(exc.detail, str) else "The request failed."
    status = exc.status_code
    if status in (404, 405):
        return NotFoundError("Route not found.", code="ROUTE_NOT_FOUND")
    if status == 401:
        return UnauthorizedError(detail)
    if status == 403:
        return ForbiddenError(detail)
    if status == 413:
        return PayloadTooLargeError()
    if status == 429:
        return TooManyRequestsError()
    if status >= 500:
        return InternalServerError(cause=exc)
    return BadRequestError(detail)


def to_app_error(exc: BaseException) -> AppError:
    if isinstance(exc, AppError):
        return exc
    if isinstance(exc, RequestValidationError):
        return _from_validation_error(exc)
    if isinstance(exc, StarletteHTTPException):
        return _from_http_exception(exc)
    return InternalServerError(cause=exc)  # unexpected: generic message, details only in the log


# ---------------------------------------------------------------------------
# 2. Build the response
# ---------------------------------------------------------------------------
def failure_response(exc: AppError) -> JSONResponse:
    """Build (and, for 5xx, log) the standard failure response for `exc`."""
    request_id = get_request_id() or str(uuid.uuid4())
    set_error_code(exc.code)  # so the access log line can show it

    if exc.status_code >= 500:
        logger.error(
            "%s: %s",
            exc.code,
            exc.message,
            exc_info=exc.cause or exc,
            extra={"data": {"status": exc.status_code, "code": exc.code}},
        )

    error: dict[str, Any] = {"code": exc.code}
    if exc.details:
        error["details"] = exc.details

    return JSONResponse(
        status_code=exc.status_code,
        content=jsonable_encoder(
            {"success": False, "message": exc.message, "error": error, "requestId": request_id}
        ),
        headers={**exc.headers, REQUEST_ID_HEADER: request_id},
    )


# ---------------------------------------------------------------------------
# 3. Register on the application
# ---------------------------------------------------------------------------
async def _handle_exception(request: Request, exc: Exception) -> JSONResponse:
    return failure_response(to_app_error(exc))


def register_exception_handlers(app: FastAPI) -> None:
    for exception_class in (AppError, RequestValidationError, StarletteHTTPException, Exception):
        app.add_exception_handler(exception_class, _handle_exception)
