"""Custom exception classes.

Services and routers never build error responses themselves; they simply
`raise` one of these. The error handler (`handlers.py`) turns every exception
into the standard failure response:

    {"success": false, "message": "...", "error": {"code": "...", "details": [...]}, "requestId": "..."}

Constructor:

    raise NotFoundError("User not found", code="USER_NOT_FOUND")
    raise ConflictError(code="EMAIL_ALREADY_EXISTS")          # default message
    raise ValidationError(details=[{"field": "email", "message": "Invalid"}])

    message  human readable text shown to the client (never put secrets here)
    code     stable machine readable code; clients should switch on this
    details  optional list shown to the client (validation issues, ...)
    cause    the original exception, for the logs only (never sent to the client)
    meta     internal extras that are NOT part of the response body.
             `meta={"retry_after": 30}` adds a `Retry-After: 30` header.
"""

from typing import Any


class AppError(Exception):
    status_code: int = 500
    default_code: str = "INTERNAL_ERROR"
    default_message: str = "Something went wrong. Please try again later."

    def __init__(
        self,
        message: str | None = None,
        *,
        code: str | None = None,
        details: list[dict[str, Any]] | None = None,
        cause: BaseException | None = None,
        meta: dict[str, Any] | None = None,
    ) -> None:
        self.message = message or self.default_message
        self.code = code or self.default_code
        self.details = details
        self.cause = cause
        self.meta = meta or {}
        super().__init__(self.message)
        if cause is not None:
            self.__cause__ = cause

    @property
    def headers(self) -> dict[str, str]:
        """Extra HTTP response headers implied by this error."""
        headers: dict[str, str] = {}
        retry_after = self.meta.get("retry_after")
        if retry_after is not None:
            headers["Retry-After"] = str(max(1, int(retry_after)))
        return headers


class BadRequestError(AppError):
    status_code = 400
    default_code = "BAD_REQUEST"
    default_message = "The request could not be understood."


class UnauthorizedError(AppError):
    status_code = 401
    default_code = "UNAUTHORIZED"
    default_message = "Authentication is required."

    @property
    def headers(self) -> dict[str, str]:
        # RFC 6750: a 401 must tell the client which scheme to use.
        return {**super().headers, "WWW-Authenticate": "Bearer"}


class ForbiddenError(AppError):
    status_code = 403
    default_code = "FORBIDDEN"
    default_message = "You do not have permission to perform this action."


class NotFoundError(AppError):
    status_code = 404
    default_code = "NOT_FOUND"
    default_message = "The requested resource was not found."


class ConflictError(AppError):
    status_code = 409
    default_code = "CONFLICT"
    default_message = "The request conflicts with the current state of the resource."


class PayloadTooLargeError(AppError):
    status_code = 413
    default_code = "PAYLOAD_TOO_LARGE"
    default_message = "The request body is too large."


class ValidationError(AppError):
    status_code = 422
    default_code = "VALIDATION_ERROR"
    default_message = "Validation failed."


class TooManyRequestsError(AppError):
    status_code = 429
    default_code = "RATE_LIMITED"
    default_message = "Too many requests. Please try again later."


class InternalServerError(AppError):
    status_code = 500
    default_code = "INTERNAL_ERROR"
    default_message = "Something went wrong. Please try again later."


class ServiceUnavailableError(AppError):
    status_code = 503
    default_code = "SERVICE_UNAVAILABLE"
    default_message = "The service is temporarily unavailable. Please try again shortly."
