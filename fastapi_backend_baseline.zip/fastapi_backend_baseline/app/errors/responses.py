"""Error responses for the OpenAPI (Swagger) documentation only.

They do not change behaviour: the real failure responses are built by
`errors/handlers.py`. These dictionaries just tell Swagger what shape to show.
"""

from typing import Any

from app.utils.schemas import FailureResponse


def documented_error(description: str) -> dict[str, Any]:
    return {"model": FailureResponse, "description": description}


# Applied to the whole application.
COMMON_RESPONSES: dict[int | str, dict[str, Any]] = {
    422: documented_error("Validation failed (`VALIDATION_ERROR`)"),
    429: documented_error("Rate limit hit (`RATE_LIMITED`); see the `Retry-After` header"),
    500: documented_error("Unexpected error (`INTERNAL_ERROR`); the message is always generic"),
}

# Applied to routers whose endpoints need a signed-in user.
PROTECTED_RESPONSES: dict[int | str, dict[str, Any]] = {
    401: documented_error(
        "Missing, invalid or expired access token (`UNAUTHORIZED`, `TOKEN_INVALID`, `TOKEN_EXPIRED`)"
    ),
    403: documented_error(
        "Role or account state does not allow it "
        "(`INSUFFICIENT_ROLE`, `ACCOUNT_INACTIVE`, `PASSWORD_CHANGE_REQUIRED`, `SUPER_ADMIN_PROTECTED`, ...)"
    ),
}
