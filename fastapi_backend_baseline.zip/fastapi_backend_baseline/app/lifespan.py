"""Application start-up and shutdown.

Start-up order (any failure stops the application with a clear message):
  1. open the database pool
  2. prepare the timing-equalisation hash used by sign-in / recovery
  3. run the start-up checks (sync the super admin, refuse unsafe data, check the seed)
  4. start the hourly token cleanup

Shutdown does the reverse.
"""

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, suppress

from fastapi import FastAPI

from app.core.config import settings
from app.core.constants import APP_VERSION
from app.core.database import db
from app.core.logger import get_logger
from app.core.security import prepare_security
from app.modules.system.service import run_startup_checks
from app.modules.system.tasks import run_cleanup_forever

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    logger.info(
        "Starting application",
        extra={"data": {"name": settings.APP_NAME, "version": APP_VERSION, "env": settings.APP_ENV}},
    )
    cleanup_task: asyncio.Task | None = None
    await db.connect()
    try:
        await prepare_security()
        await run_startup_checks()
        cleanup_task = asyncio.create_task(run_cleanup_forever(), name="token-cleanup")
        logger.info("Application ready")
        yield
    finally:
        logger.info("Shutting down")
        if cleanup_task is not None:
            cleanup_task.cancel()
            with suppress(asyncio.CancelledError):
                await cleanup_task
        await db.disconnect()
