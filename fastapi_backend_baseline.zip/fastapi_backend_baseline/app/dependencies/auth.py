"""Authentication and authorization, as FastAPI dependencies.

    # any signed-in user
    user: CurrentUser = Depends(authenticate())

    # only some roles (the super admin always passes)
    user: CurrentUser = Depends(authorize(ROLE_ADMIN))

    # member + admin only; the super admin gets 403 SUPER_ADMIN_PROTECTED
    user: CurrentUser = Depends(authorize(ROLE_MEMBER, ROLE_ADMIN, include_super_admin=False))

AUTHENTICATION (who are you?)  `authenticate`
  1. read the Bearer token, verify signature / issuer / expiry
  2. re-load the user from the database (on EVERY request)
  3. reject tokens issued before the last password change
  4. apply the account-state rules (see the two flags below)

AUTHORIZATION (what may you do?)  `authorize`
  Route level: may this ROLE call this endpoint at all? Whether this actor may
  act on that particular target user is decided separately by the policy in
  `modules/admin/policy.py`.

By default an account that is inactive, or that must change its password first,
is refused (403 ACCOUNT_INACTIVE / PASSWORD_CHANGE_REQUIRED). The few endpoints
such an account may still use opt out explicitly:

    authenticate(allow_inactive=True, allow_password_change_pending=True)
"""

from collections.abc import Awaitable, Callable
from functools import cache

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.core.constants import ROLE_SUPER_ADMIN, SUPER_ADMIN_LEVEL, SUPER_ADMIN_USER_ID
from app.core.context import set_current_user
from app.core.current_user import CurrentUser
from app.core.security import decode_access_token, super_admin_fingerprint
from app.errors.exceptions import ForbiddenError, UnauthorizedError
from app.modules.auth import service as auth_service
from app.utils.clock import to_epoch_seconds

# `auto_error=False`: we raise our own 401 so the body has the standard shape.
bearer_scheme = HTTPBearer(
    auto_error=False,
    scheme_name="BearerAuth",
    description="The `accessToken` returned by `POST /api/v1/auth/login`.",
)


def _token_invalid(reason: str) -> UnauthorizedError:
    return UnauthorizedError(reason, code="TOKEN_INVALID")


@cache
def _build_authenticator(
    allow_inactive: bool, allow_password_change_pending: bool
) -> Callable[..., Awaitable[CurrentUser]]:
    async def authenticator(
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    ) -> CurrentUser:
        if credentials is None or not credentials.credentials:
            raise UnauthorizedError("Send your access token as 'Authorization: Bearer <token>'.")

        claims = decode_access_token(credentials.credentials)
        user_id = int(claims["sub"])

        record = await auth_service.load_authentication_record(user_id)
        if record is None:
            raise _token_invalid("The account no longer exists.")  # deleted accounts stop working at once

        if user_id == SUPER_ADMIN_USER_ID:
            # The super admin has no password row. Its token carries a fingerprint of the
            # password hash in ENV; after a rotation the fingerprints differ.
            if claims.get("pwf") != super_admin_fingerprint():
                raise _token_invalid("The super admin password changed. Please sign in again.")
            role, role_level, must_change_password = ROLE_SUPER_ADMIN, SUPER_ADMIN_LEVEL, False
        else:
            password_changed_at = record["password_changed_at"]
            # Compared in whole seconds: JWT `iat` has no sub-second part, and the token that is
            # issued in the same request as a password change must remain valid.
            if password_changed_at is None or claims["iat"] < int(to_epoch_seconds(password_changed_at)):
                raise _token_invalid("The password changed after this token was issued. Please sign in again.")
            if record["role_name"] is None:
                raise ForbiddenError("The account has no active role.", code="ROLE_NOT_ASSIGNED")
            role, role_level = record["role_name"], int(record["role_level"] or 0)
            must_change_password = bool(record["must_change_password"])

        is_active = bool(record["is_active"])
        if not is_active and not allow_inactive:
            raise ForbiddenError("This account is inactive.", code="ACCOUNT_INACTIVE")
        if must_change_password and not allow_password_change_pending:
            raise ForbiddenError("You must change your password before continuing.", code="PASSWORD_CHANGE_REQUIRED")

        set_current_user(user_id, role)  # every later log line now carries the user id
        return CurrentUser(
            user_id=user_id,
            full_name=record["full_name"],
            email=record["email"],
            role=role,
            role_level=role_level,
            is_active=is_active,
            must_change_password=must_change_password,
        )

    return authenticator


def authenticate(
    *, allow_inactive: bool = False, allow_password_change_pending: bool = False
) -> Callable[..., Awaitable[CurrentUser]]:
    """Dependency: the signed-in user. (Cached per option combination so FastAPI evaluates it once per request.)"""
    return _build_authenticator(allow_inactive, allow_password_change_pending)


def authorize(
    *allowed_roles: str,
    include_super_admin: bool = True,
    allow_inactive: bool = False,
    allow_password_change_pending: bool = False,
) -> Callable[..., Awaitable[CurrentUser]]:
    """Dependency: the signed-in user, but only if their role is one of `allowed_roles`."""
    authenticator = authenticate(
        allow_inactive=allow_inactive, allow_password_change_pending=allow_password_change_pending
    )

    async def authorizer(user: CurrentUser = Depends(authenticator)) -> CurrentUser:
        if user.is_super_admin:
            if include_super_admin:
                return user
            raise ForbiddenError(
                "The super admin account is managed through the server environment, not through the API.",
                code="SUPER_ADMIN_PROTECTED",
            )
        if user.role in allowed_roles:
            return user
        raise ForbiddenError("Your role does not allow this action.", code="INSUFFICIENT_ROLE")

    return authorizer
