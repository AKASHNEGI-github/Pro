"""Rate limit helpers for routes. The numbers themselves are in `core/rate_limit_rules.py`.

Per IP (a dependency, runs before the body is validated):

    @router.post("/login", dependencies=[Depends(limit_by_ip(LOGIN_PER_IP))])

Per IP + e-mail (a function call, because the e-mail comes from the request body):

    await limit_by_ip_and_email(LOGIN_PER_IP_EMAIL, payload.email)
"""

from collections.abc import Awaitable, Callable

from app.core.context import get_client_ip
from app.core.rate_limit import RateLimitRule, rate_limiter


def limit_by_ip(rule: RateLimitRule) -> Callable[[], Awaitable[None]]:
    async def dependency() -> None:
        await rate_limiter.check(rule, get_client_ip() or "unknown")

    return dependency


async def limit_by_ip_and_email(rule: RateLimitRule, email: str) -> None:
    await rate_limiter.check(rule, f"{get_client_ip() or 'unknown'}|{email}")
