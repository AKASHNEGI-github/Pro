"""Background tasks started by the application lifespan."""

import asyncio

from app.core.constants import CLEANUP_INTERVAL_SECONDS
from app.core.logger import get_logger
from app.modules.system.service import cleanup_expired_tokens

logger = get_logger(__name__)


async def run_cleanup_forever() -> None:
    """Delete expired tokens now and then every hour. A failure is logged, never fatal."""
    while True:
        try:
            await cleanup_expired_tokens()
        except Exception:
            logger.exception("Token cleanup failed; will retry at the next interval")
        await asyncio.sleep(CLEANUP_INTERVAL_SECONDS)
