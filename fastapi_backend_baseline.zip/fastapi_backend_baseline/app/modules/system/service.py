"""Start-up checks and maintenance, with their SQL.

Runs once when the application starts (see `app/lifespan.py`):

  1. SYNC THE SUPER ADMIN   `users.user_id = 1` is created / revived / re-activated, and its
                            name and e-mail are overwritten from SUPER_ADMIN_NAME / _EMAIL.
                            Its active refresh tokens are revoked (see "rotation" in the README).
  2. REFUSE UNSAFE DATA     the super admin must have NO password, role or security-profile
                            row, and no `super_admin` role may exist. If somebody created
                            them by hand the application refuses to start.
  3. CHECK THE SEED         the `member` and `admin` roles must exist.

And periodically (hourly, plus `scripts/cleanup_tokens.py`): delete expired tokens.
"""

from datetime import datetime

from app.core.config import settings
from app.core.constants import CLEANUP_BATCH_SIZE, ROLE_ADMIN, ROLE_MEMBER, ROLE_SUPER_ADMIN, SUPER_ADMIN_USER_ID
from app.core.database import db
from app.core.logger import get_logger
from app.modules.auth import tokens
from app.utils.clock import utcnow

logger = get_logger(__name__)

DEMO_ACCOUNT_EMAILS = ("demo.admin@example.com", "demo.member@example.com")

# ---------------------------------------------------------------------------
# SQL
# ---------------------------------------------------------------------------
# Another live account already owns the super admin's e-mail (it would break the UNIQUE index).
SQL_EMAIL_USED_BY_OTHER_USER = "SELECT user_id FROM users WHERE email_active = %s AND user_id <> %s"

# The ONE query on `users` without an `is_deleted` filter: a deleted super admin row must be found and revived.
SQL_SELECT_SUPER_ADMIN_FOR_UPDATE = "SELECT user_id FROM users WHERE user_id = %s FOR UPDATE"

SQL_INSERT_SUPER_ADMIN = """
INSERT INTO users (user_id, full_name, email, is_active, is_deleted, created_by)
VALUES (%s, %s, %s, TRUE, FALSE, NULL)
"""

SQL_UPDATE_SUPER_ADMIN = """
UPDATE users
SET full_name = %s, email = %s, is_active = TRUE, is_deleted = FALSE
WHERE user_id = %s
"""

SQL_COUNT_FORBIDDEN_SUPER_ADMIN_ROWS = """
SELECT (SELECT COUNT(*) FROM user_passwords WHERE user_id = %s) AS password_rows,
       (SELECT COUNT(*) FROM user_roles WHERE user_id = %s) AS role_rows,
       (SELECT COUNT(*) FROM user_security_profiles WHERE user_id = %s) AS security_profile_rows
"""

SQL_ALL_ROLES = "SELECT role_name, is_active, is_deleted FROM roles"

SQL_FIND_DEMO_ACCOUNTS = "SELECT email FROM users WHERE email_active IN (%s, %s)"

SQL_DELETE_EXPIRED_REFRESH_TOKENS = "DELETE FROM refresh_tokens WHERE expires_at < %s LIMIT %s"

SQL_DELETE_EXPIRED_RESET_TOKENS = "DELETE FROM password_reset_tokens WHERE expires_at < %s LIMIT %s"


class StartupCheckError(RuntimeError):
    """The database is not in a state the application can safely run on."""


# ---------------------------------------------------------------------------
# Start-up
# ---------------------------------------------------------------------------
async def run_startup_checks() -> None:
    await sync_super_admin()
    await refuse_forbidden_super_admin_rows()
    await check_roles()
    if settings.is_production:
        await warn_about_demo_accounts()


async def sync_super_admin() -> None:
    email, name = settings.SUPER_ADMIN_EMAIL, settings.SUPER_ADMIN_NAME

    clash = await db.fetch_one(SQL_EMAIL_USED_BY_OTHER_USER, (email, SUPER_ADMIN_USER_ID))
    if clash is not None:
        raise StartupCheckError(
            f"SUPER_ADMIN_EMAIL is already used by user {clash['user_id']}. "
            "Choose another e-mail, or free this one (delete or rename that account) and restart."
        )

    now = utcnow()
    async with db.transaction() as tx:
        existing = await tx.fetch_one(SQL_SELECT_SUPER_ADMIN_FOR_UPDATE, (SUPER_ADMIN_USER_ID,))
        if existing is None:
            await tx.execute(SQL_INSERT_SUPER_ADMIN, (SUPER_ADMIN_USER_ID, name, email))
            action = "created"
        else:
            await tx.execute(SQL_UPDATE_SUPER_ADMIN, (name, email, SUPER_ADMIN_USER_ID))
            action = "synced"
        # Rotating SUPER_ADMIN_PASSWORD_HASH must end old super admin sessions. Its access tokens
        # die through the password fingerprint; its refresh tokens are revoked here.
        revoked = await tokens.revoke_all_refresh_tokens(tx, SUPER_ADMIN_USER_ID, now)

    logger.info(
        f"Super admin {action} from environment",
        extra={"data": {"userId": SUPER_ADMIN_USER_ID, "revokedRefreshTokens": revoked}},
    )


async def refuse_forbidden_super_admin_rows() -> None:
    counts = await db.fetch_one(SQL_COUNT_FORBIDDEN_SUPER_ADMIN_ROWS, (SUPER_ADMIN_USER_ID,) * 3)
    offenders = [table for table, key in (
        ("user_passwords", "password_rows"),
        ("user_roles", "role_rows"),
        ("user_security_profiles", "security_profile_rows"),
    ) if counts[key]]
    if offenders:
        raise StartupCheckError(
            f"user_id {SUPER_ADMIN_USER_ID} (the super admin) must not have rows in: {', '.join(offenders)}. "
            "Its credentials live only in the environment. Delete those rows and restart."
        )


async def check_roles() -> None:
    rows = await db.fetch_all(SQL_ALL_ROLES)
    if any(row["role_name"] == ROLE_SUPER_ADMIN for row in rows):
        raise StartupCheckError(
            f"A role named '{ROLE_SUPER_ADMIN}' exists. The super admin is not a role and must never be assignable. "
            "Delete that row and restart."
        )
    usable = {row["role_name"] for row in rows if row["is_active"] and not row["is_deleted"]}
    missing = [name for name in (ROLE_MEMBER, ROLE_ADMIN) if name not in usable]
    if missing:
        raise StartupCheckError(
            f"Required role(s) missing or inactive: {', '.join(missing)}. Load database/seed.sql and restart."
        )


async def warn_about_demo_accounts() -> None:
    found = await db.fetch_all(SQL_FIND_DEMO_ACCOUNTS, DEMO_ACCOUNT_EMAILS)
    if found:
        logger.warning(
            "Demo accounts exist in a PRODUCTION database; their passwords are public. Delete them.",
            extra={"data": {"emails": [row["email"] for row in found]}},
        )


# ---------------------------------------------------------------------------
# Maintenance
# ---------------------------------------------------------------------------
async def _delete_in_batches(sql: str, now: datetime) -> int:
    """Small batches keep each DELETE short, so it never blocks other queries for long."""
    total = 0
    while True:
        result = await db.execute(sql, (now, CLEANUP_BATCH_SIZE))
        total += result.row_count
        if result.row_count < CLEANUP_BATCH_SIZE:
            return total


async def cleanup_expired_tokens() -> dict[str, int]:
    """Physically delete expired refresh and password-reset tokens (the only rows the app ever hard-deletes)."""
    now = utcnow()
    deleted = {
        "refreshTokens": await _delete_in_batches(SQL_DELETE_EXPIRED_REFRESH_TOKENS, now),
        "passwordResetTokens": await _delete_in_batches(SQL_DELETE_EXPIRED_RESET_TOKENS, now),
    }
    logger.info("Expired tokens deleted", extra={"data": deleted})
    return deleted
