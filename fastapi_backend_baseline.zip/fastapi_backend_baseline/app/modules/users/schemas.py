"""Request and response models of the users module."""

from app.utils.schemas import ExistingPassword, FullName, RequestModel, ResponseModel, UtcDatetime


class UserOut(ResponseModel):
    """A user as every module returns it (profile, login, sign-up, ...)."""

    user_id: int
    full_name: str
    email: str
    role: str | None  # "super_admin" | "admin" | "member"
    is_active: bool
    must_change_password: bool
    last_login: UtcDatetime | None
    created_at: UtcDatetime


class UpdateProfileRequest(RequestModel):
    """The ONLY editable profile field is the full name; the e-mail is the login id and is immutable."""

    full_name: FullName


class DeleteAccountRequest(RequestModel):
    password: ExistingPassword  # re-authentication: deleting an account is irreversible for the user
