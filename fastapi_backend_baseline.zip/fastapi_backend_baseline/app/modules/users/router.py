"""Self-service endpoints: `/api/v1/users/me`."""

from fastapi import APIRouter, Depends

from app.core.constants import ROLE_ADMIN, ROLE_MEMBER
from app.core.current_user import CurrentUser
from app.core.rate_limit_rules import DELETE_ACCOUNT_PER_IP
from app.dependencies.auth import authenticate, authorize
from app.dependencies.rate_limit import limit_by_ip
from app.errors.responses import PROTECTED_RESPONSES
from app.modules.auth.cookies import clear_refresh_cookie
from app.modules.users import service
from app.modules.users.schemas import DeleteAccountRequest, UpdateProfileRequest, UserOut
from app.utils.response import send_success
from app.utils.schemas import SuccessResponse

router = APIRouter(prefix="/users", tags=["Users (self-service)"], responses=PROTECTED_RESPONSES)

# Members and admins manage their own account. The super admin is managed through ENV.
self_service_user = authorize(ROLE_MEMBER, ROLE_ADMIN, include_super_admin=False)


@router.get(
    "/me",
    summary="Own profile",
    description=(
        "Allowed for every signed-in account, including inactive ones "
        "and accounts that must change their password."
    ),
    response_model=SuccessResponse[UserOut],
)
async def get_me(
    current_user: CurrentUser = Depends(authenticate(allow_inactive=True, allow_password_change_pending=True)),
):
    profile = await service.get_profile(current_user.user_id)
    return send_success(profile, "Profile fetched successfully")


@router.patch(
    "/me",
    summary="Update own full name",
    description="The full name is the only editable field. The e-mail address is immutable.",
    response_model=SuccessResponse[UserOut],
)
async def update_me(payload: UpdateProfileRequest, current_user: CurrentUser = Depends(self_service_user)):
    profile = await service.update_own_name(current_user, payload.full_name)
    return send_success(profile, "Profile updated successfully")


@router.delete(
    "/me",
    summary="Delete own account",
    description=(
        "Soft delete. Requires the password in the JSON body (re-authentication). "
        "Ends every session and frees the e-mail address."
    ),
    response_model=SuccessResponse[None],
    dependencies=[Depends(limit_by_ip(DELETE_ACCOUNT_PER_IP))],
)
async def delete_me(payload: DeleteAccountRequest, current_user: CurrentUser = Depends(self_service_user)):
    await service.delete_own_account(current_user, payload.password)
    response = send_success(None, "Account deleted successfully")
    clear_refresh_cookie(response)
    return response
