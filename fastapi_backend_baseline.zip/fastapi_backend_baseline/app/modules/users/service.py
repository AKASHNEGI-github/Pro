"""User accounts: own profile, own name, account deletion, and the user building blocks
that other services reuse (`create_user`, `email_is_taken`, `close_account`).

All SQL of this module lives in this file, as constants at the top.
Every query on `users` filters `is_deleted = FALSE` (or goes through `email_active`,
which is NULL for deleted rows), so a deleted account is invisible everywhere.
"""

from app.core.constants import SUPER_ADMIN_USER_ID
from app.core.current_user import CurrentUser
from app.core.database import IntegrityError, SqlExecutor, db, is_duplicate_key_error
from app.core.logger import get_logger
from app.errors.exceptions import ConflictError, ForbiddenError, NotFoundError
from app.modules.auth import credentials, tokens
from app.modules.users.schemas import UserOut
from app.utils.clock import utcnow

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# SQL
# ---------------------------------------------------------------------------

# The super admin has no `user_roles` row; its role name is produced in SQL.
SQL_PROFILE_BY_ID = """
SELECT u.user_id, u.full_name, u.email, u.is_active, u.last_login, u.created_at,
       COALESCE(p.must_change_password, FALSE) AS must_change_password,
       CASE WHEN u.user_id = %s THEN 'super_admin' ELSE r.role_name END AS role
FROM users u
LEFT JOIN user_passwords p ON p.user_id = u.user_id
LEFT JOIN user_roles ur ON ur.user_id = u.user_id
LEFT JOIN roles r ON r.role_id = ur.role_id
WHERE u.user_id = %s AND u.is_deleted = FALSE
"""

# `email_active` is NULL for deleted users, so this only sees live accounts.
SQL_FIND_LIVE_USER_BY_EMAIL = "SELECT user_id FROM users WHERE email_active = %s"

SQL_INSERT_USER = """
INSERT INTO users (full_name, email, is_active, created_by)
VALUES (%s, %s, TRUE, %s)
"""

SQL_UPDATE_FULL_NAME = "UPDATE users SET full_name = %s WHERE user_id = %s AND is_deleted = FALSE"

SQL_SOFT_DELETE_USER = "UPDATE users SET is_deleted = TRUE WHERE user_id = %s AND is_deleted = FALSE"


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------
async def get_profile(user_id: int) -> UserOut:
    row = await db.fetch_one(SQL_PROFILE_BY_ID, (SUPER_ADMIN_USER_ID, user_id))
    if row is None:
        raise NotFoundError("User not found.", code="USER_NOT_FOUND")
    return UserOut.model_validate(row)


async def email_is_taken(email: str) -> bool:
    return await db.fetch_one(SQL_FIND_LIVE_USER_BY_EMAIL, (email,)) is not None


# ---------------------------------------------------------------------------
# Creating (used by sign-up and by "admin creates a user")
# ---------------------------------------------------------------------------
async def create_user(
    executor: SqlExecutor, *, full_name: str, email: str, created_by: int | None
) -> int:
    """Insert the `users` row and return its id.

    `created_by = None` means "self-registered". The UNIQUE index on `email_active`
    is the real guard against two accounts with the same e-mail (even when two
    requests race), so its violation is translated into a clean 409 here.
    """
    try:
        result = await executor.execute(SQL_INSERT_USER, (full_name, email, created_by))
    except IntegrityError as exc:
        if is_duplicate_key_error(exc):
            raise ConflictError(
                "An account with this e-mail address already exists.", code="EMAIL_ALREADY_EXISTS"
            ) from exc
        raise
    return result.last_insert_id


# ---------------------------------------------------------------------------
# Self-service
# ---------------------------------------------------------------------------
async def update_own_name(user: CurrentUser, full_name: str) -> UserOut:
    await db.execute(SQL_UPDATE_FULL_NAME, (full_name, user.user_id))
    return await get_profile(user.user_id)


async def delete_own_account(user: CurrentUser, password: str) -> None:
    await credentials.verify_current_password(user.user_id, password)
    await close_account(user.user_id)
    logger.info("Account deleted by its owner", extra={"data": {"userId": user.user_id}})


# ---------------------------------------------------------------------------
# Closing an account (used by self-delete and by "admin deletes a user")
# ---------------------------------------------------------------------------
async def close_account(user_id: int) -> None:
    """Soft delete: mark the row deleted, end every session, cancel pending recovery.

    The row stays (history and foreign keys stay intact) and its e-mail address
    becomes free for a new account immediately.
    """
    if user_id == SUPER_ADMIN_USER_ID:  # defence in depth; callers also check this
        raise ForbiddenError(
            "The super admin account cannot be deleted.", code="SUPER_ADMIN_PROTECTED"
        )
    now = utcnow()
    async with db.transaction() as tx:
        deleted = await tx.execute(SQL_SOFT_DELETE_USER, (user_id,))
        if deleted.row_count == 0:
            raise NotFoundError("User not found.", code="USER_NOT_FOUND")
        await tokens.revoke_all_refresh_tokens(tx, user_id, now)
        await tokens.invalidate_pending_reset_tokens(tx, user_id, now)
