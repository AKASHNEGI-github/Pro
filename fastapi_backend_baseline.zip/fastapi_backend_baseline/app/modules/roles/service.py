"""Roles: listing, lookup, and assigning a role to a user.

Only the assignable roles live in the `roles` table (`member`, `admin`).
`super_admin` is deliberately NOT a row, so it can never be assigned.
"""

from datetime import datetime

from app.core.current_user import CurrentUser
from app.core.database import Row, SqlExecutor, db
from app.modules.roles.schemas import RoleOut

SQL_LIST_ACTIVE_ROLES = """
SELECT role_id, role_name, role_level, description
FROM roles
WHERE is_active = TRUE AND is_deleted = FALSE
ORDER BY role_level, role_name
"""

SQL_FIND_ACTIVE_ROLE_BY_NAME = """
SELECT role_id, role_name, role_level
FROM roles
WHERE role_name = %s AND is_active = TRUE AND is_deleted = FALSE
"""

SQL_UPDATE_USER_ROLE = """
UPDATE user_roles
SET role_id = %s, assigned_at = %s, updated_by = %s, updated_at = %s
WHERE user_id = %s
"""

SQL_INSERT_USER_ROLE = """
INSERT INTO user_roles (user_id, role_id, assigned_at, created_by, updated_by, updated_at)
VALUES (%s, %s, %s, %s, %s, %s)
"""


async def list_roles(actor: CurrentUser, *, assignable_only: bool) -> list[RoleOut]:
    rows = await db.fetch_all(SQL_LIST_ACTIVE_ROLES)
    roles = [
        RoleOut(
            role_id=row["role_id"],
            role_name=row["role_name"],
            role_level=int(row["role_level"] or 0),
            description=row["description"],
            assignable=int(row["role_level"] or 0) <= actor.role_level,
        )
        for row in rows
    ]
    return [role for role in roles if role.assignable] if assignable_only else roles


async def find_role_by_name(role_name: str) -> Row | None:
    return await db.fetch_one(SQL_FIND_ACTIVE_ROLE_BY_NAME, (role_name,))


async def set_user_role(
    executor: SqlExecutor, *, user_id: int, role_id: int, actor_id: int | None, now: datetime
) -> None:
    """Give `user_id` exactly one role (`user_roles.user_id` is UNIQUE, so a change is an UPDATE)."""
    updated = await executor.execute(SQL_UPDATE_USER_ROLE, (role_id, now, actor_id, now, user_id))
    if updated.row_count == 0:  # the user had no role row yet
        await executor.execute(SQL_INSERT_USER_ROLE, (user_id, role_id, now, actor_id, actor_id, now))
