"""Response model of the roles module."""

from app.utils.schemas import ResponseModel


class RoleOut(ResponseModel):
    role_id: int
    role_name: str
    role_level: int
    description: str | None
    assignable: bool  # can the CALLER give this role to someone? (role_level <= caller's level)
