"""`GET /api/v1/roles`: the roles that exist, and which ones the caller may assign."""

from fastapi import APIRouter, Depends, Query

from app.core.constants import ROLE_ADMIN
from app.core.current_user import CurrentUser
from app.dependencies.auth import authorize
from app.errors.responses import PROTECTED_RESPONSES
from app.modules.roles import service
from app.modules.roles.schemas import RoleOut
from app.utils.response import send_success
from app.utils.schemas import SuccessResponse

router = APIRouter(prefix="/roles", tags=["Roles"], responses=PROTECTED_RESPONSES)


@router.get(
    "",
    summary="List roles",
    description="Admins and the super admin. Each role has an `assignable` flag for the caller.",
    response_model=SuccessResponse[list[RoleOut]],
)
async def list_roles(
    assignable: bool = Query(False, description="Return only the roles the caller may assign."),
    current_user: CurrentUser = Depends(authorize(ROLE_ADMIN)),
):
    roles = await service.list_roles(current_user, assignable_only=assignable)
    return send_success(roles, "Roles fetched successfully")
