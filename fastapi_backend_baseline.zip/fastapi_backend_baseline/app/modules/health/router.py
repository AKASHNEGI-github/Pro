"""Health probes (unversioned, outside `/api/v1`, exempt from the global rate limit).

  GET /health, /health/live   liveness: the process is up (touches no dependency)
  GET /health/ready           readiness: the database answers; 503 when it does not
"""

from fastapi import APIRouter

from app.core.constants import DB_RETRY_AFTER_SECONDS
from app.core.database import db
from app.errors.exceptions import ServiceUnavailableError
from app.errors.responses import documented_error
from app.utils.response import send_success
from app.utils.schemas import SuccessResponse

router = APIRouter(prefix="/health", tags=["Health"])


@router.get("", include_in_schema=False)
@router.head("", include_in_schema=False)
@router.head("/live", include_in_schema=False)  # some load balancers probe with HEAD
@router.get("/live", summary="Liveness", response_model=SuccessResponse[dict])
async def live():
    return send_success({"status": "ok"}, "Service is alive")


@router.head("/ready", include_in_schema=False)
@router.get(
    "/ready",
    summary="Readiness",
    response_model=SuccessResponse[dict],
    responses={503: documented_error("`SERVICE_UNAVAILABLE`: `error.details` names the probe that failed")},
)
async def ready():
    try:
        await db.ping()
    except ServiceUnavailableError as exc:
        raise ServiceUnavailableError(
            "The service is not ready.",
            details=[{"probe": "database", "status": "down"}],
            cause=exc.cause,
            meta={"retry_after": DB_RETRY_AFTER_SECONDS},
        ) from exc
    return send_success({"status": "ok", "checks": {"database": "up"}}, "Service is ready")
