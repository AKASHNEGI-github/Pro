"""`/api/v1/admin`: user administration for admins and the super admin.

Route-level rule: only `admin` and `super_admin` get in (`authorize(ROLE_ADMIN)`).
Which TARGETS an actor may act on is decided inside the service by `policy.py`.
"""

from typing import Literal

from fastapi import APIRouter, Depends, Path, Query

from app.core.constants import DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, ROLE_ADMIN
from app.core.current_user import CurrentUser
from app.dependencies.auth import authorize
from app.errors.responses import PROTECTED_RESPONSES, documented_error
from app.modules.admin import service
from app.modules.admin.schemas import (
    AdminUserOut,
    ChangeRoleRequest,
    ChangeStatusRequest,
    CreateUserRequest,
    UpdateUserRequest,
    UserWithTemporaryPasswordOut,
)
from app.utils.response import build_page_meta, send_created, send_success
from app.utils.schemas import SuccessResponse

router = APIRouter(
    prefix="/admin",
    tags=["Admin"],
    responses={
        **PROTECTED_RESPONSES,
        404: documented_error("`USER_NOT_FOUND` (also returned for the super admin when an admin asks for it)"),
    },
)

admin_only = authorize(ROLE_ADMIN)  # the super admin always passes `authorize`

UserId = Path(ge=1, le=2**63 - 1, description="The user's id")  # BIGINT range


@router.get(
    "/users",
    summary="List users",
    description=(
        "Paginated. The super admin is left out for admins. Soft-deleted users never appear. "
        "`search` matches the name or the e-mail."
    ),
    response_model=SuccessResponse[list[AdminUserOut]],
)
async def list_users(
    page: int = Query(1, ge=1, le=1_000_000),
    limit: int = Query(DEFAULT_PAGE_SIZE, ge=1, le=MAX_PAGE_SIZE),
    search: str | None = Query(None, max_length=100),
    role: Literal["admin", "member"] | None = Query(None),
    is_active: bool | None = Query(None, alias="isActive"),
    sort_by: service.SortBy = Query("createdAt", alias="sortBy"),
    sort_order: service.SortOrder = Query("desc", alias="sortOrder"),
    actor: CurrentUser = Depends(admin_only),
):
    users, total = await service.list_users(
        actor,
        page=page,
        limit=limit,
        search=search,
        role=role,
        is_active=is_active,
        sort_by=sort_by,
        sort_order=sort_order,
    )
    return send_success(users, "Users fetched successfully", meta=build_page_meta(page=page, limit=limit, total=total))


@router.post(
    "/users",
    status_code=201,
    summary="Create a user",
    description=(
        "Creates a member or an admin with a system-generated temporary password, returned ONCE. "
        "The user must change it at first login."
    ),
    response_model=SuccessResponse[UserWithTemporaryPasswordOut],
    responses={409: documented_error("`EMAIL_ALREADY_EXISTS`")},
)
async def create_user(payload: CreateUserRequest, actor: CurrentUser = Depends(admin_only)):
    user, temporary_password = await service.create_user(actor, payload)
    body = UserWithTemporaryPasswordOut(user=user, temporary_password=temporary_password)
    return send_created(body, "User created successfully")


@router.get("/users/{user_id}", summary="Get one user", response_model=SuccessResponse[AdminUserOut])
async def get_user(user_id: int = UserId, actor: CurrentUser = Depends(admin_only)):
    user = await service.get_user(actor, user_id)
    return send_success(user, "User fetched successfully")


@router.patch(
    "/users/{user_id}",
    summary="Update a user's full name",
    description="Admins: members only. The e-mail is immutable.",
    response_model=SuccessResponse[AdminUserOut],
)
async def update_user(payload: UpdateUserRequest, user_id: int = UserId, actor: CurrentUser = Depends(admin_only)):
    user = await service.update_user_name(actor, user_id, payload.full_name)
    return send_success(user, "User updated successfully")


@router.patch(
    "/users/{user_id}/role",
    summary="Change a user's role",
    description="Admins can only promote a member to admin. Demoting is for the super admin.",
    response_model=SuccessResponse[AdminUserOut],
    responses={
        404: documented_error("`USER_NOT_FOUND`, `ROLE_NOT_FOUND`"),
        409: documented_error("`CONFLICT`: the user already has this role"),
    },
)
async def change_role(payload: ChangeRoleRequest, user_id: int = UserId, actor: CurrentUser = Depends(admin_only)):
    user = await service.change_user_role(actor, user_id, payload.role)
    return send_success(user, "Role changed successfully")


@router.patch(
    "/users/{user_id}/status",
    summary="Activate or deactivate a user",
    description="Admins: members only. An inactive user can sign in but can do almost nothing.",
    response_model=SuccessResponse[AdminUserOut],
)
async def change_status(payload: ChangeStatusRequest, user_id: int = UserId, actor: CurrentUser = Depends(admin_only)):
    user = await service.set_user_status(actor, user_id, payload.is_active)
    message = "User activated successfully" if payload.is_active else "User deactivated successfully"
    return send_success(user, message)


@router.post(
    "/users/{user_id}/reset-password",
    summary="Reset a user's password",
    description=(
        "Admins: members only (only the super admin may reset an admin). Returns a temporary password ONCE; "
        "the user must change it at next login and all their sessions are ended."
    ),
    response_model=SuccessResponse[UserWithTemporaryPasswordOut],
)
async def reset_password(user_id: int = UserId, actor: CurrentUser = Depends(admin_only)):
    user, temporary_password = await service.reset_user_password(actor, user_id)
    body = UserWithTemporaryPasswordOut(user=user, temporary_password=temporary_password)
    return send_success(body, "Password reset successfully")


@router.delete(
    "/users/{user_id}",
    summary="Delete a user",
    description="Soft delete. Admins: members only (only the super admin may delete an admin).",
    response_model=SuccessResponse[None],
)
async def delete_user(user_id: int = UserId, actor: CurrentUser = Depends(admin_only)):
    await service.delete_user(actor, user_id)
    return send_success(None, "User deleted successfully")
