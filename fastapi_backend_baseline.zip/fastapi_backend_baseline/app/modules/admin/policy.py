"""Instance-level authorization: may THIS actor act on THAT target user?

`authorize(...)` in `dependencies/auth.py` answers the route-level question "may this
ROLE call this endpoint at all?". This file answers the second question, for one
specific target. These are PURE functions (no database, no HTTP): they take plain
data and either return silently or raise, which also makes them trivial to test as a table.

THE RULES
  1. HIERARCHY   A user can manage only people ranked STRICTLY BELOW them:
                 super_admin (1000) > admin (2) > member (1).
  2. ASSIGNING   A role can be given only if its level <= the actor's own level.
                 So an admin can create admins and promote a member to admin, but
                 nobody can create another super admin. Once promoted, the new admin
                 is a protected peer: other admins cannot edit, demote, deactivate,
                 reset or delete them (only the super admin can).
  3. SELF        Nobody uses the admin endpoints on their own account
                 (403 SELF_ACTION_NOT_ALLOWED); `/users/me` exists for that. This
                 prevents self-lockout and self-escalation.
  4. SUPER ADMIN It is invisible to admins (404, as if it did not exist) and cannot be
                 modified by anybody, not even by itself (403 SUPER_ADMIN_PROTECTED):
                 it is managed through ENV.
"""

from dataclasses import dataclass

from app.core.constants import SUPER_ADMIN_USER_ID
from app.core.current_user import CurrentUser
from app.errors.exceptions import ForbiddenError, NotFoundError


@dataclass(frozen=True)
class TargetUser:
    """The few facts about the target that the rules need."""

    user_id: int
    role: str | None
    role_level: int  # 0 when the user has no role

    @property
    def is_super_admin(self) -> bool:
        return self.user_id == SUPER_ADMIN_USER_ID


def assert_can_view_user(actor: CurrentUser, target: TargetUser) -> None:
    """Admins may view other admins (read-only), but never see the super admin."""
    if target.is_super_admin and not actor.is_super_admin:
        raise NotFoundError("User not found.", code="USER_NOT_FOUND")


def assert_can_manage_user(actor: CurrentUser, target: TargetUser) -> None:
    """For every action that CHANGES the target: update, role, status, reset password, delete."""
    assert_can_view_user(actor, target)  # a hidden user cannot be targeted at all

    if target.is_super_admin:
        raise ForbiddenError(
            "The super admin account is managed through the server environment, not through the API.",
            code="SUPER_ADMIN_PROTECTED",
        )
    if target.user_id == actor.user_id:
        raise ForbiddenError(
            "You cannot use the admin endpoints on your own account. Use /users/me instead.",
            code="SELF_ACTION_NOT_ALLOWED",
        )
    if target.role_level >= actor.role_level:
        raise ForbiddenError(
            "You can only manage users whose role is below yours.",
            code="INSUFFICIENT_ROLE",
        )


def assert_can_assign_role(actor: CurrentUser, role_name: str, role_level: int) -> None:
    if role_level > actor.role_level:
        raise ForbiddenError(f"You cannot assign the role '{role_name}'.", code="INSUFFICIENT_ROLE")
