"""Request and response models of the admin module."""

from typing import Literal

from app.modules.users.schemas import UserOut
from app.utils.schemas import FullName, NormalizedEmail, RequestModel, ResponseModel

# Assignable role names. `super_admin` is deliberately absent: it can never be assigned.
AssignableRole = Literal["admin", "member"]


class AdminUserOut(UserOut):
    """What admins see: a user plus who created the account."""

    created_by: int | None  # null = self-registered, 1 = created by the super admin


class UserWithTemporaryPasswordOut(ResponseModel):
    user: AdminUserOut
    temporary_password: str  # shown ONCE; the user must change it at first login


class CreateUserRequest(RequestModel):
    full_name: FullName
    email: NormalizedEmail
    role: AssignableRole


class UpdateUserRequest(RequestModel):
    full_name: FullName  # the e-mail is immutable


class ChangeRoleRequest(RequestModel):
    role: AssignableRole


class ChangeStatusRequest(RequestModel):
    is_active: bool
