"""User administration (admins and the super admin) and ALL of its SQL.

Every state-changing function follows the same three steps:

    target = await _load_target(actor, user_id)        # 404 if it does not exist or is hidden
    policy.assert_can_manage_user(actor, target)       # hierarchy / self / super admin rules
    ... do the change ...                              # then log an audit line

The rules themselves live in `policy.py`; this file only calls them.
"""

from typing import Any, Literal

from app.core.constants import ROLE_SUPER_ADMIN, SUPER_ADMIN_LEVEL, SUPER_ADMIN_USER_ID
from app.core.current_user import CurrentUser
from app.core.database import Row, db
from app.core.logger import get_logger
from app.core.security import hash_password
from app.errors.exceptions import ConflictError, NotFoundError
from app.modules.admin import policy
from app.modules.admin.policy import TargetUser
from app.modules.admin.schemas import AdminUserOut, CreateUserRequest
from app.modules.auth import credentials, tokens
from app.modules.roles import service as roles_service
from app.modules.users import service as users_service
from app.utils.clock import utcnow
from app.utils.passwords import generate_temporary_password

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# SQL
# ---------------------------------------------------------------------------

# Building blocks shared by the single-user query and the dynamic list query, so both always
# return exactly the same columns.
# The super admin has no `user_roles` row; "super_admin" is filled in by `_to_admin_user`.
_USER_COLUMNS = """
u.user_id, u.full_name, u.email, u.is_active, u.last_login, u.created_at, u.created_by,
COALESCE(p.must_change_password, FALSE) AS must_change_password,
r.role_name
"""

_USER_JOINS = """
FROM users u
LEFT JOIN user_roles ur ON ur.user_id = u.user_id
LEFT JOIN roles r ON r.role_id = ur.role_id
LEFT JOIN user_passwords p ON p.user_id = u.user_id
"""

SQL_USER_BY_ID = "SELECT " + _USER_COLUMNS + _USER_JOINS + "WHERE u.user_id = %s AND u.is_deleted = FALSE"

# The few facts the policy needs about a target.
SQL_TARGET_BY_ID = """
SELECT u.user_id, r.role_name, r.role_level
FROM users u
LEFT JOIN user_roles ur ON ur.user_id = u.user_id
LEFT JOIN roles r ON r.role_id = ur.role_id
WHERE u.user_id = %s AND u.is_deleted = FALSE
"""

SQL_UPDATE_FULL_NAME = "UPDATE users SET full_name = %s WHERE user_id = %s AND is_deleted = FALSE"

SQL_UPDATE_IS_ACTIVE = "UPDATE users SET is_active = %s WHERE user_id = %s AND is_deleted = FALSE"

# Whitelists for the dynamic list query: the client chooses a KEY, never SQL text.
_SORT_COLUMNS = {
    "createdAt": "u.created_at",
    "fullName": "u.full_name",
    "email": "u.email",
    "lastLogin": "u.last_login",
}
_SORT_DIRECTIONS = {"asc": "ASC", "desc": "DESC"}

SortBy = Literal["createdAt", "fullName", "email", "lastLogin"]
SortOrder = Literal["asc", "desc"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _to_admin_user(row: Row) -> AdminUserOut:
    role = ROLE_SUPER_ADMIN if row["user_id"] == SUPER_ADMIN_USER_ID else row["role_name"]
    return AdminUserOut.model_validate({**row, "role": role})


def _escape_like(term: str) -> str:
    """Make `%`, `_` and `\\` in a search term literal characters instead of LIKE wildcards."""
    return term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


async def _load_target(actor: CurrentUser, user_id: int) -> TargetUser:
    """The user an action is aimed at. A hidden user (the super admin, for admins) is a 404."""
    if user_id == SUPER_ADMIN_USER_ID and not actor.is_super_admin:
        raise NotFoundError("User not found.", code="USER_NOT_FOUND")
    row = await db.fetch_one(SQL_TARGET_BY_ID, (user_id,))
    if row is None:
        raise NotFoundError("User not found.", code="USER_NOT_FOUND")
    if user_id == SUPER_ADMIN_USER_ID:
        return TargetUser(user_id=user_id, role=ROLE_SUPER_ADMIN, role_level=SUPER_ADMIN_LEVEL)
    return TargetUser(user_id=user_id, role=row["role_name"], role_level=int(row["role_level"] or 0))


def _audit(action: str, actor: CurrentUser, target_id: int, **extra: Any) -> None:
    logger.info(f"Admin action: {action}", extra={"data": {"actorId": actor.user_id, "targetId": target_id, **extra}})


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------
async def list_users(
    actor: CurrentUser,
    *,
    page: int,
    limit: int,
    search: str | None,
    role: str | None,
    is_active: bool | None,
    sort_by: SortBy,
    sort_order: SortOrder,
) -> tuple[list[AdminUserOut], int]:
    """A page of users plus the total count. Soft-deleted users never appear."""
    conditions = ["u.is_deleted = FALSE"]
    params: list[Any] = []

    if not actor.is_super_admin:  # the super admin is invisible to admins
        conditions.append("u.user_id <> %s")
        params.append(SUPER_ADMIN_USER_ID)
    if search:
        conditions.append("(u.full_name LIKE %s OR u.email LIKE %s)")
        pattern = f"%{_escape_like(search.strip())}%"
        params += [pattern, pattern]
    if role:
        conditions.append("r.role_name = %s")
        params.append(role)
    if is_active is not None:
        conditions.append("u.is_active = %s")
        params.append(is_active)

    # ONLY fixed SQL fragments are joined together below (conditions written above, columns from
    # the whitelists). Every value, including the search text, travels through `params`.
    where = " AND ".join(conditions)
    direction = _SORT_DIRECTIONS[sort_order]
    order_by = f"{_SORT_COLUMNS[sort_by]} {direction}, u.user_id {direction}"

    total_row = await db.fetch_one("SELECT COUNT(*) AS total " + _USER_JOINS + " WHERE " + where, params)
    rows = await db.fetch_all(
        "SELECT " + _USER_COLUMNS + _USER_JOINS + " WHERE " + where + " ORDER BY " + order_by + " LIMIT %s OFFSET %s",
        [*params, limit, (page - 1) * limit],
    )
    return [_to_admin_user(row) for row in rows], int(total_row["total"])


async def get_user(actor: CurrentUser, user_id: int) -> AdminUserOut:
    """Admins may view other admins (read-only) but never the super admin (404)."""
    target = await _load_target(actor, user_id)
    policy.assert_can_view_user(actor, target)
    row = await db.fetch_one(SQL_USER_BY_ID, (user_id,))
    if row is None:
        raise NotFoundError("User not found.", code="USER_NOT_FOUND")
    return _to_admin_user(row)


# ---------------------------------------------------------------------------
# Creating
# ---------------------------------------------------------------------------
async def create_user(actor: CurrentUser, payload: CreateUserRequest) -> tuple[AdminUserOut, str]:
    """Create a member or admin with a one-time temporary password.

    The new user must change that password at first login (`must_change_password`) and
    has no security profile until they set one after signing in.
    """
    role = await _find_assignable_role(actor, payload.role)
    if await users_service.email_is_taken(payload.email):
        raise ConflictError("An account with this e-mail address already exists.", code="EMAIL_ALREADY_EXISTS")

    temporary_password = generate_temporary_password()
    password_hash = await hash_password(temporary_password)  # slow part first, outside the transaction
    now = utcnow()

    async with db.transaction() as tx:
        user_id = await users_service.create_user(
            tx, full_name=payload.full_name, email=payload.email, created_by=actor.user_id
        )
        await credentials.create_password(
            tx,
            user_id=user_id,
            password_hash=password_hash,
            must_change_password=True,
            created_by=actor.user_id,
            now=now,
        )
        await roles_service.set_user_role(tx, user_id=user_id, role_id=role["role_id"], actor_id=actor.user_id, now=now)

    _audit("create user", actor, user_id, role=payload.role)
    return await get_user(actor, user_id), temporary_password


async def _find_assignable_role(actor: CurrentUser, role_name: str) -> Row:
    role = await roles_service.find_role_by_name(role_name)
    if role is None:
        raise NotFoundError("Role not found.", code="ROLE_NOT_FOUND")
    policy.assert_can_assign_role(actor, role["role_name"], int(role["role_level"] or 0))
    return role


# ---------------------------------------------------------------------------
# Changing
# ---------------------------------------------------------------------------
async def update_user_name(actor: CurrentUser, user_id: int, full_name: str) -> AdminUserOut:
    target = await _load_target(actor, user_id)
    policy.assert_can_manage_user(actor, target)
    await db.execute(SQL_UPDATE_FULL_NAME, (full_name, user_id))
    _audit("update user", actor, user_id)
    return await get_user(actor, user_id)


async def change_user_role(actor: CurrentUser, user_id: int, role_name: str) -> AdminUserOut:
    """Admins can only PROMOTE members to admin; demoting is up to the super admin (see policy.py)."""
    target = await _load_target(actor, user_id)
    policy.assert_can_manage_user(actor, target)
    role = await _find_assignable_role(actor, role_name)
    if target.role == role["role_name"]:
        raise ConflictError(f"The user already has the role '{role_name}'.")

    await roles_service.set_user_role(
        db, user_id=user_id, role_id=role["role_id"], actor_id=actor.user_id, now=utcnow()
    )
    _audit("change role", actor, user_id, fromRole=target.role, toRole=role["role_name"])
    return await get_user(actor, user_id)


async def set_user_status(actor: CurrentUser, user_id: int, is_active: bool) -> AdminUserOut:
    """Deactivate / reactivate. An inactive user can still sign in but can do almost nothing."""
    target = await _load_target(actor, user_id)
    policy.assert_can_manage_user(actor, target)
    await db.execute(SQL_UPDATE_IS_ACTIVE, (is_active, user_id))
    _audit("activate user" if is_active else "deactivate user", actor, user_id)
    return await get_user(actor, user_id)


async def reset_user_password(actor: CurrentUser, user_id: int) -> tuple[AdminUserOut, str]:
    """Replace the password with a system-generated temporary one.

    Admins never choose or see a real password. The temporary one is shown once, must be
    changed at next login, and every session of the user is ended.
    """
    target = await _load_target(actor, user_id)
    policy.assert_can_manage_user(actor, target)

    temporary_password = generate_temporary_password()
    password_hash = await hash_password(temporary_password)
    now = utcnow()
    async with db.transaction() as tx:
        updated = await credentials.update_password(
            tx,
            user_id=user_id,
            password_hash=password_hash,
            must_change_password=True,
            updated_by=actor.user_id,
            now=now,
        )
        if not updated:  # a user without a password row (corrupt data): create it
            await credentials.create_password(
                tx,
                user_id=user_id,
                password_hash=password_hash,
                must_change_password=True,
                created_by=actor.user_id,
                now=now,
            )
        await tokens.revoke_all_refresh_tokens(tx, user_id, now)
        await tokens.invalidate_pending_reset_tokens(tx, user_id, now)

    _audit("reset password", actor, user_id)
    return await get_user(actor, user_id), temporary_password


async def delete_user(actor: CurrentUser, user_id: int) -> None:
    """Soft delete (ends every session, frees the e-mail address)."""
    target = await _load_target(actor, user_id)
    policy.assert_can_manage_user(actor, target)
    await users_service.close_account(user_id)
    _audit("delete user", actor, user_id)
