"""`/api/v1/auth`: sign-up, sessions, password change, security profile, forgot password.

Routers stay thin: they declare WHO may call (dependencies), HOW OFTEN (rate limits)
and the HTTP shape, then hand over to `service.py`, which holds the logic and the SQL.
"""

from fastapi import APIRouter, Cookie, Depends

from app.core.config import settings
from app.core.constants import ROLE_ADMIN, ROLE_MEMBER, TOKEN_TYPE
from app.core.current_user import CurrentUser
from app.core.rate_limit_rules import (
    CHANGE_PASSWORD_PER_IP,
    FORGOT_QUESTIONS_PER_IP,
    FORGOT_QUESTIONS_PER_IP_EMAIL,
    FORGOT_RESET_PER_IP,
    FORGOT_VERIFY_PER_IP,
    FORGOT_VERIFY_PER_IP_EMAIL,
    LOGIN_PER_IP,
    LOGIN_PER_IP_EMAIL,
    REFRESH_PER_IP,
    REGISTER_PER_IP,
    SECURITY_PROFILE_WRITE_PER_IP,
)
from app.dependencies.auth import authenticate, authorize
from app.dependencies.rate_limit import limit_by_ip, limit_by_ip_and_email
from app.errors.responses import PROTECTED_RESPONSES, documented_error
from app.modules.auth import service
from app.modules.auth.cookies import clear_refresh_cookie, set_refresh_cookie
from app.modules.auth.schemas import (
    AuthSessionOut,
    ChangePasswordRequest,
    ForgotQuestionsRequest,
    ForgotResetRequest,
    ForgotVerifyRequest,
    LoginRequest,
    RegisterRequest,
    ResetTokenOut,
    SecurityProfileStatusOut,
    SecurityProfileUpdateRequest,
    SecurityQuestionsOut,
)
from app.modules.users.schemas import UserOut
from app.utils.response import send_created, send_success
from app.utils.schemas import SuccessResponse

router = APIRouter(prefix="/auth", tags=["Auth"])

# Members and admins only; the super admin (managed through ENV) gets 403 SUPER_ADMIN_PROTECTED.
self_service_user = authorize(ROLE_MEMBER, ROLE_ADMIN, include_super_admin=False)


def _session_response(user: UserOut, session: service.Session, message: str):
    """Access token in the body, refresh token in an httpOnly cookie."""
    body = AuthSessionOut(
        access_token=session.access_token,
        token_type=TOKEN_TYPE,
        expires_in=session.expires_in,
        user=user,
    )
    response = send_success(body, message)
    set_refresh_cookie(response, session.refresh_token)
    return response


# ---------------------------------------------------------------------------
# Public
# ---------------------------------------------------------------------------
@router.get(
    "/security-questions",
    summary="The fixed recovery questions",
    description="Questions 1-3 are the same for everyone. Use them to build the sign-up form.",
    response_model=SuccessResponse[SecurityQuestionsOut],
)
async def security_questions():
    return send_success(service.get_fixed_security_questions(), "Security questions fetched successfully")


@router.post(
    "/register",
    status_code=201,
    summary="Sign up",
    description=(
        "Always creates a **member**. The security profile is mandatory (it is how a forgotten password is "
        "recovered; there is no e-mail). Does **not** sign the user in."
    ),
    response_model=SuccessResponse[UserOut],
    responses={
        403: documented_error("`REGISTRATION_DISABLED`"),
        409: documented_error("`EMAIL_ALREADY_EXISTS`"),
    },
    dependencies=[Depends(limit_by_ip(REGISTER_PER_IP))],
)
async def register(payload: RegisterRequest):
    user = await service.register(payload)
    return send_created(user, "Account created successfully")


@router.post(
    "/login",
    summary="Sign in",
    description=(
        "Returns an access token (15 minutes) and sets the rotating refresh token as an httpOnly cookie. "
        "Inactive accounts can sign in but can do almost nothing; see `user.isActive` / `user.mustChangePassword`."
    ),
    response_model=SuccessResponse[AuthSessionOut],
    responses={401: documented_error("`INVALID_CREDENTIALS`"), 403: documented_error("`ROLE_NOT_ASSIGNED`")},
    dependencies=[Depends(limit_by_ip(LOGIN_PER_IP))],
)
async def login(payload: LoginRequest):
    await limit_by_ip_and_email(LOGIN_PER_IP_EMAIL, payload.email)
    user, session = await service.login(payload.email, payload.password)
    return _session_response(user, session, "Signed in successfully")


@router.post(
    "/refresh",
    summary="Rotate the refresh token",
    description=(
        "Reads the refresh cookie. The used token is revoked and a new one is issued. "
        "Presenting an already-rotated token again revokes **every** session of that user."
    ),
    response_model=SuccessResponse[AuthSessionOut],
    responses={401: documented_error("`UNAUTHORIZED`, `TOKEN_INVALID`, `TOKEN_EXPIRED`")},
    dependencies=[Depends(limit_by_ip(REFRESH_PER_IP))],
)
async def refresh(refresh_token: str | None = Cookie(default=None, alias=settings.REFRESH_COOKIE_NAME)):
    user, session = await service.refresh_session(refresh_token)
    return _session_response(user, session, "Session refreshed successfully")


@router.post(
    "/logout",
    summary="End this session",
    description="Idempotent: succeeds even without a cookie or with an unknown token.",
    response_model=SuccessResponse[None],
)
async def logout(refresh_token: str | None = Cookie(default=None, alias=settings.REFRESH_COOKIE_NAME)):
    await service.logout(refresh_token)
    response = send_success(None, "Signed out successfully")
    clear_refresh_cookie(response)
    return response


# ---------------------------------------------------------------------------
# Signed in
# ---------------------------------------------------------------------------
@router.post(
    "/logout-all",
    summary="End every session",
    description="Allowed for inactive accounts and accounts that must change their password.",
    response_model=SuccessResponse[None],
    responses=PROTECTED_RESPONSES,
)
async def logout_all(
    current_user: CurrentUser = Depends(authenticate(allow_inactive=True, allow_password_change_pending=True)),
):
    await service.logout_all(current_user)
    response = send_success(None, "Signed out of all sessions successfully")
    clear_refresh_cookie(response)
    return response


@router.post(
    "/change-password",
    summary="Change own password",
    description=(
        "Ends every session but keeps THIS device signed in: the response carries fresh tokens. "
        "Also the way out of `PASSWORD_CHANGE_REQUIRED` after an admin-created account or an admin reset."
    ),
    response_model=SuccessResponse[AuthSessionOut],
    responses={**PROTECTED_RESPONSES, 400: documented_error("`INVALID_CURRENT_PASSWORD`")},
    dependencies=[Depends(limit_by_ip(CHANGE_PASSWORD_PER_IP))],
)
async def change_password(
    payload: ChangePasswordRequest,
    current_user: CurrentUser = Depends(
        authorize(ROLE_MEMBER, ROLE_ADMIN, include_super_admin=False, allow_password_change_pending=True)
    ),
):
    user, session = await service.change_password(current_user, payload.current_password, payload.new_password)
    return _session_response(user, session, "Password changed successfully")


@router.get(
    "/security-profile",
    summary="Is the recovery profile configured?",
    response_model=SuccessResponse[SecurityProfileStatusOut],
    responses=PROTECTED_RESPONSES,
)
async def get_security_profile(current_user: CurrentUser = Depends(self_service_user)):
    status = await service.get_security_profile_status(current_user.user_id)
    return send_success(status, "Security profile status fetched successfully")


@router.put(
    "/security-profile",
    summary="Create or replace the recovery profile",
    description=(
        "Needs the current password: the recovery answers are a second key to the account. "
        "Accounts created by an admin have no profile until they set one here."
    ),
    response_model=SuccessResponse[SecurityProfileStatusOut],
    responses={**PROTECTED_RESPONSES, 400: documented_error("`INVALID_CURRENT_PASSWORD`")},
    dependencies=[Depends(limit_by_ip(SECURITY_PROFILE_WRITE_PER_IP))],
)
async def save_security_profile(
    payload: SecurityProfileUpdateRequest, current_user: CurrentUser = Depends(self_service_user)
):
    status = await service.save_security_profile(current_user, payload)
    return send_success(status, "Security profile saved successfully")


# ---------------------------------------------------------------------------
# Forgot password (public, no e-mail involved)
# ---------------------------------------------------------------------------
@router.post(
    "/forgot-password/questions",
    summary="Questions to ask for an e-mail",
    description=(
        "Always answers with the three fixed questions; the account's own custom questions are added when they "
        "exist. An unknown e-mail looks exactly like a known one without custom questions."
    ),
    response_model=SuccessResponse[SecurityQuestionsOut],
    dependencies=[Depends(limit_by_ip(FORGOT_QUESTIONS_PER_IP))],
)
async def forgot_password_questions(payload: ForgotQuestionsRequest):
    await limit_by_ip_and_email(FORGOT_QUESTIONS_PER_IP_EMAIL, payload.email)
    questions = await service.get_recovery_questions(payload.email)
    return send_success(questions, "Security questions fetched successfully")


@router.post(
    "/forgot-password/verify",
    summary="Verify the answers",
    description=(
        "All answers must be correct. Five wrong attempts lock recovery for the account for 15 minutes "
        "(`ACCOUNT_LOCKED`, with `Retry-After`). On success returns a reset token (valid 10 minutes, single use)."
    ),
    response_model=SuccessResponse[ResetTokenOut],
    responses={
        401: documented_error("`INVALID_SECURITY_ANSWERS`"),
        429: documented_error("`RATE_LIMITED`, `ACCOUNT_LOCKED`"),
    },
    dependencies=[Depends(limit_by_ip(FORGOT_VERIFY_PER_IP))],
)
async def forgot_password_verify(payload: ForgotVerifyRequest):
    await limit_by_ip_and_email(FORGOT_VERIFY_PER_IP_EMAIL, payload.email)
    token = await service.verify_security_answers(payload)
    return send_success(token, "Answers verified successfully")


@router.post(
    "/forgot-password/reset",
    summary="Set a new password with the reset token",
    description="Ends every session of the account. Does not sign in: the user signs in with the new password.",
    response_model=SuccessResponse[None],
    responses={400: documented_error("`RESET_TOKEN_INVALID`")},
    dependencies=[Depends(limit_by_ip(FORGOT_RESET_PER_IP))],
)
async def forgot_password_reset(payload: ForgotResetRequest):
    await service.reset_password(payload.reset_token, payload.new_password)
    return send_success(None, "Password reset successfully")
