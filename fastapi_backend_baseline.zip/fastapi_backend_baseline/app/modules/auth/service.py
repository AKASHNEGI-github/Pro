"""Authentication business logic and the SQL it needs.

Sections of this file, top to bottom:
  1. SQL                       every query of this module, as named constants
  2. Small data classes
  3. Per-request authentication record   (used by `dependencies/auth.py`)
  4. Sign-up
  5. Sessions                  login, refresh (rotation + reuse detection), logout
  6. Change password
  7. Security profile          the answers that allow recovering a forgotten password
  8. Forgot password           questions -> verify answers -> reset

Security rules you will see applied below:
  * a wrong e-mail and a wrong password give the SAME error and take the same time
  * slow hashing (bcrypt) happens BEFORE a transaction starts, never while rows are locked
  * secrets (passwords, answers, tokens) are never logged
  * every timestamp comes from the application clock (`utcnow()`)
"""

import asyncio
import math
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Literal

from app.core.config import settings
from app.core.constants import (
    FIXED_SECURITY_QUESTIONS,
    PASSWORD_RESET_TOKEN_TTL_MINUTES,
    RECOVERY_LOCK_MINUTES,
    RECOVERY_MAX_FAILED_ATTEMPTS,
    ROLE_MEMBER,
    SUPER_ADMIN_USER_ID,
)
from app.core.context import get_client_ip, get_user_agent
from app.core.current_user import CurrentUser
from app.core.database import Row, SqlExecutor, db
from app.core.logger import get_logger
from app.core.security import (
    burn_verification_time,
    create_access_token,
    generate_opaque_token,
    hash_password,
    hash_security_answer,
    hash_token,
    verify_password,
    verify_security_answer,
)
from app.errors.exceptions import (
    BadRequestError,
    ConflictError,
    ForbiddenError,
    InternalServerError,
    TooManyRequestsError,
    UnauthorizedError,
    ValidationError,
)
from app.modules.auth import credentials, tokens
from app.modules.auth.schemas import (
    ForgotVerifyRequest,
    RegisterRequest,
    ResetTokenOut,
    SecurityProfileInput,
    SecurityProfileStatusOut,
    SecurityProfileUpdateRequest,
    SecurityQuestionOut,
    SecurityQuestionsOut,
)
from app.modules.roles import service as roles_service
from app.modules.users import service as users_service
from app.modules.users.schemas import UserOut
from app.utils.clock import utcnow
from app.utils.privacy import mask_email

logger = get_logger(__name__)

# ===========================================================================
# 1. SQL
# ===========================================================================

# --- per-request authentication (by user id) and sign-in (by e-mail) --------
# A role only counts when it is active and not deleted; otherwise `role_name` is NULL
# and the account has "no active role".
SQL_AUTHENTICATION_RECORD_BY_ID = """
SELECT u.user_id, u.full_name, u.email, u.is_active,
       p.must_change_password, p.updated_at AS password_changed_at,
       r.role_name, r.role_level
FROM users u
LEFT JOIN user_passwords p ON p.user_id = u.user_id
LEFT JOIN user_roles ur ON ur.user_id = u.user_id
LEFT JOIN roles r ON r.role_id = ur.role_id AND r.is_active = TRUE AND r.is_deleted = FALSE
WHERE u.user_id = %s AND u.is_deleted = FALSE
"""

SQL_LOGIN_RECORD_BY_EMAIL = """
SELECT u.user_id, p.hash_password, r.role_name
FROM users u
LEFT JOIN user_passwords p ON p.user_id = u.user_id
LEFT JOIN user_roles ur ON ur.user_id = u.user_id
LEFT JOIN roles r ON r.role_id = ur.role_id AND r.is_active = TRUE AND r.is_deleted = FALSE
WHERE u.email_active = %s
"""

SQL_UPDATE_LAST_LOGIN = "UPDATE users SET last_login = %s WHERE user_id = %s"

SQL_INSERT_LOGIN_LOG = """
INSERT INTO user_login_logs (user_id, login_time, login_status, failure_reason, ip_address)
VALUES (%s, %s, %s, %s, %s)
"""

# --- security profile --------------------------------------------------------
SQL_SELECT_SECURITY_PROFILE_FOR_UPDATE = "SELECT user_id FROM user_security_profiles WHERE user_id = %s FOR UPDATE"

SQL_INSERT_SECURITY_PROFILE = """
INSERT INTO user_security_profiles (
    user_id, dob_hash, answer_q2_hash, answer_q3_hash,
    custom_question_1, custom_answer_1_hash, custom_question_2, custom_answer_2_hash,
    failed_attempts, locked_until, created_at, updated_at)
VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 0, NULL, %s, %s)
"""

# Replacing the answers also clears any lockout.
SQL_UPDATE_SECURITY_PROFILE = """
UPDATE user_security_profiles
SET dob_hash = %s, answer_q2_hash = %s, answer_q3_hash = %s,
    custom_question_1 = %s, custom_answer_1_hash = %s,
    custom_question_2 = %s, custom_answer_2_hash = %s,
    failed_attempts = 0, locked_until = NULL, updated_at = %s
WHERE user_id = %s
"""

SQL_SECURITY_PROFILE_STATUS = """
SELECT custom_question_1, custom_question_2, updated_at
FROM user_security_profiles
WHERE user_id = %s
"""

# --- forgot password -----------------------------------------------------------
# The super admin is excluded: its credentials live in ENV, so recovery does not apply.
SQL_RECOVERY_QUESTIONS_BY_EMAIL = """
SELECT s.custom_question_1, s.custom_question_2
FROM users u
JOIN user_security_profiles s ON s.user_id = u.user_id
WHERE u.email_active = %s AND u.user_id <> %s
"""

SQL_RECOVERY_PROFILE_BY_EMAIL = """
SELECT u.user_id,
       s.dob_hash, s.answer_q2_hash, s.answer_q3_hash,
       s.custom_answer_1_hash, s.custom_answer_2_hash,
       s.failed_attempts, s.locked_until
FROM users u
JOIN user_security_profiles s ON s.user_id = u.user_id
WHERE u.email_active = %s AND u.user_id <> %s
"""

# Counts one wrong attempt atomically. After the limit is reached the account is locked
# and the counter starts again from 0.
# NOTE: MySQL evaluates the assignments of an UPDATE LEFT TO RIGHT and later ones see the
# already-updated columns. `locked_until` is therefore assigned BEFORE `failed_attempts`,
# so both expressions read the ORIGINAL attempt count. Do not reorder them.
SQL_REGISTER_FAILED_RECOVERY_ATTEMPT = """
UPDATE user_security_profiles
SET locked_until = IF(failed_attempts + 1 >= %s, %s, locked_until),
    failed_attempts = IF(failed_attempts + 1 >= %s, 0, failed_attempts + 1)
WHERE user_id = %s
"""

SQL_RESET_RECOVERY_COUNTERS = """
UPDATE user_security_profiles
SET failed_attempts = 0, locked_until = NULL
WHERE user_id = %s
"""

# Names mixed into each answer's HMAC (see core/security.py); never change them,
# or every stored answer would stop verifying.
FIELD_DOB = "dob"
FIELD_Q2 = "q2"
FIELD_Q3 = "q3"
FIELD_CUSTOM_1 = "custom1"
FIELD_CUSTOM_2 = "custom2"


# ===========================================================================
# 2. Small data classes
# ===========================================================================
@dataclass(frozen=True)
class Session:
    """What a successful login / refresh / password change hands to the router."""

    access_token: str
    expires_in: int
    refresh_token: str  # raw value; goes into the httpOnly cookie, never into the body


@dataclass(frozen=True)
class SecurityProfileHashes:
    dob_hash: str
    answer_q2_hash: str
    answer_q3_hash: str
    custom_question_1: str | None
    custom_answer_1_hash: str | None
    custom_question_2: str | None
    custom_answer_2_hash: str | None


# ===========================================================================
# 3. Per-request authentication record
# ===========================================================================
async def load_authentication_record(user_id: int, executor: SqlExecutor = db) -> Row | None:
    """Fresh account data for `authenticate`, read on EVERY request (never trusted from the token)."""
    return await executor.fetch_one(SQL_AUTHENTICATION_RECORD_BY_ID, (user_id,))


# ===========================================================================
# 4. Sign-up
# ===========================================================================
async def register(payload: RegisterRequest) -> UserOut:
    """Create a MEMBER account together with its mandatory security profile. Does not sign the user in."""
    if not settings.SELF_REGISTRATION_ENABLED:
        raise ForbiddenError("Self-registration is disabled.", code="REGISTRATION_DISABLED")

    # Cheap early exit before any hashing. The UNIQUE index (checked again inside
    # `create_user`) is the real guard when two sign-ups race.
    if await users_service.email_is_taken(payload.email):
        raise ConflictError("An account with this e-mail address already exists.", code="EMAIL_ALREADY_EXISTS")

    member_role = await roles_service.find_role_by_name(ROLE_MEMBER)
    if member_role is None:
        logger.error("The 'member' role is missing. Load database/seed.sql.")
        raise InternalServerError()

    # Slow hashing first (in parallel threads); the transaction below is then short.
    password_hash, profile_hashes = await asyncio.gather(
        hash_password(payload.password),
        _hash_security_profile(payload.security_profile),
    )

    now = utcnow()
    async with db.transaction() as tx:
        # created_by = NULL means "self-registered".
        user_id = await users_service.create_user(
            tx, full_name=payload.full_name, email=payload.email, created_by=None
        )
        await credentials.create_password(
            tx, user_id=user_id, password_hash=password_hash, must_change_password=False, created_by=None, now=now
        )
        await roles_service.set_user_role(tx, user_id=user_id, role_id=member_role["role_id"], actor_id=None, now=now)
        await _write_security_profile(tx, user_id, profile_hashes, now)

    logger.info("User registered", extra={"data": {"userId": user_id}})
    return await users_service.get_profile(user_id)


# ===========================================================================
# 5. Sessions: login, refresh, logout
# ===========================================================================
def _invalid_credentials() -> UnauthorizedError:
    return UnauthorizedError("Incorrect e-mail or password.", code="INVALID_CREDENTIALS")


async def _record_login(
    executor: SqlExecutor, user_id: int, *, success: bool, reason: str | None, now: datetime | None = None
) -> None:
    await executor.execute(
        SQL_INSERT_LOGIN_LOG,
        (user_id, now or utcnow(), "SUCCESS" if success else "FAILURE", reason, get_client_ip()),
    )


async def _start_session(executor: SqlExecutor, user_id: int, now: datetime) -> Session:
    """Create a refresh token row and an access token. `now` is shared so timestamps agree."""
    raw_refresh_token, refresh_token_hash = generate_opaque_token()
    await tokens.store_refresh_token(
        executor,
        user_id=user_id,
        token_hash=refresh_token_hash,
        expires_at=now + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        user_agent=get_user_agent(),
        now=now,
    )
    access = create_access_token(user_id, issued_at=now)
    return Session(access_token=access.token, expires_in=access.expires_in, refresh_token=raw_refresh_token)


async def login(email: str, password: str) -> tuple[UserOut, Session]:
    record = await db.fetch_one(SQL_LOGIN_RECORD_BY_EMAIL, (email,))

    if record is None:
        await burn_verification_time()  # take as long as a real check: do not reveal which e-mails exist
        logger.warning("Login failed: unknown e-mail", extra={"data": {"email": mask_email(email)}})
        raise _invalid_credentials()

    user_id: int = record["user_id"]
    is_super_admin = user_id == SUPER_ADMIN_USER_ID
    # The super admin's password hash lives in ENV; everybody else's is in `user_passwords`.
    stored_hash = settings.SUPER_ADMIN_PASSWORD_HASH if is_super_admin else record["hash_password"]

    if stored_hash is None:
        await burn_verification_time()
        password_is_correct = False
    else:
        password_is_correct = await verify_password(password, stored_hash)

    if not password_is_correct:
        await _record_login(db, user_id, success=False, reason="Wrong password")
        logger.warning("Login failed: wrong password", extra={"data": {"userId": user_id}})
        raise _invalid_credentials()

    if not is_super_admin and record["role_name"] is None:
        await _record_login(db, user_id, success=False, reason="Account has no active role")
        raise ForbiddenError("The account has no active role.", code="ROLE_NOT_ASSIGNED")

    now = utcnow()
    async with db.transaction() as tx:
        await tx.execute(SQL_UPDATE_LAST_LOGIN, (now, user_id))
        await _record_login(tx, user_id, success=True, reason=None, now=now)
        session = await _start_session(tx, user_id, now)

    logger.info("Login succeeded", extra={"data": {"userId": user_id}})
    return await users_service.get_profile(user_id), session


RefreshVerdict = Literal["ok", "invalid", "expired", "reused"]


def _judge_refresh_token(stored: Row | None, now: datetime) -> RefreshVerdict:
    """Pure decision: what is the state of the presented refresh token?

    A token that was already ROTATED (revoked and replaced) being presented again means
    two parties hold it: the real user and a thief. That is "reused". A token that was
    revoked for another reason (logout, password change) is simply invalid.
    """
    if stored is None:
        return "invalid"
    if stored["revoked_at"] is not None:
        return "reused" if stored["replaced_by_hash"] is not None else "invalid"
    if stored["expires_at"] <= now:
        return "expired"
    return "ok"


async def refresh_session(raw_refresh_token: str | None) -> tuple[UserOut, Session]:
    """Exchange a refresh token for a new access token AND a new refresh token (rotation)."""
    if not raw_refresh_token:
        raise UnauthorizedError("The refresh token is missing. Please sign in again.")

    token_hash = hash_token(raw_refresh_token)
    now = utcnow()
    user_id: int | None = None
    session: Session | None = None

    async with db.transaction() as tx:
        stored = await tokens.get_refresh_token_for_update(tx, token_hash)  # row lock
        verdict = _judge_refresh_token(stored, now)

        if verdict == "ok":
            user_id = stored["user_id"]
            record = await load_authentication_record(user_id, tx)
            if record is None:  # the account was deleted after this token was issued
                raise UnauthorizedError("The account no longer exists.", code="TOKEN_INVALID")
            if user_id != SUPER_ADMIN_USER_ID and record["role_name"] is None:
                raise ForbiddenError("The account has no active role.", code="ROLE_NOT_ASSIGNED")
            session = await _start_session(tx, user_id, now)
            await tokens.mark_refresh_token_rotated(
                tx, old_hash=token_hash, new_hash=hash_token(session.refresh_token), now=now
            )
        elif verdict == "reused":
            # Theft signal: end EVERY session of this user. (Committed when the block ends,
            # which is why the error is raised only after it.)
            await tokens.revoke_all_refresh_tokens(tx, stored["user_id"], now)
            logger.warning(
                "Refresh token reuse detected: all sessions revoked", extra={"data": {"userId": stored["user_id"]}}
            )

    if verdict == "expired":
        raise UnauthorizedError("The refresh token has expired. Please sign in again.", code="TOKEN_EXPIRED")
    if verdict in ("invalid", "reused"):
        raise UnauthorizedError("The refresh token is invalid. Please sign in again.", code="TOKEN_INVALID")

    assert user_id is not None and session is not None
    return await users_service.get_profile(user_id), session


async def logout(raw_refresh_token: str | None) -> None:
    """End this device's session. Idempotent: an unknown or missing token is not an error."""
    if raw_refresh_token:
        await tokens.revoke_refresh_token(db, hash_token(raw_refresh_token), utcnow())


async def logout_all(user: CurrentUser) -> None:
    """End every session of the caller. (Access tokens already issued live on until they expire, <= 15 minutes.)"""
    revoked = await tokens.revoke_all_refresh_tokens(db, user.user_id, utcnow())
    logger.info("All sessions ended", extra={"data": {"userId": user.user_id, "revoked": revoked}})


# ===========================================================================
# 6. Change password
# ===========================================================================
async def change_password(user: CurrentUser, current_password: str, new_password: str) -> tuple[UserOut, Session]:
    """Set a new password, end every session, but keep THIS device signed in (fresh tokens)."""
    await credentials.verify_current_password(user.user_id, current_password)
    if current_password == new_password:
        raise ValidationError(
            "Validation failed",
            details=[{"field": "newPassword", "message": "The new password must be different from the current one."}],
        )

    new_hash = await hash_password(new_password)
    now = utcnow()
    async with db.transaction() as tx:
        await credentials.update_password(
            tx,
            user_id=user.user_id,
            password_hash=new_hash,
            must_change_password=False,
            updated_by=user.user_id,
            now=now,
        )
        await tokens.revoke_all_refresh_tokens(tx, user.user_id, now)
        # Issued with the SAME `now` as `updated_at`, so this token is not rejected as "older than the change".
        session = await _start_session(tx, user.user_id, now)

    logger.info("Password changed", extra={"data": {"userId": user.user_id}})
    return await users_service.get_profile(user.user_id), session


# ===========================================================================
# 7. Security profile
# ===========================================================================
async def _hash_security_profile(profile: SecurityProfileInput) -> SecurityProfileHashes:
    async def hash_optional(field: str, answer: str | None) -> str | None:
        return None if answer is None else await hash_security_answer(field, answer)

    dob_hash, q2_hash, q3_hash, custom_1_hash, custom_2_hash = await asyncio.gather(
        hash_security_answer(FIELD_DOB, profile.date_of_birth.isoformat()),
        hash_security_answer(FIELD_Q2, profile.answer_q2),
        hash_security_answer(FIELD_Q3, profile.answer_q3),
        hash_optional(FIELD_CUSTOM_1, profile.custom_answer_1),
        hash_optional(FIELD_CUSTOM_2, profile.custom_answer_2),
    )
    return SecurityProfileHashes(
        dob_hash=dob_hash,
        answer_q2_hash=q2_hash,
        answer_q3_hash=q3_hash,
        custom_question_1=profile.custom_question_1,
        custom_answer_1_hash=custom_1_hash,
        custom_question_2=profile.custom_question_2,
        custom_answer_2_hash=custom_2_hash,
    )


async def _write_security_profile(
    executor: SqlExecutor, user_id: int, hashes: SecurityProfileHashes, now: datetime
) -> None:
    """Insert the profile, or replace it when one exists (a user has at most one)."""
    existing = await executor.fetch_one(SQL_SELECT_SECURITY_PROFILE_FOR_UPDATE, (user_id,))
    values = (
        hashes.dob_hash,
        hashes.answer_q2_hash,
        hashes.answer_q3_hash,
        hashes.custom_question_1,
        hashes.custom_answer_1_hash,
        hashes.custom_question_2,
        hashes.custom_answer_2_hash,
    )
    if existing is None:
        await executor.execute(SQL_INSERT_SECURITY_PROFILE, (user_id, *values, now, now))
    else:
        await executor.execute(SQL_UPDATE_SECURITY_PROFILE, (*values, now, user_id))


async def get_security_profile_status(user_id: int) -> SecurityProfileStatusOut:
    row = await db.fetch_one(SQL_SECURITY_PROFILE_STATUS, (user_id,))
    if row is None:
        return SecurityProfileStatusOut(configured=False)
    return SecurityProfileStatusOut(
        configured=True,
        custom_question_1=row["custom_question_1"],
        custom_question_2=row["custom_question_2"],
        updated_at=row["updated_at"],
    )


async def save_security_profile(user: CurrentUser, payload: SecurityProfileUpdateRequest) -> SecurityProfileStatusOut:
    """Create or replace the caller's recovery answers (needs the current password)."""
    await credentials.verify_current_password(user.user_id, payload.current_password)
    hashes = await _hash_security_profile(payload)
    async with db.transaction() as tx:
        await _write_security_profile(tx, user.user_id, hashes, utcnow())
    logger.info("Security profile saved", extra={"data": {"userId": user.user_id}})
    return await get_security_profile_status(user.user_id)


# ===========================================================================
# 8. Forgot password: questions -> verify answers -> reset
# ===========================================================================
def get_fixed_security_questions() -> SecurityQuestionsOut:
    return SecurityQuestionsOut(
        questions=[
            SecurityQuestionOut(id=question.id, question=question.text, type=question.answer_type)
            for question in FIXED_SECURITY_QUESTIONS
        ]
    )


async def get_recovery_questions(email: str) -> SecurityQuestionsOut:
    """The questions to ask for `email`: the three fixed ones, plus the account's custom ones if any.

    An unknown e-mail (or the super admin, or an account without a profile) gets the fixed
    questions only, so the answer does not reveal whether the account exists.
    """
    row = await db.fetch_one(SQL_RECOVERY_QUESTIONS_BY_EMAIL, (email, SUPER_ADMIN_USER_ID))
    result = get_fixed_security_questions()
    if row is not None:
        custom_questions = (
            ("customAnswer1", row["custom_question_1"]),
            ("customAnswer2", row["custom_question_2"]),
        )
        for answer_field, question in custom_questions:
            if question:
                result.questions.append(SecurityQuestionOut(id=answer_field, question=question, type="text"))
    return result


def _invalid_security_answers() -> UnauthorizedError:
    return UnauthorizedError("The answers are incorrect.", code="INVALID_SECURITY_ANSWERS")


async def _wrong_answer() -> bool:
    return False


async def _answers_are_correct(profile: Row, payload: ForgotVerifyRequest) -> bool:
    """Check EVERY answer (no early exit), so timing and the error do not reveal which one was wrong."""
    checks = [
        verify_security_answer(FIELD_DOB, payload.date_of_birth.isoformat(), profile["dob_hash"]),
        verify_security_answer(FIELD_Q2, payload.answer_q2, profile["answer_q2_hash"]),
        verify_security_answer(FIELD_Q3, payload.answer_q3, profile["answer_q3_hash"]),
    ]
    for field, stored_hash, supplied in (
        (FIELD_CUSTOM_1, profile["custom_answer_1_hash"], payload.custom_answer_1),
        (FIELD_CUSTOM_2, profile["custom_answer_2_hash"], payload.custom_answer_2),
    ):
        if stored_hash is not None:  # the account has this custom question, so an answer is required
            checks.append(verify_security_answer(field, supplied, stored_hash) if supplied else _wrong_answer())
    return all(await asyncio.gather(*checks))


async def verify_security_answers(payload: ForgotVerifyRequest) -> ResetTokenOut:
    """If ALL answers are right, issue a short-lived single-use token that allows setting a new password."""
    now = utcnow()
    profile = await db.fetch_one(SQL_RECOVERY_PROFILE_BY_EMAIL, (payload.email, SUPER_ADMIN_USER_ID))

    if profile is None:  # unknown e-mail, super admin, or no profile: same answer, same effort
        await burn_verification_time(count=3)
        raise _invalid_security_answers()

    locked_until: datetime | None = profile["locked_until"]
    if locked_until is not None and locked_until > now:
        raise TooManyRequestsError(
            "Too many wrong answers. Password recovery is locked for this account for a while.",
            code="ACCOUNT_LOCKED",
            meta={"retry_after": math.ceil((locked_until - now).total_seconds())},
        )

    if not await _answers_are_correct(profile, payload):
        await db.execute(
            SQL_REGISTER_FAILED_RECOVERY_ATTEMPT,
            (
                RECOVERY_MAX_FAILED_ATTEMPTS,
                now + timedelta(minutes=RECOVERY_LOCK_MINUTES),
                RECOVERY_MAX_FAILED_ATTEMPTS,
                profile["user_id"],
            ),
        )
        logger.warning("Recovery answers were wrong", extra={"data": {"userId": profile["user_id"]}})
        raise _invalid_security_answers()

    raw_reset_token, reset_token_hash = generate_opaque_token()
    async with db.transaction() as tx:
        await tx.execute(SQL_RESET_RECOVERY_COUNTERS, (profile["user_id"],))
        await tokens.invalidate_pending_reset_tokens(tx, profile["user_id"], now)  # supersede earlier tokens
        await tokens.store_reset_token(
            tx,
            user_id=profile["user_id"],
            token_hash=reset_token_hash,
            expires_at=now + timedelta(minutes=PASSWORD_RESET_TOKEN_TTL_MINUTES),
            requested_ip=get_client_ip(),
            now=now,
        )
    logger.info("Recovery answers verified", extra={"data": {"userId": profile["user_id"]}})
    return ResetTokenOut(reset_token=raw_reset_token, expires_in=PASSWORD_RESET_TOKEN_TTL_MINUTES * 60)


async def reset_password(reset_token: str, new_password: str) -> None:
    """Use a reset token (once) to set a new password. Ends every session; does not sign in."""
    new_hash = await hash_password(new_password)  # slow part first, before any row is locked
    now = utcnow()
    user_id: int | None = None

    async with db.transaction() as tx:
        stored = await tokens.get_reset_token_for_update(tx, hash_token(reset_token))  # row lock: single use
        is_usable = stored is not None and stored["used_at"] is None and stored["expires_at"] > now
        if is_usable:
            user_id = stored["user_id"]
            await credentials.update_password(
                tx, user_id=user_id, password_hash=new_hash, must_change_password=False, updated_by=user_id, now=now
            )
            await tokens.mark_reset_token_used(tx, stored["password_reset_tokens_id"], now)
            await tokens.revoke_all_refresh_tokens(tx, user_id, now)
            await tx.execute(SQL_RESET_RECOVERY_COUNTERS, (user_id,))

    if user_id is None:
        raise BadRequestError("The reset token is invalid or has expired.", code="RESET_TOKEN_INVALID")
    logger.info("Password reset", extra={"data": {"userId": user_id}})
