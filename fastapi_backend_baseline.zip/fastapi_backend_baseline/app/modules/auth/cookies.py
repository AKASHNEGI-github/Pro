"""The refresh-token cookie.

The refresh token never appears in a response body. It travels only in this
cookie, which JavaScript cannot read (`HttpOnly`) and which the browser sends only
to `/api/v1/auth/*` (`Path`), so it is not attached to ordinary API calls.

`send_success()` returns a ready-made response object, so the cookie is set on THAT
object (FastAPI ignores cookies set on the injected `Response` parameter when the
route returns its own response).
"""

from fastapi import Response

from app.core.config import settings
from app.core.constants import REFRESH_COOKIE_PATH


def set_refresh_cookie(response: Response, raw_refresh_token: str) -> None:
    response.set_cookie(
        key=settings.REFRESH_COOKIE_NAME,
        value=raw_refresh_token,
        max_age=settings.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
        path=REFRESH_COOKIE_PATH,
        domain=settings.REFRESH_COOKIE_DOMAIN,
        secure=settings.REFRESH_COOKIE_SECURE,
        httponly=True,
        samesite=settings.REFRESH_COOKIE_SAMESITE,
    )


def clear_refresh_cookie(response: Response) -> None:
    """Attributes must match those used to set the cookie, or the browser keeps it."""
    response.delete_cookie(
        key=settings.REFRESH_COOKIE_NAME,
        path=REFRESH_COOKIE_PATH,
        domain=settings.REFRESH_COOKIE_DOMAIN,
        secure=settings.REFRESH_COOKIE_SECURE,
        httponly=True,
        samesite=settings.REFRESH_COOKIE_SAMESITE,
    )
