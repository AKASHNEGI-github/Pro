"""SQL for the `user_passwords` table (one row per user, overwritten on change).

Shared by auth (sign-up, change/reset password), users (delete account needs the
password) and admin (create user, reset password).

`updated_at` doubles as "password last changed at": access tokens issued before it
are rejected by `authenticate`. It is therefore always set from the APPLICATION
clock (like the JWT `iat` it is compared with), never from MySQL's default.

The super admin has NO row here; its password hash lives in ENV.
"""

from datetime import datetime

from app.core.database import SqlExecutor, db
from app.core.security import verify_password
from app.errors.exceptions import BadRequestError

SQL_SELECT_PASSWORD_HASH = "SELECT hash_password FROM user_passwords WHERE user_id = %s"

SQL_INSERT_PASSWORD = """
INSERT INTO user_passwords (user_id, hash_password, must_change_password, created_by, updated_by, updated_at)
VALUES (%s, %s, %s, %s, %s, %s)
"""

SQL_UPDATE_PASSWORD = """
UPDATE user_passwords
SET hash_password = %s, must_change_password = %s, updated_by = %s, updated_at = %s
WHERE user_id = %s
"""


async def verify_current_password(user_id: int, password: str) -> None:
    """Re-authentication for sensitive actions. Raises 400 INVALID_CURRENT_PASSWORD.

    Deliberately 400, not 401: a client must not mistake a typo here for an
    expired session and sign the user out.
    """
    row = await db.fetch_one(SQL_SELECT_PASSWORD_HASH, (user_id,))
    if row is None or not await verify_password(password, row["hash_password"]):
        raise BadRequestError("The current password is incorrect.", code="INVALID_CURRENT_PASSWORD")


async def create_password(
    executor: SqlExecutor,
    *,
    user_id: int,
    password_hash: str,
    must_change_password: bool,
    created_by: int | None,
    now: datetime,
) -> None:
    await executor.execute(
        SQL_INSERT_PASSWORD, (user_id, password_hash, must_change_password, created_by, created_by, now)
    )


async def update_password(
    executor: SqlExecutor,
    *,
    user_id: int,
    password_hash: str,
    must_change_password: bool,
    updated_by: int,
    now: datetime,
) -> bool:
    """Returns False when the user has no password row (only possible for corrupt data)."""
    result = await executor.execute(
        SQL_UPDATE_PASSWORD, (password_hash, must_change_password, updated_by, now, user_id)
    )
    return result.row_count > 0
