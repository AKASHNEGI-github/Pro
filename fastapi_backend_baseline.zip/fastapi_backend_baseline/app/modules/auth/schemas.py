"""Request and response models of the auth module."""

import re
from datetime import date
from typing import Annotated, Literal

from pydantic import AfterValidator, BeforeValidator, StringConstraints, model_validator

from app.modules.users.schemas import UserOut
from app.utils.clock import utcnow
from app.utils.schemas import (
    ExistingPassword,
    FullName,
    NormalizedEmail,
    Password,
    RequestModel,
    ResponseModel,
    UtcDatetime,
)


# ---------------------------------------------------------------------------
# Reusable field types
# ---------------------------------------------------------------------------
def _require_iso_date(value: object) -> object:
    """Only `YYYY-MM-DD` strings (Pydantic would also accept timestamps and other forms)."""
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise ValueError("Date must be written as YYYY-MM-DD")
    return value


def _check_date_of_birth_range(value: date) -> date:
    if not date(1900, 1, 1) <= value < utcnow().date():
        raise ValueError("Date of birth must be between 1900-01-01 and yesterday")
    return value


DateOfBirth = Annotated[date, BeforeValidator(_require_iso_date), AfterValidator(_check_date_of_birth_range)]

# Answers are compared after normalisation (trimmed, case-folded), see core/security.py.
Answer = Annotated[str, StringConstraints(strip_whitespace=True, min_length=2, max_length=100)]
CustomQuestion = Annotated[str, StringConstraints(strip_whitespace=True, min_length=5, max_length=200)]


# ---------------------------------------------------------------------------
# Security profile (answers used to recover a forgotten password)
# ---------------------------------------------------------------------------
class SecurityProfileInput(RequestModel):
    """Questions 1-3 are fixed (date of birth + two questions defined in the application).
    Questions 4-5 are optional and written by the user; each needs its answer."""

    date_of_birth: DateOfBirth
    answer_q2: Answer
    answer_q3: Answer
    custom_question_1: CustomQuestion | None = None
    custom_answer_1: Answer | None = None
    custom_question_2: CustomQuestion | None = None
    custom_answer_2: Answer | None = None

    @model_validator(mode="after")
    def _custom_question_and_answer_come_together(self) -> "SecurityProfileInput":
        for number, question, answer in (
            (1, self.custom_question_1, self.custom_answer_1),
            (2, self.custom_question_2, self.custom_answer_2),
        ):
            if (question is None) != (answer is None):
                raise ValueError(f"customQuestion{number} and customAnswer{number} must be sent together")
        return self


class SecurityProfileUpdateRequest(SecurityProfileInput):
    """Replacing the recovery answers is as sensitive as changing the password, so it
    needs the current password."""

    current_password: ExistingPassword


class SecurityProfileStatusOut(ResponseModel):
    configured: bool
    custom_question_1: str | None = None
    custom_question_2: str | None = None
    updated_at: UtcDatetime | None = None


# ---------------------------------------------------------------------------
# Sign-up and sessions
# ---------------------------------------------------------------------------
class RegisterRequest(RequestModel):
    full_name: FullName
    email: NormalizedEmail
    password: Password
    security_profile: SecurityProfileInput  # mandatory at sign-up


class LoginRequest(RequestModel):
    email: NormalizedEmail
    password: ExistingPassword  # the password policy is NOT applied when signing in


class AuthSessionOut(ResponseModel):
    """Returned by login, and by change-password (which keeps this device signed in).
    The refresh token is NOT in the body: it is set as an httpOnly cookie."""

    access_token: str
    token_type: Literal["Bearer"] = "Bearer"
    expires_in: int  # seconds
    user: UserOut


class ChangePasswordRequest(RequestModel):
    current_password: ExistingPassword
    new_password: Password


# ---------------------------------------------------------------------------
# Forgot password (security questions, no e-mail involved)
# ---------------------------------------------------------------------------
class SecurityQuestionOut(ResponseModel):
    id: str  # also the name of the request field that carries the answer
    question: str
    type: Literal["date", "text"]


class SecurityQuestionsOut(ResponseModel):
    questions: list[SecurityQuestionOut]


class ForgotQuestionsRequest(RequestModel):
    email: NormalizedEmail


class ForgotVerifyRequest(RequestModel):
    email: NormalizedEmail
    date_of_birth: DateOfBirth
    answer_q2: Answer
    answer_q3: Answer
    custom_answer_1: Answer | None = None  # required only if the account has custom question 1
    custom_answer_2: Answer | None = None  # required only if the account has custom question 2


class ResetTokenOut(ResponseModel):
    reset_token: str
    expires_in: int  # seconds


class ForgotResetRequest(RequestModel):
    reset_token: Annotated[str, StringConstraints(min_length=20, max_length=200)]
    new_password: Password
