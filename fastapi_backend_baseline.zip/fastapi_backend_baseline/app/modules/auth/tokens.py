"""SQL for refresh-token and password-reset-token rows.

Kept in its own file because several services need it: auth (sessions,
recovery), users (delete account) and admin (reset password, delete user), and
the start-up code (revoke the super admin's sessions).

Only the SHA-256 digest of a token is ever stored (see `core/security.py`).
"""

from datetime import datetime

from app.core.database import Row, SqlExecutor

# ---------------------------------------------------------------------------
# refresh_tokens
# Rotation: when a token is used, it gets `revoked_at` + `replaced_by_hash` and a
# new row is inserted. Presenting an already-rotated token again is a reuse
# (theft) signal, and every active token of that user is then revoked.
# ---------------------------------------------------------------------------
SQL_INSERT_REFRESH_TOKEN = """
INSERT INTO refresh_tokens (user_id, token_hash, expires_at, user_agent, created_at, updated_at)
VALUES (%s, %s, %s, %s, %s, %s)
"""

SQL_SELECT_REFRESH_TOKEN_FOR_UPDATE = """
SELECT user_id, expires_at, revoked_at, replaced_by_hash
FROM refresh_tokens
WHERE token_hash = %s
FOR UPDATE
"""

SQL_MARK_REFRESH_TOKEN_ROTATED = """
UPDATE refresh_tokens
SET revoked_at = %s, replaced_by_hash = %s, updated_at = %s
WHERE token_hash = %s
"""

SQL_REVOKE_REFRESH_TOKEN = """
UPDATE refresh_tokens
SET revoked_at = %s, updated_at = %s
WHERE token_hash = %s AND revoked_at IS NULL
"""

SQL_REVOKE_ALL_REFRESH_TOKENS_OF_USER = """
UPDATE refresh_tokens
SET revoked_at = %s, updated_at = %s
WHERE user_id = %s AND revoked_at IS NULL
"""


async def store_refresh_token(
    executor: SqlExecutor,
    *,
    user_id: int,
    token_hash: str,
    expires_at: datetime,
    user_agent: str | None,
    now: datetime,
) -> None:
    await executor.execute(SQL_INSERT_REFRESH_TOKEN, (user_id, token_hash, expires_at, user_agent, now, now))


async def get_refresh_token_for_update(executor: SqlExecutor, token_hash: str) -> Row | None:
    """Locks the row, so two simultaneous refreshes with the same token cannot both succeed."""
    return await executor.fetch_one(SQL_SELECT_REFRESH_TOKEN_FOR_UPDATE, (token_hash,))


async def mark_refresh_token_rotated(
    executor: SqlExecutor, *, old_hash: str, new_hash: str, now: datetime
) -> None:
    await executor.execute(SQL_MARK_REFRESH_TOKEN_ROTATED, (now, new_hash, now, old_hash))


async def revoke_refresh_token(executor: SqlExecutor, token_hash: str, now: datetime) -> None:
    await executor.execute(SQL_REVOKE_REFRESH_TOKEN, (now, now, token_hash))


async def revoke_all_refresh_tokens(executor: SqlExecutor, user_id: int, now: datetime) -> int:
    """End every session of `user_id`. Returns how many tokens were revoked."""
    result = await executor.execute(SQL_REVOKE_ALL_REFRESH_TOKENS_OF_USER, (now, now, user_id))
    return result.row_count


# ---------------------------------------------------------------------------
# password_reset_tokens: short-lived, single-use, issued only after every
# security answer was correct.
# ---------------------------------------------------------------------------
SQL_INSERT_RESET_TOKEN = """
INSERT INTO password_reset_tokens (user_id, token_hash, expires_at, requested_ip, created_at)
VALUES (%s, %s, %s, %s, %s)
"""

# A newly issued token supersedes every earlier unused one ("used" also means "superseded").
SQL_INVALIDATE_PENDING_RESET_TOKENS = """
UPDATE password_reset_tokens
SET used_at = %s
WHERE user_id = %s AND used_at IS NULL
"""

# `FOR UPDATE OF t` locks only the token row (not the user row we join for the deleted check).
SQL_SELECT_RESET_TOKEN_FOR_UPDATE = """
SELECT t.password_reset_tokens_id, t.user_id, t.expires_at, t.used_at
FROM password_reset_tokens t
JOIN users u ON u.user_id = t.user_id AND u.is_deleted = FALSE
WHERE t.token_hash = %s
FOR UPDATE OF t
"""

SQL_MARK_RESET_TOKEN_USED = """
UPDATE password_reset_tokens
SET used_at = %s
WHERE password_reset_tokens_id = %s
"""


async def store_reset_token(
    executor: SqlExecutor,
    *,
    user_id: int,
    token_hash: str,
    expires_at: datetime,
    requested_ip: str | None,
    now: datetime,
) -> None:
    await executor.execute(SQL_INSERT_RESET_TOKEN, (user_id, token_hash, expires_at, requested_ip, now))


async def invalidate_pending_reset_tokens(executor: SqlExecutor, user_id: int, now: datetime) -> None:
    await executor.execute(SQL_INVALIDATE_PENDING_RESET_TOKENS, (now, user_id))


async def get_reset_token_for_update(executor: SqlExecutor, token_hash: str) -> Row | None:
    return await executor.fetch_one(SQL_SELECT_RESET_TOKEN_FOR_UPDATE, (token_hash,))


async def mark_reset_token_used(executor: SqlExecutor, reset_token_id: int, now: datetime) -> None:
    await executor.execute(SQL_MARK_RESET_TOKEN_USED, (now, reset_token_id))
