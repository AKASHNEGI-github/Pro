"""Error boundary middleware (the INNERMOST layer, right outside the router).

Starlette answers an unexpected exception from OUTSIDE all middleware, so that
500 response would miss the CORS headers, security headers and X-Request-Id
(browsers then show a misleading "CORS error" instead of the real 500).
Catching the exception here, inside the other middleware, turns it into the
standard 500 response which then travels outwards through all of them.
"""

from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.errors.handlers import failure_response, to_app_error


class ErrorBoundaryMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        response_started = False

        async def tracking_send(message: Message) -> None:
            nonlocal response_started
            if message["type"] == "http.response.start":
                response_started = True
            await send(message)

        try:
            await self.app(scope, receive, tracking_send)
        except Exception as exc:
            if response_started:
                raise  # headers are already on the wire; nothing sensible can be sent
            await failure_response(to_app_error(exc))(scope, receive, send)
