"""Request context middleware (the OUTERMOST layer).

For every HTTP request it:
  1. decides the request id (uses a valid incoming `X-Request-Id`, else makes a UUID)
  2. finds the real client IP
  3. opens the request context store (see `core/context.py`)
  4. adds `X-Request-Id` to the response
  5. writes ONE access-log line when the request is finished

Because it is outermost, everything else (other middleware, routers, services,
error handlers, the logger) runs with the context already available.

Pure ASGI middleware (not `BaseHTTPMiddleware`): it is faster and, importantly,
keeps context variables working correctly across the whole request.
"""

import ipaddress
import logging
import re
import time
import uuid

from starlette.datastructures import Headers, MutableHeaders
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.core.config import settings
from app.core.constants import REQUEST_ID_HEADER, USER_AGENT_MAX_LENGTH
from app.core.context import RequestContext, end_request_context, start_request_context
from app.core.logger import get_logger

logger = get_logger(__name__)

# A request id sent by a gateway is accepted only if it is short and harmless
# (it ends up in logs and response headers).
_VALID_REQUEST_ID = re.compile(r"^[A-Za-z0-9._-]{8,64}$")
_HEALTH_PATH_PREFIX = "/health"


def resolve_client_ip(scope: Scope, headers: Headers) -> str | None:
    """The client's IP address.

    Without a trusted proxy this is the address of the TCP peer. With
    `TRUSTED_PROXY_COUNT = N` the app sits behind N proxies, and each proxy
    appends the address it saw to `X-Forwarded-For`. The entry that the FIRST
    proxy (the one facing the internet) appended is therefore the N-th from the
    right; everything to its left could have been forged by the client.
    """
    client = scope.get("client")
    peer = client[0] if client else None

    proxy_count = settings.TRUSTED_PROXY_COUNT
    if proxy_count <= 0:
        return peer

    forwarded = [part.strip() for part in headers.get("x-forwarded-for", "").split(",") if part.strip()]
    if len(forwarded) < proxy_count:
        return peer  # the header does not look like it went through our proxies
    candidate = forwarded[-proxy_count]
    try:
        ipaddress.ip_address(candidate)
    except ValueError:
        return peer
    return candidate


class RequestContextMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        headers = Headers(scope=scope)
        request_id = headers.get(REQUEST_ID_HEADER, "")
        if not _VALID_REQUEST_ID.match(request_id):
            request_id = str(uuid.uuid4())

        user_agent = headers.get("user-agent")
        context = RequestContext(
            request_id=request_id,
            method=scope["method"],
            path=scope["path"],
            client_ip=resolve_client_ip(scope, headers),
            user_agent=user_agent[:USER_AGENT_MAX_LENGTH] if user_agent else None,
        )
        token = start_request_context(context)
        started_at = time.perf_counter()
        status_code = 500  # replaced as soon as a response starts

        async def send_with_request_id(message: Message) -> None:
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = message["status"]
                MutableHeaders(scope=message)[REQUEST_ID_HEADER] = request_id
            await send(message)

        try:
            await self.app(scope, receive, send_with_request_id)
        finally:
            self._log_access(context, status_code, started_at)
            end_request_context(token)

    @staticmethod
    def _log_access(context: RequestContext, status_code: int, started_at: float) -> None:
        data: dict[str, object] = {
            "method": context.method,
            "path": context.path,  # no query string: it could contain sensitive values
            "status": status_code,
            "durationMs": round((time.perf_counter() - started_at) * 1000, 1),
            "ip": context.client_ip,
        }
        if context.error_code:
            data["errorCode"] = context.error_code

        if status_code >= 500:
            level = logging.ERROR
        elif context.path.startswith(_HEALTH_PATH_PREFIX) and status_code < 400:
            level = logging.DEBUG  # probes hit these every few seconds; keep them out of the INFO log
        else:
            level = logging.INFO
        logger.log(level, "request completed", extra={"data": data})
