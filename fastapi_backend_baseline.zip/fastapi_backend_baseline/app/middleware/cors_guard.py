"""CORS guard middleware.

Browsers send an `Origin` header with cross-site requests. This middleware:

  * no `Origin` header (curl, mobile apps, server-to-server)  -> let it through
  * `Origin` equals the API's own host (Swagger UI, same-site)  -> let it through
  * `Origin` listed in CORS_ORIGINS                            -> let it through and add
                                                                  the CORS response headers;
                                                                  answers preflight (OPTIONS) itself
  * any other `Origin`                                         -> 403 CORS_ORIGIN_NOT_ALLOWED

We use our own guard instead of Starlette's `CORSMiddleware` because that one
never rejects a request: it only omits headers, so the standard error shape
and the explicit 403 would be lost.

`Allow-Credentials: true` lets the browser send the refresh-token cookie, which
is why a wildcard origin is NOT supported: origins must be listed one by one.
"""

from urllib.parse import urlparse

from starlette.datastructures import Headers, MutableHeaders
from starlette.responses import Response
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.errors.exceptions import ForbiddenError
from app.errors.handlers import failure_response

_ALLOWED_METHODS = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
_ALLOWED_HEADERS = "Authorization, Content-Type, X-Request-Id"
_EXPOSED_HEADERS = "X-Request-Id, Retry-After"
_PREFLIGHT_MAX_AGE_SECONDS = "600"


class CORSGuardMiddleware:
    def __init__(self, app: ASGIApp, allowed_origins: list[str]) -> None:
        self.app = app
        self.allowed_origins = {origin.lower() for origin in allowed_origins}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        headers = Headers(scope=scope)
        origin = headers.get("origin")
        if origin is None or self._is_same_host(origin, headers.get("host")):
            await self.app(scope, receive, send)
            return

        if origin.lower() not in self.allowed_origins:
            response = failure_response(
                ForbiddenError("This origin is not allowed.", code="CORS_ORIGIN_NOT_ALLOWED")
            )
            await response(scope, receive, send)
            return

        is_preflight = scope["method"] == "OPTIONS" and "access-control-request-method" in headers
        if is_preflight:
            preflight = Response(
                status_code=204,
                headers={
                    "Access-Control-Allow-Origin": origin,
                    "Access-Control-Allow-Credentials": "true",
                    "Access-Control-Allow-Methods": _ALLOWED_METHODS,
                    "Access-Control-Allow-Headers": _ALLOWED_HEADERS,
                    "Access-Control-Max-Age": _PREFLIGHT_MAX_AGE_SECONDS,
                    "Vary": "Origin",
                },
            )
            await preflight(scope, receive, send)
            return

        async def send_with_cors_headers(message: Message) -> None:
            if message["type"] == "http.response.start":
                response_headers = MutableHeaders(scope=message)
                response_headers["Access-Control-Allow-Origin"] = origin
                response_headers["Access-Control-Allow-Credentials"] = "true"
                response_headers["Access-Control-Expose-Headers"] = _EXPOSED_HEADERS
                response_headers.append("Vary", "Origin")
            await send(message)

        await self.app(scope, receive, send_with_cors_headers)

    @staticmethod
    def _is_same_host(origin: str, host_header: str | None) -> bool:
        """Browsers add `Origin` even to same-site POSTs (e.g. Swagger UI "Try it out")."""
        return bool(host_header) and urlparse(origin).netloc.lower() == host_header.lower()
