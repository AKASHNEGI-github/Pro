"""Global rate limit middleware: every client IP may make 100 requests per minute.

Per-route limits (login, register, recovery, ...) are stricter and live next to
the routes (see `dependencies/rate_limit.py`). Health probes are exempt, because
load balancers call them constantly from a single IP.
"""

from starlette.types import ASGIApp, Receive, Scope, Send

from app.core.context import get_client_ip
from app.core.rate_limit import rate_limiter
from app.core.rate_limit_rules import GLOBAL_PER_IP
from app.errors.exceptions import TooManyRequestsError
from app.errors.handlers import failure_response

_EXEMPT_PATH_PREFIXES = ("/health",)


class GlobalRateLimitMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http" and not scope["path"].startswith(_EXEMPT_PATH_PREFIXES):
            try:
                await rate_limiter.check(GLOBAL_PER_IP, get_client_ip() or "unknown")
            except TooManyRequestsError as exc:
                await failure_response(exc)(scope, receive, send)
                return
        await self.app(scope, receive, send)
