"""Body size limit middleware: requests larger than 100 kb are refused with 413.

Two checks:
  1. a declared `Content-Length` above the limit is refused immediately, before
     reading a single byte of the body;
  2. otherwise (for example chunked uploads that declare no length) the body is
     read here, counting bytes, and refused as soon as it exceeds the limit.

Reading the body here (instead of letting the route read it) is safe because the
limit is small: at most 100 kb is ever held in memory. The body is then handed
to the application unchanged. It also means a "too large" error is always raised
OUTSIDE of FastAPI's body parsing, which would otherwise turn it into a 400.

(Starlette 1.x has a built-in `max_body_size` option, but it answers with a
plain-text body, which would break our "only two response shapes" rule.)
"""

from starlette.datastructures import Headers
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.core.constants import MAX_BODY_BYTES
from app.errors.exceptions import PayloadTooLargeError
from app.errors.handlers import failure_response


class BodySizeLimitMiddleware:
    def __init__(self, app: ASGIApp, max_bytes: int = MAX_BODY_BYTES) -> None:
        self.app = app
        self.max_bytes = max_bytes

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        too_large = PayloadTooLargeError(f"The request body must not be larger than {self.max_bytes // 1024} kb.")

        declared_length = Headers(scope=scope).get("content-length")
        if declared_length is not None and declared_length.isdigit() and int(declared_length) > self.max_bytes:
            await failure_response(too_large)(scope, receive, send)
            return

        body = bytearray()
        more_body = True
        while more_body:
            message = await receive()
            if message["type"] == "http.disconnect":
                return  # the client went away; nobody is left to answer
            body.extend(message.get("body", b""))
            if len(body) > self.max_bytes:
                await failure_response(too_large)(scope, receive, send)
                return
            more_body = message.get("more_body", False)

        body_delivered = False

        async def replay_receive() -> Message:
            nonlocal body_delivered
            if not body_delivered:
                body_delivered = True
                return {"type": "http.request", "body": bytes(body), "more_body": False}
            return await receive()  # later calls only wait for a disconnect

        await self.app(scope, replay_receive, send)
