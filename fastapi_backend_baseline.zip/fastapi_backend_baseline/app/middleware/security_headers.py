"""Security headers middleware: adds protective headers to every response."""

from starlette.datastructures import MutableHeaders
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.core.config import settings

_STATIC_HEADERS = {
    "X-Content-Type-Options": "nosniff",  # the browser must not guess content types
    "X-Frame-Options": "DENY",  # never render this API inside a frame
    "Referrer-Policy": "no-referrer",
    "Cache-Control": "no-store",  # responses contain account data and tokens: never cache
}
# The API only returns JSON, so no resource may be loaded from a response ...
_API_CONTENT_SECURITY_POLICY = "default-src 'none'; frame-ancestors 'none'"
# ... except on the Swagger UI / ReDoc pages (development only), which need scripts and styles.
_DOCS_PATHS = ("/docs", "/redoc", "/openapi.json")
_HSTS = "max-age=31536000; includeSubDomains"


class SecurityHeadersMiddleware:
    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        is_docs_page = scope["path"].startswith(_DOCS_PATHS)

        async def send_with_security_headers(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = MutableHeaders(scope=message)
                for name, value in _STATIC_HEADERS.items():
                    headers.setdefault(name, value)
                if not is_docs_page:
                    headers.setdefault("Content-Security-Policy", _API_CONTENT_SECURITY_POLICY)
                if settings.is_production:
                    headers.setdefault("Strict-Transport-Security", _HSTS)  # only meaningful over HTTPS
            await send(message)

        await self.app(scope, receive, send_with_security_headers)
