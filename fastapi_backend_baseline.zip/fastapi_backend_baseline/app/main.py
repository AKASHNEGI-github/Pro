"""Application entry point.

Run it with:   uvicorn app.main:app --reload

This file only WIRES things together; there is no business logic here:
logging -> FastAPI app -> middleware -> error handlers -> routers.
"""

from fastapi import FastAPI

from app.api_router import api_router
from app.core.config import settings
from app.core.constants import API_PREFIX, APP_VERSION
from app.core.logger import configure_logging
from app.errors.handlers import register_exception_handlers
from app.errors.responses import COMMON_RESPONSES
from app.lifespan import lifespan
from app.middleware.body_size_limit import BodySizeLimitMiddleware
from app.middleware.cors_guard import CORSGuardMiddleware
from app.middleware.error_boundary import ErrorBoundaryMiddleware
from app.middleware.rate_limit import GlobalRateLimitMiddleware
from app.middleware.request_context import RequestContextMiddleware
from app.middleware.security_headers import SecurityHeadersMiddleware
from app.modules.health.router import router as health_router

DESCRIPTION = """
Enterprise-grade FastAPI + MySQL backend baseline: role based access control
(super admin / admin / member), JWT access tokens with rotating refresh tokens,
security-question password recovery, one standard response shape, custom
exceptions, request context, structured logging and rate limiting.

**Every response has one of two shapes.**
Success: `{ success: true, message, data, meta?, requestId }`.
Failure: `{ success: false, message, error: { code, details? }, requestId }`.

Click **Authorize** and paste the `accessToken` from `POST /api/v1/auth/login`.
"""


def _register_middleware(app: FastAPI) -> None:
    """The order matters. A request travels through this list from TOP to BOTTOM,
    and the response travels back up.

      1. RequestContext   request id, context store, access log           (outermost)
      2. SecurityHeaders  adds protective headers to every response
      3. CORSGuard        rejects unknown browser origins, answers preflight
      4. GlobalRateLimit  100 requests / minute / IP
      5. BodySizeLimit    rejects bodies over 100 kb
      6. ErrorBoundary    turns unexpected crashes into the standard 500     (innermost)
         ... then FastAPI's own exception handling, routing and the routers.

    Why this order:
      * RequestContext is first, so everything below (including the logger and the error
        handler) already knows the request id.
      * ErrorBoundary is last, so even a 500 passes outwards through 1-3 and still gets its
        request id, security headers and CORS headers.
      * Cheap rejections (origin, rate limit) happen before the body is read.
    """
    stack: list[tuple[type, dict]] = [
        (RequestContextMiddleware, {}),
        (SecurityHeadersMiddleware, {}),
        (CORSGuardMiddleware, {"allowed_origins": settings.cors_origins}),
        (GlobalRateLimitMiddleware, {}),
        (BodySizeLimitMiddleware, {}),
        (ErrorBoundaryMiddleware, {}),
    ]
    # Starlette makes the LAST middleware you add the outermost one, hence `reversed`.
    for middleware_class, options in reversed(stack):
        app.add_middleware(middleware_class, **options)


def create_app() -> FastAPI:
    configure_logging()

    app = FastAPI(
        title=settings.APP_NAME,
        version=APP_VERSION,
        description=DESCRIPTION,
        lifespan=lifespan,
        # Swagger UI / ReDoc / openapi.json are development tools: hidden in production.
        docs_url="/docs" if settings.docs_enabled else None,
        redoc_url="/redoc" if settings.docs_enabled else None,
        openapi_url="/openapi.json" if settings.docs_enabled else None,
        responses=COMMON_RESPONSES,
    )

    _register_middleware(app)
    register_exception_handlers(app)

    app.include_router(health_router)  # /health        (unversioned, for load balancers)
    app.include_router(api_router, prefix=API_PREFIX)  # /api/v1/...
    return app


app = create_app()
