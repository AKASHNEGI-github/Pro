# FastAPI Backend Baseline

An enterprise-grade **FastAPI + MySQL** backend baseline. **No ORM:** every query is real, hand-written, parameterised SQL (SQL-injection safe) that lives in the module's `service.py`. It ships with role-based access control (**Super Admin / Admin / Member**), JWT access tokens with **rotating refresh tokens**, **security-question password recovery** (no e-mail service), a **standard API response** (exactly two shapes), custom exceptions, a **request context store**, **structured logging** and **rate limiting**.

This README is the single source of truth for the project: what it does, how it is built, and **why every decision was taken**. Section [21](#21-decisions-log) lists all decisions; section [20](#20-known-limitations-and-future-extensions) lists what is deliberately not included.

> **Origin of this document.** The design (roles, schema, token model, error codes, API surface) was first written for a Node/Express stack. This project implements it in **FastAPI (async) + MySQL**. Where an Express idea has a different Python form, section [21.4](#214-express-to-fastapi-translation) shows the mapping. Where the build improved on the original design, the change is called out in section [21.3](#213-refinements-made-while-building).

---

## Table of contents

1. [Overview](#1-overview)
2. [Tech stack](#2-tech-stack)
3. [Quick start](#3-quick-start)
4. [Configuration (environment variables)](#4-configuration-environment-variables)
5. [Roles and authorization (RBAC)](#5-roles-and-authorization-rbac)
6. [Database](#6-database)
7. [Authentication and sessions](#7-authentication-and-sessions)
8. [Passwords and account lifecycle](#8-passwords-and-account-lifecycle)
9. [Password recovery (security questions)](#9-password-recovery-security-questions)
10. [Standard API response and error handling](#10-standard-api-response-and-error-handling)
11. [API reference](#11-api-reference)
12. [Request lifecycle and middleware](#12-request-lifecycle-and-middleware)
13. [Request context store](#13-request-context-store)
14. [Logging](#14-logging)
15. [Rate limiting](#15-rate-limiting)
16. [Start-up, seeding and background jobs](#16-start-up-seeding-and-background-jobs)
17. [Project structure and coding conventions](#17-project-structure-and-coding-conventions)
18. [Deployment](#18-deployment)
19. [Security notes](#19-security-notes)
20. [Known limitations and future extensions](#20-known-limitations-and-future-extensions)
21. [Decisions log](#21-decisions-log)
22. [Verification: what was tested](#22-verification-what-was-tested)
23. [Troubleshooting](#23-troubleshooting)

---

## 1. Overview

### 1.1 What it is

A starting point for backend projects that need accounts, roles and sessions done properly, so a new project begins with those concerns solved and well documented instead of rebuilding them.

At the top of the hierarchy sits the **super admin**: one reserved account whose credentials live only in the server environment. Below it are **admins** (manage users) and **members** (manage only their own account).

### 1.2 What is included

| Area | What you get |
| --- | --- |
| **RBAC** | Super admin / admin / member; a strict "manage only people below you" hierarchy; route-level and instance-level authorization |
| **Authentication** | 15-minute JWT access tokens (no role inside) + opaque rotating refresh tokens in an `httpOnly` cookie, with theft (reuse) detection |
| **Account lifecycle** | Self sign-up, admin-created users with temporary passwords, forced password change, activate/deactivate, soft delete with e-mail reuse |
| **Password recovery** | Security questions (no e-mail service), per-account lockout, single-use reset token |
| **API contract** | Exactly two response shapes (success / failure), stable error codes, custom exception classes with the right status codes |
| **Cross-cutting** | Request context store, structured JSON logging, layered rate limiting, six small middlewares, health probes |
| **Operations** | Idempotent SQL seeds, start-up self-checks that refuse unsafe data, hourly token cleanup, Docker + compose |

### 1.3 Design principles

1. **Readability first.** Anyone should be able to open a file and understand it. Each file has a docstring that says what it is for; each function does one thing.
2. **Three layers per feature module**, always the same: `router.py` (HTTP only) → `service.py` (business logic **and its SQL**) → the database. `schemas.py` holds the Pydantic models. `policy.py` (pure functions) exists where instance-level rules are needed.
3. **Real SQL, visible.** Queries are named constants at the top of each `service.py`, with `%s` placeholders. Values never get into SQL text. No `SELECT *`.
4. **Fail loudly, early.** Bad configuration or unsafe database contents stop the application at start-up with a clear message.
5. **Secure by default.** Secrets are hashed or peppered, tokens are stored only as digests, errors never leak internals, and nothing sensitive is ever logged.
6. **One way to do each thing.** One response helper, one error handler, one place for rate-limit numbers, one place for constants.

---

## 2. Tech stack

| Concern | Choice | Version tested | Why |
| --- | --- | --- | --- |
| Language | **Python** | 3.12 | Modern typing and asyncio. 3.12+ is required. |
| Web framework | **FastAPI** | 0.165.0 | Async, automatic OpenAPI docs, Pydantic validation. |
| ASGI toolkit | **Starlette** | 1.10.0 | FastAPI's base. The middlewares are written against it in pure-ASGI style. |
| Server | **Uvicorn** (`[standard]`) | 0.54.0 | Fast event loop and HTTP parser (uvloop, httptools). |
| Database | **MySQL** | 8.0.16+ (8.4 LTS recommended) | Needs expression defaults and enforced `CHECK` constraints. Tested on 8.0.46. |
| DB driver | **asyncmy** | 0.2.18 | Async, fast (Cython), plain SQL with `%s` placeholders and a connection pool. |
| Login to MySQL 8 | **cryptography** | 50.0.2 | Required by asyncmy for MySQL 8's default `caching_sha2_password` login, but **not declared** by asyncmy. It is pinned in `requirements.txt` (see [23](#23-troubleshooting)). |
| Validation, settings | **Pydantic v2**, **pydantic-settings** | 2.14.3 / 2.16.3 | Typed request/response models and validated environment configuration. |
| Password hashing | **bcrypt** (library used directly) | 5.0.0 | `passlib` is unmaintained. bcrypt runs in worker threads (it is CPU heavy). |
| Tokens | **PyJWT** | 2.7.0 | Small, well maintained. |
| Linting (optional) | **ruff** | any recent | Configuration is in `pyproject.toml`. |

**Why no ORM?** The project's goal is that every query is visible, reviewable and tunable, so there is nothing hidden between a service and the database. The cost is writing SQL by hand; the benefit is that nothing surprising ever runs. The SQL stays safe because values are always bound parameters.

**Why asyncmy?** The application is fully async (the event loop is never blocked by database or hashing work), and asyncmy is a fast async driver that supports plain SQL and pooling.

---

## 3. Quick start

### 3.1 Requirements

* **Python 3.12 or newer**
* **MySQL 8.0.16 or newer** (8.4 LTS recommended). MariaDB is not supported: the schema uses the MySQL 8 collation `utf8mb4_0900_as_ci`, and this project was only tested on MySQL.
* Optional: Docker with Compose v2

### 3.2 Run it locally

```bash
# 1. Python environment
python3.12 -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2. Database: schema, required seed, and (development only) the demo accounts
mysql -u root -p < database/schema.sql
mysql -u root -p < database/seed.sql
mysql -u root -p < database/seed.demo.sql          # NEVER in production

# 3. A least-privilege database user (the app never changes the schema)
mysql -u root -p -e "
  CREATE USER 'app_user'@'%' IDENTIFIED BY 'change-me-db-password';
  GRANT SELECT, INSERT, UPDATE, DELETE ON fastapi_backend_baseline.* TO 'app_user'@'%';"

# 4. Configuration
cp .env.example .env                   # then open .env and set DB_PASSWORD at least

# 5. Run (from the project root: the .env file is read from the current directory)
uvicorn app.main:app --reload
```

Open **http://localhost:8000/docs** (Swagger UI). Click **Authorize** and paste the `accessToken` returned by `POST /api/v1/auth/login`.

Check the database connection: `curl http://localhost:8000/health/ready`.

### 3.3 Run it with Docker

```bash
cp .env.example .env                   # set DB_PASSWORD (and review the secrets)
docker compose -f docker-compose.yml -f docker-compose.dev.yml up --build
```

* `docker-compose.yml` starts **MySQL 8.4 + the API** and loads `schema.sql` and the **required** `seed.sql` on the first start.
* `docker-compose.dev.yml` (the overlay) also loads **`seed.demo.sql`**. Production uses only the base file, so demo accounts can never reach production by accident.
* MySQL loads the SQL files only when its data volume is empty. To start over: `docker compose down -v`.
* `DB_HOST` and `DB_NAME` are fixed inside the compose file (`db` and `fastapi_backend_baseline`), so the same `.env` also works outside Docker. `DB_USER` must not be `root`.

### 3.4 Accounts for trying things out

| Role | E-mail | Password |
| --- | --- | --- |
| Super admin | value of `SUPER_ADMIN_EMAIL` (`superadmin@example.com` in `.env.example`) | `SuperAdmin@12345` (the hash in `.env.example`) |
| Admin | `demo.admin@example.com` | `Admin@12345` |
| Member | `demo.member@example.com` | `Member@12345` |

The two demo accounts exist only if you loaded `seed.demo.sql`. Their passwords are public, so **never load that file in production**. Production also refuses to start with the example super admin password (section [4.2](#42-production-safety-checks)).

The demo accounts have **no security profile**, exactly like any account created by an admin. To try "forgot password" with one, sign in first and call `PUT /api/v1/auth/security-profile` (section [9.6](#96-who-can-use-recovery)).

### 3.5 Try it with `curl`

Always send `Content-Type: application/json` with a body (a bare `curl -d` sends a form content type, and the API answers with a clear `422`).

```bash
BASE=http://localhost:8000/api/v1

# Sign in. -c saves the refresh cookie, -b sends it back later.
curl -s -c cookies.txt -X POST $BASE/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"demo.admin@example.com","password":"Admin@12345"}'

# Call a protected endpoint with the accessToken from the response
TOKEN=...paste the accessToken here...
curl -s $BASE/admin/users -H "Authorization: Bearer $TOKEN"

# Rotate the refresh token (uses the cookie, no body)
curl -s -b cookies.txt -c cookies.txt -X POST $BASE/auth/refresh

# Sign up a new member (security profile is mandatory)
curl -s -X POST $BASE/auth/register -H "Content-Type: application/json" -d '{
  "fullName": "Jane Doe",
  "email": "jane@example.com",
  "password": "Passw0rd!x",
  "securityProfile": {
    "dateOfBirth": "1990-05-21",
    "answerQ2": "Lahore",
    "answerQ3": "Tommy"
  }
}'
```

---

## 4. Configuration (environment variables)

All configuration comes from environment variables. A `.env` file in the working directory is read automatically; real environment variables take precedence over it. Settings are **validated once at start-up** (`app/core/config.py`): a missing or malformed value stops the application at once, and all problems are reported together. `.env.example` documents every variable; the tables below are the reference.

### 4.1 Reference

**Application**

| Variable | Default | Description |
| --- | --- | --- |
| `APP_NAME` | `FastAPI Backend Baseline` | Shown in the OpenAPI docs and the start-up log. |
| `APP_ENV` | `development` | `development`, `production` or `test`. `production` enables strict start-up checks and HSTS, and hides `/docs`, `/redoc`, `/openapi.json`. |
| `LOG_LEVEL` | `INFO` | `DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`. Case-insensitive. |
| `LOG_FORMAT` | `json` | `json` (one object per line, for production) or `text` (readable, for your laptop). |
| `SELF_REGISTRATION_ENABLED` | `true` | `false` makes `POST /auth/register` answer `403 REGISTRATION_DISABLED`. Admins can still create users. |
| `CORS_ORIGINS` | *(empty)* | Comma-separated browser origins allowed to call the API, with no trailing slash. Empty means no cross-origin browser access. No wildcard (see [12.4](#124-the-middlewares-one-by-one)). |
| `TRUSTED_PROXY_COUNT` | `0` | Number of reverse proxies in front of the app. `0` ignores `X-Forwarded-For`. See [13.2](#132-the-client-ip). |
| `RATE_LIMIT_ENABLED` | `true` | Master switch for all rate limits. Turn off only for local experiments. |

**Database**

| Variable | Default | Description |
| --- | --- | --- |
| `DB_HOST` | `127.0.0.1` | |
| `DB_PORT` | `3306` | |
| `DB_USER` | *(required)* | Needs only `SELECT, INSERT, UPDATE, DELETE` on the database. |
| `DB_PASSWORD` | *(required)* | |
| `DB_NAME` | `fastapi_backend_baseline` | |
| `DB_POOL_MIN_SIZE` / `DB_POOL_MAX_SIZE` | `1` / `10` | Connection pool size. Min must not exceed max. |
| `DB_POOL_RECYCLE_SECONDS` | `1800` | Connections older than this are replaced (keep below MySQL's `wait_timeout`). |
| `DB_CONNECT_TIMEOUT_SECONDS` | `10` | |
| `DB_POOL_ACQUIRE_TIMEOUT_SECONDS` | `10` | How long a request waits for a free connection before answering `503`. |

**Tokens**

| Variable | Default | Description |
| --- | --- | --- |
| `JWT_SECRET` | *(required)* | Signs access tokens. **At least 32 characters.** Generate: `python -c "import secrets; print(secrets.token_hex(32))"`. |
| `JWT_ALGORITHM` | `HS256` | `HS256`, `HS384` or `HS512`. |
| `JWT_ISSUER` | `fastapi-backend-baseline` | Written into and verified on every access token. |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | `15` | 1 to 120. |
| `REFRESH_TOKEN_EXPIRE_DAYS` | `7` | 1 to 90. The refresh cookie lives this long. |
| `REFRESH_COOKIE_NAME` | `refresh_token` | |
| `REFRESH_COOKIE_SECURE` | `false` | **Must be `true` in production** (HTTPS only). |
| `REFRESH_COOKIE_SAMESITE` | `lax` | `lax`, `strict` or `none` (`none` requires `REFRESH_COOKIE_SECURE=true`). |
| `REFRESH_COOKIE_DOMAIN` | *(unset)* | Set only if the API and the web app live on different sub-domains. An empty value means "not set". |

**Hashing**

| Variable | Default | Description |
| --- | --- | --- |
| `BCRYPT_ROUNDS` | `12` | Cost, 10 to 15. Each +1 doubles the time (12 is about 250 ms). |
| `SECURITY_ANSWER_PEPPER` | *(required)* | Secret mixed (HMAC) into security answers before bcrypt. At least 32 characters. **Changing it invalidates every stored security answer** (section [9.3](#93-how-answers-are-stored)). |

**Super admin** (the only place its credentials live)

| Variable | Default | Description |
| --- | --- | --- |
| `SUPER_ADMIN_NAME` | `Super Admin` | Synced into the reserved `users` row at every start. |
| `SUPER_ADMIN_EMAIL` | *(required)* | The super admin signs in with this. Synced at every start. |
| `SUPER_ADMIN_PASSWORD_HASH` | *(required)* | A **bcrypt hash**, never the plain password. Generate with `python scripts/hash_password.py`. |

### 4.2 Production safety checks

When `APP_ENV=production`, the application **refuses to start** if any of these hold (all problems are listed together):

* `REFRESH_COOKIE_SECURE` is not `true`;
* `JWT_SECRET` or `SECURITY_ANSWER_PEPPER` still starts with the `change-me` placeholder from `.env.example`;
* `SUPER_ADMIN_PASSWORD_HASH` is the hash of the **public** example password `SuperAdmin@12345`.

Always (any environment): `REFRESH_COOKIE_SAMESITE=none` without `REFRESH_COOKIE_SECURE=true` is refused, `DB_POOL_MIN_SIZE` greater than `DB_POOL_MAX_SIZE` is refused, and `SUPER_ADMIN_PASSWORD_HASH` must look like a bcrypt hash.

### 4.3 The `$` in the super admin hash

A bcrypt hash contains `$` characters. In a `.env` file, **wrap it in single quotes**:

```ini
SUPER_ADMIN_PASSWORD_HASH='$2b$12$....'
```

Without quotes, shells and Docker Compose may treat `$2b` as a variable. When the value is supplied through a secret manager, an `environment:` entry or the process environment, use the bare value with no quotes.

### 4.4 Rotating the super admin password

1. `python scripts/hash_password.py` (asks for the new password twice; the input is hidden; the policy is enforced).
2. Put the printed `SUPER_ADMIN_PASSWORD_HASH=...` line in `.env` (or your secret manager).
3. Restart the application.

Every existing super admin session ends automatically (section [7.7](#77-the-super-admin-session-and-password-rotation)). Nothing is changed in the database: the password never lives there.

---
## 5. Roles and authorization (RBAC)

### 5.1 Roles

| Role | Level | Stored in | Purpose |
| --- | --- | --- | --- |
| `super_admin` | 1000 (in code) | `users` row **`user_id = 1`** only; **not** in `roles` | Top role, no restrictions, exactly one, credentials in ENV only |
| `admin` | 2 (`roles.role_level`) | `roles` + `user_roles` | User management |
| `member` | 1 (`roles.role_level`) | `roles` + `user_roles` | Default role of every sign-up |

### 5.2 The super admin design

The super admin is a **reserved row, `users.user_id = 1`**, because `roles.created_by`, login logs and refresh tokens all have foreign keys to `users`. A purely virtual account would break them and lose the audit trail.

* The row holds only name and e-mail. At **every start-up** they are synced from `SUPER_ADMIN_NAME` / `SUPER_ADMIN_EMAIL` (the row is also created, revived and re-activated if needed).
* It has **no** `user_passwords`, **no** `user_roles` and **no** security-profile row. The start-up check **refuses to run** if someone wrote such rows for id 1.
* The password lives **only in ENV**, as a bcrypt hash (`SUPER_ADMIN_PASSWORD_HASH`), never as plain text. Login compares against it with bcrypt.
* "Only one super admin" is enforced **structurally**: there is no `super_admin` row in `roles`, so it can never be assigned through the API, and a second super admin cannot exist. The start-up check also refuses to run if someone adds a `super_admin` role row.
* Nobody can register with its e-mail (unique index).
* The super admin account is **managed by ENV, not by the API**. Change password, update profile, delete account and security profile do not apply to it (`403 SUPER_ADMIN_PROTECTED`), and no admin endpoint can modify it, not even by the super admin itself. (The public recovery flow treats its e-mail like an unknown e-mail, see [9.6](#96-who-can-use-recovery).)
* To rotate its password: generate a new hash (`python scripts/hash_password.py`), update the secret, restart. Existing sessions end automatically (section [7.7](#77-the-super-admin-session-and-password-rotation)).
* `created_by = 1` on a row means "created by the super admin"; `created_by = NULL` on a user means "self-registered".

**Why ENV and not the database?** A leaked database credential, an SQL injection elsewhere or a careless DB admin could otherwise take over the top account. With ENV, the database cannot grant super admin access. In production the hash can come from a secret manager and stay out of the code base and out of database dumps. The trade-off: rotating the password needs a restart, which is acceptable for a rarely used, tightly controlled account.

### 5.3 The hierarchy rule

> A user can manage only people ranked **strictly below** them: `super_admin > admin > member`.

Exceptions and additions that make it match the agreed behaviour:

* An **admin can create admins and promote a member to admin** (a role can be assigned if its level is ≤ the actor's own level). After that the new admin is a protected peer: other admins cannot edit, demote, deactivate, reset or delete them.
* **Nobody uses the admin endpoints on their own account** (`403 SELF_ACTION_NOT_ALLOWED`). That prevents self-lockout and self-escalation; use `/users/me` instead.
* **The super admin is invisible to admins:** it is left out of their user list and `GET /admin/users/1` answers `404`, so it cannot be targeted. Admins can still *view* other admins (read-only).

### 5.4 Permission matrix

| Action | Member | Admin | Super admin |
| --- | :---: | :---: | :---: |
| Sign up (always creates a Member) | public | | |
| Login, refresh, logout | ✓ | ✓ | ✓ |
| View own profile | ✓ | ✓ | ✓ (read-only) |
| Update own profile (name only; e-mail is immutable) | ✓ | ✓ | – |
| Change own password, manage own security profile | ✓ | ✓ | – (ENV) |
| Forgot password (security questions) | ✓ | ✓ | – (ENV) |
| Delete own account (soft delete, needs password) | ✓ | ✓ | – |
| List and view users | – | ✓ (super admin hidden) | ✓ all |
| Create a user (member or admin) | – | ✓ | ✓ |
| Update another user's profile | – | members only | anyone |
| Activate / deactivate | – | members only | anyone |
| Change a role | – | promote member → admin only | any direction |
| Reset another user's password | – | members only | anyone |
| Delete another user | – | members only | anyone |
| List roles | – | ✓ | ✓ |

"Anyone" never includes the super admin's own account.

### 5.5 Two layers of authorization

1. **Route level.** `Depends(authenticate())` then `Depends(authorize(ROLE_ADMIN))` decide whether a *role* may call an endpoint at all (`app/dependencies/auth.py`). The super admin always passes `authorize`, unless a route says `include_super_admin=False`, which answers `403 SUPER_ADMIN_PROTECTED` (used by every self-service route that does not apply to it).
2. **Instance level.** `modules/admin/policy.py` decides whether *this actor* may perform *this action* on *that target* (`assert_can_manage_user`, `assert_can_assign_role`, `assert_can_view_user`). They are **pure functions** (no database, no HTTP), so they are easy to read and to test as a table.

The role is **never read from the token.** `authenticate` reloads the user from the database on every request, so a role change, deactivation or deletion takes effect on the user's very next request.

The order of checks inside `assert_can_manage_user`:

1. target is the super admin → admins get `404 USER_NOT_FOUND` (it is invisible), the super admin gets `403 SUPER_ADMIN_PROTECTED`
2. target is the actor → `403 SELF_ACTION_NOT_ALLOWED`
3. target's level ≥ actor's level → `403 INSUFFICIENT_ROLE`

### 5.6 Account states

| State | Flag | Can sign in | Can use the API |
| --- | --- | :---: | --- |
| Active | `is_active = 1` | ✓ | ✓ |
| Inactive | `is_active = 0` | ✓ | Only: view profile, refresh, logout, logout-all. Everything else → `403 ACCOUNT_INACTIVE` |
| Deleted | `is_deleted = 1` | ✗ | ✗ (access and refresh tokens stop working at once) |
| Must change password | `must_change_password = 1` | ✓ | Only: view profile, change password, refresh, logout, logout-all. Everything else → `403 PASSWORD_CHANGE_REQUIRED` |

Enforced by default in `authenticate()`. A route opts out explicitly:
`authenticate(allow_inactive=True, allow_password_change_pending=True)`.

An account with **no active role** (corrupt data, or its role was deactivated) is refused with `403 ROLE_NOT_ASSIGNED` at login and on every request.

---

## 6. Database

### 6.1 Entity relationships

```mermaid
erDiagram
    users ||--o| user_passwords : "credentials (none for super admin)"
    users ||--o| user_roles : "exactly one role (none for super admin)"
    roles ||--o{ user_roles : "assigned in"
    users ||--o| user_security_profiles : "recovery answers"
    users ||--o{ user_login_logs : "logins"
    users ||--o{ refresh_tokens : "sessions"
    users ||--o{ password_reset_tokens : "recovery tokens"
    users ||--o{ users : "created_by"
```

### 6.2 Tables

| Table | Purpose |
| --- | --- |
| `users` | Identity. `is_active` = can authenticate but cannot act. `is_deleted` = soft delete. `email_active` / `sso_id_active` are generated columns that are `NULL` for deleted rows, so the `UNIQUE` index only covers live users: a deleted account keeps its history **and** its e-mail is immediately free for a new account. |
| `user_passwords` | One row per user, overwritten on change. `must_change_password` forces a change at next login. `updated_at` doubles as "password last changed at" (invalidates older access tokens). |
| `roles` | Assignable roles (`member`, `admin`) with `role_level`. No `super_admin` row. |
| `user_roles` | One role per user (`user_id` is `UNIQUE`), so a role change is always an `UPDATE`. |
| `user_login_logs` | Every successful login and every failed attempt for a known account (`user_id` is `NOT NULL`, so unknown e-mails go to the application log only). |
| `refresh_tokens` | Only the SHA-256 digest of each token; rotation chain via `replaced_by_hash`. |
| `user_security_profiles` | Hashed answers to the recovery questions, plus `failed_attempts` / `locked_until`. |
| `password_reset_tokens` | Short-lived (10 min), single-use, digest only. |

### 6.3 Conventions

* **UTC everywhere.** Every timestamp is `DATETIME(6)` in UTC; every pooled connection runs `SET time_zone = '+00:00'`. `updated_at` is not auto-updated by MySQL, so services set it explicitly.
* **One clock.** All timestamps that are written, compared or checked against a JWT `iat` come from the **application** clock (`utcnow()` in `app/utils/clock.py`), never from MySQL's default. This way a clock difference between the app server and the database server can never produce false "token older than the password change" results.
* **Soft delete only.** Rows are never physically removed by the API. (Only expired tokens are purged, by the cleanup job.) Every query on `users` filters `is_deleted = FALSE` (or goes through `email_active`). The single exception is the start-up sync, which must find a deleted super admin row to revive it.
* **Audit columns.** `created_by` / `updated_by` reference `users(user_id)`.
* **Booleans** are `TINYINT(1)`. Pydantic converts them to real booleans in API output; code that reads them directly uses `bool(...)`.
* **No `SELECT *`** in application code; columns are always listed explicitly.
* **No `ON DUPLICATE KEY UPDATE`.** It would act on whichever unique index conflicts first, which could silently modify another user's row. Upserts are an explicit `SELECT ... FOR UPDATE` followed by `INSERT` or `UPDATE`.

### 6.4 Changes to the schema you provided

The provided schema was kept as is, with one addition (as in the original design) and two corrections:

* `user_passwords.must_change_password BOOLEAN NOT NULL DEFAULT FALSE` (needed by admin-created users and admin password resets).
* **Fixed:** the SQL files contained `USE node_backend_baseline;` while the database created was `fastapi_backend_baseline`. All three files now use `fastapi_backend_baseline`.
* Formatting restored (indentation was lost when the files were pasted).

Notes: `users` has no `updated_at` / `updated_by`, so profile edits are not audited at column level (see [20](#20-known-limitations-and-future-extensions)). `sso_id` is unused in this baseline; it is an extension point.

### 6.5 SQL files

| File | When | Content |
| --- | --- | --- |
| `database/schema.sql` | Once, to create the database | All tables, indexes and constraints. Requires MySQL 8.0.16+. |
| `database/seed.sql` | **Every environment** (idempotent) | User 1 (placeholder name/e-mail, overwritten from ENV at every start) and the roles `member` (level 1) and `admin` (level 2). |
| `database/seed.demo.sql` | **Development only** (idempotent) | The two demo accounts. Their passwords are public. |

Seed order matters: user 1 is inserted first because `roles.created_by` is `NOT NULL` and references it. With user 1 inserted explicitly, the next real user gets id 2; if the demo seed is loaded, ids 2 and 3 are taken and the next one is 4.

### 6.6 How the SQL layer works (`app/core/database.py`)

```python
from app.core.database import db

row  = await db.fetch_one("SELECT user_id FROM users WHERE user_id = %s", (5,))   # dict or None
rows = await db.fetch_all("SELECT role_id, role_name FROM roles")                 # list of dicts
done = await db.execute("UPDATE users SET full_name = %s WHERE user_id = %s", (name, 5))
done.row_count, done.last_insert_id

async with db.transaction() as tx:          # commit on success, roll back on any exception
    result = await tx.execute("INSERT INTO users (...) VALUES (%s, %s)", (a, b))
    await tx.execute("INSERT INTO user_roles (...) VALUES (%s, %s)", (result.last_insert_id, 1))
```

* **Parameters only.** Values are always passed in `params` with `%s` placeholders. The few dynamic queries (the admin list) join together only fixed SQL fragments written in code, with column names taken from a whitelist; the client chooses a *key* (`sortBy=email`), never SQL text. `LIKE` search terms have `%`, `_` and `\` escaped.
* **Pool.** `asyncmy` pool, UTC per connection, autocommit on; a transaction exists only inside `db.transaction()`. Connections left in a transaction are discarded on release.
* **`row_count` means rows matched.** The `FOUND_ROWS` client flag is set, so `UPDATE ... WHERE user_id = 5` reports `1` even if the new values equal the old ones (otherwise "0 rows" would be ambiguous).
* **Errors.** Server down, pool exhausted, deadlock and lock-wait timeout become `503 SERVICE_UNAVAILABLE` with `Retry-After`. Constraint errors are left for services to translate (a duplicate e-mail becomes `409 EMAIL_ALREADY_EXISTS`). After an outage the pool recovers by itself.
* **Locking reads.** Rows that must not be used twice are locked with `SELECT ... FOR UPDATE` inside a transaction: refresh tokens (rotation) and reset tokens (single use).
* **No nested connections.** Code inside `db.transaction()` always uses the `tx` object, never `db`. (If it did, a pool of size 1 would deadlock. The whole test run was repeated with a pool of one connection to prove this.)
* **MySQL quirk handled.** MySQL evaluates the assignments of an `UPDATE` **left to right**, and later ones see already-updated columns. The recovery lockout counter (`SQL_REGISTER_FAILED_RECOVERY_ATTEMPT`) depends on that order; its comment says "do not reorder". Swapping the two assignments silently loses the lock.
* **Stacked statements.** asyncmy enables multi-statements on the connection. Parameter escaping makes injection impossible, and the application never sends more than one statement at a time.

---

## 7. Authentication and sessions

### 7.1 The pieces

| Token | Form | Lifetime | Where it lives | Stored server-side as |
| --- | --- | --- | --- | --- |
| **Access token** | signed JWT | 15 minutes | Sent by the client as `Authorization: Bearer ...` (keep it in memory) | not stored |
| **Refresh token** | random opaque string (384 bits) | 7 days (sliding) | `httpOnly` cookie, never in a response body | SHA-256 digest in `refresh_tokens` |
| **Reset token** | random opaque string | 10 minutes, single use | Returned once by the recovery flow | SHA-256 digest in `password_reset_tokens` |

**Access token claims:** `sub` (user id), `iat`, `exp`, `iss`, `jti`, and, for the super admin only, `pwf` (see 7.7). **There is no role in the token.**

### 7.2 What `authenticate` does on every request

`app/dependencies/auth.py`, in this order:

1. Read the `Authorization: Bearer` header → `401 UNAUTHORIZED` if missing or malformed.
2. Verify signature, issuer and expiry → `401 TOKEN_EXPIRED` or `401 TOKEN_INVALID`.
3. **Re-load the user from the database** (one query joining users, password row, role). Not found or deleted → `401 TOKEN_INVALID`. This is why deleting an account ends its sessions at once.
4. Reject tokens issued **before the last password change** (`iat` vs `user_passwords.updated_at`, see 7.5) → `401 TOKEN_INVALID`.
5. No active role → `403 ROLE_NOT_ASSIGNED`.
6. Apply the account-state rules (inactive, must change password), see [5.6](#56-account-states).
7. Store the user id in the request context, so every later log line carries it.

### 7.3 Login

```text
POST /auth/login {email, password}
  → rate limits (per IP, per IP + e-mail)
  → look up the live account by e-mail
  → unknown e-mail: do a dummy bcrypt check anyway, answer 401 INVALID_CREDENTIALS
  → wrong password: write a FAILURE row to user_login_logs, answer the SAME 401
  → no active role: 403 ROLE_NOT_ASSIGNED
  → success: update last_login, write a SUCCESS log row, create a refresh token row,
             issue an access token, set the cookie
```

The super admin goes through the same path, except its hash comes from ENV instead of `user_passwords`. Inactive accounts **can** sign in. The `user` object in the response has `isActive` and `mustChangePassword` so a client knows what to show.

### 7.4 Refresh token rotation and reuse detection

```mermaid
sequenceDiagram
    participant C as Client
    participant A as API
    participant D as refresh_tokens
    C->>A: POST /auth/refresh (cookie = token A)
    A->>D: SELECT ... WHERE token_hash = sha256(A) FOR UPDATE
    alt A is active and not expired
        A->>D: A: revoked_at = now, replaced_by_hash = sha256(B)
        A->>D: INSERT token B
        A-->>C: new access token + cookie = B
    else A was already rotated (replaced_by_hash set)
        A->>D: revoke EVERY active token of the user
        A-->>C: 401 TOKEN_INVALID (reuse detected)
    else A revoked for another reason / unknown
        A-->>C: 401 TOKEN_INVALID
    else A expired
        A-->>C: 401 TOKEN_EXPIRED
    end
```

* The row is **locked** (`FOR UPDATE`), so two simultaneous refreshes with the same token cannot both succeed: exactly one wins. This was tested with real parallel requests.
* **Reuse detection:** if an already-rotated token is presented again, two parties hold it (the real user and a thief). All sessions of that user are revoked, and the event is logged as a warning. The revocation is committed before the `401` is raised.
* A token revoked by **logout**, **password change** etc. (no `replaced_by_hash`) is only invalid, not "stolen".
* Rotation is **sliding**: each refresh issues a token valid for another 7 days. There is no absolute session limit (see [20](#20-known-limitations-and-future-extensions)).
* On a refresh failure the response does not clear the cookie; the client should discard its session.

### 7.5 What ends a session

| Event | Refresh tokens | Access tokens already issued |
| --- | --- | --- |
| `POST /auth/logout` | this device's token revoked | stay valid until they expire (≤ 15 min) |
| `POST /auth/logout-all` | all revoked | stay valid until they expire (≤ 15 min) |
| Change password | all revoked, **this device gets fresh tokens** | **rejected immediately** (issued before the change) |
| Forgot-password reset | all revoked | **rejected immediately** |
| Admin resets a password | all revoked | **rejected immediately** |
| Account deleted (self or admin) | all revoked | **rejected immediately** (user no longer found) |
| Role change / deactivation | untouched | **take effect immediately** (re-read on every request) |
| Super admin password rotated in ENV | all revoked at start-up | **rejected immediately** (fingerprint mismatch) |

**The same-second window.** A JWT `iat` has whole-second resolution. The comparison with the password-change time is therefore done in whole seconds: an access token issued less than one second before a password change is not rejected. In exchange, the token issued *in the same request* as the change (change-password hands this device fresh tokens) can never be wrongly rejected. Both are issued with the same timestamp.

### 7.6 The refresh cookie

| Attribute | Value |
| --- | --- |
| Name | `REFRESH_COOKIE_NAME` (default `refresh_token`) |
| `HttpOnly` | always (JavaScript cannot read it) |
| `Path` | `/api/v1/auth` (the browser sends it only to auth endpoints) |
| `Max-Age` | 7 days (`REFRESH_TOKEN_EXPIRE_DAYS`) |
| `SameSite` | `Lax` by default (`REFRESH_COOKIE_SAMESITE`) |
| `Secure` | `REFRESH_COOKIE_SECURE`: false for plain `http://localhost`, **true in production** |
| `Domain` | unset by default (`REFRESH_COOKIE_DOMAIN`) |

The cookie is set on the response object that `send_success()` returns (FastAPI ignores cookies set on the injected `Response` parameter when a route returns its own response).

**Client guidance (browser apps)**

* Keep the access token **in memory**, not in `localStorage`.
* Call the API with credentials included (`fetch(..., { credentials: "include" })`) and list the app's origin in `CORS_ORIGINS`.
* When a call answers `401 TOKEN_EXPIRED`, call `POST /auth/refresh` once, then retry. Use a **single in-flight refresh** shared by all callers (and, across tabs, a lock or `BroadcastChannel`). Two simultaneous refreshes with the same cookie look like token theft and **end all sessions** (reuse detection).
* `SameSite=Lax` works when the web app and the API share a registrable domain (`localhost` ports, or `app.example.com` and `api.example.com`). For a different site use `REFRESH_COOKIE_SAMESITE=none` together with `REFRESH_COOKIE_SECURE=true`.

### 7.7 The super admin session and password rotation

The super admin has no `user_passwords.updated_at` to compare a token's `iat` with, so rotation works differently:

* **Access tokens.** The super admin's JWT carries `pwf`, a short HMAC fingerprint of the *current* `SUPER_ADMIN_PASSWORD_HASH`. `authenticate` recomputes it from ENV on every request. After a rotation and restart the fingerprints differ and old tokens fail with `401 TOKEN_INVALID` at once.
* **Refresh tokens.** At every start-up the super admin's active refresh tokens are revoked.

**Trade-off:** the super admin has to sign in again after *every* restart or deploy, not only after a rotation (there is nowhere to store a "last seen fingerprint" without a schema change). For a rarely used account this is acceptable, and it is the safer default. With several workers, a worker that starts later also revokes super admin sessions created moments earlier by another worker; it only affects the super admin and only around deploys.

Ordinary users' sessions are **not** affected by a restart (tested).

---
## 8. Passwords and account lifecycle

### 8.1 Password policy

Enforced whenever a user **chooses** a password (sign-up, change password, forgot-password reset). It is **not** applied when signing in, only a sanity limit of 128 characters.

* 8 to 64 characters, **and** at most 72 bytes in UTF-8 (bcrypt's own limit; bcrypt 5 refuses longer input)
* at least one uppercase letter, one lowercase letter, one digit and one special character (any character that is not a letter or a digit)

Violations answer `422 VALIDATION_ERROR` with `details[].field = "password"` (or `newPassword`) and a message naming what is missing.

### 8.2 Hashing

* **bcrypt**, cost `BCRYPT_ROUNDS` (default 12 ≈ 250 ms), random salt per hash.
* bcrypt is CPU heavy, so every hash and verify runs in a **worker thread** (`asyncio.to_thread`). The event loop keeps serving other requests (tested: `/health/live` answers in a few milliseconds while 16 logins are hashing).
* Several hashes needed by one request (sign-up hashes the password and up to five answers) run **in parallel threads**, and always **before** a database transaction starts, so no row is locked while bcrypt is working.
* **Timing equalisation.** When an e-mail does not exist, the application still performs the same amount of bcrypt work against a pre-computed dummy hash (with the configured cost), so response time does not reveal which e-mails exist. (Recovery does three dummy checks, matching its three or more real ones.)

### 8.3 Sign-up

`POST /auth/register` always creates a **member**, together with its security profile, in **one transaction** (user, password, role, profile: all or nothing). It does not sign the user in. The e-mail must be free (`409 EMAIL_ALREADY_EXISTS` otherwise). If two sign-ups race with the same e-mail, the unique index lets exactly one win and the other gets the same clean `409`, never a `500` (tested with 12 simultaneous requests). `SELF_REGISTRATION_ENABLED=false` closes this endpoint.

### 8.4 Change password

`POST /auth/change-password` `{currentPassword, newPassword}`:

1. verify the current password (`400 INVALID_CURRENT_PASSWORD`; deliberately **400**, not 401, so a client never mistakes a typo for an expired session and signs the user out);
2. the new password must differ (`422` on `newPassword`) and satisfy the policy;
3. in one transaction: store the new hash, clear `must_change_password`, revoke **all** refresh tokens, issue a **fresh** token pair for this device.

The response has the same shape as login. Other devices are signed out, this device stays signed in.

### 8.5 Admin-created users and temporary passwords

An admin (or the super admin) creates a user with `{fullName, email, role}`. The system generates a **temporary password** (16 characters, always satisfying the policy, avoiding look-alike characters such as `0/O` and `1/l/I`, because an admin may read it out). It is:

* returned **once** in the response (`temporaryPassword`);
* never stored in clear and never logged;
* paired with `must_change_password = 1`: the user can sign in, but only view their profile, change their password, refresh and sign out until they change it (`403 PASSWORD_CHANGE_REQUIRED` for everything else).

The new user has **no security profile** until they set one after signing in (`PUT /auth/security-profile`). `created_by` is the creating admin.

### 8.6 Admin password reset

`POST /admin/users/{id}/reset-password` follows the same model: a new temporary password, `must_change_password = 1`, **all sessions of the user revoked**, any pending recovery token cancelled. Admins never choose or see a real password. It is also the fallback when a user forgot their security answers (there is no e-mail to fall back on). Admins can reset **members** only; only the super admin can reset an admin.

### 8.7 Deleting an account

Both `DELETE /users/me` (the owner, with their password in the JSON body) and `DELETE /admin/users/{id}` perform a **soft delete** (`close_account` in `users/service.py`), in one transaction:

* `users.is_deleted = TRUE` (the row and its foreign keys stay, history is intact);
* all refresh tokens revoked, pending reset tokens cancelled;
* the e-mail becomes free **immediately** (`email_active` turns `NULL`), so a new account can use it.

Access tokens stop working at once because `authenticate` no longer finds the user. The super admin can never be deleted (`close_account` refuses it as a last line of defence).

`DELETE /users/me` carries a JSON body because deleting needs re-authentication. (Some HTTP clients and proxies drop bodies on `DELETE`; this one does not.)

### 8.8 Names and e-mail addresses

* **E-mail:** trimmed and lower-cased before any query; at most 150 characters; unique among live accounts, case-insensitively (the column collation is `utf8mb4_0900_as_ci`). **Immutable** through every endpoint, because it is the login identifier.
* **Full name:** trimmed, 2 to 100 characters, any Unicode (stored as `utf8mb4`). The only profile field a user or admin can edit.

### 8.9 Login log

Every successful login and every failed attempt **for a known account** is written to `user_login_logs` (status, failure reason, IP). Attempts with an unknown e-mail go only to the application log, with the e-mail masked (`j***@example.com`), because the table requires a `user_id`.

---

## 9. Password recovery (security questions)

There is no e-mail service, so a forgotten password is recovered with **security questions**.

### 9.1 The flow

```mermaid
sequenceDiagram
    participant U as User
    participant A as API
    U->>A: POST /auth/forgot-password/questions {email}
    A-->>U: the questions to ask (3 fixed + the account's custom ones)
    U->>A: POST /auth/forgot-password/verify {email, answers...}
    Note over A: check ALL answers, count failures, lock after 5
    A-->>U: {resetToken, expiresIn: 600}
    U->>A: POST /auth/forgot-password/reset {resetToken, newPassword}
    A-->>U: 200 (all sessions of the account are ended)
    U->>A: POST /auth/login (with the new password)
```

### 9.2 The questions

* **Fixed for everyone (defined in code, `FIXED_SECURITY_QUESTIONS`):**
  1. *What is your date of birth?* (field `dateOfBirth`, `YYYY-MM-DD`)
  2. *In which city were you born?* (field `answerQ2`)
  3. *What was the name of your first pet?* (field `answerQ3`)
* **Custom, optional, written by the user (up to two):** `customQuestion1` / `customAnswer1` and `customQuestion2` / `customAnswer2`. A question and its answer are sent together or not at all (also enforced by `CHECK` constraints). The question text is stored; the answer is not.

`GET /auth/security-questions` returns the fixed ones (for the sign-up form). `POST /auth/forgot-password/questions` returns the fixed ones plus the account's custom ones. Each question has an `id` which is also the **name of the request field that carries its answer** (`dateOfBirth`, `answerQ2`, `answerQ3`, `customAnswer1`, `customAnswer2`).

### 9.3 How answers are stored

Answers are **never stored or logged in plain text.**

1. **Normalise:** Unicode NFKC, case-folded, whitespace trimmed and collapsed. `" LAHORE "`, `"lahore"` and a decomposed `ü` versus a composed `ü` all become the same value. The date of birth is an ISO date string.
2. **Pepper:** HMAC-SHA256 with `SECURITY_ANSWER_PEPPER` (a secret from ENV), over `"<field>:<answer>"`. The field name is part of the message so a hash made for one question cannot be moved into another question's column and still verify. A leaked database alone cannot be brute-forced offline without the pepper.
3. **bcrypt** the resulting 64 hex characters (this also keeps it below bcrypt's 72-byte limit).

> **Changing `SECURITY_ANSWER_PEPPER` invalidates every stored answer.** Treat it as a long-lived secret. (Rotating it would need key versioning, see [20](#20-known-limitations-and-future-extensions).)

### 9.4 Verifying and the lockout

`POST /auth/forgot-password/verify`:

* **All** answers must be right. They are all checked (no early exit), so neither the timing nor the error reveals which answer was wrong. Answers are case- and whitespace-insensitive.
* An account that has custom questions must answer them too; a missing custom answer counts as a wrong one.
* Wrong answers answer `401 INVALID_SECURITY_ANSWERS` and are counted **atomically** in the database (`failed_attempts`). On the **5th** wrong attempt the account is locked for **15 minutes** (`locked_until`) and the counter restarts at 0.
* While locked, even correct answers answer `429 ACCOUNT_LOCKED` with a `Retry-After` header (seconds).
* A successful verification resets the counter and issues the reset token.

This is **on top of** the IP rate limits (10 per 15 minutes per IP, 5 per 15 minutes per IP + e-mail, see [15](#15-rate-limiting)).

### 9.5 The reset token and the reset

A successful verification issues a **reset token**: random, valid **10 minutes**, **single use**, stored only as a SHA-256 digest. Issuing a new one supersedes (invalidates) every earlier unused token of that user.

`POST /auth/forgot-password/reset` `{resetToken, newPassword}` locks the token row, then in one transaction: sets the new password (policy applies), clears `must_change_password`, marks the token used, **revokes all sessions** of the account and clears the lockout counters. It does **not** sign the user in. A token that is unknown, used, superseded or expired answers `400 RESET_TOKEN_INVALID`, and the same applies if the account was deleted in the meantime.

### 9.6 Who can use recovery

| Account | Behaviour |
| --- | --- |
| Member / admin **with** a security profile | Works as described. |
| Account **without** a profile (created by an admin, the demo accounts) | Looks exactly like an unknown e-mail: `questions` returns the fixed questions, `verify` answers `401 INVALID_SECURITY_ANSWERS`. The user must sign in first and call `PUT /auth/security-profile`, or ask an admin for a password reset. |
| Unknown e-mail | Fixed questions; `verify` answers `401 INVALID_SECURITY_ANSWERS`, after the same amount of bcrypt work as a real attempt. |
| **Super admin** | Credentials live in ENV, so recovery does not apply. The public endpoints treat its e-mail **like an unknown e-mail** (they do **not** answer `403 SUPER_ADMIN_PROTECTED`, which would reveal that this is the super admin's address). The authenticated self-service routes do answer `403 SUPER_ADMIN_PROTECTED`. |

**Creating or replacing the profile** (`PUT /auth/security-profile`) **requires the current password** (`400 INVALID_CURRENT_PASSWORD` otherwise) and clears any lockout. The answers are a second key to the account; without this check a stolen access token could plant answers and take the account over through the recovery flow. `GET /auth/security-profile` tells whether a profile exists and shows the custom question texts.

### 9.7 Information the public endpoints still reveal

* `POST /auth/forgot-password/questions` returns an account's **custom question texts**, so an e-mail that has custom questions is distinguishable from one that has none. This is inherent to showing questions before authentication; accounts without custom questions are indistinguishable from unknown e-mails.
* Anybody can lock another account's *recovery* for 15 minutes by sending wrong answers for its e-mail (the IP rate limits make this expensive but not impossible).

---

## 10. Standard API response and error handling

There are exactly **two** response shapes. The HTTP status code is the source of truth, so the body does not repeat it.

**Success**

```json
{
  "success": true,
  "message": "Users fetched successfully",
  "data": [],
  "meta": { "page": 1, "limit": 20, "total": 134, "totalPages": 7 },
  "requestId": "b1c2d3e4-..."
}
```

* `data` is `null` when there is nothing to return.
* `meta` appears only on paginated lists.
* Convention for `data`: a single resource is the object itself; a list is an array (with `meta`); an endpoint returning several things uses a named object (`{ user, temporaryPassword }`, `{ accessToken, tokenType, expiresIn, user }`).
* JSON uses **camelCase**. Timestamps are ISO-8601 in UTC with a trailing `Z` (`2026-11-21T05:53:36.056835Z`).

**Failure**

```json
{
  "success": false,
  "message": "Validation failed",
  "error": {
    "code": "VALIDATION_ERROR",
    "details": [{ "field": "email", "message": "Invalid email address" }]
  },
  "requestId": "b1c2d3e4-..."
}
```

* `details` is optional (validation issues; the failing probe of a readiness check).
* `requestId` comes from the request context store and matches every log line of that request (it is also returned as the `X-Request-Id` header).
* **Unexpected errors return a generic message**; the stack trace and the cause go to the logger only.

Helpers: `send_success`, `send_created` (201) in `app/utils/response.py`. **Failures are produced solely by the error handler** (`app/errors/handlers.py`); services and routers just `raise`.

### 10.1 Custom exception classes

Raise these from services and routers (`app/errors/exceptions.py`). Constructor: `new XxxError(message?, code=..., details=..., cause=..., meta=...)`, in Python `XxxError(message=None, *, code=None, details=None, cause=None, meta=None)`.

| Class | HTTP | Default code |
| --- | :---: | --- |
| `BadRequestError` | 400 | `BAD_REQUEST` |
| `UnauthorizedError` | 401 | `UNAUTHORIZED` |
| `ForbiddenError` | 403 | `FORBIDDEN` |
| `NotFoundError` | 404 | `NOT_FOUND` |
| `ConflictError` | 409 | `CONFLICT` |
| `PayloadTooLargeError` | 413 | `PAYLOAD_TOO_LARGE` |
| `ValidationError` | 422 | `VALIDATION_ERROR` |
| `TooManyRequestsError` | 429 | `RATE_LIMITED` |
| `InternalServerError` | 500 | `INTERNAL_ERROR` |
| `ServiceUnavailableError` | 503 | `SERVICE_UNAVAILABLE` |

* `message` is shown to the client (never put secrets in it); `code` is the stable machine-readable value clients should switch on; `details` is shown to the client; `cause` is for the logs only; `meta` is internal and never in the body (`meta={"retry_after": 30}` adds a `Retry-After: 30` header).
* A `401` always carries `WWW-Authenticate: Bearer`.
* `ValidationError` (ours) and Pydantic's are different classes. Inside the project, import ours from `app.errors.exceptions`.

### 10.2 Error codes

| Code | HTTP | Meaning |
| --- | :---: | --- |
| `VALIDATION_ERROR` | 422 | Body / query / params failed validation (also unknown fields) |
| `BAD_REQUEST` | 400 | Malformed JSON and other generic client errors |
| `INVALID_CURRENT_PASSWORD` | 400 | Wrong current password (deliberately not 401: clients must not treat it as an expired session) |
| `RESET_TOKEN_INVALID` | 400 | Password-reset token unknown, used, superseded or expired |
| `UNAUTHORIZED` | 401 | Missing / malformed `Authorization` header (or missing refresh cookie) |
| `TOKEN_INVALID` | 401 | Bad, revoked or no-longer-valid token (also after a password change, and for a deleted account) |
| `TOKEN_EXPIRED` | 401 | Expired access or refresh token |
| `INVALID_CREDENTIALS` | 401 | Wrong e-mail or password (same answer for both) |
| `INVALID_SECURITY_ANSWERS` | 401 | Recovery answers incorrect (same answer for unknown accounts) |
| `FORBIDDEN` | 403 | Generic fallback; the application uses the specific codes below |
| `INSUFFICIENT_ROLE` | 403 | The role (or hierarchy) does not allow it |
| `ACCOUNT_INACTIVE` | 403 | `is_active = 0` |
| `PASSWORD_CHANGE_REQUIRED` | 403 | `must_change_password = 1` |
| `SUPER_ADMIN_PROTECTED` | 403 | Action not applicable to the ENV-managed super admin |
| `SELF_ACTION_NOT_ALLOWED` | 403 | Admin endpoint used on one's own account |
| `ROLE_NOT_ASSIGNED` | 403 | The account has no active role |
| `REGISTRATION_DISABLED` | 403 | `SELF_REGISTRATION_ENABLED=false` |
| `CORS_ORIGIN_NOT_ALLOWED` | 403 | Origin not in `CORS_ORIGINS` |
| `USER_NOT_FOUND` / `ROLE_NOT_FOUND` / `ROUTE_NOT_FOUND` / `NOT_FOUND` | 404 | Resource not found |
| `EMAIL_ALREADY_EXISTS` / `CONFLICT` | 409 | Duplicate |
| `PAYLOAD_TOO_LARGE` | 413 | Body over 100 kb |
| `RATE_LIMITED` | 429 | Rate limit hit (`Retry-After` is sent) |
| `ACCOUNT_LOCKED` | 429 | Recovery locked after 5 wrong attempts (`Retry-After`) |
| `INTERNAL_ERROR` | 500 | Unexpected error (generic message) |
| `SERVICE_UNAVAILABLE` | 503 | Database unavailable / busy (`Retry-After`) |

### 10.3 How the framework's own errors are mapped

| Situation | Result |
| --- | --- |
| Request body is not valid JSON | `400 BAD_REQUEST` (FastAPI's default would be a 422) |
| A field is invalid or unknown | `422 VALIDATION_ERROR`, `details` = `[{field, message}]` with dotted paths such as `securityProfile.dateOfBirth` |
| A body sent without `Content-Type: application/json` | `422 VALIDATION_ERROR` on `field: "body"` with a message that says what to do |
| Unknown route **or** wrong method | `404 ROUTE_NOT_FOUND` (both are "no such endpoint" to a client) |
| Anything unexpected | `500 INTERNAL_ERROR` with a generic message; the real error and stack trace are logged |
| Request rejected by a middleware | The same failure shape (`403 CORS_ORIGIN_NOT_ALLOWED`, `429 RATE_LIMITED`, `413 PAYLOAD_TOO_LARGE`) |

A malformed HTTP request (for example a garbage `Content-Length` header) is rejected by the HTTP server itself, before the application sees it, with the server's own plain-text `400`. That cannot be wrapped.

---

## 11. API reference

Base URL: `/api/v1`. Probes live at `/health` (unversioned). Bodies are JSON (`Content-Type: application/json`, max 100 kb). Protected routes need `Authorization: Bearer <accessToken>`. Interactive docs: `/docs` (not in production).

Legend for "Access": 🌐 public · 🍪 refresh cookie · 🔑 Bearer token (the role in brackets).

### 11.1 Auth: `/auth`

| Method | Path | Access | Description |
| --- | --- | --- | --- |
| GET | `/auth/security-questions` | 🌐 | The fixed recovery questions |
| POST | `/auth/register` | 🌐 | Sign up (member). `201`. Errors: `409 EMAIL_ALREADY_EXISTS`, `403 REGISTRATION_DISABLED` |
| POST | `/auth/login` | 🌐 | Sign in → access token + cookie. Errors: `401 INVALID_CREDENTIALS`, `403 ROLE_NOT_ASSIGNED` |
| POST | `/auth/refresh` | 🍪 | Rotate the refresh token. Errors: `401 UNAUTHORIZED / TOKEN_INVALID / TOKEN_EXPIRED` |
| POST | `/auth/logout` | 🍪 | End this session (idempotent) |
| POST | `/auth/logout-all` | 🔑 any (inactive / must-change allowed) | End every session |
| POST | `/auth/change-password` | 🔑 member, admin (must-change allowed) | Change password, keep this device signed in. Error: `400 INVALID_CURRENT_PASSWORD` |
| GET | `/auth/security-profile` | 🔑 member, admin | Is the recovery profile configured? |
| PUT | `/auth/security-profile` | 🔑 member, admin | Create / replace the recovery profile (needs `currentPassword`) |
| POST | `/auth/forgot-password/questions` | 🌐 | Questions for an e-mail |
| POST | `/auth/forgot-password/verify` | 🌐 | Verify answers → reset token. Errors: `401 INVALID_SECURITY_ANSWERS`, `429 ACCOUNT_LOCKED` |
| POST | `/auth/forgot-password/reset` | 🌐 | Set a new password with the token. Error: `400 RESET_TOKEN_INVALID` |

**Request bodies**

| Endpoint | Body |
| --- | --- |
| `register` | `fullName`, `email`, `password`, `securityProfile` `{ dateOfBirth, answerQ2, answerQ3, customQuestion1?, customAnswer1?, customQuestion2?, customAnswer2? }` |
| `login` | `email`, `password` |
| `change-password` | `currentPassword`, `newPassword` |
| `PUT security-profile` | `currentPassword` + the same fields as `securityProfile` above |
| `forgot-password/questions` | `email` |
| `forgot-password/verify` | `email`, `dateOfBirth`, `answerQ2`, `answerQ3`, `customAnswer1?`, `customAnswer2?` (the custom ones are required when the account has custom questions) |
| `forgot-password/reset` | `resetToken`, `newPassword` |

Field rules: `dateOfBirth` is `YYYY-MM-DD` between 1900-01-01 and yesterday; answers are 2 to 100 characters; custom questions 5 to 200 characters; unknown fields are rejected.

**Login / refresh / change-password response** (the refresh token is in the cookie, never in the body):

```json
{
  "success": true,
  "message": "Signed in successfully",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "tokenType": "Bearer",
    "expiresIn": 900,
    "user": {
      "userId": 2,
      "fullName": "Demo Admin",
      "email": "demo.admin@example.com",
      "role": "admin",
      "isActive": true,
      "mustChangePassword": false,
      "lastLogin": "2026-11-21T05:53:36.328711Z",
      "createdAt": "2026-11-21T05:53:31.189109Z"
    }
  },
  "requestId": "7cbbfdd6-5eb8-4cc0-9081-cd1aa865891a"
}
```

with `Set-Cookie: refresh_token=<opaque>; HttpOnly; Max-Age=604800; Path=/api/v1/auth; SameSite=lax` (plus `Secure` when `REFRESH_COOKIE_SECURE=true`).

### 11.2 Users (self-service): `/users`

| Method | Path | Access | Description |
| --- | --- | --- | --- |
| GET | `/users/me` | 🔑 any (inactive / must-change allowed) | Own profile |
| PATCH | `/users/me` | 🔑 member, admin | Update own **full name** (e-mail is immutable). Body `{ "fullName": "..." }` |
| DELETE | `/users/me` | 🔑 member, admin | Delete own account. Body `{ "password": "..." }` (re-authentication) |

### 11.3 Admin: `/admin` (admin and super admin)

| Method | Path | Description |
| --- | --- | --- |
| GET | `/admin/users` | List users. Query: `page`, `limit` (1-100, default 20), `search` (name or e-mail), `role` (`admin`/`member`), `isActive`, `sortBy` (`createdAt`, `fullName`, `email`, `lastLogin`), `sortOrder` (`asc`/`desc`) |
| POST | `/admin/users` | Create a user `{ fullName, email, role }` → temporary password (shown once). `201` |
| GET | `/admin/users/{userId}` | Get one user |
| PATCH | `/admin/users/{userId}` | Update the full name |
| PATCH | `/admin/users/{userId}/role` | Change role `{ role: "admin" \| "member" }` |
| PATCH | `/admin/users/{userId}/status` | Activate / deactivate `{ isActive: true \| false }` |
| POST | `/admin/users/{userId}/reset-password` | Reset password → temporary password (shown once) |
| DELETE | `/admin/users/{userId}` | Soft-delete the user |

Which targets an admin may act on is defined in section [5](#5-roles-and-authorization-rbac). `role=super_admin` is not a valid filter or value anywhere.

**Paginated list** (`GET /admin/users?limit=2&sortBy=email&sortOrder=asc`):

```json
{
  "success": true,
  "message": "Users fetched successfully",
  "data": [
    {
      "userId": 2, "fullName": "Demo Admin", "email": "demo.admin@example.com", "role": "admin",
      "isActive": true, "mustChangePassword": false,
      "lastLogin": "2026-11-21T05:53:36.328711Z", "createdAt": "2026-11-21T05:53:31.189109Z",
      "createdBy": 1
    }
  ],
  "meta": { "page": 1, "limit": 2, "total": 3, "totalPages": 2 },
  "requestId": "6a8e59d8-3277-4294-881c-65aee1a69a8e"
}
```

**Create a user** (`POST /admin/users`, `201`):

```json
{
  "success": true,
  "message": "User created successfully",
  "data": {
    "user": { "userId": 5, "fullName": "Bob Builder", "email": "bob@example.com", "role": "member",
              "isActive": true, "mustChangePassword": true, "lastLogin": null,
              "createdAt": "2026-11-21T05:53:36.423626Z", "createdBy": 2 },
    "temporaryPassword": "fYSs=H#m-rqc3gUZ"
  },
  "requestId": "2ea8bb93-6515-4c3b-915d-00a34693dc42"
}
```

### 11.4 Roles and health

| Method | Path | Access | Description |
| --- | --- | --- | --- |
| GET | `/roles` | 🔑 admin, super admin | Assignable roles with an `assignable` flag per caller; `?assignable=true` filters |
| GET, HEAD | `/health`, `/health/live` | 🌐 | Liveness (no dependencies) |
| GET, HEAD | `/health/ready` | 🌐 | Readiness: database ping, `503` when down (`error.details` = `[{"probe":"database","status":"down"}]`) |

### 11.5 Example failures

```json
{ "success": false, "message": "Incorrect e-mail or password.",
  "error": { "code": "INVALID_CREDENTIALS" }, "requestId": "e868cb06-..." }
```

```json
{ "success": false, "message": "Validation failed",
  "error": { "code": "VALIDATION_ERROR", "details": [
    { "field": "password", "message": "Password must be 8 to 64 characters long; must contain an uppercase letter; ..." },
    { "field": "securityProfile.dateOfBirth", "message": "Date must be written as YYYY-MM-DD" } ] },
  "requestId": "bae804aa-..." }
```

---
## 12. Request lifecycle and middleware

### 12.1 The journey of a request

```text
 Client
   │
   ▼
 1  RequestContextMiddleware   request id, context store, X-Request-Id header, access log     (outermost)
 2  SecurityHeadersMiddleware  nosniff, frame deny, no-store, CSP, HSTS (production)
 3  CORSGuardMiddleware        unknown browser origin → 403; answers CORS preflight
 4  GlobalRateLimitMiddleware  100 requests / minute / IP (health probes exempt)
 5  BodySizeLimitMiddleware    body over 100 kb → 413
 6  ErrorBoundaryMiddleware    unexpected crash → standard 500                               (innermost)
   │
   ▼
 FastAPI: exception handlers → routing → dependencies → body validation
   • per-route rate limit      Depends(limit_by_ip(...))
   • authenticate / authorize  who are you, may your role call this
   • request validation        Pydantic models (unknown fields rejected)
   │
   ▼
 router.py  (thin: HTTP only)  →  service.py  (logic + SQL)  →  MySQL
   │
   ▼
 send_success(...)  → the response travels back UP through 6 → 1, collecting headers
```

### 12.2 Why this order

* **RequestContext is outermost.** Everything below it (other middleware, routers, services, the logger, the error handler) already knows the request id, and the access log line is written after everything else has finished.
* **ErrorBoundary is innermost.** Starlette answers an unexpected exception from *outside* all middleware, so that 500 would miss the CORS headers, the security headers and `X-Request-Id`, and a browser shows a misleading "CORS error" instead of the real 500. Catching the crash just outside the router makes the 500 travel outwards through 3 → 1 like any other response (tested).
* **Cheap rejections come before the body is read:** unknown origin (3), rate limit (4), declared `Content-Length` (5).
* **SecurityHeaders and CORS are outside the rate limit and size limit,** so 429 and 413 responses carry the CORS headers and a browser can read them.

### 12.3 How errors flow

1. Code in a router or service **raises** an exception (ours, or Pydantic/FastAPI's).
2. FastAPI's registered exception handler converts it with `to_app_error()` and builds the response with `failure_response()` (`app/errors/handlers.py`).
3. A middleware that rejects a request early (CORS, rate limit, body size) calls the **same** `failure_response()` itself and writes the response to the next layer outwards.
4. An exception that nobody handled is caught by `ErrorBoundaryMiddleware` and becomes a generic `500`.

So there is one function that builds failure bodies, and the response shape cannot drift.

### 12.4 The middlewares, one by one

**1. `request_context.py`.** Takes the request id from an incoming `X-Request-Id` header if (and only if) it matches `^[A-Za-z0-9._-]{8,64}$`, otherwise generates a UUID (so a gateway can propagate its trace id, and nothing hostile can end up in logs or headers). Resolves the client IP ([13.2](#132-the-client-ip)), opens the context store, adds `X-Request-Id` to the response, and writes **one access-log line** per request (method, path without query string, status, duration, IP, user id, error code).

**2. `security_headers.py`.**

| Header | Value |
| --- | --- |
| `X-Content-Type-Options` | `nosniff` |
| `X-Frame-Options` | `DENY` |
| `Referrer-Policy` | `no-referrer` |
| `Cache-Control` | `no-store` (responses contain account data and tokens) |
| `Content-Security-Policy` | `default-src 'none'; frame-ancestors 'none'` on API responses (not on `/docs`, `/redoc`, `/openapi.json`, which need scripts) |
| `Strict-Transport-Security` | `max-age=31536000; includeSubDomains`, only when `APP_ENV=production` |

**3. `cors_guard.py`.** Starlette's `CORSMiddleware` never *rejects* a request (it only omits headers), so a custom guard is used:

| Request | Result |
| --- | --- |
| No `Origin` header (curl, mobile apps, server to server) | Passes |
| `Origin` host equals the API's own `Host` (Swagger UI "Try it out", same-site) | Passes |
| `Origin` listed in `CORS_ORIGINS` | Passes with `Access-Control-Allow-Origin`, `-Allow-Credentials: true`, `-Expose-Headers: X-Request-Id, Retry-After`, `Vary: Origin`. A preflight (`OPTIONS` + `Access-Control-Request-Method`) is answered here with `204` |
| Any other `Origin` | `403 CORS_ORIGIN_NOT_ALLOWED` |

Origins must be listed **one by one** (no wildcard): `Allow-Credentials: true` is needed for the refresh cookie, and browsers forbid combining it with `*`. Allowed methods: `GET, POST, PUT, PATCH, DELETE, OPTIONS`; allowed request headers: `Authorization, Content-Type, X-Request-Id`; preflight cache 10 minutes.

**4. `rate_limit.py`.** Applies `GLOBAL_PER_IP` (100 per minute per client IP) to everything except paths under `/health`.

**5. `body_size_limit.py`.** A declared `Content-Length` above 100 kb is refused immediately without reading a byte. Otherwise (for example chunked bodies) the body is read **in this middleware, counting bytes**, refused as soon as it exceeds the limit, and then handed to the application unchanged. Because at most 100 kb is ever buffered, this is safe, and it guarantees that "too large" is raised **outside** FastAPI's body parsing, which would otherwise turn any exception raised while reading into a `400`. Starlette 1.x has a built-in `max_body_size`, but it answers with a plain-text body, which would break the "two shapes" rule.

**6. `error_boundary.py`.** See 12.2.

All six are **pure ASGI** middleware (not `BaseHTTPMiddleware`): faster, and they keep context variables working correctly across the whole request.

### 12.5 Adding a middleware

Write a class with `__init__(self, app)` and `async def __call__(self, scope, receive, send)`, pass through when `scope["type"] != "http"`, and register it in `_register_middleware()` in `app/main.py` at the right place in the list. The list is written outermost first; the code adds it in reverse because Starlette makes the last middleware added the outermost one.

---

## 13. Request context store

`app/core/context.py`. For every HTTP request one `RequestContext` object is created by the outermost middleware and kept in a `ContextVar`:

| Field | Set by | Used for |
| --- | --- | --- |
| `request_id` | request middleware | the `requestId` in every response body, `X-Request-Id`, every log line |
| `method`, `path` | request middleware | the access log |
| `client_ip` | request middleware | rate limits, login logs, `password_reset_tokens.requested_ip` |
| `user_agent` | request middleware (max 512 chars) | `refresh_tokens.user_agent` |
| `user_id`, `role` | `authenticate` | every later log line carries the user id |
| `error_code` | the error handler | shown in the access log |

Any code that runs while a request is being handled can read it **without it being passed around as an argument**: `get_request_id()`, `get_client_ip()`, `get_user_agent()`, `get_user_id()`. Concurrent requests never see each other's data (each asyncio task has its own copy). Outside of a request (start-up code, scripts) there is no context and the getters return `None`.

The `ContextVar` holds a **mutable object** rather than separate variables, so `authenticate` filling in the user id is visible to the access-log middleware that finishes the request later.

### 13.1 Request id

Every response has the id twice: `X-Request-Id` and `requestId` in the body. Every log line of that request has it too. When a client reports a problem, ask for the `requestId` and search the logs for it.

### 13.2 The client IP

`resolve_client_ip()` in `middleware/request_context.py`.

* `TRUSTED_PROXY_COUNT=0` (default): the IP of the TCP peer. `X-Forwarded-For` is **ignored**, so it cannot be spoofed.
* `TRUSTED_PROXY_COUNT=N`: the app is behind N proxies, and each proxy appends the address it saw to `X-Forwarded-For`. The entry appended by the first proxy (the one facing the internet) is the **N-th from the right**. Everything to its left could have been forged by the client. If the header has fewer entries than N, or the chosen entry is not a valid IP address, the TCP peer is used.

Examples: header `6.6.6.6, 198.51.100.7, 10.0.0.1` gives `198.51.100.7` with `N=2`; header `6.6.6.6, 198.51.100.7` gives `198.51.100.7` with `N=1`.

Run Uvicorn with **`--no-proxy-headers`** when you use `TRUSTED_PROXY_COUNT`, so that only one component interprets forwarded headers (the Dockerfile does this).

---

## 14. Logging

`app/core/logger.py`. Standard-library `logging`, configured once at start-up. Every log line automatically carries the `requestId` and `userId` of the request that produced it (read from the context store).

**JSON (default, for production)**: one object per line, ready for ELK, Loki, CloudWatch and similar:

```json
{"timestamp": "2026-11-21T05:53:36.328+00:00", "level": "INFO", "logger": "app.middleware.request_context",
 "message": "request completed", "requestId": "7cbbfdd6-5eb8-4cc0-9081-cd1aa865891a", "userId": 2,
 "data": {"method": "GET", "path": "/api/v1/admin/users", "status": 200, "durationMs": 14.2, "ip": "203.0.113.5"}}
```

**Text (`LOG_FORMAT=text`, for your laptop):** `05:53:36.328 INFO    [7cbbfdd6 user=2] app.middleware.request_context: request completed {"method": ...}`.

### 14.1 How to log

```python
from app.core.logger import get_logger
logger = get_logger(__name__)

logger.info("User created", extra={"data": {"userId": 5}})   # structured fields go in extra["data"]
logger.warning("Something odd")
logger.error("Failed", exc_info=exc)
```

### 14.2 What is logged

| Event | Level | Notes |
| --- | --- | --- |
| Every request | INFO (ERROR for 5xx) | `request completed` with method, path (no query string), status, `durationMs`, IP, `errorCode`. `/health*` successes are DEBUG, so probes do not flood the log |
| Unexpected errors / 5xx | ERROR | with the stack trace; the client only ever sees a generic message |
| Login failure, recovery failure, refresh-token **reuse** | WARNING | user id, never the secret. An unknown e-mail is logged masked (`j***@example.com`) |
| Register, login success, password change, reset, logout-all, security profile saved | INFO | user id |
| Admin actions (create, update, role, activate/deactivate, reset, delete) | INFO | `actorId`, `targetId`, and what changed (an audit trail) |
| Start-up and shutdown, super admin sync, cleanup results | INFO | |

### 14.3 What is never logged

Passwords (including temporary passwords), password hashes, security answers, access / refresh / reset tokens, cookies, `Authorization` headers, and query strings. As a **safety net**, any value stored under a key containing `password`, `token`, `secret`, `answer`, `hash`, `authorization` or `cookie` is replaced by `[REDACTED]` (numbers such as counts are left alone). The test run checked the server log for the passwords and tokens used.

Uvicorn's own access log is turned off (this one replaces it) and its other loggers are routed through the same formatter.

---

## 15. Rate limiting

All numbers are in **one file**: `app/core/rate_limit_rules.py`. "Per IP + e-mail" stops one attacker from guessing one account's password or answers without locking out everybody who shares an IP.

| Route | Per IP | Per IP + e-mail |
| --- | --- | --- |
| *every request (global)* | 100 / min | |
| `POST /auth/login` | 20 / 15 min | 5 / 15 min |
| `POST /auth/register` | 5 / hour | |
| `POST /auth/refresh` | 30 / min | |
| `POST /auth/forgot-password/questions` | 10 / 15 min | 5 / 15 min |
| `POST /auth/forgot-password/verify` | 10 / 15 min | 5 / 15 min (plus the database lockout) |
| `POST /auth/forgot-password/reset` | 5 / 15 min | |
| `POST /auth/change-password` | 5 / 15 min | |
| `PUT /auth/security-profile` | 5 / 15 min | |
| `DELETE /users/me` | 5 / 15 min | |

The last two rows are not in the original design: they are routes that re-check the caller's current password, so they share the strict "5 per 15 minutes" rule of change-password (a stolen access token must not be able to guess the password).

**Semantics**

* **Sliding window log:** a hit is refused when the key already has `limit` hits inside the last `window` seconds. Refused hits are not recorded, so hammering is not punished beyond the window.
* **All attempts count**, successful ones too (5 logins per 15 minutes for one e-mail from one IP).
* **Per-IP limits are checked before the body is validated** (a dependency), so malformed requests are limited too. Per-IP + e-mail limits need the e-mail, so they run right after validation, inside the route, and the e-mail is normalised first (case and spaces cannot dodge the limit).
* **Response:** `429 RATE_LIMITED` in the standard shape with a `Retry-After` header (seconds until the oldest hit leaves the window).
* The global limit exempts `/health*` (load balancers probe from one IP).
* `RATE_LIMIT_ENABLED=false` switches everything off.

**In-memory store, Redis later.** The counters live in the memory of one process (`InMemoryRateLimitStore`, with periodic pruning of idle keys). That is right for one instance and for this baseline; with several instances or workers each one counts separately and counters reset on restart. The store sits behind a one-method interface (`RateLimitStore.hit(key, limit, window_seconds)`), so a Redis implementation can be passed to `RateLimiter(...)` at the bottom of `app/core/rate_limit.py` without touching anything else.

**How a route uses it**

```python
@router.post("/login", dependencies=[Depends(limit_by_ip(LOGIN_PER_IP))])
async def login(payload: LoginRequest):
    await limit_by_ip_and_email(LOGIN_PER_IP_EMAIL, payload.email)
    ...
```

---

## 16. Start-up, seeding and background jobs

### 16.1 Start-up sequence (`app/lifespan.py`)

Any failure stops the application with a clear message.

1. Settings are validated (import time): missing or unsafe configuration is reported all at once.
2. The database pool is opened.
3. A throw-away bcrypt hash with the configured cost is prepared (timing equalisation).
4. **Start-up checks** (`modules/system/service.py`):
   * **Sync the super admin.** Create / revive / re-activate `users.user_id = 1` and overwrite its name and e-mail from `SUPER_ADMIN_NAME` / `SUPER_ADMIN_EMAIL`. If another live user already owns that e-mail the application refuses to start and names the user. The super admin's active refresh tokens are revoked (see [7.7](#77-the-super-admin-session-and-password-rotation)).
   * **Refuse unsafe data.** `user_passwords`, `user_roles` or `user_security_profiles` rows for user 1, or any role named `super_admin` → refuse to start.
   * **Check the seed.** `member` and `admin` must exist, be active and not deleted, otherwise the message says "Load database/seed.sql".
   * In production: a **warning** if the demo accounts exist.
5. The hourly token cleanup task is started.

On shutdown the cleanup task is cancelled and the pool is closed.

### 16.2 Token cleanup

Expired refresh and password-reset tokens are the only rows the application physically deletes. `cleanup_expired_tokens()` deletes them in batches of 5000 (so no single `DELETE` blocks others for long), once at start-up and then every hour. The same function runs on demand with `python scripts/cleanup_tokens.py` (useful for an external scheduler: cron, a Kubernetes CronJob).

`user_login_logs` is not purged (see [20](#20-known-limitations-and-future-extensions)).

### 16.3 Several workers or instances

* The start-up sync is idempotent and runs in every worker. Load `seed.sql` **before** the first start with several workers (so user 1 already exists; two workers inserting it simultaneously could collide).
* A worker that starts later revokes the super admin's refresh tokens again, which can end a super admin session created moments earlier by another worker (only around deploys, only the super admin).
* The token cleanup runs in every worker. It is idempotent and harmless; use `scripts/cleanup_tokens.py` from one scheduler instead if you prefer.
* Rate-limit counters are per process (see section 15).

---

## 17. Project structure and coding conventions

### 17.1 Layout

```text
fastapi_backend_baseline/
├── app/
│   ├── main.py                  # app factory: logging → FastAPI → middleware → error handlers → routers
│   ├── lifespan.py              # start-up / shutdown sequence
│   ├── api_router.py            # mounts every module router under /api/v1
│   ├── core/                    # infrastructure, knows nothing about HTTP routes or features
│   │   ├── config.py            #   settings from ENV, validated; production safety checks
│   │   ├── constants.py         #   roles, levels, security questions, limits (no magic numbers)
│   │   ├── context.py           #   request context store (ContextVar)
│   │   ├── current_user.py      #   the CurrentUser dataclass
│   │   ├── database.py          #   asyncmy pool, fetch_one / fetch_all / execute, transaction()
│   │   ├── logger.py            #   structured logging that reads the context store
│   │   ├── rate_limit.py        #   rate limiter + store interface (in-memory now, Redis later)
│   │   ├── rate_limit_rules.py  #   every rate limit number
│   │   └── security.py          #   bcrypt, JWT, token hashing, answer pepper
│   ├── errors/
│   │   ├── exceptions.py        #   custom exception classes
│   │   ├── handlers.py          #   the ONLY producer of failure responses
│   │   └── responses.py         #   OpenAPI documentation of error responses
│   ├── middleware/              # six pure-ASGI middlewares (see section 12)
│   ├── dependencies/
│   │   ├── auth.py              #   authenticate(...) and authorize(...)
│   │   └── rate_limit.py        #   per-route rate limit helpers
│   ├── utils/
│   │   ├── response.py          #   send_success / send_created / build_page_meta
│   │   ├── schemas.py           #   RequestModel / ResponseModel, shared field types, envelope models
│   │   ├── passwords.py         #   password policy, temporary password generator
│   │   ├── clock.py             #   utcnow(): the single time source
│   │   └── privacy.py           #   mask_email
│   └── modules/                 # one folder per feature
│       ├── auth/    router · schemas · service · tokens · credentials · cookies
│       ├── users/   router · schemas · service
│       ├── admin/   router · schemas · service · policy
│       ├── roles/   router · schemas · service
│       ├── health/  router
│       └── system/  service (start-up checks, cleanup) · tasks
├── database/        schema.sql · seed.sql · seed.demo.sql
├── scripts/         hash_password.py · cleanup_tokens.py
├── .env.example · requirements.txt · pyproject.toml (lint config only)
├── Dockerfile · docker-compose.yml · docker-compose.dev.yml
└── README.md
```

Note: the logging module is `logger.py` (not `logging.py`) so it can never shadow Python's standard `logging` module.

### 17.2 The layers

| Layer | May contain | Must not contain |
| --- | --- | --- |
| `router.py` | HTTP concerns only: path, method, status code, dependencies (auth, rate limit), calling the service, `send_success(...)` | SQL, business rules |
| `schemas.py` | Pydantic request and response models | logic |
| `service.py` | Business logic **and its SQL** (named constants at the top), raising `AppError` subclasses | HTTP objects (`Request`, `Response`) |
| `policy.py` | Pure functions: plain data in, return or raise | database, HTTP |
| `core/` | Infrastructure | feature logic |

Dependency direction: `router → service → core / other modules' services`. Modules reuse each other **through services and the small shared SQL files** (`auth/tokens.py`, `auth/credentials.py`), never through each other's routers. For example `admin` uses `users.close_account`, `roles.set_user_role`, `auth.tokens` and `auth.credentials`, so no query exists twice and there are no circular imports.

### 17.3 Coding conventions

* **Every file starts with a docstring** that says what it is for. Functions are short and do one thing.
* **SQL:** named constants `SQL_...` at the top of the service, `%s` placeholders, parameters always in the second argument, columns listed explicitly, `is_deleted = FALSE` on `users`, `updated_at` set explicitly, timestamps from `utcnow()`.
* **Errors:** raise a specific exception class with a stable `code` and a safe message. Never build an error response by hand. Never put secrets or internals in a message.
* **Responses:** return `send_success(data, "Message")` or `send_created(...)`. Declare `response_model=SuccessResponse[...]` on the route so Swagger shows the real shape.
* **JSON is camelCase**, Python is snake_case (converted by the base models). Request models forbid unknown fields.
* **Slow work (bcrypt) happens before a transaction**, and code inside a transaction uses only the `tx` object.
* **Logging:** structured fields in `extra={"data": {...}}`; never log secrets.
* **Time:** only `utcnow()`; never `datetime.now()` and never MySQL's `NOW()` for values the app compares.

### 17.4 Adding a new module (worked example: `notes`)

1. **Table.** Add it to `database/schema.sql` (and ship a small `ALTER`/`CREATE` script for databases that already exist). Follow the conventions: `BIGINT AUTO_INCREMENT` id, `DATETIME(6)` UTC, `is_deleted`, `created_by`/`created_at`.
2. **Folder** `app/modules/notes/` with `__init__.py`, `schemas.py`, `service.py`, `router.py`.
3. **Schemas**

```python
# app/modules/notes/schemas.py
from typing import Annotated
from pydantic import StringConstraints
from app.utils.schemas import RequestModel, ResponseModel, UtcDatetime

class CreateNoteRequest(RequestModel):
    title: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=200)]

class NoteOut(ResponseModel):
    note_id: int
    title: str
    created_at: UtcDatetime
```

4. **Service** (logic and SQL together)

```python
# app/modules/notes/service.py
from app.core.current_user import CurrentUser
from app.core.database import db
from app.errors.exceptions import NotFoundError
from app.modules.notes.schemas import NoteOut
from app.utils.clock import utcnow

SQL_INSERT_NOTE = "INSERT INTO notes (user_id, title, created_at, created_by) VALUES (%s, %s, %s, %s)"
SQL_NOTE_BY_ID = """
SELECT note_id, title, created_at
FROM notes
WHERE note_id = %s AND user_id = %s AND is_deleted = FALSE
"""

async def create_note(user: CurrentUser, title: str) -> NoteOut:
    result = await db.execute(SQL_INSERT_NOTE, (user.user_id, title, utcnow(), user.user_id))
    return await get_note(user, result.last_insert_id)

async def get_note(user: CurrentUser, note_id: int) -> NoteOut:
    row = await db.fetch_one(SQL_NOTE_BY_ID, (note_id, user.user_id))
    if row is None:
        raise NotFoundError("Note not found.", code="NOTE_NOT_FOUND")
    return NoteOut.model_validate(row)
```

5. **Router**

```python
# app/modules/notes/router.py
from fastapi import APIRouter, Depends
from app.core.constants import ROLE_ADMIN, ROLE_MEMBER
from app.core.current_user import CurrentUser
from app.dependencies.auth import authorize
from app.errors.responses import PROTECTED_RESPONSES
from app.modules.notes import service
from app.modules.notes.schemas import CreateNoteRequest, NoteOut
from app.utils.response import send_created
from app.utils.schemas import SuccessResponse

router = APIRouter(prefix="/notes", tags=["Notes"], responses=PROTECTED_RESPONSES)

@router.post("", status_code=201, summary="Create a note", response_model=SuccessResponse[NoteOut])
async def create_note(
    payload: CreateNoteRequest,
    user: CurrentUser = Depends(authorize(ROLE_MEMBER, ROLE_ADMIN, include_super_admin=False)),
):
    note = await service.create_note(user, payload.title)
    return send_created(note, "Note created successfully")
```

6. **Mount it** in `app/api_router.py`: `api_router.include_router(notes_router)`.
7. **Checklist before you are done**
   * a docstring on every new file; SQL as named constants with `%s` placeholders and explicit columns;
   * the route declares who may call it (`authenticate` / `authorize`) and, if it is sensitive, a rate limit;
   * errors raised as exception classes with a stable `code`;
   * no secrets in logs or messages;
   * the endpoint added to section 11 of this README (and its error codes to section 10).

### 17.5 Optional linting

`pip install ruff` then `ruff check .`. The rules are in `pyproject.toml` (line length 120).

---
## 18. Deployment

### 18.1 Production checklist

* [ ] `APP_ENV=production` (turns on the strict start-up checks, HSTS, hides `/docs`).
* [ ] `REFRESH_COOKIE_SECURE=true` and the app is served over **HTTPS** (terminate TLS at your proxy / load balancer).
* [ ] Fresh secrets: `JWT_SECRET` and `SECURITY_ANSWER_PEPPER` (random, at least 32 characters, **different from each other**, stored in a secret manager). Keep the pepper for the life of the data (changing it invalidates every stored security answer).
* [ ] Your **own** super admin password: `python scripts/hash_password.py` (production refuses the public example).
* [ ] `seed.demo.sql` was **not** loaded. (If it was, the start-up log warns.)
* [ ] A least-privilege database user (`SELECT, INSERT, UPDATE, DELETE`); the schema is loaded by a different, privileged account.
* [ ] `CORS_ORIGINS` lists exactly the browser origins that need access.
* [ ] `TRUSTED_PROXY_COUNT` equals the number of proxies in front of the app, and Uvicorn runs with `--no-proxy-headers`.
* [ ] `LOG_FORMAT=json`, and the logs are shipped somewhere searchable.
* [ ] The server clock is synchronised (NTP). JWT `iat` is compared across instances with a 10 second leeway.
* [ ] Database pool size: `workers × DB_POOL_MAX_SIZE` must stay below MySQL's `max_connections`.
* [ ] Probes: liveness `GET /health/live`, readiness `GET /health/ready`.
* [ ] Database backups configured.

### 18.2 Running the app

```bash
# one process (development, small deployments)
uvicorn app.main:app --host 0.0.0.0 --port 8000 --no-proxy-headers

# several worker processes
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4 --no-proxy-headers
```

Rate-limit counters are per worker (section 15). Start-up checks run in every worker (section 16.3). Prefer a few workers with `DB_POOL_MAX_SIZE` sized accordingly over one huge pool.

**Behind nginx** (one proxy, so `TRUSTED_PROXY_COUNT=1`):

```nginx
location / {
    proxy_pass http://127.0.0.1:8000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;   # appends; the app reads the last entry
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

### 18.3 Docker and Compose

`docker-compose.yml` runs MySQL 8.4 + the API; add `-f docker-compose.dev.yml` only for development (it loads the demo accounts). For production, build the image, run only the `api` service, and point it at a managed or separately operated MySQL: set `DB_HOST`, supply secrets through your platform's secret store instead of a `.env` file, and load `schema.sql` and `seed.sql` once with a privileged account. The image runs as an unprivileged user, has a `HEALTHCHECK`, and does **not** contain `.env` (see `.dockerignore`).

### 18.4 Database

* MySQL 8.0.16+ (8.4 LTS recommended), `utf8mb4`. Timestamps are stored as UTC `DATETIME(6)`, and each connection pins its session time zone to UTC, so the server's time zone setting does not matter.
* The application never changes the schema, so its user needs only `SELECT, INSERT, UPDATE, DELETE` (verified: the whole test run, the recovery flow with its locking reads, and the cleanup job all work with exactly these four privileges).
* **Schema changes.** The baseline has no migration tool: the schema is a plain SQL file. For a live database, ship numbered SQL scripts (`database/migrations/002_add_notes.sql`) and apply them with your usual process. A migration tool such as Alembic can be added later without an ORM (it can run raw SQL).

---

## 19. Security notes

| Threat | Mitigation | Where |
| --- | --- | --- |
| Stolen database | Passwords and answers are bcrypt hashes; answers are also peppered with a secret that is not in the database; tokens stored only as SHA-256; the super admin's password is not in the database at all | `core/security.py`, section 9.3 |
| SQL injection | Values are always bound parameters; dynamic SQL uses only fixed fragments and whitelisted columns; LIKE terms are escaped; there is no ORM-style string building from input | section 6.6 |
| Credential stuffing, brute force | Layered rate limits (IP and IP + e-mail), bcrypt cost, same error and same timing for unknown e-mail and wrong password | sections 8.2, 15 |
| Guessing recovery answers | All answers must be right, per-account lockout (5 wrong → 15 min), peppered hashes, rate limits | section 9.4 |
| User enumeration | Identical error and timing for unknown versus wrong; the recovery endpoints answer alike for unknown, super admin and profile-less accounts (the one remaining signal, custom question texts, is listed in 9.7) | sections 7.3, 9.6 |
| Refresh-token theft | Opaque tokens, rotation, **reuse detection** revokes all sessions, `httpOnly` cookie limited to `/api/v1/auth`, `SameSite`, `Secure` in production | section 7.4 |
| Access-token theft | 15-minute lifetime; the user is re-read on every request (deactivation, deletion, role change take effect at once); password change / reset invalidates older tokens | sections 7.2, 7.5 |
| JWT attacks | Algorithm pinned from settings (`alg=none` and other algorithms are refused), issuer verified, `exp`, `iat`, `sub`, `iss` required | `core/security.py`, tested |
| Privilege escalation | Role never read from the token; hierarchy rule in pure functions; roles can only be assigned up to the actor's level; `super_admin` is not a role; mass assignment impossible (request models forbid unknown fields) | section 5 |
| CSRF | The only cookie-authenticated endpoints are `refresh` and `logout`; the cookie is `SameSite` and path-limited; foreign origins get `403` from the CORS guard; every other endpoint needs a header token that a foreign site cannot attach | sections 7.6, 12.4 |
| Clickjacking, content sniffing | `X-Frame-Options: DENY`, CSP `frame-ancestors 'none'`, `nosniff` | section 12.4 |
| Information leaks in errors and logs | Generic 500 message, stack traces only in logs, secrets never logged (+ redaction safety net), query strings not logged, e-mails masked | sections 10, 14 |
| Resource exhaustion | Global and per-route rate limits, 100 kb body limit, bcrypt in threads (event loop stays responsive), bounded pool with acquire timeout, 503 with `Retry-After` | sections 12, 15 |
| Misconfiguration | Validated settings; production refuses insecure cookie, placeholder secrets and the public example super admin password; start-up refuses unsafe database contents | sections 4.2, 16.1 |
| Supply chain | All dependencies pinned to exact tested versions | `requirements.txt` |

If you adapt the project, re-read section 20 first: it lists what the baseline deliberately does not do.

---

## 20. Known limitations and future extensions

These are known, accepted limits of the baseline, not surprises.

### 20.1 Known limitations

| Limitation | Impact | Possible fix |
| --- | --- | --- |
| **Access tokens cannot be revoked individually.** `logout` and `logout-all` end refresh tokens; already issued access tokens live until they expire (≤ 15 minutes). | A stolen access token works for up to 15 minutes after logout. (Deactivation, deletion, role changes and password changes are *not* affected: they take effect at once.) | Add a `tokens_valid_after` column on `users` and compare it with `iat`, exactly like the password-change check. |
| **Sub-second window for password change.** `iat` has whole-second resolution. | A token issued less than one second before a password change is not rejected. | Add a token version number to the user and the JWT. |
| **Rate-limit counters are per process** and reset on restart. | With several workers or instances the effective limit is higher. | Implement the store interface on Redis (section 15). |
| **Reuse detection also fires on benign parallel refreshes** (two tabs refreshing with the same cookie at the same moment). | The user is signed out everywhere and must sign in again. | Client-side single-flight refresh (section 7.6) and/or a short grace window for a just-rotated token. |
| **No absolute session lifetime.** Rotation is sliding: a session that keeps refreshing never ends by age. | A stolen-but-unnoticed refresh token that is rotated regularly stays alive. | Store `session_started_at` and refuse refresh beyond N days. |
| **The super admin signs in again after every restart or deploy.** | Inconvenience for a rare account. | Store the last-seen password fingerprint (needs a schema change). |
| **`users` has no `updated_at` / `updated_by`.** | Profile edits (name, status) are not audited at column level. Admin actions are in the application log. | Add the two columns and set them in the update queries. |
| **`user_login_logs` is never purged.** | Unbounded growth. | A retention job, like the token cleanup. |
| **Login attempts for unknown e-mails are not in `user_login_logs`.** (`user_id` is `NOT NULL`.) | They are only in the application log. | Allow `NULL` or add a separate table. |
| **Security questions are a weaker recovery channel than e-mail or MFA.** | Answers can be guessed or known to someone close to the user. Mitigated by hashing, peppering, lockout and rate limits. | Add e-mail or TOTP-based recovery as an alternative channel. |
| **Recovery can be locked by an attacker** (5 wrong answers for a victim's e-mail lock it for 15 minutes). | Nuisance; sign-in with the password still works. | CAPTCHA or per-IP-and-account lockout. |
| **Custom question texts are public** through `forgot-password/questions`. | Distinguishes accounts that have custom questions (see 9.7). | Ask custom questions only after the fixed answers are verified (a two-step flow). |
| **Changing `SECURITY_ANSWER_PEPPER` invalidates every stored answer.** | Cannot be rotated casually. | Key versioning stored next to each hash. |
| **No password blocklist or strength meter** (policy only checks composition). | `Password1!` passes. | Check against a breached-password list (k-anonymity API) or zxcvbn. |
| **No e-mail verification and no MFA.** | By design (no e-mail service). | See the extension ideas below. |
| **Start-up with several workers** against an empty database can race on creating user 1; a later worker revokes the super admin's sessions again. | Only on a first-ever start or around deploys. | Load `seed.sql` first (section 16.3); run the start-up sync as a one-off job. |
| **Offset pagination and `LIKE '%term%'` search.** | Deep pages and large tables get slower; the search cannot use an index. | Keyset pagination; a `FULLTEXT` index. |
| **Docker files were not executed during the build** (no Docker in the build environment). | They may need small adjustments on your machine. | Run `docker compose up --build` once and report problems. |
| **Tested on MySQL 8.0.46**, not on 8.4. | 8.4 should work (only `caching_sha2_password`, which is covered by the `cryptography` dependency), but it has not been run. | Run it against 8.4 as part of your acceptance. |

### 20.2 Extension ideas and where they plug in

| Idea | Where |
| --- | --- |
| Redis-backed rate limiting | implement `RateLimitStore` in `core/rate_limit.py` |
| Single sign-on (`users.sso_id` exists, unused) | a new auth router and service; the unique `sso_id_active` index is ready |
| More roles | add rows to `roles` with a `role_level`; the hierarchy rule and `assignable` flag adapt automatically (update the `AssignableRole` literal in `admin/schemas.py`) |
| E-mail or SMS channels | a notification service; recovery and invitation flows can use it |
| MFA (TOTP) | a table + two endpoints in `auth`; `authenticate` stays unchanged |
| Metrics and tracing | a middleware beside `request_context.py`; the request id is already propagated |
| Per-tenant data | add a tenant id to `CurrentUser` and to queries |
| API keys for service accounts | a table + an alternative branch in `authenticate` |
| Soft-delete restore | an admin endpoint that flips `is_deleted` back (watch the unique e-mail index) |
| Migrations | Alembic running raw SQL, or numbered `.sql` files |
| Automated tests | see section 22.4 |

---

## 21. Decisions log

### 21.1 Open questions we settled

| Question | Decision | Why |
| --- | --- | --- |
| Can an admin change a **member's** password? | Yes, as a **reset**: system-generated temporary password, shown once, forced change at next login, sessions revoked | Admins never choose or see a real password; it is the fallback when someone forgets their security answers (no e-mail) |
| Can an admin change **another admin's** password? | **No**, super admin only | A rogue or compromised admin could otherwise take over peer accounts |
| Can an admin **delete another admin**? | **No**, super admin only | Same reason |
| Can an admin **update another admin's role**? | Admins may **promote** members to admin but cannot demote; demotion is super-admin only | Matches "admins can add admins", keeps peers protected |
| Can members and admins **delete their own profile**? | Yes: soft delete, needs the password, revokes every session, frees the e-mail | The unique-active-e-mail design supports re-registration; the system is never orphaned because the super admin always exists |
| Super admin | Reserved row `user_id = 1`, credentials only in ENV (bcrypt hash), not a role | Foreign keys and the audit trail need a real row; "only one" is structural |

### 21.2 Other decisions

| Topic | Decision |
| --- | --- |
| Tokens | 15-minute JWT + opaque rotating refresh token in an `httpOnly` cookie, with reuse detection |
| Per-request check | `authenticate` re-reads `is_deleted`, `is_active`, role and password state from the database on every request |
| Inactive users | May sign in, refresh, log out and view their profile; everything else returns `403 ACCOUNT_INACTIVE` (explicit allow-list) |
| Admin-created users | Temporary password + `must_change_password`; no security profile until they set one after first login |
| E-mail | Immutable through every endpoint (it is the login identifier) |
| Profile | The only editable profile field is the full name |
| Rate limiting | On every auth route, layered per IP and per IP + e-mail |
| Super admin visibility | Hidden from admins (list omits it, `GET /admin/users/1` is `404`) |
| Self-service for the super admin | Not applicable; ENV is the source of truth (`403 SUPER_ADMIN_PROTECTED`) |
| Role hierarchy | Generic rule on `role_level`: manage only strictly lower levels; assign roles up to your own level |
| Sign-up | Does not auto-login; security profile mandatory |
| Change password | Revokes all sessions but keeps the calling device signed in |
| Access-token invalidation | Tokens issued before the last password change are rejected (`iat` vs `user_passwords.updated_at`) |
| Security answers | Normalised, peppered (HMAC) and bcrypt-hashed |
| Roles vs. JWT | The JWT carries no role |
| Seed data | `seed.sql` (required, idempotent) is separate from `seed.demo.sql` (development only), so production can never receive demo accounts by accident |
| `DELETE /users/me` | Carries a JSON body (`{ password }`) because deleting requires re-authentication |
| Runtime | Python 3.12+ (the original design named Node 22+) |

### 21.3 Refinements made while building

Changes relative to the original design, each with its reason. They are all in the code and in this document.

| # | Refinement | Why |
| --- | --- | --- |
| 1 | `PUT /auth/security-profile` **requires `currentPassword`**, and change-password, security-profile and `DELETE /users/me` share the strict 5 / 15 min limit | The recovery answers are a second key to the account; a stolen access token must not be able to plant answers, or guess the password |
| 2 | The **public recovery endpoints answer for the super admin's e-mail like for an unknown e-mail**, not with `403 SUPER_ADMIN_PROTECTED` | A 403 there would confirm which address belongs to the top account. The authenticated self-service routes still return the 403 |
| 3 | **`TRUSTED_PROXY_COUNT`** (a number) instead of a `TRUST_PROXY_HEADERS` flag | A boolean that trusts `X-Forwarded-For` is spoofable whenever the proxy appends to the header. The N-th entry from the right is correct for any number of proxies; `0` is "trust nothing" |
| 4 | **Production safety checks** (secure cookie, no placeholder secrets, no public example super admin password) | The example `.env` is public; running production with it must be impossible, not merely discouraged |
| 5 | **`cryptography` is pinned in `requirements.txt`** | asyncmy needs it for MySQL 8's default login but does not declare it (found with a clean virtualenv, section 22) |
| 6 | Logging module named `logger.py` | Avoids shadowing Python's `logging` |
| 7 | The **application clock** is the only source of time; token and password-change times are compared in whole seconds | No dependence on the database's clock; the token issued with a password change is never wrongly rejected |
| 8 | `FOUND_ROWS` client flag | `row_count` means "rows matched", so an `UPDATE` that changes nothing is not mistaken for "not found" |
| 9 | No `ON DUPLICATE KEY UPDATE`; explicit `SELECT ... FOR UPDATE` upserts | The clause would act on whichever unique index conflicts first, possibly another user's row |
| 10 | Own body-size middleware instead of Starlette 1.x's `max_body_size` | The built-in answers with plain text and would break the two-shapes rule |
| 11 | `ErrorBoundaryMiddleware` as the innermost layer | So a 500 still carries CORS headers, security headers and the request id |
| 12 | Incoming `X-Request-Id` is honoured when valid | Lets a gateway propagate its trace id, without letting anyone inject arbitrary text into logs |
| 13 | Dummy bcrypt work for unknown e-mails (login and recovery) | Response time must not reveal which e-mails exist |
| 14 | Start-up **refuses** unsafe data (rows for user 1, a `super_admin` role, a clashing e-mail, missing seed roles) | "Exactly one super admin, never assignable" is then guaranteed, not assumed |
| 15 | Refresh **reuse detection only for rotated tokens** | A token revoked by logout is merely invalid; treating it as theft would sign users out wrongly |
| 16 | Unknown routes **and** wrong methods → `404 ROUTE_NOT_FOUND`; malformed JSON → `400 BAD_REQUEST` | Consistent with the error-code list (FastAPI's defaults are 405 and 422) |
| 17 | A friendly `422` message for a missing JSON `Content-Type` | The most common mistake when trying an API with a bare `curl -d` |
| 18 | `HEAD` accepted on the health probes | Some load balancers probe with `HEAD` |
| 19 | `GET /users/me` allowed in every account state | A client needs it to learn *why* it is restricted (`isActive`, `mustChangePassword`) |
| 20 | Admin views include `createdBy` | `created_by = NULL` (self-registered) and `1` (super admin) carry meaning for admins |
| 21 | Timestamps in API output are UTC with `Z`; JSON is camelCase; request models forbid unknown fields | Unambiguous times; one naming style; no mass assignment |
| 22 | Security headers (`nosniff`, frame deny, `no-store`, CSP, HSTS in production) | Cheap, standard hardening for an API that returns account data |
| 23 | Login accepts any password up to 128 characters (policy not applied) | Changing the policy later must never lock anyone out; the cap only avoids pointless hashing work |
| 24 | A redaction safety net in the logger | Defence in depth if someone ever logs a secret by mistake |
| 25 | `Generic[T]` kept instead of the newer class syntax; ruff configured | Readability for the widest audience |
| 26 | `DB_NAME` fixed to `fastapi_backend_baseline` inside Compose | The SQL files hard-code the database name; a mismatch would give MySQL's user no privileges |

### 21.4 Express to FastAPI translation

| Original (Express) | Here (FastAPI) |
| --- | --- |
| `authenticate()` / `authorize(ROLES.ADMIN)` middleware | `Depends(authenticate())` / `Depends(authorize(ROLE_ADMIN))`, `app/dependencies/auth.py` |
| `admin.policy.js` (`assertCanManageUser`, `assertCanAssignRole`) | `modules/admin/policy.py` (`assert_can_manage_user`, `assert_can_assign_role`) |
| Request validation (zod / Joi) | Pydantic v2 models in each `schemas.py` |
| Request context store (`AsyncLocalStorage`) | `contextvars.ContextVar` (`app/core/context.py`) |
| Structured logger (pino / winston) | Standard `logging` with `JsonFormatter` (`app/core/logger.py`) |
| `express-rate-limit` (Redis later) | Custom sliding-window limiter behind a store interface (Redis later) |
| `helmet`, `cors`, JSON body limit | `SecurityHeadersMiddleware`, `CORSGuardMiddleware`, `BodySizeLimitMiddleware` |
| Error-handling middleware | Exception handlers + `ErrorBoundaryMiddleware` (`app/errors/handlers.py`) |
| `sendSuccess`, `sendCreated` (`src/utils/response.js`) | `send_success`, `send_created` (`app/utils/response.py`) |
| `src/errors/` classes | `app/errors/exceptions.py` |
| `mysql2` pool, `timezone: 'Z'` | `asyncmy` pool with `init_command="SET time_zone = '+00:00'"` |
| `Boolean(...)` for `TINYINT(1)` | `bool(...)` / Pydantic |
| `npm run hash-password` | `python scripts/hash_password.py` |
| `package.json`, Node 22+ | `requirements.txt`, Python 3.12+ |
| `dotenv` | `pydantic-settings` (validated at start-up) |
| `jsonwebtoken`, `bcrypt` | `PyJWT`, `bcrypt` (in worker threads) |

### 21.5 Decisions taken with the project owner during the build

| Topic | Decision |
| --- | --- |
| Concurrency model | **Async** FastAPI with a pooled async driver (`asyncmy`) |
| Python and packaging | Python 3.12+, `pip` and `requirements.txt` |
| Query style | Plain parameterised SQL in each module's `service.py`; no ORM |
| Project shape | Module-based layout (`router`, `schemas`, `service`, `policy` where needed) with shared code in `core/`; **no tests module** for now |
| Schema, seeds | The provided SQL kept as is; the `USE node_backend_baseline` typo fixed; the provided demo password hashes reused unchanged |
| Fixed security questions | Date of birth; *In which city were you born?*; *What was the name of your first pet?* |
| Password policy | 8 to 64 characters, upper + lower + digit + special (≤ 72 bytes) |
| Rate limits | The table in section 15; in-memory now, Redis-ready |
| Refresh cookie | `refresh_token`, `httpOnly`, 7 days, `SameSite=Lax`, path `/api/v1/auth`, `Secure` driven by an ENV flag |
| Super admin credentials | In ENV only (bcrypt hash), not in the database |
| Super admin password rotation | Done through ENV + restart; **invalidates every existing super admin session** (password-hash fingerprint in the JWT, refresh tokens revoked at start-up) |
| Docker | `Dockerfile` + `docker-compose.yml` (app + MySQL 8.4); the demo seed only through the development overlay |
| Documentation | One README containing every decision, delivered with the project as a zip |

---

## 22. Verification: what was tested

### 22.1 Environment

Built and tested on Ubuntu 24.04, **Python 3.12.3**, **MySQL 8.0.46** and the exact versions in `requirements.txt`. The suites below ran against the **real running server over HTTP** and the **real database**, not against mocks.

### 22.2 Test suites (401 checks, all passing on the final code)

The checks were scratch scripts used while building. By decision there is no tests module in the project, so they are **not shipped**; section 22.4 lists what to turn into permanent tests.

| Suite | Checks | What it covers |
| --- | ---: | --- |
| Basics | 36 | Response envelope, request id, security headers, 404/405, malformed JSON, validation details, 413 (declared and chunked), CORS (allowed, rejected, preflight, same-host), OpenAPI |
| Auth 1 | 70 | Sign-up validation and normalisation, DB contents (nothing stored in clear), login, JWT claims, every token failure mode (`alg=none`, wrong secret/issuer, expired, unknown user), refresh rotation, **theft detection**, expiry, **concurrent refresh race**, logout, logout-all, change password with token invalidation |
| Auth 2 | 51 | Recovery questions, wrong answers, **lockout**, case/space-insensitive answers, reset token (single use, superseded, expired), security profile, super admin protections |
| Admin | 122 | Route-level and instance-level authorization, hidden super admin, hierarchy, self-actions, role changes taking effect immediately, account states, temporary passwords and forced change, resets, soft delete and e-mail reuse, pagination, search, **SQL-injection and LIKE-wildcard attempts**, audit logging, no secrets in the log |
| Rate limits | 27 | Every limit in section 15, the global limit, health exemption, and the sliding-window store with a controlled clock |
| Start-up | 30 | Refusal of unsafe data (all cases), super admin row repair, empty database, **super admin password rotation**, configuration validation |
| Resilience | 41 | Unexpected crash path (generic message, CORS and security headers kept, stack in the log), batched token cleanup (12 000 rows), JSON log structure and request-id correlation, client-IP / proxy handling, production mode, disabled registration, **database outage and automatic recovery** |
| Concurrency | 6 | 12 simultaneous sign-ups with one e-mail (one winner, no half-created rows), 30 parallel logins, `/health` stays fast while bcrypt runs |
| Extras | 18 | `HEAD` probes, wrong `Content-Type`, Unicode names and answers, id bounds, OpenAPI quality |

### 22.3 Other checks

* **Mutation checks.** Four critical behaviours were deliberately broken (peer-admin management allowed, old tokens accepted after a password change, reuse detection removed, the recovery-lock `UPDATE` reordered). Every mutation made the suites fail, so the tests are not vacuous. The `UPDATE` ordering was also proved directly in MySQL: with the assignments swapped, the 5th wrong attempt resets the counter but **loses the lock**.
* **Pool of one connection.** The auth and admin suites were repeated with a connection pool of size 1 (acquire timeout 3 s). They all pass, proving no code path holds a connection while asking for another.
* **Least privilege.** The admin and recovery suites and the cleanup script were repeated with a database user that has only `SELECT, INSERT, UPDATE, DELETE`.
* **Clean installation.** A fresh virtual environment with only `requirements.txt` boots against MySQL 8's default login. Removing `cryptography` reproduces the failure described in section 23, which is how the missing dependency was found.
* **Lint.** `ruff check .` passes; every line is within 120 characters.

### 22.4 Not tested, and recommended tests to add

**Not tested:** the Docker files (no Docker in the build environment), MySQL 8.4, Windows and macOS, real browsers (CORS and cookies were verified at the HTTP level, not in a browser), load and performance.

**Worth turning into permanent tests** (the framework-agnostic ones first):

1. `admin/policy.py` as a table: actor × target × action → allowed or error code.
2. Password policy and temporary-password generator.
3. `InMemoryRateLimitStore` with a fake clock.
4. `_judge_refresh_token` (the four verdicts).
5. Error mapping: every exception type → status, code, shape.
6. The integration scenarios above, using `httpx` against a disposable MySQL (for example a Compose service).

---

## 23. Troubleshooting

| Symptom | Cause and fix |
| --- | --- |
| Start-up fails with `'cryptography' package is required for sha256_password or caching_sha2_password auth methods` | MySQL 8's default login needs the `cryptography` package. It is pinned in `requirements.txt`; run `pip install -r requirements.txt` in the active environment. |
| `Field required` errors for `DB_USER`, `JWT_SECRET`, ... at start-up | There is no `.env` in the **current directory** (run Uvicorn from the project root), or the variables are not set. Copy `.env.example` to `.env`. |
| `SUPER_ADMIN_PASSWORD_HASH must be a bcrypt hash` | The `$` in the hash was interpreted by the shell or Compose. Wrap it in **single quotes** in `.env` (section 4.3). |
| `Required role(s) missing or inactive ... Load database/seed.sql` | The seed was not loaded: `mysql -u root -p < database/seed.sql`. |
| `SUPER_ADMIN_EMAIL is already used by user N` | A live account already has that e-mail. Pick another e-mail, or delete or rename that account. |
| `Unsafe production configuration: ...` | Fix every listed item (section 4.2). |
| `user_id 1 ... must not have rows in: ...` | Someone created a password, role or security-profile row for the super admin. Delete those rows. |
| Browser: `403 CORS_ORIGIN_NOT_ALLOWED` | Add the exact origin (scheme + host + port, no trailing slash) to `CORS_ORIGINS`. |
| The browser does not send the refresh cookie | Use `credentials: "include"`; list the origin in `CORS_ORIGINS`; on plain `http://` keep `REFRESH_COOKIE_SECURE=false`; the cookie is only sent to `/api/v1/auth/*`; for a different *site* use `SameSite=none` + `Secure`. |
| `429 RATE_LIMITED` while developing | Wait for `Retry-After`, restart the app (counters are in memory), or set `RATE_LIMIT_ENABLED=false`. Note all login attempts count, not only failures. |
| The super admin is signed out after every restart | By design (section 7.7). |
| A user is suddenly signed out everywhere | Refresh-token **reuse detection**: two refreshes with the same cookie (two tabs, a retry). Share a single in-flight refresh (section 7.6). Look for the `Refresh token reuse detected` warning in the log. |
| `401 TOKEN_INVALID` right after changing the password | Expected: older access tokens are rejected. Use the new tokens from the `change-password` response. |
| `422` with "The request body must be a JSON object ..." | Send `Content-Type: application/json` (a bare `curl -d` does not). |
| `503 SERVICE_UNAVAILABLE` | The database is down, a deadlock/lock timeout occurred, or the pool is exhausted. Check `/health/ready` and the logs; adjust `DB_POOL_MAX_SIZE`. It recovers by itself once MySQL is back. |
| `Access denied`, `Can't connect to MySQL` | Check `DB_HOST`, `DB_USER`, `DB_PASSWORD`. In Docker the host is `db`. The DB user needs `SELECT, INSERT, UPDATE, DELETE` on `fastapi_backend_baseline.*`. |
| Docker: the SQL files did not run | MySQL loads them only for an **empty** data volume. `docker compose down -v` and start again. |
| `500 INTERNAL_ERROR` | Take the `requestId` from the response and search the logs for it; the stack trace is there. |
| `/docs` returns 404 | Production hides the docs (`APP_ENV=production`). |
| `401 TOKEN_INVALID` for tokens that are brand new, across several servers | Clock skew above 10 seconds between servers (a token looks like it comes from the future). Synchronise clocks (NTP). |

---

## Appendix A. Glossary

| Term | Meaning |
| --- | --- |
| **Access token** | Short-lived (15 min) signed JWT that proves who you are on each call. Carries no role. |
| **Refresh token** | Long-lived (7 days) opaque secret in an `httpOnly` cookie, used only to get a new access token. |
| **Rotation** | Every use of a refresh token replaces it with a new one. |
| **Reuse detection** | Presenting an already-rotated refresh token is treated as theft and ends all of the user's sessions. |
| **Authentication / authorization** | Who are you? / What may you do? |
| **Route-level / instance-level authorization** | May this *role* call this endpoint? / May this *actor* act on that *target*? |
| **Soft delete** | The row is marked `is_deleted` instead of being removed; history stays. |
| **Pepper** | A secret kept outside the database and mixed into a hash (unlike a salt, which is stored with it). |
| **Request context store** | Per-request data (id, IP, user) readable anywhere without passing it as an argument. |
| **Pure ASGI middleware** | A middleware written directly against the ASGI interface (fast, keeps context variables intact). |
| **Idempotent** | Safe to run more than once with the same result (the seeds, logout). |
